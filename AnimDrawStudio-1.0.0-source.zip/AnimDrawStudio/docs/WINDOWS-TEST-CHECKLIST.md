# Windows test checklist

The drawing engine has 250 automated tests. The Windows program itself (the window, the mouse, the pen, the dialogs, the
installer) has **never been run by the people who wrote it**, so it needs a first test on a real Windows PC. This list is
ordered so that the problems that matter most show up first. Allow about 30 to 45 minutes. Tick the boxes as you go and
write down anything that does not match the "Expect" text.

If something goes wrong, the error reports are in `%APPDATA%\AnimDraw Studio\logs` (open them with Notepad). Note the
step number, what you did, what you expected and what happened, and keep the newest report file.

## 0. Build

- [ ] Install the .NET 8 SDK. In the folder with `AnimDrawStudio.sln` run `publish.cmd`.
  Expect: it ends with "Done." and `publish\win-x64\AnimDrawStudio.exe` exists. Tests pass in the middle of the output
  (`Passed: 250   Failed: 0`).
- [ ] If anything fails, copy the last 30 lines of the output. The usual causes are no internet on the first restore and
  a missing .NET 8 **SDK** (the runtime alone is not enough).
- [ ] Optional: `publish.cmd -Zip -Installer` (Inno Setup 6.3+ installed). Expect `dist\` to hold a zip and a setup exe.

## 1. Start-up (the most important check)

- [ ] Double-click `AnimDrawStudio.exe`. Expect: a dark window with a menu bar, a tool column on the left, a white canvas
  in the middle, Layers and Colour panels on the right, a timeline at the bottom and a status bar. No error box.
  (The first start of a single-file exe can take a few seconds.)
- [ ] All icons in the toolbar, layer panel and timeline are visible (no empty squares). Hover a few: tooltips appear.
- [ ] Open each of the 8 menus (File, Edit, View, Drawing, Animation, Layer, Export, Help). Expect: entries with shortcuts
  shown on the right, greyed-out entries that make sense (for example Undo and Redo are grey in a new project, and
  Deselect and Duplicate Selection are grey until something is selected).
- [ ] *View > Theme > Light*, then back to *Dark*. Expect: the whole window changes at once, text stays readable.
- [ ] Close the window. Expect: it closes without a question (nothing is unsaved).

## 2. Drawing

- [ ] Draw a few strokes with the **Brush** (B). Expect: smooth lines, no lag, no gaps. Change the size and opacity in the
  bar above the canvas, draw again.
- [ ] **Undo** (Ctrl+Z) and **Redo** (Ctrl+Y) several times. Expect: strokes disappear and come back in order. The Edit menu
  names the step ("Undo Brush Stroke" or similar).
- [ ] **Pencil** (P) with *Snap to pixels*: zoom in (mouse wheel) and check the lines are made of whole square pixels.
- [ ] **Eraser** (E). Expect: it removes paint; on a transparent background it leaves transparency.
- [ ] **Line, Rectangle, Ellipse** (L, R, O): drag. Hold Shift (straight line, square, circle) and Alt (from the centre).
  Try Outline, Filled, Outline and fill.
- [ ] **Fill** (G): click inside a closed shape. Expect: it fills the inside only. Try Tolerance and Contiguous.
- [ ] **Eyedropper** (I): click a colour. Expect: the primary colour changes. Right-click sets the second colour.
- [ ] **Select** (M): drag a rectangle, then Ctrl+C, Ctrl+V. Expect: the copy appears in the middle of the view, selected, and the
  **Move** tool (V) switches on by itself so you can drag it. Try Ctrl+X, Ctrl+Shift+V (paste in place), Ctrl+D (duplicate), Del (clear the
  selection), and undo after each.
- [ ] Copy a piece, switch to another program (Paint, Word) and paste. Expect: the picture appears there.
  Copy a picture in another program and paste here (Ctrl+V). Expect: it appears on the canvas.
- [ ] Zoom with the wheel, pan with Space+drag, middle mouse button and the Hand tool (H). Ctrl+0 (fit), Ctrl+1 (100%).
- [ ] *Colour panel*: change the colour with the square, the hue bar, the hex box; save a colour in "My colours"; X swaps
  the two colours.

## 3. Layers

- [ ] Add 3 layers (Ctrl+Shift+N). Draw something different on each. Hide one (eye), lock one (padlock) and try to draw on
  it. Expect: the hidden one disappears, the locked one refuses to be drawn on with a message.
- [ ] Rename (double-click the name or F2), reorder by dragging and with Ctrl+[ / Ctrl+], change the opacity slider,
  duplicate (Ctrl+J), merge down (Ctrl+Shift+M), delete (Ctrl+Shift+Del). Undo each.
- [ ] Expect: the small picture on each layer row matches the drawing.

## 4. Frames, playback and onion skin

- [ ] Press F5 four times, drawing something slightly different on each frame (a ball moving, for example).
- [ ] Press Enter. Expect: the animation plays at the frame rate shown in the timeline (FPS box), the window stays
  responsive, Enter pauses, Shift+Enter stops and returns to the start frame. Try Loop (Ctrl+L), and changing the FPS while
  stopped.
- [ ] Home / End / comma / period move between frames; the frame number is shown.
- [ ] Turn on Onion skin (Shift+O) and draw on frame 3. Expect: frames 2 and 4 show faintly. Open *Animation > Onion Skin
  Settings* and change the strength and the number of frames.
- [ ] F6 / F7 make keyframes; Shift+F6 removes one; Shift+comma / Shift+period jump between keyframes.
  Add a background layer, draw on it in frame 1 only, then press F5 on another layer: the background stays visible in the
  new frames (it is held).
- [ ] *View > Preview Window* (Ctrl+P). Expect: a separate window plays the animation. Try the speed slider, zoom, scrubber,
  and edit in the main window while it is open (the preview refreshes a moment later).

## 5. Saving, opening and not losing work

- [ ] Ctrl+S: choose a name. Expect: the title shows the name, the status bar says saved. Make a change: the title shows
  it is unsaved.
- [ ] Close the window with unsaved changes. Expect: "Save changes?" with Save / Don't save / Cancel; Cancel keeps the
  program open.
- [ ] Reopen with Ctrl+O. Expect: every layer and frame is as you left it. *File > Open Recent* lists the file.
- [ ] Drag the `.animdraw` file onto the open window and onto the exe icon. Expect: it opens.
- [ ] **Crash recovery:** draw something, wait for the autosave time (default 2 minutes, or set it to 1 in Preferences),
  then end the program with Task Manager (End task). Start it again. Expect: a "Recover unsaved work" window; Recover
  opens your drawing as a new, unsaved project.
- [ ] Save As (Ctrl+Shift+S) onto an existing file. Expect: a question about replacing it.

## 6. Export

For each, open *Export* (Ctrl+E), look at the summary under the options, export, and open the result.

- [ ] **GIF** with 4+ frames. Open it in a web browser. Expect: it animates at the chosen speed and loops. Try
  transparent background on a project with a transparent background.
- [ ] **PNG image** (one frame), **PNG sequence** (a folder of numbered files) and **Sprite sheet** (one PNG and a `.json`).
- [ ] **MP4 without FFmpeg**: Expect a clear explanation, a Browse button and a download link; no crash. The other formats
  still work.
- [ ] **MP4 with FFmpeg**: download a Windows FFmpeg build, point the dialog (or *Preferences*) at `ffmpeg.exe`. Export.
  Expect: a video that plays in Windows Media Player or the Films & TV app.
- [ ] While an export runs, press Cancel. Expect: it stops, and the window says it was cancelled. Close the dialog with
  the X while it runs. Expect: the same.
- [ ] Export onto an existing file. Expect: a question before replacing it.

## 7. Extra hardware and screens

- [ ] **Pen tablet** (if you have one): draw with the pen. Expect: lines get thicker with pressure (the "Pen pressure: size"
  box is on by default for the brush). Try "opacity". Use the eraser end of the pen. If pressure does not work, say which
  tablet and driver you use (Wacom, Huion, Surface Pen...). Note: *Windows Ink* settings in the tablet driver can matter.
- [ ] **High-DPI**: set *Settings > Display > Scale* to 150% and then 200%, restart the program. Expect: crisp text and
  icons, the canvas still lines up with the pointer when drawing. Move the window between two monitors with different
  scaling, if you have them.
- [ ] **Big canvas**: *File > New* with 3840 × 2160, then 8192 × 4320 (a warning appears). Draw, undo, play 10 frames, export a
  GIF. Expect: usable speed on 4K; note the memory use in Task Manager and the time for the export.

## 8. Installer (only if you built it)

- [ ] Run `AnimDrawStudio-Setup-1.0.0.exe`. Expect: installs without asking for administrator rights (the default is
  for the current user), a Start menu entry appears, the program starts at the end.
- [ ] Double-click a `.animdraw` file (if you ticked the file-type option). Expect: it opens in AnimDraw Studio.
- [ ] Uninstall from *Settings > Apps*. Expect: the program is removed; your settings and recovery folders stay.

## What to send back

For each failure: the step number, a screenshot if it is about looks, the newest file from
`%APPDATA%\AnimDraw Studio\logs`, and your Windows version (Win + R, type `winver`).
