<#
.SYNOPSIS
    Builds AnimDraw Studio into a program that runs on any Windows 10/11 PC without installing .NET.

.DESCRIPTION
    Steps: check the .NET SDK, restore, build (Release), run the engine tests, publish AnimDrawStudio.exe as ONE
    self-contained file, and optionally make a zip file and an installer.

    Run it from the folder that contains AnimDrawStudio.sln (or double-click publish.cmd):

        powershell -ExecutionPolicy Bypass -File .\publish.ps1

    The program is written to .\publish\win-x64\AnimDrawStudio.exe, the zip file and installer to .\dist\.
    The first run needs an internet connection: NuGet downloads the .NET runtime that gets packed into the exe.

.PARAMETER Runtime
    win-x64 (default) or win-arm64.

.PARAMETER SkipTests
    Do not run the engine tests before publishing.

.PARAMETER FrameworkDependent
    Make a small build (a few MB) that needs the ".NET 8 Desktop Runtime" to be installed on the PC.

.PARAMETER ReadyToRun
    Pre-compile the program for a faster start (bigger file; downloads one more package from NuGet).

.PARAMETER Zip
    Also create dist\AnimDrawStudio-<version>-<runtime>.zip.

.PARAMETER Installer
    Also create dist\AnimDrawStudio-Setup-<version>.exe with Inno Setup 6.3 or newer (https://jrsoftware.org/isdl.php).

.PARAMETER FfmpegExe
    Optional path to ffmpeg.exe. It is copied to an "ffmpeg" folder beside the program so that MP4 export works out of
    the box. Read the FFmpeg licence (https://ffmpeg.org/legal.html) before you give such a package to other people.

.EXAMPLE
    .\publish.ps1 -Zip -Installer
#>
[CmdletBinding()]
param(
    [ValidateSet('win-x64', 'win-arm64')]
    [string] $Runtime = 'win-x64',
    [switch] $SkipTests,
    [switch] $FrameworkDependent,
    [switch] $ReadyToRun,
    [switch] $Zip,
    [switch] $Installer,
    [string] $FfmpegExe
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$root     = $PSScriptRoot
$solution = Join-Path $root 'AnimDrawStudio.sln'
$app      = Join-Path $root 'src\AnimDraw.App\AnimDraw.App.csproj'
$tests    = Join-Path $root 'tests\AnimDraw.Core.Tests\AnimDraw.Core.Tests.csproj'
$outDir   = Join-Path $root "publish\$Runtime"
$distDir  = Join-Path $root 'dist'

function Write-Step([string] $text) {
    Write-Host ''
    Write-Host "==> $text" -ForegroundColor Cyan
}

function Invoke-Dotnet([string[]] $Arguments) {
    Write-Host ("dotnet " + ($Arguments -join ' ')) -ForegroundColor DarkGray
    & dotnet @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "dotnet $($Arguments[0]) failed (exit code $LASTEXITCODE). The messages above say why."
    }
}

if (-not (Test-Path $solution)) {
    throw 'AnimDrawStudio.sln was not found. Run this script from the folder that contains it.'
}
if ($Installer -and $Runtime -ne 'win-x64') {
    throw 'The installer script is made for win-x64 only. Leave out -Installer, or use -Runtime win-x64.'
}

Write-Step 'Checking the .NET SDK'
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw 'The .NET SDK was not found. Install the .NET 8 SDK from https://dotnet.microsoft.com/download and run this script again.'
}
$sdk = (& dotnet --version | Select-Object -First 1).Trim()
$sdkMajor = [int]($sdk.Split('.')[0])
if ($sdkMajor -lt 8) {
    throw "The .NET SDK $sdk is too old. Install the .NET 8 SDK (or a newer one)."
}
Write-Host ".NET SDK $sdk"

$version = '1.0.0'
$versionNode = Select-Xml -Path (Join-Path $root 'Directory.Build.props') -XPath '//Version' | Select-Object -First 1
if ($versionNode) { $version = $versionNode.Node.InnerText.Trim() }
Write-Host "AnimDraw Studio version $version, target $Runtime"

Write-Step 'Cleaning the previous output'
if (Test-Path $outDir) { Remove-Item -Recurse -Force $outDir }
New-Item -ItemType Directory -Force -Path $outDir, $distDir | Out-Null

Write-Step 'Restoring packages'
Invoke-Dotnet @('restore', $solution, '--nologo')

Write-Step 'Building the solution (Release)'
Invoke-Dotnet @('build', $solution, '-c', 'Release', '--no-restore', '--nologo')

if ($SkipTests) {
    Write-Host 'Skipping the engine tests (-SkipTests).'
}
else {
    Write-Step 'Running the engine tests'
    Invoke-Dotnet @('run', '--project', $tests, '-c', 'Release', '--no-build', '--nologo')
}

Write-Step "Publishing AnimDrawStudio.exe ($Runtime)"
$publishArgs = @('publish', $app, '-c', 'Release', '-r', $Runtime, '-o', $outDir, '--nologo',
                 '-p:DebugType=none', '-p:DebugSymbols=false')
if ($FrameworkDependent) {
    $publishArgs += @('--self-contained', 'false')
}
else {
    # One exe with the .NET runtime inside. Trimming is NOT used: WPF does not support it.
    $publishArgs += @('--self-contained', 'true', '-p:PublishSingleFile=true',
                      '-p:IncludeNativeLibrariesForSelfExtract=true', '-p:EnableCompressionInSingleFile=true')
    if ($ReadyToRun) { $publishArgs += '-p:PublishReadyToRun=true' }
}
Invoke-Dotnet $publishArgs

if ($FfmpegExe) {
    Write-Step 'Adding FFmpeg'
    if (-not (Test-Path $FfmpegExe -PathType Leaf)) { throw "ffmpeg.exe was not found at: $FfmpegExe" }
    $ffmpegDir = Join-Path $outDir 'ffmpeg'
    New-Item -ItemType Directory -Force -Path $ffmpegDir | Out-Null
    Copy-Item -LiteralPath $FfmpegExe -Destination (Join-Path $ffmpegDir 'ffmpeg.exe') -Force
    Write-Host 'Copied ffmpeg.exe. Check the FFmpeg licence before you give this package to other people.' -ForegroundColor Yellow
}

$exe = Join-Path $outDir 'AnimDrawStudio.exe'
if (-not (Test-Path $exe)) { throw "The publish step did not create $exe." }
$sizeMb = [math]::Round((Get-Item $exe).Length / 1MB, 1)
Write-Host "Created $exe ($sizeMb MB)" -ForegroundColor Green

$zipPath = $null
if ($Zip) {
    Write-Step 'Creating the zip file'
    $zipPath = Join-Path $distDir "AnimDrawStudio-$version-$Runtime.zip"
    if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
    Compress-Archive -Path (Join-Path $outDir '*') -DestinationPath $zipPath
    Write-Host "Created $zipPath" -ForegroundColor Green
}

$setupPath = $null
if ($Installer) {
    Write-Step 'Creating the installer (Inno Setup)'
    $candidates = @(
        (Get-Command iscc -ErrorAction SilentlyContinue | ForEach-Object { $_.Source }),
        (Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe'),
        (Join-Path $env:ProgramFiles 'Inno Setup 6\ISCC.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Inno Setup 6\ISCC.exe')
    ) | Where-Object { $_ -and (Test-Path $_) }
    $iscc = $candidates | Select-Object -First 1
    if (-not $iscc) {
        throw 'Inno Setup was not found. Install version 6.3 or newer from https://jrsoftware.org/isdl.php and run this again, or leave out -Installer.'
    }
    & $iscc "/DAppVersion=$version" "/DPublishDir=$outDir" "/DOutputDir=$distDir" (Join-Path $root 'installer\AnimDrawStudio.iss')
    if ($LASTEXITCODE -ne 0) { throw "Inno Setup failed (exit code $LASTEXITCODE). The messages above say why." }
    $setupPath = Join-Path $distDir "AnimDrawStudio-Setup-$version.exe"
}

Write-Host ''
Write-Host 'Done.' -ForegroundColor Green
Write-Host "  Program:   $exe"
if ($zipPath)   { Write-Host "  Zip file:  $zipPath" }
if ($setupPath) { Write-Host "  Installer: $setupPath" }
