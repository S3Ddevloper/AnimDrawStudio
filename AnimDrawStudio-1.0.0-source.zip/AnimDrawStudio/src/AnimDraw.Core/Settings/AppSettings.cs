namespace AnimDraw.Core.Settings;

public enum AppTheme
{
    Dark,
    Light
}

public sealed class WindowPlacement
{
    public double Left { get; set; } = double.NaN;
    public double Top { get; set; } = double.NaN;
    public double Width { get; set; } = 1360;
    public double Height { get; set; } = 860;
    public bool Maximized { get; set; }
}

/// <summary>Everything remembered between runs. Saved as JSON; every value has a safe default.</summary>
public sealed class AppSettings
{
    public const int MaxRecentProjects = 12;
    public const int MaxRecentColors = 16;
    public const int MaxCustomColors = 32;

    public AppTheme Theme { get; set; } = AppTheme.Dark;

    public List<string> RecentProjects { get; set; } = new();
    public List<string> RecentColors { get; set; } = new();

    /// <summary>Colours the user saved on purpose in the colour panel.</summary>
    public List<string> CustomColors { get; set; } = new();

    /// <summary>Ask before deleting layers or frames and before clearing the canvas.</summary>
    public bool ConfirmDestructive { get; set; } = true;

    // New-project defaults
    public int NewProjectWidth { get; set; } = 1280;
    public int NewProjectHeight { get; set; } = 720;
    public double NewProjectFps { get; set; } = 12;
    public string NewProjectBackground { get; set; } = "White";

    public int AutosaveMinutes { get; set; } = 2;
    public bool AutoKeyframe { get; set; } = true;
    public bool ShowPixelGrid { get; set; }

    public string? FfmpegPath { get; set; }
    public string? LastProjectFolder { get; set; }
    public string? LastExportFolder { get; set; }

    public double RightPanelWidth { get; set; } = 270;
    public double TimelineHeight { get; set; } = 230;

    public WindowPlacement Window { get; set; } = new();

    // Last-used tool options
    public double BrushSize { get; set; } = 12;
    public double BrushOpacity { get; set; } = 1.0;
    public double BrushHardness { get; set; } = 0.85;
    public string PrimaryColor { get; set; } = "#000000";
    public string SecondaryColor { get; set; } = "#FFFFFF";

    /// <summary>Clamps values loaded from a hand-edited or damaged file back into sensible ranges.</summary>
    public void Normalize()
    {
        RecentProjects = (RecentProjects ?? new()).Where(p => !string.IsNullOrWhiteSpace(p)).Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(MaxRecentProjects).ToList();
        RecentColors = (RecentColors ?? new()).Where(c => !string.IsNullOrWhiteSpace(c)).Take(MaxRecentColors).ToList();
        CustomColors = (CustomColors ?? new()).Where(c => !string.IsNullOrWhiteSpace(c)).Distinct(StringComparer.OrdinalIgnoreCase).Take(MaxCustomColors).ToList();
        NewProjectWidth = Math.Clamp(NewProjectWidth, 1, Model.ProjectLimits.MaxDimension);
        NewProjectHeight = Math.Clamp(NewProjectHeight, 1, Model.ProjectLimits.MaxDimension);
        if (!Model.ProjectLimits.IsValidSize(NewProjectWidth, NewProjectHeight, out _))
        {
            // Each side is allowed on its own, but together they hold more pixels than the program can handle
            // (only possible in a hand-edited file). Starting up must never fail because of that.
            NewProjectWidth = 1280;
            NewProjectHeight = 720;
        }
        NewProjectFps = Model.ProjectLimits.ClampFps(NewProjectFps);
        AutosaveMinutes = Math.Clamp(AutosaveMinutes, 0, 60);
        RightPanelWidth = double.IsNaN(RightPanelWidth) ? 270 : Math.Clamp(RightPanelWidth, 200, 600);
        TimelineHeight = double.IsNaN(TimelineHeight) ? 230 : Math.Clamp(TimelineHeight, 120, 600);
        BrushSize = double.IsNaN(BrushSize) ? 12 : Math.Clamp(BrushSize, 1, 500);
        BrushOpacity = double.IsNaN(BrushOpacity) ? 1 : Math.Clamp(BrushOpacity, 0.01, 1);
        BrushHardness = double.IsNaN(BrushHardness) ? 0.85 : Math.Clamp(BrushHardness, 0, 1);
        Window ??= new WindowPlacement();
        Window.Width = double.IsNaN(Window.Width) ? 1360 : Math.Clamp(Window.Width, 640, 10000);
        Window.Height = double.IsNaN(Window.Height) ? 860 : Math.Clamp(Window.Height, 480, 10000);
    }
}
