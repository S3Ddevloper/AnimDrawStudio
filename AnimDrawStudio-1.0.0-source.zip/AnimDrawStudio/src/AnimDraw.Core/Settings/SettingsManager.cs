using System.Text.Json;
using System.Text.Json.Serialization;

namespace AnimDraw.Core.Settings;

/// <summary>Loads and saves <see cref="AppSettings"/> and keeps the recent-projects list.</summary>
public sealed class SettingsManager
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
        Converters = { new JsonStringEnumConverter() },
        NumberHandling = JsonNumberHandling.AllowNamedFloatingPointLiterals | JsonNumberHandling.AllowReadingFromString
    };

    private readonly string _path;
    private readonly object _lock = new();

    public const string AppFolderName = "AnimDraw Studio";

    /// <summary>The per-user folder used for settings (and recovery files, unless told otherwise).</summary>
    public static string DefaultDataFolder => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), AppFolderName);

    public static string DefaultRecoveryFolder => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), AppFolderName, "Recovery");

    public SettingsManager(string? folder = null)
    {
        Folder = folder ?? DefaultDataFolder;
        _path = Path.Combine(Folder, "settings.json");
    }

    public string Folder { get; }
    public string FilePath => _path;
    public AppSettings Settings { get; private set; } = new();

    /// <summary>Set when the settings file existed but could not be read (it is then replaced by defaults on the next save).</summary>
    public string? LoadProblem { get; private set; }

    public event Action? Changed;

    public AppSettings Load()
    {
        lock (_lock)
        {
            LoadProblem = null;
            try
            {
                if (File.Exists(_path))
                {
                    using var fs = new FileStream(_path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    var loaded = JsonSerializer.Deserialize<AppSettings>(fs, JsonOptions);
                    Settings = loaded ?? new AppSettings();
                }
                else Settings = new AppSettings();
            }
            catch (Exception ex) when (ex is JsonException or IOException or UnauthorizedAccessException or NotSupportedException)
            {
                LoadProblem = "The settings file could not be read, so defaults are being used. " + ex.Message;
                TryKeepBrokenCopy();
                Settings = new AppSettings();
            }
            Settings.Normalize();
            return Settings;
        }
    }

    /// <summary>Writes the settings. Failure is reported through the return value, never an exception.</summary>
    public bool Save(out string? error)
    {
        lock (_lock)
        {
            error = null;
            string? temp = null;
            try
            {
                Settings.Normalize();
                Directory.CreateDirectory(Folder);
                temp = _path + "." + Guid.NewGuid().ToString("N")[..8] + ".tmp";
                using (var fs = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    JsonSerializer.Serialize(fs, Settings, JsonOptions);
                if (File.Exists(_path)) File.Replace(temp, _path, null);
                else File.Move(temp, _path);
                temp = null;
                return true;
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException)
            {
                error = "Your settings could not be saved: " + ex.Message;
                return false;
            }
            finally
            {
                if (temp != null)
                {
                    try { File.Delete(temp); } catch (Exception) { }
                }
            }
        }
    }

    private void TryKeepBrokenCopy()
    {
        try
        {
            if (File.Exists(_path)) File.Copy(_path, _path + ".broken", overwrite: true);
        }
        catch (Exception) { }
    }

    // ----- recent projects -----

    /// <summary>Moves a project to the top of the recent list.</summary>
    public void AddRecent(string path)
    {
        if (string.IsNullOrWhiteSpace(path)) return;
        string full;
        try { full = Path.GetFullPath(path); } catch (Exception) { return; }
        lock (_lock)
        {
            Settings.RecentProjects.RemoveAll(p => string.Equals(p, full, StringComparison.OrdinalIgnoreCase));
            Settings.RecentProjects.Insert(0, full);
            if (Settings.RecentProjects.Count > AppSettings.MaxRecentProjects)
                Settings.RecentProjects.RemoveRange(AppSettings.MaxRecentProjects, Settings.RecentProjects.Count - AppSettings.MaxRecentProjects);
            Settings.LastProjectFolder = Path.GetDirectoryName(full);
        }
        Changed?.Invoke();
    }

    public void RemoveRecent(string path)
    {
        lock (_lock) Settings.RecentProjects.RemoveAll(p => string.Equals(p, path, StringComparison.OrdinalIgnoreCase));
        Changed?.Invoke();
    }

    public void ClearRecent()
    {
        lock (_lock) Settings.RecentProjects.Clear();
        Changed?.Invoke();
    }

    /// <summary>The recent list without files that no longer exist. Asks the file system about every entry, which can be slow for network drives.</summary>
    public IReadOnlyList<string> GetRecentExisting()
    {
        lock (_lock) return Settings.RecentProjects.Where(File.Exists).ToList();
    }

    /// <summary>The recent list as it is remembered, without touching the file system (safe to call while a menu opens).</summary>
    public IReadOnlyList<string> GetRecent()
    {
        lock (_lock) return Settings.RecentProjects.ToList();
    }

    public void AddRecentColor(string hex)
    {
        if (string.IsNullOrWhiteSpace(hex)) return;
        lock (_lock)
        {
            Settings.RecentColors.RemoveAll(c => string.Equals(c, hex, StringComparison.OrdinalIgnoreCase));
            Settings.RecentColors.Insert(0, hex);
            if (Settings.RecentColors.Count > AppSettings.MaxRecentColors)
                Settings.RecentColors.RemoveRange(AppSettings.MaxRecentColors, Settings.RecentColors.Count - AppSettings.MaxRecentColors);
        }
        Changed?.Invoke();
    }

    /// <summary>Saves a colour in the user's own palette. Returns false when it is already there or the palette is full.</summary>
    public bool AddCustomColor(string hex)
    {
        if (string.IsNullOrWhiteSpace(hex)) return false;
        lock (_lock)
        {
            if (Settings.CustomColors.Any(c => string.Equals(c, hex, StringComparison.OrdinalIgnoreCase))) return false;
            if (Settings.CustomColors.Count >= AppSettings.MaxCustomColors) return false;
            Settings.CustomColors.Add(hex);
        }
        Changed?.Invoke();
        return true;
    }

    public void RemoveCustomColor(string hex)
    {
        lock (_lock) Settings.CustomColors.RemoveAll(c => string.Equals(c, hex, StringComparison.OrdinalIgnoreCase));
        Changed?.Invoke();
    }
}
