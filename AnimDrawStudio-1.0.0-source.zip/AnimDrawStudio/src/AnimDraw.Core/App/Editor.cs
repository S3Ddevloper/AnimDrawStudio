using AnimDraw.Core.Animation;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.IO;
using AnimDraw.Core.Model;
using AnimDraw.Core.Rendering;
using AnimDraw.Core.Settings;
using AnimDraw.Core.Tools;

namespace AnimDraw.Core.App;

/// <summary>Artwork that was copied inside AnimDraw Studio. The id lets the window tell it apart from other pictures on the system clipboard.</summary>
public sealed class PixelClipboard
{
    public Guid Id { get; private set; } = Guid.Empty;
    public PixelBuffer? Image { get; private set; }

    /// <summary>Where the artwork was on the canvas when it was copied.</summary>
    public IntRect Origin { get; private set; }

    public bool HasImage => Image != null;

    public void Set(PixelBuffer image, IntRect origin)
    {
        Image = image;
        Origin = origin;
        Id = Guid.NewGuid();
    }

    public void Clear()
    {
        Image = null;
        Origin = IntRect.Empty;
        Id = Guid.Empty;
    }
}

/// <summary>What one playback tick produced.</summary>
public readonly record struct PlaybackTick(bool FrameChanged, int Frame, PixelBuffer? Image);

/// <summary>
/// Everything the main window needs besides drawing itself: the open document and its file, the tools and their settings,
/// copy and paste, autosave and recovery, and playback. The window only displays this and forwards what the user does,
/// which keeps the behaviour testable without a screen.
/// </summary>
public sealed class Editor : IDisposable
{
    private readonly ToolContext _toolContext;
    private FrameCache? _cache;
    private long _cacheContentVersion = -1;
    private long _cacheStructureVersion = -1;

    public Editor(SettingsManager settingsManager, RecoveryManager? recovery = null, PlaybackEngine? playback = null)
    {
        SettingsManager = settingsManager;
        Recovery = recovery ?? new RecoveryManager(SettingsManager.DefaultRecoveryFolder);
        Playback = playback ?? new PlaybackEngine();

        var s = Settings;
        Document = CreateDocument(s.NewProjectWidth, s.NewProjectHeight, s.NewProjectFps, ParseBackground(s.NewProjectBackground));

        var toolSettings = new ToolSettings();
        _toolContext = new ToolContext(Document, toolSettings)
        {
            Notify = msg => Status?.Invoke(msg),
            ColorPicked = OnColorPicked
        };
        Tools = new ToolManager(_toolContext);
        ApplySettingsToTools();
    }

    // ----- state -----

    public SettingsManager SettingsManager { get; }
    public AppSettings Settings => SettingsManager.Settings;
    public RecoveryManager Recovery { get; }
    public ToolManager Tools { get; }
    public ToolSettings ToolSettings => Tools.Settings;
    public PlaybackEngine Playback { get; }
    public PixelClipboard Clipboard { get; } = new();

    public Document Document { get; private set; }

    /// <summary>Where the project is saved, or null for a project that was never saved.</summary>
    public string? FilePath { get; private set; }

    /// <summary>The project's name for titles and messages.</summary>
    public string DisplayName => FilePath != null ? Path.GetFileNameWithoutExtension(FilePath) : "Untitled";

    public bool IsDirty => Document.IsDirty;

    /// <summary>A different project was opened or created. Views must connect to <see cref="Document"/> again.</summary>
    public event Action? DocumentReplaced;

    /// <summary>The file name or its saved state changed (window title).</summary>
    public event Action? FileStateChanged;

    /// <summary>A short message for the status bar.</summary>
    public event Action<string>? Status;

    public void Say(string message) => Status?.Invoke(message);

    // ----- new / open / save -----

    public static BackgroundSettings ParseBackground(string? text)
    {
        if (string.Equals(text, "Transparent", StringComparison.OrdinalIgnoreCase)) return BackgroundSettings.Transparent;
        if (string.IsNullOrWhiteSpace(text) || string.Equals(text, "White", StringComparison.OrdinalIgnoreCase)) return BackgroundSettings.White;
        return ArgbColor.TryParse(text, out var c) ? BackgroundSettings.Custom(c) : BackgroundSettings.White;
    }

    public static string BackgroundToText(BackgroundSettings bg) => bg.Mode switch
    {
        BackgroundMode.White => "White",
        BackgroundMode.Transparent => "Transparent",
        _ => bg.Color.WithAlpha(255).ToHex()
    };

    private Document CreateDocument(int width, int height, double fps, BackgroundSettings background)
    {
        var project = Project.CreateNew(width, height, fps, background);
        var doc = new Document(project) { AutoKeyframe = Settings.AutoKeyframe };
        doc.MarkSaved();
        return doc;
    }

    /// <summary>Starts a new, empty project. Throws <see cref="ArgumentOutOfRangeException"/> for an impossible size.</summary>
    public void NewProject(int width, int height, double fps, BackgroundSettings background)
    {
        var doc = CreateDocument(width, height, fps, background);
        Adopt(doc, null);
        Say($"New project {width} x {height} px, {ProjectLimits.ClampFps(fps):0.##} fps");
    }

    /// <summary>Opens a project file. Throws <see cref="ProjectFileException"/> with a message fit for the user.</summary>
    public async Task OpenAsync(string path, IProgress<double>? progress = null, CancellationToken ct = default)
    {
        var doc = await ProjectFileManager.OpenAsync(path, progress, ct).ConfigureAwait(true);
        doc.AutoKeyframe = Settings.AutoKeyframe;
        string full = Path.GetFullPath(path);
        Adopt(doc, full);
        SettingsManager.AddRecent(full);
        SettingsManager.Save(out _);
        Say($"Opened {Path.GetFileName(full)}");
    }

    /// <summary>Saves to the project's own file. Call <see cref="SaveAsync(string, IProgress{double}, CancellationToken)"/> when there is none yet.</summary>
    public Task SaveAsync(IProgress<double>? progress = null, CancellationToken ct = default)
    {
        if (FilePath == null) throw new InvalidOperationException("The project has no file yet.");
        return SaveAsync(FilePath, progress, ct);
    }

    public async Task SaveAsync(string path, IProgress<double>? progress, CancellationToken ct = default)
    {
        string normalized = ProjectFileManager.NormalizePath(path);
        await ProjectFileManager.SaveAsync(Document, normalized, null, progress, ct).ConfigureAwait(true);
        string full = Path.GetFullPath(normalized);
        FilePath = full;
        SettingsManager.AddRecent(full);
        SettingsManager.Save(out _);
        Recovery.ClearCurrent();
        FileStateChanged?.Invoke();
        Say($"Saved {Path.GetFileName(full)}");
    }

    /// <summary>Opens a recovery copy as an unsaved project, so the user decides where to keep it.</summary>
    public void AdoptRecovered(LoadedProject loaded, string? originalPath)
    {
        var doc = ProjectFileManager.DocumentFrom(loaded);
        doc.AutoKeyframe = Settings.AutoKeyframe;
        Adopt(doc, null);
        Document.MarkModified();
        Say(originalPath != null
            ? $"Recovered unsaved work from \"{Path.GetFileName(originalPath)}\". Save it to keep it."
            : "Recovered unsaved work. Save it to keep it.");
    }

    private void Adopt(Document doc, string? path)
    {
        StopPlayback(syncDocument: false);
        DisposeCache();
        Document = doc;
        FilePath = path;
        Tools.SetDocument(doc);
        Recovery.ClearCurrent();
        DocumentReplaced?.Invoke();
        FileStateChanged?.Invoke();
    }

    // ----- autosave / recovery -----

    /// <summary>Writes a recovery copy when there are unsaved changes. Safe to call often; returns true when a copy was written.</summary>
    public Task<bool> AutosaveIfNeededAsync() => Recovery.AutosaveAsync(Document, FilePath, DisplayName);

    /// <summary>
    /// Writes the recovery copy now and waits for it, for the moment Windows is about to end the session and there is no
    /// time for questions. Returns true when a copy was written; false when nothing needed writing, an autosave was already
    /// running, or it did not finish within <paramref name="timeout"/>.
    /// </summary>
    public bool SaveRecoveryCopyNow(TimeSpan timeout)
    {
        var task = AutosaveIfNeededAsync();
        return task.Wait(timeout) && task.Result;
    }

    /// <summary>
    /// Set by the window when the person agreed to leave (saved, or chose not to save). Leaving with unsaved changes
    /// without that agreement (Windows logging off, a fatal error) keeps the recovery copy for the next start.
    /// </summary>
    public bool ExitApproved { get; set; }

    public IReadOnlyList<RecoveryEntry> FindRecoverable() => Recovery.FindRecoverable();

    // ----- tool settings -----

    private void OnColorPicked(ArgbColor color, bool secondary)
    {
        if (secondary) ToolSettings.SecondaryColor = color;
        else ToolSettings.PrimaryColor = color;
        ToolSettings.RaiseChanged();
        SettingsManager.AddRecentColor(color.WithAlpha(255).ToHex());
    }

    private void ApplySettingsToTools()
    {
        var s = Settings;
        var ts = ToolSettings;
        ts.Brush.Size = s.BrushSize;
        ts.Brush.Opacity = s.BrushOpacity;
        ts.Brush.Hardness = s.BrushHardness;
        ts.PrimaryColor = ArgbColor.ParseOrDefault(s.PrimaryColor, ArgbColor.Black);
        ts.SecondaryColor = ArgbColor.ParseOrDefault(s.SecondaryColor, ArgbColor.White);
        ts.Normalize();
    }

    /// <summary>Copies the tool options into the settings and writes the settings file.</summary>
    public bool PersistSettings(out string? error)
    {
        var s = Settings;
        var ts = ToolSettings;
        s.BrushSize = ts.Brush.Size;
        s.BrushOpacity = ts.Brush.Opacity;
        s.BrushHardness = ts.Brush.Hardness;
        s.PrimaryColor = ts.PrimaryColor.ToHex();
        s.SecondaryColor = ts.SecondaryColor.ToHex();
        s.AutoKeyframe = Document.AutoKeyframe;
        return SettingsManager.Save(out error);
    }

    /// <summary>Remembers a colour the user chose in the recent-colours list.</summary>
    public void RememberColor(ArgbColor color) => SettingsManager.AddRecentColor(color.WithAlpha(255).ToHex());

    // ----- copy and paste -----

    /// <summary>Copies the selection (or the whole drawing) of the active layer. Returns false when there is nothing to copy.</summary>
    public bool Copy()
    {
        var buf = Document.CopySelection();
        if (buf == null) { Say("Nothing to copy: the layer is empty here."); return false; }
        Clipboard.Set(buf, Document.Selection ?? Document.CanvasBounds);
        Say("Copied");
        return true;
    }

    public bool Cut()
    {
        if (Document.ActiveLayer.Locked) { Say($"Layer \"{Document.ActiveLayer.Name}\" is locked."); return false; }
        var region = Document.Selection ?? Document.CanvasBounds;
        if (!Document.CutSelection(out var buf) || buf == null) { Say("Nothing to cut: the layer is empty here."); return false; }
        Clipboard.Set(buf, region);
        Say("Cut");
        return true;
    }

    /// <summary>
    /// Pastes an image onto the active layer with its middle at (<paramref name="centerX"/>, <paramref name="centerY"/>),
    /// then selects it so it can be moved right away.
    /// </summary>
    public bool Paste(PixelBuffer image, int centerX, int centerY)
    {
        if (image.Width <= 0 || image.Height <= 0) return false;
        int x = centerX - image.Width / 2;
        int y = centerY - image.Height / 2;
        if (!Document.PasteBuffer(image, x, y, "Paste"))
        {
            Say(Document.ActiveLayer.Locked || !Document.ActiveLayer.Visible
                ? $"Layer \"{Document.ActiveLayer.Name}\" cannot be drawn on. Unlock or show it first."
                : "Nothing was pasted: the picture lies outside the canvas.");
            return false;
        }
        Say("Pasted");
        return true;
    }

    /// <summary>Pastes what was copied inside the program, in the place it came from.</summary>
    public bool PasteInternalInPlace()
    {
        if (Clipboard.Image == null) return false;
        return Document.PasteBuffer(Clipboard.Image, Clipboard.Origin.X, Clipboard.Origin.Y, "Paste");
    }

    // ----- playback -----

    public bool IsPlaying => Playback.State == PlaybackState.Playing;

    /// <summary>The flattened frame that playback is showing, once <see cref="StartPlayback"/> has run.</summary>
    public FrameCache? PlaybackCache => _cache;

    /// <summary>Starts playing from the current frame. The project is snapshotted, so nothing can change under the player.</summary>
    public void StartPlayback()
    {
        var doc = Document;
        doc.CommitActiveEdit();
        EnsureCache();
        Playback.FrameCount = doc.FrameCount;
        Playback.Fps = doc.Project.Fps;
        Playback.Loop = doc.Project.Loop;
        Playback.SetRange(null, null);
        Playback.Play(doc.CurrentFrame);
        _cache!.StartPrefetch(Playback.CurrentFrame, Playback.Loop);
    }

    public void TogglePlayback()
    {
        if (IsPlaying) PausePlayback(); else StartPlayback();
    }

    /// <summary>Stops where it is and makes that the frame being edited.</summary>
    public void PausePlayback()
    {
        if (Playback.State == PlaybackState.Stopped) return;
        Playback.Stop(returnToStart: false);
        FinishPlayback(Playback.CurrentFrame);
    }

    /// <summary>Stops and returns to the frame playback began from.</summary>
    public void StopPlayback(bool syncDocument = true)
    {
        if (Playback.State == PlaybackState.Stopped) return;
        Playback.Stop(returnToStart: true);
        if (syncDocument) FinishPlayback(Playback.CurrentFrame);
        else _cache?.StopPrefetch();
    }

    private void FinishPlayback(int frame)
    {
        _cache?.StopPrefetch();
        Document.GoToFrame(frame);
    }

    /// <summary>
    /// Advances playback to the current time. Never blocks: when the background thread has not finished a frame yet the
    /// previous picture stays on screen and the frame counts as dropped.
    /// </summary>
    public PlaybackTick TickPlayback()
    {
        if (Playback.State != PlaybackState.Playing) return new PlaybackTick(false, Playback.CurrentFrame, null);
        bool changed = Playback.Tick();
        if (Playback.State != PlaybackState.Playing)
        {
            // A non-looping animation reached its end.
            FinishPlayback(Playback.CurrentFrame);
            return new PlaybackTick(true, Playback.CurrentFrame, null);
        }
        if (!changed) return new PlaybackTick(false, Playback.CurrentFrame, null);
        _cache?.UpdatePlayhead(Playback.CurrentFrame);
        PixelBuffer? image = null;
        _cache?.TryGetCached(Playback.CurrentFrame, out image);
        return new PlaybackTick(true, Playback.CurrentFrame, image);
    }

    private void EnsureCache()
    {
        var doc = Document;
        if (_cache != null && _cacheContentVersion == doc.ContentVersion && _cacheStructureVersion == doc.StructureVersion) return;
        DisposeCache();
        _cache = new FrameCache(doc.CreateSnapshot(), withBackground: false);
        _cacheContentVersion = doc.ContentVersion;
        _cacheStructureVersion = doc.StructureVersion;
    }

    private void DisposeCache()
    {
        _cache?.Dispose();
        _cache = null;
        _cacheContentVersion = _cacheStructureVersion = -1;
    }

    public void Dispose()
    {
        StopPlayback(syncDocument: false);
        DisposeCache();
        Recovery.KeepFilesOnDispose = IsDirty && !ExitApproved;
        Recovery.Dispose();
    }
}
