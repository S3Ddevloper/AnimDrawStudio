using AnimDraw.Core.Geometry;

namespace AnimDraw.Core.App;

/// <summary>
/// The zoom and pan of the drawing area: converts between canvas pixels and positions in the view, and keeps the
/// canvas reachable. It knows nothing about WPF. Positions in the view are in device-independent units (the unit WPF
/// uses), while <see cref="Zoom"/> counts physical screen pixels per canvas pixel, so 100% really shows one canvas
/// pixel on one screen pixel even on a scaled (125%, 150%...) display.
/// </summary>
public sealed class Viewport
{
    public const double MinZoom = 0.02;
    public const double MaxZoom = 64.0;

    /// <summary>The longest side the zoomed canvas may reach, in view units. Keeps the renderer well inside its limits.</summary>
    public const double MaxScaledExtent = 120_000;

    /// <summary>The steps the zoom buttons and the mouse wheel move through.</summary>
    public static readonly double[] ZoomSteps =
    {
        0.02, 0.03125, 0.0625, 0.125, 0.1667, 0.25, 0.3333, 0.5, 0.6667, 0.8, 1, 1.25, 1.5, 2, 3, 4, 5, 6, 8, 12, 16, 24, 32, 48, 64
    };

    private double _zoom = 1;
    private double _dpi = 1;

    public int CanvasWidth { get; private set; } = 1;
    public int CanvasHeight { get; private set; } = 1;
    public double ViewWidth { get; private set; } = 100;
    public double ViewHeight { get; private set; } = 100;

    /// <summary>Where the canvas's top-left corner is, in view units.</summary>
    public double OffsetX { get; private set; }
    public double OffsetY { get; private set; }

    /// <summary>Physical screen pixels per canvas pixel (1 = 100%).</summary>
    public double Zoom => _zoom;

    /// <summary>Physical pixels per view unit (the display scale, for example 1.25 at 125%).</summary>
    public double DpiScale
    {
        get => _dpi;
        set
        {
            double v = double.IsNaN(value) || value < 0.25 ? 1 : Math.Min(value, 8);
            if (v == _dpi) return;
            _dpi = v;
            _zoom = Math.Clamp(_zoom, MinZoom, MaxZoomFor(CanvasWidth, CanvasHeight));
        }
    }

    /// <summary>View units that one canvas pixel occupies.</summary>
    public double Scale => _zoom / _dpi;

    /// <summary>The zoom as text, for example "125%".</summary>
    public string ZoomText => FormatZoom(_zoom);

    public static string FormatZoom(double zoom)
    {
        double pct = zoom * 100;
        return (pct >= 10 || Math.Abs(pct - Math.Round(pct)) < 0.05 ? Math.Round(pct).ToString("0") : pct.ToString("0.#")) + "%";
    }

    public double MaxZoomFor(int canvasWidth, int canvasHeight)
    {
        double longest = Math.Max(1, Math.Max(canvasWidth, canvasHeight));
        return Math.Max(MinZoom, Math.Min(MaxZoom, MaxScaledExtent * _dpi / longest));
    }

    public void SetCanvasSize(int width, int height)
    {
        CanvasWidth = Math.Max(1, width);
        CanvasHeight = Math.Max(1, height);
        _zoom = Math.Clamp(_zoom, MinZoom, MaxZoomFor(CanvasWidth, CanvasHeight));
        ClampPan();
    }

    public void SetViewSize(double width, double height)
    {
        double w = double.IsNaN(width) ? 100 : Math.Max(1, width);
        double h = double.IsNaN(height) ? 100 : Math.Max(1, height);
        if (w == ViewWidth && h == ViewHeight) return;
        // Keep the middle of the view on the same canvas point while the window is resized.
        double cx = (ViewWidth / 2 - OffsetX) / Scale;
        double cy = (ViewHeight / 2 - OffsetY) / Scale;
        ViewWidth = w;
        ViewHeight = h;
        OffsetX = w / 2 - cx * Scale;
        OffsetY = h / 2 - cy * Scale;
        ClampPan();
    }

    // ----- conversion -----

    public (double X, double Y) CanvasToView(double x, double y) => (OffsetX + x * Scale, OffsetY + y * Scale);

    public (double X, double Y) ViewToCanvas(double x, double y) => ((x - OffsetX) / Scale, (y - OffsetY) / Scale);

    /// <summary>The canvas rectangle in view units.</summary>
    public (double X, double Y, double Width, double Height) CanvasRectInView() =>
        (OffsetX, OffsetY, CanvasWidth * Scale, CanvasHeight * Scale);

    /// <summary>The part of the canvas that is inside the view, in whole canvas pixels (empty when none is visible).</summary>
    public IntRect VisibleCanvasRect()
    {
        var (x0, y0) = ViewToCanvas(0, 0);
        var (x1, y1) = ViewToCanvas(ViewWidth, ViewHeight);
        int left = (int)Math.Floor(Math.Max(0, x0));
        int top = (int)Math.Floor(Math.Max(0, y0));
        int right = (int)Math.Ceiling(Math.Min(CanvasWidth, x1));
        int bottom = (int)Math.Ceiling(Math.Min(CanvasHeight, y1));
        return right <= left || bottom <= top ? IntRect.Empty : IntRect.FromLTRB(left, top, right, bottom);
    }

    // ----- zoom -----

    /// <summary>Sets the zoom so that the canvas point under (anchorX, anchorY) stays where it is.</summary>
    public void ZoomTo(double zoom, double anchorX, double anchorY)
    {
        double z = double.IsNaN(zoom) ? _zoom : Math.Clamp(zoom, MinZoom, MaxZoomFor(CanvasWidth, CanvasHeight));
        var (cx, cy) = ViewToCanvas(anchorX, anchorY);
        _zoom = z;
        OffsetX = anchorX - cx * Scale;
        OffsetY = anchorY - cy * Scale;
        ClampPan();
    }

    /// <summary>Zooms around the middle of the view.</summary>
    public void ZoomToCenter(double zoom) => ZoomTo(zoom, ViewWidth / 2, ViewHeight / 2);

    /// <summary>Moves to the next larger (direction &gt; 0) or smaller zoom step around the given view position.</summary>
    public void ZoomStep(int direction, double anchorX, double anchorY)
    {
        ZoomTo(NextStep(_zoom, direction), anchorX, anchorY);
    }

    public static double NextStep(double zoom, int direction)
    {
        if (direction > 0)
        {
            foreach (double s in ZoomSteps) if (s > zoom * 1.0001) return s;
            return ZoomSteps[^1];
        }
        if (direction < 0)
        {
            for (int i = ZoomSteps.Length - 1; i >= 0; i--) if (ZoomSteps[i] < zoom / 1.0001) return ZoomSteps[i];
            return ZoomSteps[0];
        }
        return zoom;
    }

    /// <summary>Makes the whole canvas fit in the view with a margin, centred.</summary>
    public void FitToView(double margin = 24)
    {
        double availW = Math.Max(16, ViewWidth - 2 * margin);
        double availH = Math.Max(16, ViewHeight - 2 * margin);
        double z = Math.Min(availW * _dpi / CanvasWidth, availH * _dpi / CanvasHeight);
        _zoom = Math.Clamp(z, MinZoom, Math.Min(16, MaxZoomFor(CanvasWidth, CanvasHeight)));
        CenterCanvas();
    }

    /// <summary>Sets an exact zoom (1 = 100%) and centres the canvas.</summary>
    public void SetZoomCentered(double zoom)
    {
        _zoom = Math.Clamp(zoom, MinZoom, MaxZoomFor(CanvasWidth, CanvasHeight));
        CenterCanvas();
    }

    public void CenterCanvas()
    {
        OffsetX = (ViewWidth - CanvasWidth * Scale) / 2;
        OffsetY = (ViewHeight - CanvasHeight * Scale) / 2;
        ClampPan();
    }

    // ----- pan -----

    public void PanBy(double dx, double dy)
    {
        OffsetX += dx;
        OffsetY += dy;
        ClampPan();
    }

    /// <summary>
    /// Lets the canvas move freely (the workspace feels endless) but never so far that it cannot be found again: at
    /// least a corner-sized piece of it always stays in view.
    /// </summary>
    public void ClampPan()
    {
        double w = CanvasWidth * Scale, h = CanvasHeight * Scale;
        double keepX = Math.Min(Math.Max(48, ViewWidth * 0.15), Math.Min(w, ViewWidth));
        double keepY = Math.Min(Math.Max(48, ViewHeight * 0.15), Math.Min(h, ViewHeight));
        OffsetX = Math.Clamp(OffsetX, keepX - w, ViewWidth - keepX);
        OffsetY = Math.Clamp(OffsetY, keepY - h, ViewHeight - keepY);
        if (double.IsNaN(OffsetX)) OffsetX = 0;
        if (double.IsNaN(OffsetY)) OffsetY = 0;
    }

    /// <summary>True when the zoom is high enough that single pixels should be drawn as crisp squares.</summary>
    public bool ShowsIndividualPixels => _zoom >= 2.0;

    /// <summary>True when a pixel grid is readable (each pixel at least 8 screen pixels wide).</summary>
    public bool CanShowPixelGrid => _zoom >= 8.0;
}
