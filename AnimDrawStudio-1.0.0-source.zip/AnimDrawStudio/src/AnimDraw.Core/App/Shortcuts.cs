using System.Text;

namespace AnimDraw.Core.App;

/// <summary>Every action the user can start from a menu, a button or the keyboard.</summary>
public enum CommandId
{
    // File
    NewProject, OpenProject, Save, SaveAs, ProjectSettings, Exit,
    // Edit
    Undo, Redo, Cut, Copy, Paste, PasteInPlace, DuplicateSelection, SelectAll, Deselect, ClearSelection, ClearFrame, Preferences,
    // View
    ZoomIn, ZoomOut, ZoomFit, Zoom100, Zoom200, TogglePixelGrid, ShowPreview, ThemeDark, ThemeLight,
    // Tools
    ToolBrush, ToolPencil, ToolEraser, ToolLine, ToolRectangle, ToolEllipse, ToolFill, ToolEyedropper, ToolSelect, ToolMove, ToolHand, ToolZoom,
    SwapColors, BrushSmaller, BrushLarger,
    // Animation
    PlayPause, StopPlayback, ToggleLoop, FirstFrame, PreviousFrame, NextFrame, LastFrame, PreviousKeyframe, NextKeyframe,
    InsertFrame, DeleteFrame, DuplicateFrame, InsertKeyframe, InsertBlankKeyframe, RemoveKeyframe, ToggleOnionSkin, OnionSkinSettings, ToggleAutoKeyframe,
    // Layer
    NewLayer, DeleteLayer, DuplicateLayer, RenameLayer, LayerUp, LayerDown, MergeLayerDown, ToggleLayerVisible, ToggleLayerLock,
    // Export
    ExportDialog, ExportGif, ExportMp4, ExportPng, ExportPngSequence, ExportSpriteSheet,
    // Help
    ShowShortcuts, About, OpenFfmpegPage
}

public sealed record CommandInfo(CommandId Id, string Category, string Name);

/// <summary>A key plus modifiers. <see cref="Key"/> uses the names of WPF's <c>Key</c> enumeration (for example "Z", "F5", "OemPlus").</summary>
public readonly record struct KeyGestureSpec(string Key, bool Ctrl = false, bool Shift = false, bool Alt = false)
{
    /// <summary>Parses text like "Ctrl+Shift+S". Returns false for text that is not a gesture.</summary>
    public static bool TryParse(string? text, out KeyGestureSpec gesture)
    {
        gesture = default;
        if (string.IsNullOrWhiteSpace(text)) return false;
        bool ctrl = false, shift = false, alt = false;
        string? key = null;
        foreach (string raw in text.Split('+', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            switch (raw.ToLowerInvariant())
            {
                case "ctrl": case "control": ctrl = true; break;
                case "shift": shift = true; break;
                case "alt": alt = true; break;
                default:
                    if (key != null) return false;
                    key = raw;
                    break;
            }
        }
        if (key == null) return false;
        gesture = new KeyGestureSpec(key, ctrl, shift, alt);
        return true;
    }

    /// <summary>The form stored in the shortcut table: "Ctrl+Shift+OemPlus".</summary>
    public string ToStorageString()
    {
        var sb = new StringBuilder();
        if (Ctrl) sb.Append("Ctrl+");
        if (Alt) sb.Append("Alt+");
        if (Shift) sb.Append("Shift+");
        return sb.Append(Key).ToString();
    }

    /// <summary>The form shown to people: "Ctrl+Shift+=".</summary>
    public string ToDisplayString()
    {
        var sb = new StringBuilder();
        if (Ctrl) sb.Append("Ctrl+");
        if (Alt) sb.Append("Alt+");
        if (Shift) sb.Append("Shift+");
        return sb.Append(DisplayKey(Key)).ToString();
    }

    public static string DisplayKey(string key) => key switch
    {
        "OemPlus" => "=",
        "OemMinus" => "-",
        "OemComma" => ",",
        "OemPeriod" => ".",
        "OemOpenBrackets" => "[",
        "OemCloseBrackets" => "]",
        "OemQuotes" => "'",
        "OemSemicolon" => ";",
        "OemQuestion" => "/",
        "OemPipe" => "\\",
        "OemTilde" => "`",
        "Add" => "Num +",
        "Subtract" => "Num -",
        "Escape" => "Esc",
        "Return" => "Enter",
        "Back" => "Backspace",
        "Prior" => "Page Up",
        "Next" => "Page Down",
        "Delete" => "Del",
        "Insert" => "Ins",
        var k when k.Length == 2 && k[0] == 'D' && char.IsDigit(k[1]) => k[1].ToString(),
        var k when k.StartsWith("NumPad", StringComparison.Ordinal) && k.Length == 7 => "Num " + k[6],
        _ => key
    };

    public override string ToString() => ToStorageString();
}

/// <summary>The default keyboard shortcuts and the list of all commands with their menu names.</summary>
public sealed class ShortcutMap
{
    private readonly Dictionary<CommandId, List<KeyGestureSpec>> _byCommand = new();
    private readonly Dictionary<KeyGestureSpec, CommandId> _byGesture = new();

    public static readonly IReadOnlyList<CommandInfo> Commands = new List<CommandInfo>
    {
        new(CommandId.NewProject, "File", "New Project"),
        new(CommandId.OpenProject, "File", "Open Project"),
        new(CommandId.Save, "File", "Save"),
        new(CommandId.SaveAs, "File", "Save As"),
        new(CommandId.ProjectSettings, "File", "Project Settings"),
        new(CommandId.Exit, "File", "Exit"),

        new(CommandId.Undo, "Edit", "Undo"),
        new(CommandId.Redo, "Edit", "Redo"),
        new(CommandId.Cut, "Edit", "Cut"),
        new(CommandId.Copy, "Edit", "Copy"),
        new(CommandId.Paste, "Edit", "Paste"),
        new(CommandId.PasteInPlace, "Edit", "Paste in Place"),
        new(CommandId.DuplicateSelection, "Edit", "Duplicate Selection"),
        new(CommandId.SelectAll, "Edit", "Select All"),
        new(CommandId.Deselect, "Edit", "Deselect"),
        new(CommandId.ClearSelection, "Edit", "Clear Selection / Layer Drawing"),
        new(CommandId.ClearFrame, "Edit", "Clear Canvas (all layers, this frame)"),
        new(CommandId.Preferences, "Edit", "Preferences"),

        new(CommandId.ZoomIn, "View", "Zoom In"),
        new(CommandId.ZoomOut, "View", "Zoom Out"),
        new(CommandId.ZoomFit, "View", "Fit Canvas to Window"),
        new(CommandId.Zoom100, "View", "Actual Size (100%)"),
        new(CommandId.Zoom200, "View", "Zoom 200%"),
        new(CommandId.TogglePixelGrid, "View", "Pixel Grid"),
        new(CommandId.ShowPreview, "View", "Preview Window"),
        new(CommandId.ThemeDark, "View", "Dark Theme"),
        new(CommandId.ThemeLight, "View", "Light Theme"),

        new(CommandId.ToolBrush, "Drawing", "Brush"),
        new(CommandId.ToolPencil, "Drawing", "Pencil"),
        new(CommandId.ToolEraser, "Drawing", "Eraser"),
        new(CommandId.ToolLine, "Drawing", "Line"),
        new(CommandId.ToolRectangle, "Drawing", "Rectangle"),
        new(CommandId.ToolEllipse, "Drawing", "Ellipse"),
        new(CommandId.ToolFill, "Drawing", "Fill"),
        new(CommandId.ToolEyedropper, "Drawing", "Eyedropper"),
        new(CommandId.ToolSelect, "Drawing", "Select"),
        new(CommandId.ToolMove, "Drawing", "Move"),
        new(CommandId.ToolHand, "Drawing", "Hand (pan)"),
        new(CommandId.ToolZoom, "Drawing", "Zoom Tool"),
        new(CommandId.SwapColors, "Drawing", "Swap Colours"),
        new(CommandId.BrushSmaller, "Drawing", "Smaller Brush"),
        new(CommandId.BrushLarger, "Drawing", "Larger Brush"),

        new(CommandId.PlayPause, "Animation", "Play / Pause"),
        new(CommandId.StopPlayback, "Animation", "Stop"),
        new(CommandId.ToggleLoop, "Animation", "Loop"),
        new(CommandId.FirstFrame, "Animation", "First Frame"),
        new(CommandId.PreviousFrame, "Animation", "Previous Frame"),
        new(CommandId.NextFrame, "Animation", "Next Frame"),
        new(CommandId.LastFrame, "Animation", "Last Frame"),
        new(CommandId.PreviousKeyframe, "Animation", "Previous Keyframe"),
        new(CommandId.NextKeyframe, "Animation", "Next Keyframe"),
        new(CommandId.InsertFrame, "Animation", "Add Frame"),
        new(CommandId.DeleteFrame, "Animation", "Delete Frame"),
        new(CommandId.DuplicateFrame, "Animation", "Duplicate Frame"),
        new(CommandId.InsertKeyframe, "Animation", "Add Keyframe"),
        new(CommandId.InsertBlankKeyframe, "Animation", "Add Blank Keyframe"),
        new(CommandId.RemoveKeyframe, "Animation", "Remove Keyframe"),
        new(CommandId.ToggleOnionSkin, "Animation", "Onion Skin"),
        new(CommandId.OnionSkinSettings, "Animation", "Onion Skin Settings"),
        new(CommandId.ToggleAutoKeyframe, "Animation", "Auto Keyframe"),

        new(CommandId.NewLayer, "Layer", "New Layer"),
        new(CommandId.DeleteLayer, "Layer", "Delete Layer"),
        new(CommandId.DuplicateLayer, "Layer", "Duplicate Layer"),
        new(CommandId.RenameLayer, "Layer", "Rename Layer"),
        new(CommandId.LayerUp, "Layer", "Move Layer Up"),
        new(CommandId.LayerDown, "Layer", "Move Layer Down"),
        new(CommandId.MergeLayerDown, "Layer", "Merge Down"),
        new(CommandId.ToggleLayerVisible, "Layer", "Show / Hide Layer"),
        new(CommandId.ToggleLayerLock, "Layer", "Lock / Unlock Layer"),

        new(CommandId.ExportDialog, "Export", "Export..."),
        new(CommandId.ExportGif, "Export", "Animated GIF..."),
        new(CommandId.ExportMp4, "Export", "MP4 Video..."),
        new(CommandId.ExportPng, "Export", "PNG Image (current frame)..."),
        new(CommandId.ExportPngSequence, "Export", "PNG Sequence..."),
        new(CommandId.ExportSpriteSheet, "Export", "Sprite Sheet..."),

        new(CommandId.ShowShortcuts, "Help", "Keyboard Shortcuts"),
        new(CommandId.About, "Help", "About AnimDraw Studio"),
        new(CommandId.OpenFfmpegPage, "Help", "Get FFmpeg (for MP4 export)")
    };

    public static CommandInfo Info(CommandId id) => Commands.First(c => c.Id == id);

    public static ShortcutMap CreateDefault()
    {
        var m = new ShortcutMap();
        void Add(CommandId id, string key, bool ctrl = false, bool shift = false, bool alt = false) =>
            m.Bind(id, new KeyGestureSpec(key, ctrl, shift, alt));

        Add(CommandId.NewProject, "N", ctrl: true);
        Add(CommandId.OpenProject, "O", ctrl: true);
        Add(CommandId.Save, "S", ctrl: true);
        Add(CommandId.SaveAs, "S", ctrl: true, shift: true);
        Add(CommandId.Exit, "F4", alt: true);

        Add(CommandId.Undo, "Z", ctrl: true);
        Add(CommandId.Redo, "Y", ctrl: true);
        Add(CommandId.Redo, "Z", ctrl: true, shift: true);
        Add(CommandId.Cut, "X", ctrl: true);
        Add(CommandId.Copy, "C", ctrl: true);
        Add(CommandId.Paste, "V", ctrl: true);
        Add(CommandId.PasteInPlace, "V", ctrl: true, shift: true);
        Add(CommandId.DuplicateSelection, "D", ctrl: true);
        Add(CommandId.SelectAll, "A", ctrl: true);
        Add(CommandId.Deselect, "A", ctrl: true, shift: true);
        Add(CommandId.ClearSelection, "Delete");
        Add(CommandId.ClearFrame, "Delete", ctrl: true);

        Add(CommandId.ZoomIn, "OemPlus", ctrl: true);
        Add(CommandId.ZoomIn, "Add", ctrl: true);
        Add(CommandId.ZoomOut, "OemMinus", ctrl: true);
        Add(CommandId.ZoomOut, "Subtract", ctrl: true);
        Add(CommandId.ZoomFit, "D0", ctrl: true);
        Add(CommandId.Zoom100, "D1", ctrl: true);
        Add(CommandId.Zoom200, "D2", ctrl: true);
        Add(CommandId.TogglePixelGrid, "G", ctrl: true, shift: true);
        Add(CommandId.ShowPreview, "P", ctrl: true);
        Add(CommandId.Preferences, "OemComma", ctrl: true);

        Add(CommandId.ToolBrush, "B");
        Add(CommandId.ToolPencil, "P");
        Add(CommandId.ToolEraser, "E");
        Add(CommandId.ToolLine, "L");
        Add(CommandId.ToolRectangle, "R");
        Add(CommandId.ToolEllipse, "O");
        Add(CommandId.ToolFill, "G");
        Add(CommandId.ToolEyedropper, "I");
        Add(CommandId.ToolSelect, "M");
        Add(CommandId.ToolMove, "V");
        Add(CommandId.ToolHand, "H");
        Add(CommandId.ToolZoom, "Z");
        Add(CommandId.SwapColors, "X");
        Add(CommandId.BrushSmaller, "OemOpenBrackets");
        Add(CommandId.BrushLarger, "OemCloseBrackets");

        Add(CommandId.PlayPause, "Return");
        Add(CommandId.StopPlayback, "Return", shift: true);
        Add(CommandId.ToggleLoop, "L", ctrl: true);
        Add(CommandId.FirstFrame, "Home");
        Add(CommandId.PreviousFrame, "OemComma");
        Add(CommandId.NextFrame, "OemPeriod");
        Add(CommandId.LastFrame, "End");
        Add(CommandId.PreviousKeyframe, "OemComma", shift: true);
        Add(CommandId.NextKeyframe, "OemPeriod", shift: true);
        Add(CommandId.InsertFrame, "F5");
        Add(CommandId.DeleteFrame, "F5", shift: true);
        Add(CommandId.DuplicateFrame, "D", ctrl: true, shift: true);
        Add(CommandId.InsertKeyframe, "F6");
        Add(CommandId.InsertBlankKeyframe, "F7");
        Add(CommandId.RemoveKeyframe, "F6", shift: true);
        Add(CommandId.ToggleOnionSkin, "O", shift: true);

        Add(CommandId.NewLayer, "N", ctrl: true, shift: true);
        Add(CommandId.DeleteLayer, "Delete", ctrl: true, shift: true);
        Add(CommandId.DuplicateLayer, "J", ctrl: true);
        Add(CommandId.RenameLayer, "F2");
        Add(CommandId.LayerUp, "OemCloseBrackets", ctrl: true);
        Add(CommandId.LayerDown, "OemOpenBrackets", ctrl: true);
        Add(CommandId.MergeLayerDown, "M", ctrl: true, shift: true);

        Add(CommandId.ExportDialog, "E", ctrl: true);

        Add(CommandId.ShowShortcuts, "F1");
        return m;
    }

    /// <summary>Adds a gesture for a command. A gesture can belong to one command only; binding it again moves it.</summary>
    public void Bind(CommandId id, KeyGestureSpec gesture)
    {
        if (_byGesture.TryGetValue(gesture, out var previous) && previous != id)
            _byCommand[previous].Remove(gesture);
        _byGesture[gesture] = id;
        if (!_byCommand.TryGetValue(id, out var list)) _byCommand[id] = list = new List<KeyGestureSpec>();
        if (!list.Contains(gesture)) list.Add(gesture);
    }

    /// <summary>The command a pressed key combination runs, if any.</summary>
    public CommandId? Find(KeyGestureSpec gesture) => _byGesture.TryGetValue(gesture, out var id) ? id : null;

    /// <summary>All gestures of a command; the first is the one shown in menus.</summary>
    public IReadOnlyList<KeyGestureSpec> GesturesOf(CommandId id) =>
        _byCommand.TryGetValue(id, out var list) ? list : Array.Empty<KeyGestureSpec>();

    public string DisplayTextOf(CommandId id)
    {
        var g = GesturesOf(id);
        return g.Count == 0 ? "" : g[0].ToDisplayString();
    }

    public IEnumerable<(CommandId Id, KeyGestureSpec Gesture)> AllBindings() =>
        _byGesture.Select(kv => (kv.Value, kv.Key));
}
