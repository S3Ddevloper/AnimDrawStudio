using AnimDraw.Core.Imaging;

namespace AnimDraw.Core.Model;

public enum BackgroundMode
{
    White,
    Transparent,
    Custom
}

/// <summary>What is shown behind the artwork when a frame is displayed or exported.</summary>
public sealed record BackgroundSettings(BackgroundMode Mode, ArgbColor Color)
{
    public static readonly BackgroundSettings White = new(BackgroundMode.White, ArgbColor.White);
    public static readonly BackgroundSettings Transparent = new(BackgroundMode.Transparent, ArgbColor.Transparent);

    public static BackgroundSettings Custom(ArgbColor color) => new(BackgroundMode.Custom, color.WithAlpha(255));

    /// <summary>The colour that fills the canvas (fully transparent for the transparent mode).</summary>
    public ArgbColor EffectiveColor => Mode switch
    {
        BackgroundMode.White => ArgbColor.White,
        BackgroundMode.Transparent => ArgbColor.Transparent,
        _ => Color.WithAlpha(255)
    };

    public uint PremultipliedPixel => EffectiveColor.ToPremultiplied();
}

/// <summary>Onion-skin options. These are view settings stored with the project.</summary>
public sealed class OnionSkinSettings
{
    public bool Enabled { get; set; } = true;
    public int PreviousFrames { get; set; } = 1;
    public int NextFrames { get; set; } = 1;

    /// <summary>Strength of the ghost frames, 0.05 to 0.9.</summary>
    public double Opacity { get; set; } = 0.35;

    /// <summary>Tint previous frames red and next frames blue so they are easy to tell apart.</summary>
    public bool Colorize { get; set; } = true;

    public OnionSkinSettings Clone() => new()
    {
        Enabled = Enabled,
        PreviousFrames = PreviousFrames,
        NextFrames = NextFrames,
        Opacity = Opacity,
        Colorize = Colorize
    };

    public void Normalize()
    {
        PreviousFrames = Math.Clamp(PreviousFrames, 0, ProjectLimits.MaxOnionFrames);
        NextFrames = Math.Clamp(NextFrames, 0, ProjectLimits.MaxOnionFrames);
        Opacity = Math.Clamp(double.IsNaN(Opacity) ? 0.35 : Opacity, 0.05, 0.9);
    }
}

public static class ProjectLimits
{
    public const int MinDimension = 1;
    public const int MaxDimension = 8192;
    public const long MaxPixels = 50_000_000;
    public const long WarnPixels = 16_000_000;
    public const int MaxFrames = 10_000;
    public const int MaxLayers = 128;
    public const int MaxOnionFrames = 5;
    public const double MinFps = 1;
    public const double MaxFps = 120;

    public static bool IsValidSize(int width, int height, out string? problem)
    {
        if (width < MinDimension || height < MinDimension || width > MaxDimension || height > MaxDimension)
        {
            problem = $"Width and height must be between {MinDimension} and {MaxDimension} pixels.";
            return false;
        }
        if ((long)width * height > MaxPixels)
        {
            problem = $"A canvas of {width} x {height} has more than {MaxPixels / 1_000_000} million pixels, which is more than AnimDraw Studio can hold in memory.";
            return false;
        }
        problem = null;
        return true;
    }

    public static double ClampFps(double fps) =>
        double.IsNaN(fps) ? 12 : Math.Clamp(fps, MinFps, MaxFps);
}
