namespace AnimDraw.Core.Model;

/// <summary>
/// The editable animation: canvas size, frame rate, layers (index 0 is the bottom layer) and, per layer,
/// the keyframed drawings. This is pure data; editing goes through <see cref="Editing.Document"/>.
/// </summary>
public sealed class Project
{
    public int Width { get; private set; }
    public int Height { get; private set; }
    public double Fps { get; set; } = 12;
    public int FrameCount { get; set; } = 1;
    public bool Loop { get; set; } = true;
    public BackgroundSettings Background { get; set; } = BackgroundSettings.White;
    public OnionSkinSettings Onion { get; set; } = new();
    public List<Layer> Layers { get; } = new();

    public Project(int width, int height)
    {
        if (!ProjectLimits.IsValidSize(width, height, out string? problem))
            throw new ArgumentOutOfRangeException(nameof(width), problem);
        Width = width;
        Height = height;
    }

    /// <summary>A new project with one empty layer and one frame.</summary>
    public static Project CreateNew(int width, int height, double fps, BackgroundSettings? background = null)
    {
        var p = new Project(width, height)
        {
            Fps = ProjectLimits.ClampFps(fps),
            Background = background ?? BackgroundSettings.White
        };
        p.Layers.Add(new Layer("Layer 1"));
        return p;
    }

    public void SetSize(int width, int height)
    {
        if (!ProjectLimits.IsValidSize(width, height, out string? problem))
            throw new ArgumentOutOfRangeException(nameof(width), problem);
        Width = width;
        Height = height;
    }

    public Layer? FindLayer(Guid id)
    {
        foreach (var l in Layers) if (l.Id == id) return l;
        return null;
    }

    public int IndexOfLayer(Layer layer) => Layers.IndexOf(layer);

    public TimeSpan Duration => TimeSpan.FromSeconds(FrameCount / Math.Max(1.0, Fps));

    /// <summary>Picks "Layer N" with the lowest unused N.</summary>
    public string NextLayerName()
    {
        for (int n = Layers.Count + 1; ; n++)
        {
            string name = $"Layer {n}";
            if (!Layers.Any(l => l.Name == name)) return name;
        }
    }
}
