namespace AnimDraw.Core.Model;

/// <summary>
/// A layer holds its own artwork: a track of keyframes, each pointing at a private drawing (cel).
/// Layers never share artwork with each other, so editing one cannot change another.
/// </summary>
public sealed class Layer
{
    public Guid Id { get; }
    public string Name { get; set; }
    public bool Visible { get; set; } = true;
    public bool Locked { get; set; }

    /// <summary>0 (invisible) to 1 (fully opaque).</summary>
    public double Opacity { get; set; } = 1.0;

    public CelTrack Track { get; } = new();

    public Layer(string name) : this(Guid.NewGuid(), name) { }

    public Layer(Guid id, string name)
    {
        Id = id;
        Name = name;
    }

    public Cel? GetCelAt(int frame) => Track.GetCelAt(frame);

    public int Opacity255 => (int)Math.Round(Math.Clamp(Opacity, 0, 1) * 255);

    /// <summary>A new layer with its own copy of every drawing (pixel data is shared until edited).</summary>
    public Layer Duplicate(string newName)
    {
        var copy = new Layer(newName) { Visible = Visible, Locked = Locked, Opacity = Opacity };
        foreach (var (frame, cel) in Track.Keyframes) copy.Track.Set(frame, cel.Clone());
        return copy;
    }
}
