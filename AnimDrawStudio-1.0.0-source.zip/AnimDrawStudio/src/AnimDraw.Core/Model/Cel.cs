using AnimDraw.Core.Imaging;

namespace AnimDraw.Core.Model;

/// <summary>
/// One drawing: the artwork a single layer shows from one keyframe up to the next keyframe.
/// Cels share pixel tiles copy-on-write, so duplicating one is cheap.
/// </summary>
public sealed class Cel
{
    public TiledSurface Surface { get; }

    public Cel(TiledSurface surface) => Surface = surface;

    public Cel(int width, int height) => Surface = new TiledSurface(width, height);

    /// <summary>An independent copy (pixel data is shared until either copy is edited).</summary>
    public Cel Clone() => new(Surface.Clone());
}
