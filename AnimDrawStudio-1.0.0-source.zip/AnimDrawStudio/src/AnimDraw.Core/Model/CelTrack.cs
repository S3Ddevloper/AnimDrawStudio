namespace AnimDraw.Core.Model;

/// <summary>
/// The keyframes of one layer, sorted by frame number. A keyframe's drawing is "held" (shown) on every
/// following frame until the next keyframe, exactly like an exposure sheet.
/// </summary>
public sealed class CelTrack
{
    private readonly List<int> _frames = new();
    private readonly List<Cel> _cels = new();

    public int Count => _frames.Count;

    public int FrameAt(int index) => _frames[index];

    public Cel CelAt(int index) => _cels[index];

    public IEnumerable<(int Frame, Cel Cel)> Keyframes
    {
        get
        {
            for (int i = 0; i < _frames.Count; i++) yield return (_frames[i], _cels[i]);
        }
    }

    /// <summary>Index of the keyframe with the greatest frame number that is &lt;= <paramref name="frame"/>, or -1.</summary>
    public int FloorIndex(int frame)
    {
        int lo = 0, hi = _frames.Count - 1, answer = -1;
        while (lo <= hi)
        {
            int mid = (lo + hi) >> 1;
            if (_frames[mid] <= frame) { answer = mid; lo = mid + 1; }
            else hi = mid - 1;
        }
        return answer;
    }

    /// <summary>The drawing shown at a frame (the keyframe at or before it), or null when nothing is drawn yet.</summary>
    public Cel? GetCelAt(int frame)
    {
        int i = FloorIndex(frame);
        return i < 0 ? null : _cels[i];
    }

    /// <summary>Frame number of the keyframe governing <paramref name="frame"/>, or -1.</summary>
    public int GoverningKeyFrame(int frame)
    {
        int i = FloorIndex(frame);
        return i < 0 ? -1 : _frames[i];
    }

    public bool IsKeyframe(int frame)
    {
        int i = FloorIndex(frame);
        return i >= 0 && _frames[i] == frame;
    }

    public bool TryGetExact(int frame, out Cel cel)
    {
        int i = FloorIndex(frame);
        if (i >= 0 && _frames[i] == frame) { cel = _cels[i]; return true; }
        cel = null!;
        return false;
    }

    /// <summary>First frame after <paramref name="frame"/> that has a keyframe, or -1.</summary>
    public int NextKeyFrameAfter(int frame)
    {
        int i = FloorIndex(frame) + 1;
        return i < _frames.Count ? _frames[i] : -1;
    }

    /// <summary>Last frame (inclusive) that the keyframe governing <paramref name="frame"/> is held for.</summary>
    public int HoldEnd(int frame, int frameCount)
    {
        int next = NextKeyFrameAfter(frame);
        return next < 0 ? frameCount - 1 : next - 1;
    }

    /// <summary>Adds a keyframe, replacing any keyframe already on that frame.</summary>
    public void Set(int frame, Cel cel)
    {
        int i = FloorIndex(frame);
        if (i >= 0 && _frames[i] == frame) { _cels[i] = cel; return; }
        _frames.Insert(i + 1, frame);
        _cels.Insert(i + 1, cel);
    }

    public bool Remove(int frame)
    {
        int i = FloorIndex(frame);
        if (i < 0 || _frames[i] != frame) return false;
        _frames.RemoveAt(i);
        _cels.RemoveAt(i);
        return true;
    }

    public void Clear()
    {
        _frames.Clear();
        _cels.Clear();
    }

    /// <summary>Moves every keyframe at or after <paramref name="fromFrame"/> by <paramref name="delta"/> frames.</summary>
    public void ShiftFrom(int fromFrame, int delta)
    {
        for (int i = 0; i < _frames.Count; i++)
            if (_frames[i] >= fromFrame) _frames[i] += delta;
    }

    /// <summary>Drops keyframes after <paramref name="lastFrame"/>.</summary>
    public void RemoveAfter(int lastFrame)
    {
        for (int i = _frames.Count - 1; i >= 0 && _frames[i] > lastFrame; i--)
        {
            _frames.RemoveAt(i);
            _cels.RemoveAt(i);
        }
    }

    /// <summary>Replaces this track's contents with those of another (cels are shared, not copied).</summary>
    public void CopyFrom(CelTrack other)
    {
        _frames.Clear();
        _cels.Clear();
        _frames.AddRange(other._frames);
        _cels.AddRange(other._cels);
    }

    public CelTrack Clone()
    {
        var t = new CelTrack();
        t.CopyFrom(this);
        return t;
    }
}
