using System.Diagnostics;

namespace AnimDraw.Core.Animation;

public enum PlaybackState
{
    Stopped,
    Playing,
    Paused
}

/// <summary>
/// Decides which frame should be on screen at a given moment. It never blocks and owns no thread: the
/// application calls <see cref="Tick"/> from its render loop and shows <see cref="CurrentFrame"/>. Time comes from
/// a monotonic clock, so the average speed is exact even when the machine drops frames.
/// </summary>
public sealed class PlaybackEngine
{
    public const double MinSpeed = 0.1;
    public const double MaxSpeed = 8.0;

    private readonly Func<long> _clock;
    private readonly long _frequency;

    private double _fps = 12;
    private double _speed = 1;
    private int _frameCount = 1;
    private int _firstFrame;
    private int _lastFrame;
    private bool _hasRange;

    private long _anchorTicks;
    private double _anchorPosition;   // frame position (fractional, unwrapped) at _anchorTicks
    private int _lastShownUnwrapped;
    private long _pausedTicks;

    private readonly Queue<long> _recentShows = new();

    public PlaybackEngine() : this(Stopwatch.GetTimestamp, Stopwatch.Frequency) { }

    /// <param name="clock">Returns a tick count that only increases.</param>
    /// <param name="ticksPerSecond">How many clock ticks make one second.</param>
    public PlaybackEngine(Func<long> clock, long ticksPerSecond)
    {
        _clock = clock;
        _frequency = ticksPerSecond;
    }

    public PlaybackState State { get; private set; } = PlaybackState.Stopped;
    public int CurrentFrame { get; private set; }

    /// <summary>The frame playback began from; <see cref="Stop"/> returns here.</summary>
    public int StartFrame { get; private set; }

    public bool Loop { get; set; } = true;

    /// <summary>Frames that were skipped because the display could not keep up.</summary>
    public long DroppedFrames { get; private set; }

    public event Action<int>? FrameChanged;
    public event Action<PlaybackState>? StateChanged;

    public double Fps
    {
        get => _fps;
        set
        {
            double v = double.IsNaN(value) ? 12 : Math.Clamp(value, 1, 240);
            if (State == PlaybackState.Playing) Reanchor();
            _fps = v;
        }
    }

    /// <summary>Playback speed multiplier (0.1x to 8x).</summary>
    public double Speed
    {
        get => _speed;
        set
        {
            double v = double.IsNaN(value) ? 1 : Math.Clamp(value, MinSpeed, MaxSpeed);
            if (State == PlaybackState.Playing) Reanchor();
            _speed = v;
        }
    }

    public int FrameCount
    {
        get => _frameCount;
        set
        {
            _frameCount = Math.Max(1, value);
            if (!_hasRange) _lastFrame = _frameCount - 1;
            else
            {
                _lastFrame = Math.Min(_lastFrame, _frameCount - 1);
                _firstFrame = Math.Min(_firstFrame, _lastFrame);
            }
            if (CurrentFrame >= _frameCount) CurrentFrame = _frameCount - 1;
        }
    }

    public int FirstFrame => _hasRange ? _firstFrame : 0;
    public int LastFrame => _hasRange ? _lastFrame : _frameCount - 1;

    /// <summary>Limits playback to part of the timeline (inclusive). Pass null to play everything.</summary>
    public void SetRange(int? first, int? last)
    {
        if (first == null || last == null) { _hasRange = false; return; }
        _hasRange = true;
        _firstFrame = Math.Clamp(Math.Min(first.Value, last.Value), 0, _frameCount - 1);
        _lastFrame = Math.Clamp(Math.Max(first.Value, last.Value), 0, _frameCount - 1);
    }

    /// <summary>Frames per second actually shown over roughly the last second.</summary>
    public double MeasuredFps
    {
        get
        {
            if (_recentShows.Count < 2) return 0;
            long span = _recentShows.Last() - _recentShows.Peek();
            return span <= 0 ? 0 : (_recentShows.Count - 1) * (double)_frequency / span;
        }
    }

    public void Play(int fromFrame)
    {
        int first = FirstFrame, last = LastFrame;
        int start = Math.Clamp(fromFrame, 0, _frameCount - 1);
        // Pressing play on the last frame (or outside the range) starts over, like a media player.
        if (start < first || start > last || (start == last && !Loop && last > first)) start = first;
        StartFrame = start;
        SetFrame(start, notify: true);
        _anchorTicks = _clock();
        _anchorPosition = start;
        _lastShownUnwrapped = start;
        _recentShows.Clear();
        DroppedFrames = 0;
        SetState(PlaybackState.Playing);
    }

    public void Pause()
    {
        if (State != PlaybackState.Playing) return;
        _pausedTicks = _clock();
        SetState(PlaybackState.Paused);
    }

    public void Resume()
    {
        if (State != PlaybackState.Paused) return;
        long now = _clock();
        _anchorTicks += now - _pausedTicks; // time spent paused does not count
        SetState(PlaybackState.Playing);
    }

    public void TogglePlayPause(int currentFrame)
    {
        switch (State)
        {
            case PlaybackState.Playing: Pause(); break;
            case PlaybackState.Paused: Resume(); break;
            default: Play(currentFrame); break;
        }
    }

    /// <summary>Stops and, by default, goes back to the frame playback started from.</summary>
    public void Stop(bool returnToStart = true)
    {
        bool wasRunning = State != PlaybackState.Stopped;
        SetState(PlaybackState.Stopped);
        if (wasRunning && returnToStart) SetFrame(StartFrame, notify: true);
    }

    /// <summary>Jumps to a frame. While playing, playback continues from there.</summary>
    public void Seek(int frame)
    {
        frame = Math.Clamp(frame, 0, _frameCount - 1);
        SetFrame(frame, notify: true);
        if (State == PlaybackState.Playing)
        {
            _anchorTicks = _clock();
            _anchorPosition = frame;
            _lastShownUnwrapped = frame;
        }
        else if (State == PlaybackState.Paused)
        {
            _anchorTicks = _pausedTicks;
            _anchorPosition = frame;
            _lastShownUnwrapped = frame;
        }
    }

    /// <summary>Advances to the frame that belongs to the current time. Returns true when the shown frame changed.</summary>
    public bool Tick()
    {
        if (State != PlaybackState.Playing) return false;
        long now = _clock();
        double seconds = (double)(now - _anchorTicks) / _frequency;
        double position = _anchorPosition + seconds * _fps * _speed;
        int first = FirstFrame, last = LastFrame;
        int length = last - first + 1;
        int unwrapped = (int)Math.Floor(position);

        int frame;
        bool finished = false;
        if (Loop)
        {
            int offset = unwrapped - first;
            frame = first + (((offset % length) + length) % length);
        }
        else if (unwrapped > last)
        {
            frame = last;
            finished = true;
        }
        else frame = Math.Max(first, unwrapped);

        if (unwrapped - _lastShownUnwrapped > 1) DroppedFrames += unwrapped - _lastShownUnwrapped - 1;

        bool changed = frame != CurrentFrame;
        if (changed || unwrapped != _lastShownUnwrapped)
        {
            _lastShownUnwrapped = unwrapped;
        }
        if (changed)
        {
            RecordShown(now);
            SetFrame(frame, notify: true);
        }
        if (finished) SetState(PlaybackState.Stopped);
        return changed;
    }

    private void Reanchor()
    {
        long now = _clock();
        double seconds = (double)(now - _anchorTicks) / _frequency;
        _anchorPosition += seconds * _fps * _speed;
        _anchorTicks = now;
    }

    private void RecordShown(long now)
    {
        _recentShows.Enqueue(now);
        while (_recentShows.Count > 1 && now - _recentShows.Peek() > _frequency) _recentShows.Dequeue();
    }

    private void SetFrame(int frame, bool notify)
    {
        if (frame == CurrentFrame) return;
        CurrentFrame = frame;
        if (notify) FrameChanged?.Invoke(frame);
    }

    private void SetState(PlaybackState state)
    {
        if (state == State) return;
        State = state;
        StateChanged?.Invoke(state);
    }
}
