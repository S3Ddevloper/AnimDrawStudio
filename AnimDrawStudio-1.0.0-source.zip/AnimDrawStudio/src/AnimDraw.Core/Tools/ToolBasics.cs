using AnimDraw.Core.Drawing;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Imaging;

namespace AnimDraw.Core.Tools;

public enum ToolKind
{
    Brush,
    Pencil,
    Eraser,
    Line,
    Rectangle,
    Ellipse,
    Fill,
    Eyedropper,
    Select,
    Move,
    Hand,
    Zoom
}

/// <summary>A pointer event in canvas coordinates (one pixel = 1.0).</summary>
public readonly record struct PointerInput(
    float X,
    float Y,
    float Pressure = 1f,
    bool Shift = false,
    bool Ctrl = false,
    bool Alt = false,
    bool Secondary = false,
    bool Inverted = false)
{
    public StrokePoint ToStroke() => new(X, Y, Pressure);
}

public enum ShapeStyle
{
    Outline,
    Filled,
    OutlineAndFill
}

/// <summary>User-adjustable options shared by the tools, including the two paint colours.</summary>
public sealed class ToolSettings
{
    public BrushSettings Brush { get; } = BrushSettings.CreateBrush();
    public BrushSettings Pencil { get; } = BrushSettings.CreatePencil();
    public BrushSettings Eraser { get; } = BrushSettings.CreateEraser();
    public FillOptions Fill { get; } = new();

    public double ShapeLineWidth { get; set; } = 3;
    public ShapeStyle ShapeStyle { get; set; } = ShapeStyle.Outline;
    public bool EyedropperSampleAllLayers { get; set; } = true;

    public ArgbColor PrimaryColor { get; set; } = ArgbColor.Black;
    public ArgbColor SecondaryColor { get; set; } = ArgbColor.White;

    public event Action? Changed;

    public void RaiseChanged() => Changed?.Invoke();

    public void SwapColors()
    {
        (PrimaryColor, SecondaryColor) = (SecondaryColor, PrimaryColor);
        RaiseChanged();
    }

    public void Normalize()
    {
        Brush.Normalize();
        Pencil.Normalize();
        Eraser.Normalize();
        ShapeLineWidth = double.IsNaN(ShapeLineWidth) ? 3 : Math.Clamp(ShapeLineWidth, 1, 200);
        Fill.Tolerance = Math.Clamp(Fill.Tolerance, 0, 255);
        Fill.Grow = Math.Clamp(Fill.Grow, 0, 4);
    }
}

/// <summary>What a tool needs from the application.</summary>
public sealed class ToolContext
{
    public ToolContext(Document document, ToolSettings settings)
    {
        Document = document;
        Settings = settings;
    }

    public Document Document { get; set; }
    public ToolSettings Settings { get; }

    /// <summary>Show a short message to the user (status bar).</summary>
    public Action<string> Notify { get; set; } = _ => { };

    /// <summary>A tool picked a colour (eyedropper).</summary>
    public Action<ArgbColor, bool> ColorPicked { get; set; } = (_, _) => { };
}

public interface ITool
{
    ToolKind Kind { get; }
    string DisplayName { get; }

    /// <summary>True while a pointer drag is in progress.</summary>
    bool IsActive { get; }

    void PointerDown(PointerInput p);
    void PointerMove(PointerInput p);
    void PointerUp(PointerInput p);

    /// <summary>Abandons a drag in progress (Escape, focus loss).</summary>
    void Cancel();
}

public abstract class ToolBase : ITool
{
    protected ToolBase(ToolContext context) => Context = context;

    protected ToolContext Context { get; }
    protected Document Document => Context.Document;
    protected ToolSettings Settings => Context.Settings;

    public abstract ToolKind Kind { get; }
    public abstract string DisplayName { get; }
    public bool IsActive { get; protected set; }

    public abstract void PointerDown(PointerInput p);
    public abstract void PointerMove(PointerInput p);
    public abstract void PointerUp(PointerInput p);
    public abstract void Cancel();

    protected ArgbColor ColorFor(PointerInput p) => p.Secondary ? Settings.SecondaryColor : Settings.PrimaryColor;

    protected EditSession? BeginEditOrExplain()
    {
        var session = Document.BeginEdit(out string? error);
        if (session == null && error != null) Context.Notify(error);
        return session;
    }
}

/// <summary>Hand and Zoom are handled by the canvas view; these stand-ins only keep the tool list uniform.</summary>
public sealed class ViewTool : ToolBase
{
    public ViewTool(ToolContext context, ToolKind kind) : base(context)
    {
        Kind = kind;
        DisplayName = kind == ToolKind.Hand ? "Hand" : "Zoom";
    }

    public override ToolKind Kind { get; }
    public override string DisplayName { get; }
    public override void PointerDown(PointerInput p) { }
    public override void PointerMove(PointerInput p) { }
    public override void PointerUp(PointerInput p) { }
    public override void Cancel() { }
}
