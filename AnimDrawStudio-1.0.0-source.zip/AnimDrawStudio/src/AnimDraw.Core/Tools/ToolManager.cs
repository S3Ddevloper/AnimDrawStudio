using AnimDraw.Core.Editing;

namespace AnimDraw.Core.Tools;

/// <summary>Owns the tool instances, remembers which one is active and forwards pointer input to it.</summary>
public sealed class ToolManager
{
    private readonly Dictionary<ToolKind, ITool> _tools = new();
    private ITool _current;

    public ToolManager(ToolContext context)
    {
        Context = context;
        foreach (var kind in Enum.GetValues<ToolKind>()) _tools[kind] = Create(kind);
        _current = _tools[ToolKind.Brush];
    }

    public ToolContext Context { get; }
    public ToolSettings Settings => Context.Settings;
    public ITool Current => _current;
    public ToolKind CurrentKind => _current.Kind;

    /// <summary>Raised after the active tool changed.</summary>
    public event Action<ToolKind>? ToolChanged;

    private ITool Create(ToolKind kind) => kind switch
    {
        ToolKind.Brush or ToolKind.Pencil or ToolKind.Eraser => new BrushTool(Context, kind),
        ToolKind.Line or ToolKind.Rectangle or ToolKind.Ellipse => new ShapeTool(Context, kind),
        ToolKind.Fill => new FillTool(Context),
        ToolKind.Eyedropper => new EyedropperTool(Context),
        ToolKind.Select => new SelectTool(Context),
        ToolKind.Move => new MoveTool(Context),
        _ => new ViewTool(Context, kind)
    };

    public ITool Get(ToolKind kind) => _tools[kind];

    public void Select(ToolKind kind)
    {
        if (kind == _current.Kind) return;
        _current.Cancel();
        _current = _tools[kind];
        ToolChanged?.Invoke(kind);
    }

    /// <summary>The document this manager's tools draw on changed (a project was opened or created).</summary>
    public void SetDocument(Document document)
    {
        _current.Cancel();
        Context.Document = document;
    }

    public bool IsDrawing => _current.IsActive;

    public void PointerDown(PointerInput p) => _current.PointerDown(p);
    public void PointerMove(PointerInput p) => _current.PointerMove(p);
    public void PointerUp(PointerInput p) => _current.PointerUp(p);
    public void Cancel() => _current.Cancel();
}
