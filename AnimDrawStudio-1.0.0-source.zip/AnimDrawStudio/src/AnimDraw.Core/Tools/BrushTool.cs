using AnimDraw.Core.Drawing;
using AnimDraw.Core.Editing;

namespace AnimDraw.Core.Tools;

/// <summary>Freehand painting: the brush, the pixel pencil and the eraser.</summary>
public sealed class BrushTool : ToolBase
{
    private readonly ToolKind _kind;
    private EditSession? _session;
    private BrushStroke? _stroke;
    private string _undoName = "Brush";
    private StrokePoint _lastEnd;
    private bool _hasLastEnd;

    public BrushTool(ToolContext context, ToolKind kind) : base(context)
    {
        if (kind is not (ToolKind.Brush or ToolKind.Pencil or ToolKind.Eraser))
            throw new ArgumentException("Not a freehand tool", nameof(kind));
        _kind = kind;
    }

    public override ToolKind Kind => _kind;

    public override string DisplayName => _kind switch
    {
        ToolKind.Pencil => "Pencil",
        ToolKind.Eraser => "Eraser",
        _ => "Brush"
    };

    public override void PointerDown(PointerInput p)
    {
        if (IsActive) Cancel();
        _session = BeginEditOrExplain();
        if (_session == null) return;

        // The flipped end of a pen erases, whatever tool is selected.
        bool erase = _kind == ToolKind.Eraser || p.Inverted;
        var settings = erase ? Settings.Eraser : _kind == ToolKind.Pencil ? Settings.Pencil : Settings.Brush;
        settings.Normalize();
        _undoName = erase ? "Erase" : DisplayName;

        _stroke = new BrushStroke(_session, settings, ColorFor(p), erase);
        var start = p.ToStroke();
        if (p.Shift && _hasLastEnd)
        {
            _stroke.Begin(_lastEnd);
            _stroke.LineTo(start);
        }
        else
        {
            _stroke.Begin(start);
        }
        _session.TakeDirty();
        IsActive = true;
    }

    public override void PointerMove(PointerInput p)
    {
        if (!IsActive || _stroke == null || _session == null) return;
        _stroke.Add(p.ToStroke());
        _session.TakeDirty();
    }

    public override void PointerUp(PointerInput p)
    {
        if (!IsActive || _stroke == null || _session == null) return;
        _stroke.Add(p.ToStroke());
        _stroke.End();
        _session.TakeDirty();
        _lastEnd = p.ToStroke();
        _hasLastEnd = true;
        _session.Commit(_undoName);
        Reset();
    }

    public override void Cancel()
    {
        if (!IsActive) return;
        _session?.Cancel();
        Reset();
    }

    private void Reset()
    {
        _session = null;
        _stroke = null;
        IsActive = false;
    }
}
