using AnimDraw.Core.Drawing;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Imaging;

namespace AnimDraw.Core.Tools;

/// <summary>Straight line, rectangle and ellipse. The shape is redrawn live while dragging.</summary>
public sealed class ShapeTool : ToolBase
{
    private readonly ToolKind _kind;
    private EditSession? _session;
    private StrokeBuffer? _scratch;
    private PointerInput _start;
    private PointerInput _current;

    public ShapeTool(ToolContext context, ToolKind kind) : base(context)
    {
        if (kind is not (ToolKind.Line or ToolKind.Rectangle or ToolKind.Ellipse))
            throw new ArgumentException("Not a shape tool", nameof(kind));
        _kind = kind;
    }

    public override ToolKind Kind => _kind;

    public override string DisplayName => _kind switch
    {
        ToolKind.Line => "Line",
        ToolKind.Rectangle => "Rectangle",
        _ => "Ellipse"
    };

    public override void PointerDown(PointerInput p)
    {
        if (IsActive) Cancel();
        _session = BeginEditOrExplain();
        if (_session == null) return;
        _scratch = new StrokeBuffer(_session.Surface.Width, _session.Surface.Height);
        _start = _current = p;
        IsActive = true;
        Render();
    }

    public override void PointerMove(PointerInput p)
    {
        if (!IsActive) return;
        _current = p;
        Render();
    }

    public override void PointerUp(PointerInput p)
    {
        if (!IsActive || _session == null) return;
        _current = p;
        float dx = _current.X - _start.X, dy = _current.Y - _start.Y;
        if (dx * dx + dy * dy < 1f)
        {
            Cancel();
            return;
        }
        Render();
        _session.Commit(DisplayName);
        Reset();
    }

    public override void Cancel()
    {
        if (!IsActive) return;
        _session?.Cancel();
        Reset();
    }

    private void Reset()
    {
        _session = null;
        _scratch = null;
        IsActive = false;
    }

    private void Render()
    {
        var session = _session!;
        session.Revert();

        var style = _kind == ToolKind.Line ? ShapeStyle.Outline : Settings.ShapeStyle;
        double width = Math.Clamp(Settings.ShapeLineWidth, 1, 200);
        bool oddWidth = ((int)Math.Round(width) & 1) == 1;

        // Whole-pixel alignment keeps thin lines and filled edges crisp.
        float Snap(float v, bool half) => half ? MathF.Floor(v) + 0.5f : MathF.Round(v);
        bool halfPixel = oddWidth && style != ShapeStyle.Filled;

        float x0 = Snap(_start.X, halfPixel), y0 = Snap(_start.Y, halfPixel);
        float x1 = Snap(_current.X, halfPixel), y1 = Snap(_current.Y, halfPixel);

        var primary = ColorFor(_start);
        var other = _start.Secondary ? Settings.PrimaryColor : Settings.SecondaryColor;

        var outline = new BrushSettings
        {
            Size = width,
            Hardness = 1,
            Opacity = 1,
            Spacing = 0.1,
            PressureAffectsSize = false,
            Smoothing = 0,
            Antialias = true
        };

        if (_kind == ToolKind.Line)
        {
            if (_current.Shift) (x1, y1) = SnapAngle(x0, y0, x1, y1);
            var stroke = new BrushStroke(session, outline, primary, false, _scratch);
            stroke.Begin(new StrokePoint(x0, y0));
            stroke.LineTo(new StrokePoint(x1, y1));
            session.TakeDirty();
            return;
        }

        // Bounding box, with Shift = square/circle and Alt = grow from the centre.
        float dx = x1 - x0, dy = y1 - y0;
        if (_current.Shift)
        {
            float m = MathF.Max(MathF.Abs(dx), MathF.Abs(dy));
            dx = dx < 0 ? -m : m;
            dy = dy < 0 ? -m : m;
        }
        float left, top, right, bottom;
        if (_current.Alt)
        {
            left = x0 - dx; right = x0 + dx;
            top = y0 - dy; bottom = y0 + dy;
        }
        else
        {
            left = x0; right = x0 + dx;
            top = y0; bottom = y0 + dy;
        }
        if (right < left) (left, right) = (right, left);
        if (bottom < top) (top, bottom) = (bottom, top);

        Func<int, Tile?>? under = null;
        if (style != ShapeStyle.Outline)
        {
            var fillColor = style == ShapeStyle.Filled ? primary : other;
            var fill = new BrushStroke(session, outline, fillColor, false, _scratch);
            if (_kind == ToolKind.Rectangle) fill.FillRectCoverage(left, top, right, bottom);
            else fill.FillEllipseCoverage((left + right) / 2, (top + bottom) / 2, (right - left) / 2, (bottom - top) / 2);

            if (style == ShapeStyle.OutlineAndFill)
            {
                // The outline must be composited over the fill, not over the original pixels.
                var snapshot = new Dictionary<int, Tile?>();
                foreach (int index in session.Recorder.Indices)
                {
                    var tile = session.Surface.GetTile(index);
                    if (tile != null) tile.Frozen = true;
                    snapshot[index] = tile;
                }
                var recorder = session.Recorder;
                under = index => snapshot.TryGetValue(index, out var t) ? t : recorder.GetOriginal(index);
            }
        }

        if (style != ShapeStyle.Filled)
        {
            var stroke = new BrushStroke(session, outline, primary, false, _scratch, under);
            if (_kind == ToolKind.Rectangle)
            {
                stroke.Begin(new StrokePoint(left, top));
                stroke.LineTo(new StrokePoint(right, top));
                stroke.LineTo(new StrokePoint(right, bottom));
                stroke.LineTo(new StrokePoint(left, bottom));
                stroke.LineTo(new StrokePoint(left, top));
            }
            else
            {
                float cx = (left + right) / 2, cy = (top + bottom) / 2;
                float rx = (right - left) / 2, ry = (bottom - top) / 2;
                int n = Math.Clamp((int)(MathF.PI * MathF.Max(rx, ry)), 32, 1024);
                stroke.Begin(new StrokePoint(cx + rx, cy));
                for (int i = 1; i <= n; i++)
                {
                    float a = i * (MathF.PI * 2f / n);
                    stroke.LineTo(new StrokePoint(cx + rx * MathF.Cos(a), cy + ry * MathF.Sin(a)));
                }
            }
        }
        session.TakeDirty();
    }

    private static (float X, float Y) SnapAngle(float x0, float y0, float x1, float y1)
    {
        float dx = x1 - x0, dy = y1 - y0;
        float len = MathF.Sqrt(dx * dx + dy * dy);
        if (len < 0.001f) return (x1, y1);
        float step = MathF.PI / 4f;
        float angle = MathF.Round(MathF.Atan2(dy, dx) / step) * step;
        return (x0 + MathF.Cos(angle) * len, y0 + MathF.Sin(angle) * len);
    }
}
