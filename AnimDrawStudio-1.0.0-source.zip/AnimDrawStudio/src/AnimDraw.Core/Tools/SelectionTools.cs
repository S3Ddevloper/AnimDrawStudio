using AnimDraw.Core.Editing;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;

namespace AnimDraw.Core.Tools;

/// <summary>Rectangular selection. A plain click clears the selection.</summary>
public sealed class SelectTool : ToolBase
{
    private PointerInput _start;
    private bool _dragged;

    public SelectTool(ToolContext context) : base(context) { }

    public override ToolKind Kind => ToolKind.Select;
    public override string DisplayName => "Select";

    public override void PointerDown(PointerInput p)
    {
        _start = p;
        _dragged = false;
        IsActive = true;
    }

    public override void PointerMove(PointerInput p)
    {
        if (!IsActive) return;
        float dx = p.X - _start.X, dy = p.Y - _start.Y;
        if (!_dragged && dx * dx + dy * dy < 4f) return;
        _dragged = true;

        int x0 = (int)MathF.Round(_start.X), y0 = (int)MathF.Round(_start.Y);
        int x1 = (int)MathF.Round(p.X), y1 = (int)MathF.Round(p.Y);
        if (p.Shift)
        {
            int size = Math.Max(Math.Abs(x1 - x0), Math.Abs(y1 - y0));
            x1 = x0 + (x1 < x0 ? -size : size);
            y1 = y0 + (y1 < y0 ? -size : size);
        }
        var rect = IntRect.FromLTRB(Math.Min(x0, x1), Math.Min(y0, y1), Math.Max(x0, x1), Math.Max(y0, y1));
        Document.SelectRect(rect);
    }

    public override void PointerUp(PointerInput p)
    {
        if (!IsActive) return;
        PointerMove(p);
        if (!_dragged) Document.Deselect();
        IsActive = false;
    }

    public override void Cancel() => IsActive = false;
}

/// <summary>
/// Drags the selected artwork (or the whole drawing when nothing is selected). Hold Alt to drag a copy,
/// Shift to keep to one axis. The whole drag is one undo step.
/// </summary>
public sealed class MoveTool : ToolBase
{
    private EditSession? _session;
    private IntRect _region;
    private PixelBuffer? _lifted;
    private PointerInput _start;
    private bool _hadSelection;
    private bool _copy;
    private int _dx, _dy;

    public MoveTool(ToolContext context) : base(context) { }

    public override ToolKind Kind => ToolKind.Move;
    public override string DisplayName => "Move";

    public override void PointerDown(PointerInput p)
    {
        if (IsActive) Cancel();
        var doc = Document;
        if (doc.PeekActiveCel() == null)
        {
            Context.Notify("There is nothing drawn on this layer at this frame.");
            return;
        }

        _hadSelection = doc.Selection != null;
        _region = doc.Selection ?? doc.CanvasBounds;
        _session = BeginEditOrExplain();
        if (_session == null) return;

        _lifted = _session.Surface.ReadRegion(_region);
        if (_lifted.IsBlank())
        {
            _session.Cancel();
            _session = null;
            Context.Notify("Nothing to move in the selection.");
            return;
        }

        _copy = p.Alt;
        _start = p;
        _dx = _dy = 0;
        IsActive = true;
    }

    public override void PointerMove(PointerInput p)
    {
        if (!IsActive) return;
        int dx = (int)MathF.Round(p.X - _start.X);
        int dy = (int)MathF.Round(p.Y - _start.Y);
        if (p.Shift)
        {
            if (Math.Abs(dx) >= Math.Abs(dy)) dy = 0; else dx = 0;
        }
        if (dx == _dx && dy == _dy) return;
        _dx = dx;
        _dy = dy;
        Render();
    }

    public override void PointerUp(PointerInput p)
    {
        if (!IsActive || _session == null) return;
        PointerMove(p);
        var moved = _region.Offset(_dx, _dy);
        _session.Commit(_copy ? "Copy Move" : "Move");
        if (_hadSelection) Document.SelectRect(moved);
        Reset();
    }

    public override void Cancel()
    {
        if (!IsActive) return;
        _session?.Cancel();
        Reset();
    }

    private void Reset()
    {
        _session = null;
        _lifted = null;
        IsActive = false;
    }

    private void Render()
    {
        var session = _session!;
        session.Revert();
        var surface = session.Surface;
        if (!_copy) surface.ClearRect(_region, session.Recorder);
        var target = _region.Offset(_dx, _dy);
        surface.BlendBuffer(_lifted!, target.X, target.Y, session.Recorder);
        session.AddDirty(_region);
        session.AddDirty(target);
        session.TakeDirty();
        if (_hadSelection) Document.SelectRect(target);
    }
}
