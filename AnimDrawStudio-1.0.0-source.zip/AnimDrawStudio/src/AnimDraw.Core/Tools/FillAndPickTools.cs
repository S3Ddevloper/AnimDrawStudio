using AnimDraw.Core.Drawing;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.Rendering;

namespace AnimDraw.Core.Tools;

/// <summary>Paint bucket.</summary>
public sealed class FillTool : ToolBase
{
    public FillTool(ToolContext context) : base(context) { }

    public override ToolKind Kind => ToolKind.Fill;
    public override string DisplayName => "Fill";

    public override void PointerDown(PointerInput p)
    {
        int x = (int)MathF.Floor(p.X), y = (int)MathF.Floor(p.Y);
        var doc = Document;
        if (!doc.CanvasBounds.Contains(x, y)) return;

        var session = BeginEditOrExplain();
        if (session == null) return;

        try
        {
            var options = Settings.Fill;
            PixelBuffer source;
            if (options.SampleAllLayers)
            {
                source = Compositor.ComposeFrame(doc.Project, doc.CurrentFrame, withBackground: false);
            }
            else
            {
                source = session.Surface.ToBuffer();
            }

            var mask = FloodFill.ComputeMask(source.Pixels, source.Width, source.Height, x, y,
                options.Tolerance, options.Contiguous, session.Clip, out var bounds);
            if (mask == null)
            {
                session.Cancel();
                return;
            }

            var color = ColorFor(p);
            FloodFill.Apply(session, mask, bounds, color.ToPremultiplied(), options.Grow);
            session.TakeDirty();
            session.Commit("Fill");
        }
        catch
        {
            session.Cancel();
            throw;
        }
    }

    public override void PointerMove(PointerInput p) { }
    public override void PointerUp(PointerInput p) { }
    public override void Cancel() { }
}

/// <summary>Picks a colour from the artwork. Click or drag; right button picks the secondary colour.</summary>
public sealed class EyedropperTool : ToolBase
{
    private bool _secondary;

    public EyedropperTool(ToolContext context) : base(context) { }

    public override ToolKind Kind => ToolKind.Eyedropper;
    public override string DisplayName => "Eyedropper";

    public override void PointerDown(PointerInput p)
    {
        IsActive = true;
        _secondary = p.Secondary;
        Sample(p);
    }

    public override void PointerMove(PointerInput p)
    {
        if (IsActive) Sample(p);
    }

    public override void PointerUp(PointerInput p)
    {
        if (IsActive) Sample(p);
        IsActive = false;
    }

    public override void Cancel() => IsActive = false;

    private void Sample(PointerInput p)
    {
        int x = (int)MathF.Floor(p.X), y = (int)MathF.Floor(p.Y);
        var doc = Document;
        if (!doc.CanvasBounds.Contains(x, y)) return;

        uint pixel = Settings.EyedropperSampleAllLayers && !p.Alt
            ? Compositor.SamplePixel(doc.Project, doc.CurrentFrame, x, y, withBackground: true)
            : doc.PeekActiveCel()?.Surface.GetPixel(x, y) ?? 0u;

        if (Px.A(pixel) == 0) return;
        var c = ArgbColor.FromPremultiplied(pixel);
        // Keep the alpha the user had chosen only when sampling fully opaque colours.
        Context.ColorPicked(c, _secondary);
    }
}
