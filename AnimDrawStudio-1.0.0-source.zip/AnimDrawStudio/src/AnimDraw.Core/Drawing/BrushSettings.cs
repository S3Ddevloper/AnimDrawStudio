namespace AnimDraw.Core.Drawing;

/// <summary>Everything that shapes a brush, pencil or eraser stroke.</summary>
public sealed class BrushSettings
{
    public const double MinSize = 1;
    public const double MaxSize = 500;

    /// <summary>Diameter in canvas pixels.</summary>
    public double Size { get; set; } = 12;

    /// <summary>0 = very soft edge, 1 = crisp edge.</summary>
    public double Hardness { get; set; } = 0.85;

    /// <summary>Opacity of the whole stroke, 0 to 1. Overlapping dabs inside one stroke never build up beyond it.</summary>
    public double Opacity { get; set; } = 1.0;

    /// <summary>Distance between dabs as a fraction of the brush diameter.</summary>
    public double Spacing { get; set; } = 0.1;

    /// <summary>Pen pressure changes the brush size.</summary>
    public bool PressureAffectsSize { get; set; } = true;

    /// <summary>Pen pressure changes the stroke opacity.</summary>
    public bool PressureAffectsOpacity { get; set; }

    /// <summary>Stabilizer: 0 follows the pointer exactly, values near 1 trail behind it and smooth wobbles.</summary>
    public double Smoothing { get; set; } = 0.25;

    /// <summary>Soft anti-aliased dabs (brush, eraser) or hard aliased pixels (pencil).</summary>
    public bool Antialias { get; set; } = true;

    /// <summary>Snap dabs to whole pixels for crisp pixel-art lines (pencil).</summary>
    public bool SnapToPixels { get; set; }

    public BrushSettings Clone() => (BrushSettings)MemberwiseClone();

    public void Normalize()
    {
        Size = Clamp(Size, MinSize, MaxSize, 12);
        Hardness = Clamp(Hardness, 0, 1, 0.85);
        Opacity = Clamp(Opacity, 0.01, 1, 1);
        Spacing = Clamp(Spacing, 0.02, 1, 0.1);
        Smoothing = Clamp(Smoothing, 0, 0.95, 0);
    }

    private static double Clamp(double v, double lo, double hi, double fallback) =>
        double.IsNaN(v) || double.IsInfinity(v) ? fallback : Math.Clamp(v, lo, hi);

    public static BrushSettings CreateBrush() => new();

    public static BrushSettings CreatePencil() => new()
    {
        Size = 2,
        Hardness = 1,
        Opacity = 1,
        Spacing = 0.2,
        PressureAffectsSize = false,
        Smoothing = 0,
        Antialias = false,
        SnapToPixels = true
    };

    public static BrushSettings CreateEraser() => new()
    {
        Size = 24,
        Hardness = 1,
        Opacity = 1,
        Spacing = 0.1,
        PressureAffectsSize = true,
        Smoothing = 0.15
    };
}
