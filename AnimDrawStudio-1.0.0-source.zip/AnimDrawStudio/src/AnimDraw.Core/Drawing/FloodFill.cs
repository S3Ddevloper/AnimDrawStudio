using AnimDraw.Core.Editing;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;

namespace AnimDraw.Core.Drawing;

public sealed class FillOptions
{
    /// <summary>How different (0-255, per channel) a pixel may be from the clicked pixel and still be filled.</summary>
    public int Tolerance { get; set; } = 32;

    /// <summary>Pixels to spread the fill under neighbouring line art so no light fringe is left (0-4).</summary>
    public int Grow { get; set; } = 1;

    /// <summary>Fill only the connected area (true) or every matching pixel on the canvas (false).</summary>
    public bool Contiguous { get; set; } = true;

    /// <summary>Decide the area from all visible layers instead of only the active layer.</summary>
    public bool SampleAllLayers { get; set; }

    public FillOptions Clone() => (FillOptions)MemberwiseClone();
}

/// <summary>Scanline flood fill with tolerance and edge growth.</summary>
public static class FloodFill
{
    /// <summary>
    /// Finds the area to fill. <paramref name="source"/> holds the pixels that decide the area (one row after another,
    /// <paramref name="width"/> pixels per row). Returns a mask (1 = filled) or null if the seed is outside the clip.
    /// </summary>
    public static byte[]? ComputeMask(uint[] source, int width, int height, int seedX, int seedY,
        int tolerance, bool contiguous, IntRect clip, out IntRect bounds)
    {
        bounds = IntRect.Empty;
        clip = clip.Intersect(new IntRect(0, 0, width, height));
        if (!clip.Contains(seedX, seedY)) return null;

        uint seed = source[seedY * width + seedX];
        tolerance = Math.Clamp(tolerance, 0, 255);
        var mask = new byte[width * height];

        bool Match(int x, int y) => Px.MaxChannelDiff(source[y * width + x], seed) <= tolerance;

        int minX = width, minY = height, maxX = -1, maxY = -1;
        void Mark(int y, int x0, int x1)
        {
            Array.Fill(mask, (byte)1, y * width + x0, x1 - x0 + 1);
            if (x0 < minX) minX = x0;
            if (x1 > maxX) maxX = x1;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        }

        if (!contiguous)
        {
            for (int y = clip.Y; y < clip.Bottom; y++)
            for (int x = clip.X; x < clip.Right; x++)
                if (Match(x, y)) Mark(y, x, x);
        }
        else
        {
            var stack = new Stack<(int X, int Y)>();
            stack.Push((seedX, seedY));
            while (stack.Count > 0)
            {
                var (x, y) = stack.Pop();
                if (mask[y * width + x] != 0 || !Match(x, y)) continue;

                int left = x, right = x;
                while (left > clip.X && mask[y * width + left - 1] == 0 && Match(left - 1, y)) left--;
                while (right < clip.Right - 1 && mask[y * width + right + 1] == 0 && Match(right + 1, y)) right++;
                Mark(y, left, right);

                for (int ny = y - 1; ny <= y + 1; ny += 2)
                {
                    if (ny < clip.Y || ny >= clip.Bottom) continue;
                    bool inRun = false;
                    for (int nx = left; nx <= right; nx++)
                    {
                        bool ok = mask[ny * width + nx] == 0 && Match(nx, ny);
                        if (ok && !inRun) stack.Push((nx, ny));
                        inRun = ok;
                    }
                }
            }
        }

        if (maxX < 0) return null;
        bounds = IntRect.FromLTRB(minX, minY, maxX + 1, maxY + 1);
        return mask;
    }

    /// <summary>Fills the area found by <see cref="ComputeMask"/> in an edit session. Returns the changed rectangle.</summary>
    public static IntRect Apply(EditSession session, byte[] mask, IntRect bounds, uint fillPixel, int grow)
    {
        var surface = session.Surface;
        int w = surface.Width, h = surface.Height;
        grow = Math.Clamp(grow, 0, 4);
        var area = bounds.Inflate(grow, grow).Intersect(session.Clip);
        if (area.IsEmpty) return IntRect.Empty;

        // Grow the mask outward in rings so the colour slides under anti-aliased line edges.
        byte[]? ring = null;
        if (grow > 0)
        {
            ring = new byte[w * h];
            var current = (byte[])mask.Clone();
            for (int step = 0; step < grow; step++)
            {
                var next = (byte[])current.Clone();
                for (int y = area.Y; y < area.Bottom; y++)
                for (int x = area.X; x < area.Right; x++)
                {
                    int i = y * w + x;
                    if (current[i] != 0) continue;
                    if ((x > 0 && current[i - 1] != 0) || (x < w - 1 && current[i + 1] != 0) ||
                        (y > 0 && current[i - w] != 0) || (y < h - 1 && current[i + w] != 0))
                    {
                        next[i] = 1;
                        ring[i] = 1;
                    }
                }
                current = next;
            }
        }

        var dirty = IntRect.Empty;
        surface.TryGetTileRange(area, out int tx0, out int ty0, out int tx1, out int ty1);
        for (int ty = ty0; ty <= ty1; ty++)
        for (int tx = tx0; tx <= tx1; tx++)
        {
            int index = surface.TileIndex(tx, ty);
            var part = surface.TileBounds(index).Intersect(area).Intersect(session.Clip);
            if (part.IsEmpty) continue;

            bool touches = false;
            for (int y = part.Y; y < part.Bottom && !touches; y++)
            for (int x = part.X; x < part.Right; x++)
            {
                int i = y * w + x;
                if (mask[i] != 0 || (ring != null && ring[i] != 0)) { touches = true; break; }
            }
            if (!touches) continue;

            var tile = surface.GetTileForWrite(index, session.Recorder);
            for (int y = part.Y; y < part.Bottom; y++)
            {
                int row = (y & Tile.Mask) << Tile.Shift;
                for (int x = part.X; x < part.Right; x++)
                {
                    int i = y * w + x;
                    int t = row | (x & Tile.Mask);
                    if (mask[i] != 0) tile.Data[t] = fillPixel;
                    else if (ring != null && ring[i] != 0) tile.Data[t] = Px.SourceOver(fillPixel, tile.Data[t]);
                }
            }
            dirty = dirty.Union(part);
        }

        session.AddDirty(dirty);
        return dirty;
    }
}
