using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;

namespace AnimDraw.Core.Drawing;

/// <summary>
/// Accumulates the coverage (0-255) of a stroke or shape. Dabs merge with "max", so a stroke that crosses
/// itself keeps a uniform opacity. The grid lines up with <see cref="TiledSurface"/> tiles.
/// </summary>
public sealed class StrokeBuffer
{
    private readonly byte[]?[] _tiles;
    private readonly bool[] _inUse;
    private readonly List<int> _used = new();

    public int Width { get; }
    public int Height { get; }
    public int TilesX { get; }
    public int TilesY { get; }

    public StrokeBuffer(int width, int height)
    {
        Width = width;
        Height = height;
        TilesX = (width + Tile.Size - 1) >> Tile.Shift;
        TilesY = (height + Tile.Size - 1) >> Tile.Shift;
        _tiles = new byte[]?[TilesX * TilesY];
        _inUse = new bool[TilesX * TilesY];
    }

    public byte[]? GetTile(int index) => _tiles[index];

    public byte Get(int x, int y)
    {
        if ((uint)x >= (uint)Width || (uint)y >= (uint)Height) return 0;
        var t = _tiles[(y >> Tile.Shift) * TilesX + (x >> Tile.Shift)];
        return t == null ? (byte)0 : t[((y & Tile.Mask) << Tile.Shift) | (x & Tile.Mask)];
    }

    /// <summary>Forgets all coverage but keeps the tile arrays for reuse.</summary>
    public void Clear()
    {
        foreach (int i in _used)
        {
            Array.Clear(_tiles[i]!);
            _inUse[i] = false;
        }
        _used.Clear();
    }

    private byte[] TileFor(int index)
    {
        var t = _tiles[index];
        if (t == null) { t = new byte[Tile.PixelCount]; _tiles[index] = t; }
        if (!_inUse[index]) { _inUse[index] = true; _used.Add(index); }
        return t;
    }

    /// <summary>
    /// Adds a round dab. Coverage never decreases. <paramref name="strength"/> (0-255) scales the dab, which is
    /// how pen pressure changes opacity. Returns the pixels that may have changed.
    /// </summary>
    public IntRect StampCircle(float cx, float cy, float radius, float hardness, bool antialias, int strength, IntRect clip)
    {
        if (strength <= 0) return IntRect.Empty;
        float outer = antialias ? radius + 0.5f : radius;
        var box = IntRect.FromLTRB((int)MathF.Floor(cx - outer), (int)MathF.Floor(cy - outer),
                                   (int)MathF.Ceiling(cx + outer), (int)MathF.Ceiling(cy + outer))
            .Intersect(clip).Intersect(new IntRect(0, 0, Width, Height));
        if (box.IsEmpty) return IntRect.Empty;

        float inner = antialias ? MathF.Max(0f, MathF.Min(radius * hardness, radius - 0.5f)) : radius;
        float invBand = antialias ? 1f / MathF.Max(0.0001f, outer - inner) : 0f;
        bool smooth = antialias && hardness < 0.999f;
        float outer2 = outer * outer;

        for (int y = box.Y; y < box.Bottom; y++)
        {
            float dy = y + 0.5f - cy;
            float dy2 = dy * dy;
            if (dy2 > outer2) continue;
            int ty = y >> Tile.Shift;
            int rowInTile = (y & Tile.Mask) << Tile.Shift;
            int curTx = -1;
            byte[] cur = null!;
            for (int x = box.X; x < box.Right; x++)
            {
                float dx = x + 0.5f - cx;
                float d2 = dx * dx + dy2;
                if (d2 > outer2) continue;

                int a;
                if (!antialias)
                {
                    a = strength;
                }
                else
                {
                    float d = MathF.Sqrt(d2);
                    float f = d <= inner ? 1f : (outer - d) * invBand;
                    if (f <= 0f) continue;
                    if (smooth) f = f * f * (3f - 2f * f);
                    a = (int)(f * strength + 0.5f);
                    if (a <= 0) continue;
                }

                int txNow = x >> Tile.Shift;
                if (txNow != curTx) { curTx = txNow; cur = TileFor(ty * TilesX + txNow); }
                int i = rowInTile | (x & Tile.Mask);
                if (cur[i] < a) cur[i] = (byte)a;
            }
        }
        return box;
    }

    /// <summary>Adds an axis-aligned filled rectangle with anti-aliased edges.</summary>
    public IntRect FillRect(float left, float top, float right, float bottom, int strength, IntRect clip)
    {
        if (right < left) (left, right) = (right, left);
        if (bottom < top) (top, bottom) = (bottom, top);
        var box = IntRect.FromLTRB((int)MathF.Floor(left), (int)MathF.Floor(top), (int)MathF.Ceiling(right), (int)MathF.Ceiling(bottom))
            .Intersect(clip).Intersect(new IntRect(0, 0, Width, Height));
        if (box.IsEmpty || strength <= 0) return IntRect.Empty;

        for (int y = box.Y; y < box.Bottom; y++)
        {
            float cy = MathF.Min(y + 1, bottom) - MathF.Max(y, top);
            if (cy <= 0) continue;
            for (int x = box.X; x < box.Right; x++)
            {
                float cx = MathF.Min(x + 1, right) - MathF.Max(x, left);
                if (cx <= 0) continue;
                int a = (int)(cx * cy * strength + 0.5f);
                if (a <= 0) continue;
                var tile = TileFor((y >> Tile.Shift) * TilesX + (x >> Tile.Shift));
                int i = ((y & Tile.Mask) << Tile.Shift) | (x & Tile.Mask);
                if (tile[i] < a) tile[i] = (byte)a;
            }
        }
        return box;
    }

    /// <summary>Adds a filled ellipse with anti-aliased edges.</summary>
    public IntRect FillEllipse(float cx, float cy, float rx, float ry, int strength, IntRect clip)
    {
        rx = MathF.Max(0.01f, rx);
        ry = MathF.Max(0.01f, ry);
        var box = IntRect.FromLTRB((int)MathF.Floor(cx - rx - 1), (int)MathF.Floor(cy - ry - 1),
                                   (int)MathF.Ceiling(cx + rx + 1), (int)MathF.Ceiling(cy + ry + 1))
            .Intersect(clip).Intersect(new IntRect(0, 0, Width, Height));
        if (box.IsEmpty || strength <= 0) return IntRect.Empty;

        for (int y = box.Y; y < box.Bottom; y++)
        {
            float dy = y + 0.5f - cy;
            for (int x = box.X; x < box.Right; x++)
            {
                float dx = x + 0.5f - cx;
                float nx = dx / rx, ny = dy / ry;
                float k = MathF.Sqrt(nx * nx + ny * ny);
                // First-order distance estimate to the ellipse boundary, in pixels (negative inside).
                float gx = nx / rx, gy = ny / ry;
                float grad = MathF.Sqrt(gx * gx + gy * gy);
                float dist = grad < 1e-6f ? -MathF.Min(rx, ry) : (k - 1f) / grad;
                float f = Math.Clamp(0.5f - dist, 0f, 1f);
                if (f <= 0f) continue;
                int a = (int)(f * strength + 0.5f);
                if (a <= 0) continue;
                var tile = TileFor((y >> Tile.Shift) * TilesX + (x >> Tile.Shift));
                int i = ((y & Tile.Mask) << Tile.Shift) | (x & Tile.Mask);
                if (tile[i] < a) tile[i] = (byte)a;
            }
        }
        return box;
    }
}
