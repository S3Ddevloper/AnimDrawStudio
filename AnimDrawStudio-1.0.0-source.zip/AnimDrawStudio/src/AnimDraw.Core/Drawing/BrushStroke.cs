using AnimDraw.Core.Editing;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;

namespace AnimDraw.Core.Drawing;

/// <summary>A pointer position in canvas pixels with pen pressure (1.0 for a mouse).</summary>
public readonly record struct StrokePoint(float X, float Y, float Pressure = 1f)
{
    public static StrokePoint Lerp(StrokePoint a, StrokePoint b, float t) =>
        new(a.X + (b.X - a.X) * t, a.Y + (b.Y - a.Y) * t, a.Pressure + (b.Pressure - a.Pressure) * t);

    public static float Distance(StrokePoint a, StrokePoint b)
    {
        float dx = b.X - a.X, dy = b.Y - a.Y;
        return MathF.Sqrt(dx * dx + dy * dy);
    }
}

/// <summary>
/// Paints (or erases) one stroke into an <see cref="EditSession"/>. Dabs are accumulated in a coverage
/// buffer and composited over the pixels that were there when the stroke began, so the brush opacity
/// applies to the stroke as a whole.
/// </summary>
public sealed class BrushStroke
{
    private readonly EditSession _session;
    private readonly BrushSettings _brush;
    private readonly bool _erase;
    private readonly StrokeBuffer _coverage;
    private readonly uint _opaqueColor;
    private readonly int _baseAlpha;
    private readonly IntRect _clip;

    private bool _started;
    private StrokePoint _filtered;
    private StrokePoint _prev;       // previous (filtered) input point, the Bezier control point
    private StrokePoint _segStart;   // start of the next curve segment (a midpoint)
    private StrokePoint _lastRaw;
    private StrokePoint _penDown;
    private int _inputCount;
    private float _toNextDab;

    private readonly Func<int, Tile?>? _under;

    /// <param name="reuse">A coverage buffer to recycle (cleared here) so repeated shape previews do not allocate.</param>
    /// <param name="under">Supplies the pixels a tile held before this pass; defaults to the tiles from before the whole edit.</param>
    public BrushStroke(EditSession session, BrushSettings brush, ArgbColor color, bool erase,
        StrokeBuffer? reuse = null, Func<int, Tile?>? under = null)
    {
        _session = session;
        _brush = brush;
        _erase = erase;
        _under = under;
        _clip = session.Clip;
        _coverage = reuse ?? new StrokeBuffer(session.Surface.Width, session.Surface.Height);
        if (reuse != null) reuse.Clear();
        _opaqueColor = Px.Pack(255, color.R, color.G, color.B);
        double alpha = brush.Opacity * (erase ? 1.0 : color.A / 255.0);
        _baseAlpha = Math.Clamp((int)Math.Round(alpha * 255), 1, 255);
    }

    public IntRect Dirty => _session.Dirty;

    /// <summary>Starts the stroke with a dab at the pointer position.</summary>
    public void Begin(StrokePoint p)
    {
        _started = true;
        _filtered = _prev = _segStart = _lastRaw = _penDown = p;
        _inputCount = 1;
        Stamp(p.X, p.Y, p.Pressure);
        _toNextDab = DabSpacing(p.Pressure);
    }

    /// <summary>Continues a freehand stroke; the path is stabilized and smoothed into curves.</summary>
    public void Add(StrokePoint raw)
    {
        if (!_started) { Begin(raw); return; }
        _lastRaw = raw;
        float follow = 1f - (float)_brush.Smoothing;
        _filtered = StrokePoint.Lerp(_filtered, raw, follow);

        if (_inputCount == 1)
        {
            var mid = StrokePoint.Lerp(_penDown, _filtered, 0.5f);
            Line(_penDown, mid);
            _prev = _filtered;
            _segStart = mid;
            _inputCount = 2;
            return;
        }

        var end = StrokePoint.Lerp(_prev, _filtered, 0.5f);
        Curve(_segStart, _prev, end);
        _segStart = end;
        _prev = _filtered;
        _inputCount++;
    }

    /// <summary>Draws a straight segment from the last point (shapes and straight lines).</summary>
    public void LineTo(StrokePoint p)
    {
        if (!_started) { Begin(p); return; }
        Line(_penDown, p);
        _penDown = _segStart = _prev = _filtered = _lastRaw = p;
        _inputCount = Math.Max(_inputCount, 2);
    }

    /// <summary>Finishes a freehand stroke by running the brush up to the final pointer position.</summary>
    public void End()
    {
        if (!_started) return;
        if (_inputCount >= 2)
        {
            Line(_segStart, _prev);
            if (StrokePoint.Distance(_prev, _lastRaw) > 0.01f) Line(_prev, _lastRaw);
        }
        else if (StrokePoint.Distance(_penDown, _lastRaw) > 0.01f)
        {
            Line(_penDown, _lastRaw);
        }
    }

    // ----- path walking -----

    private float DabSpacing(float pressure)
    {
        float scale = _brush.PressureAffectsSize ? Lerp(0.15f, 1f, Math.Clamp(pressure, 0f, 1f)) : 1f;
        float diameter = (float)_brush.Size * scale;
        return MathF.Max(0.5f, diameter * (float)_brush.Spacing);
    }

    private void Curve(StrokePoint s, StrokePoint control, StrokePoint e)
    {
        float chord = StrokePoint.Distance(s, control) + StrokePoint.Distance(control, e);
        int steps = Math.Clamp((int)MathF.Ceiling(chord / 2f), 1, 400);
        var last = s;
        for (int i = 1; i <= steps; i++)
        {
            float t = i / (float)steps, u = 1 - t;
            var p = new StrokePoint(
                u * u * s.X + 2 * u * t * control.X + t * t * e.X,
                u * u * s.Y + 2 * u * t * control.Y + t * t * e.Y,
                u * u * s.Pressure + 2 * u * t * control.Pressure + t * t * e.Pressure);
            Line(last, p);
            last = p;
        }
    }

    /// <summary>Places dabs along a straight piece, carrying the spacing over from the previous piece.</summary>
    private void Line(StrokePoint a, StrokePoint b)
    {
        float len = StrokePoint.Distance(a, b);
        if (len < 1e-4f) return;
        float d = _toNextDab;
        while (d <= len)
        {
            var p = StrokePoint.Lerp(a, b, d / len);
            Stamp(p.X, p.Y, p.Pressure);
            d += DabSpacing(p.Pressure);
        }
        _toNextDab = d - len;
    }

    private static float Lerp(float a, float b, float t) => a + (b - a) * t;

    // ----- dabs -----

    private void Stamp(float x, float y, float pressure)
    {
        pressure = Math.Clamp(float.IsNaN(pressure) ? 1f : pressure, 0f, 1f);
        float sizeScale = _brush.PressureAffectsSize ? Lerp(0.15f, 1f, pressure) : 1f;
        float radius = MathF.Max(0.25f, (float)_brush.Size * 0.5f * sizeScale);
        int strength = _brush.PressureAffectsOpacity ? (int)(255 * Lerp(0.1f, 1f, pressure)) : 255;

        if (_brush.SnapToPixels)
        {
            bool oddDiameter = ((int)MathF.Round(radius * 2f) & 1) == 1;
            if (oddDiameter) { x = MathF.Floor(x) + 0.5f; y = MathF.Floor(y) + 0.5f; }
            else { x = MathF.Round(x); y = MathF.Round(y); }
        }

        var rect = _coverage.StampCircle(x, y, radius, (float)_brush.Hardness, _brush.Antialias, strength, _clip);
        if (rect.IsEmpty) return;
        ApplyCoverage(rect);
        _session.AddDirty(rect);
    }

    /// <summary>Re-composites the covered pixels in a rectangle over their original colours.</summary>
    private void ApplyCoverage(IntRect rect)
    {
        var surface = _session.Surface;
        if (!surface.TryGetTileRange(rect, out int tx0, out int ty0, out int tx1, out int ty1)) return;
        for (int ty = ty0; ty <= ty1; ty++)
        for (int tx = tx0; tx <= tx1; tx++)
        {
            int index = surface.TileIndex(tx, ty);
            var cov = _coverage.GetTile(index);
            if (cov == null) continue;
            var part = surface.TileBounds(index).Intersect(rect);
            var tile = surface.GetTileForWrite(index, _session.Recorder);
            var original = _under != null ? _under(index) : _session.Recorder.GetOriginal(index);
            for (int y = part.Y; y < part.Bottom; y++)
            {
                int row = (y & Tile.Mask) << Tile.Shift;
                for (int x = part.X; x < part.Right; x++)
                {
                    int i = row | (x & Tile.Mask);
                    byte c = cov[i];
                    if (c == 0) continue;
                    int eff = c == 255 ? _baseAlpha : Px.Mul255(c, _baseAlpha);
                    uint under = original == null ? 0u : original.Data[i];
                    tile.Data[i] = _erase
                        ? Px.DestinationOut(under, eff)
                        : Px.SourceOver(under, Px.Scale(_opaqueColor, eff));
                }
            }
        }
    }

    // ----- used by the shape tools -----

    /// <summary>Adds filled-rectangle coverage (so a filled shape can sit under its outline).</summary>
    public void FillRectCoverage(float l, float t, float r, float b) => Apply(_coverage.FillRect(l, t, r, b, 255, _clip));

    public void FillEllipseCoverage(float cx, float cy, float rx, float ry) =>
        Apply(_coverage.FillEllipse(cx, cy, rx, ry, 255, _clip));

    private void Apply(IntRect rect)
    {
        if (rect.IsEmpty) return;
        ApplyCoverage(rect);
        _session.AddDirty(rect);
    }
}
