using System.Text.Json;
using System.Text.Json.Serialization;

namespace AnimDraw.Core.IO;

/// <summary>A problem opening or saving a file, worded so it can be shown to the user as is.</summary>
public sealed class ProjectFileException : Exception
{
    public ProjectFileException(string message) : base(message) { }
    public ProjectFileException(string message, Exception inner) : base(message, inner) { }
}

/// <summary>
/// The .animdraw container is a ZIP file:
/// <code>
/// manifest.json     format name and version
/// project.json      canvas, frame rate, layers, keyframes, settings
/// cels/00001.png    one PNG per distinct drawing, cropped to its artwork
/// preview.png       small picture of the first frame
/// </code>
/// Every drawing is stored as its own image, so layers and frames stay editable when the project is reopened.
/// </summary>
public static class ProjectFileFormat
{
    public const string FormatName = "AnimDraw";
    public const int CurrentVersion = 1;
    public const string Extension = ".animdraw";
    public const string ManifestEntry = "manifest.json";
    public const string ProjectEntry = "project.json";
    public const string PreviewEntry = "preview.png";
    public const string CelFolder = "cels/";

    public static readonly JsonSerializerOptions Json = new()
    {
        WriteIndented = false,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        PropertyNameCaseInsensitive = true,
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
        MaxDepth = 32
    };
}

internal sealed class ManifestDto
{
    public string Format { get; set; } = ProjectFileFormat.FormatName;
    public int Version { get; set; } = ProjectFileFormat.CurrentVersion;
    public string? App { get; set; }
    public string? SavedUtc { get; set; }
}

internal sealed class BackgroundDto
{
    public string Mode { get; set; } = "White";
    public string Color { get; set; } = "#FFFFFF";
}

internal sealed class OnionDto
{
    public bool Enabled { get; set; } = true;
    public int PreviousFrames { get; set; } = 1;
    public int NextFrames { get; set; } = 1;
    public double Opacity { get; set; } = 0.35;
    public bool Colorize { get; set; } = true;
}

internal sealed class CelDto
{
    public int Frame { get; set; }

    /// <summary>Path of the PNG inside the archive, or null for an empty drawing.</summary>
    public string? Image { get; set; }

    public int X { get; set; }
    public int Y { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
}

internal sealed class LayerDto
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "Layer";
    public bool Visible { get; set; } = true;
    public bool Locked { get; set; }
    public double Opacity { get; set; } = 1.0;
    public List<CelDto> Cels { get; set; } = new();
}

internal sealed class ProjectDto
{
    public int Width { get; set; }
    public int Height { get; set; }
    public double Fps { get; set; } = 12;
    public int FrameCount { get; set; } = 1;
    public bool Loop { get; set; } = true;
    public BackgroundDto Background { get; set; } = new();
    public OnionDto Onion { get; set; } = new();
    public int CurrentFrame { get; set; }
    public string? ActiveLayerId { get; set; }
    public List<LayerDto> Layers { get; set; } = new();
}
