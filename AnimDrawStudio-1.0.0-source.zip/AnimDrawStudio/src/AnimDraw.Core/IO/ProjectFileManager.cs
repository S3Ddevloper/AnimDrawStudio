using AnimDraw.Core.Editing;
using AnimDraw.Core.Model;

namespace AnimDraw.Core.IO;

/// <summary>Opens and saves project files safely, turning file-system problems into messages a person can act on.</summary>
public static class ProjectFileManager
{
    /// <summary>Adds the .animdraw extension when the name has none.</summary>
    public static string NormalizePath(string path)
    {
        if (string.IsNullOrWhiteSpace(path)) throw new ProjectFileException("Please choose a file name.");
        string trimmed = path.Trim();
        return Path.GetExtension(trimmed).Equals(ProjectFileFormat.Extension, StringComparison.OrdinalIgnoreCase)
            ? trimmed
            : trimmed + ProjectFileFormat.Extension;
    }

    /// <summary>Reads a project from disk.</summary>
    public static LoadedProject Open(string path, IProgress<double>? progress = null, CancellationToken ct = default)
    {
        try
        {
            using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 81920, FileOptions.SequentialScan);
            return ProjectSerializer.Load(fs, progress, ct);
        }
        catch (FileNotFoundException ex)
        {
            throw new ProjectFileException($"The file \"{Path.GetFileName(path)}\" could not be found. It may have been moved or deleted.", ex);
        }
        catch (DirectoryNotFoundException ex)
        {
            throw new ProjectFileException("The folder that contained this project no longer exists.", ex);
        }
        catch (UnauthorizedAccessException ex)
        {
            throw new ProjectFileException($"AnimDraw Studio is not allowed to read \"{Path.GetFileName(path)}\".", ex);
        }
        catch (IOException ex)
        {
            throw new ProjectFileException($"The file \"{Path.GetFileName(path)}\" could not be read: {ex.Message}", ex);
        }
    }

    /// <summary>
    /// Writes a snapshot to disk. The data goes to a temporary file first and replaces the real file only when it is
    /// complete, so a crash or full disk never destroys the previous save.
    /// </summary>
    public static void Save(Project snapshot, string path, int currentFrame, Guid activeLayerId,
        SaveOptions? options = null, IProgress<double>? progress = null, CancellationToken ct = default)
    {
        path = NormalizePath(path);
        string full;
        try { full = Path.GetFullPath(path); }
        catch (Exception ex) when (ex is ArgumentException or NotSupportedException or PathTooLongException)
        {
            throw new ProjectFileException("That file name is not valid.", ex);
        }

        string dir = Path.GetDirectoryName(full) ?? ".";
        string temp = Path.Combine(dir, $".{Path.GetFileName(full)}.{Guid.NewGuid():N}.tmp");
        try
        {
            using (var fs = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, FileOptions.SequentialScan))
            {
                ProjectSerializer.Save(snapshot, fs, currentFrame, activeLayerId, options, progress, ct);
                fs.Flush(true);
            }
            if (File.Exists(full)) File.Replace(temp, full, null);
            else File.Move(temp, full);
        }
        catch (OperationCanceledException) { throw; }
        catch (UnauthorizedAccessException ex)
        {
            throw new ProjectFileException(
                $"AnimDraw Studio is not allowed to write to \"{Path.GetFileName(full)}\". Choose another folder, or check that the file is not read-only.", ex);
        }
        catch (DirectoryNotFoundException ex)
        {
            throw new ProjectFileException("The folder you chose does not exist any more.", ex);
        }
        catch (PathTooLongException ex)
        {
            throw new ProjectFileException("The file path is too long. Choose a shorter name or a folder closer to the top of the drive.", ex);
        }
        catch (IOException ex)
        {
            bool diskFull = (ex.HResult & 0xFFFF) is 0x27 or 0x70;
            throw new ProjectFileException(
                diskFull
                    ? "The disk is full. Free some space, or save to a different drive."
                    : $"The project could not be saved: {ex.Message}", ex);
        }
        finally
        {
            try { if (File.Exists(temp)) File.Delete(temp); } catch (IOException) { } catch (UnauthorizedAccessException) { }
        }
    }

    /// <summary>
    /// Saves the document without freezing the interface: the project is snapshotted on the calling (UI) thread,
    /// written on a worker thread, and the document is marked saved only if the write succeeded.
    /// </summary>
    public static async Task SaveAsync(Document doc, string path, SaveOptions? options = null,
        IProgress<double>? progress = null, CancellationToken ct = default)
    {
        doc.CommitActiveEdit();
        var token = doc.BeginSave();
        var snapshot = doc.CreateSnapshot();
        int frame = doc.CurrentFrame;
        Guid active = doc.ActiveLayer.Id;
        await Task.Run(() => Save(snapshot, path, frame, active, options, progress, ct), ct).ConfigureAwait(true);
        doc.CompleteSave(token);
    }

    /// <summary>Opens a project on a worker thread and wraps it in a document.</summary>
    public static async Task<Document> OpenAsync(string path, IProgress<double>? progress = null, CancellationToken ct = default)
    {
        var loaded = await Task.Run(() => Open(path, progress, ct), ct).ConfigureAwait(true);
        return DocumentFrom(loaded);
    }

    public static Document DocumentFrom(LoadedProject loaded)
    {
        var doc = new Document(loaded.Project);
        if (loaded.ActiveLayerId is Guid id)
        {
            var layer = loaded.Project.FindLayer(id);
            if (layer != null) doc.SetActiveLayer(layer);
        }
        doc.GoToFrame(loaded.CurrentFrame);
        doc.MarkSaved();
        return doc;
    }
}
