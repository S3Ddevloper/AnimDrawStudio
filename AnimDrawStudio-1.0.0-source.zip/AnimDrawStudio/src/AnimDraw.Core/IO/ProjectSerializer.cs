using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;
using AnimDraw.Core.Rendering;

namespace AnimDraw.Core.IO;

public sealed class SaveOptions
{
    /// <summary>Fast keeps autosave quick; Normal is used for ordinary saves.</summary>
    public PngCompression Compression { get; set; } = PngCompression.Normal;

    public bool IncludePreview { get; set; } = true;
}

public sealed record LoadedProject(Project Project, int CurrentFrame, Guid? ActiveLayerId);

/// <summary>Reads and writes the .animdraw container. Works on a project snapshot, so it is safe to run on a worker thread.</summary>
public static class ProjectSerializer
{
    private static readonly string AppName =
        "AnimDraw Studio " + (typeof(ProjectSerializer).Assembly.GetName().Version?.ToString(3) ?? "1.0.0");

    private const long EncodeMemoryBudget = 768L * 1024 * 1024;

    // ------------------------------------------------------------------ saving

    public static void Save(Project project, Stream output, int currentFrame, Guid activeLayerId,
        SaveOptions? options = null, IProgress<double>? progress = null, CancellationToken ct = default)
    {
        options ??= new SaveOptions();

        // Identical drawings (duplicated frames, held layers) are written once.
        var uniqueByHash = new Dictionary<string, int>();
        var uniques = new List<Cel>();
        var celIndex = new Dictionary<Cel, int>(); // Cel does not override Equals, so this compares by reference
        foreach (var layer in project.Layers)
        foreach (var (_, cel) in layer.Track.Keyframes)
        {
            if (celIndex.ContainsKey(cel)) continue;
            if (cel.Surface.IsBlank()) { celIndex[cel] = -1; continue; }
            string hash = HashSurface(cel.Surface);
            if (!uniqueByHash.TryGetValue(hash, out int idx))
            {
                idx = uniques.Count;
                uniqueByHash[hash] = idx;
                uniques.Add(cel);
            }
            celIndex[cel] = idx;
        }

        var bounds = new IntRect[uniques.Count];
        long largest = 1;
        for (int i = 0; i < uniques.Count; i++)
        {
            bounds[i] = uniques[i].Surface.GetContentBounds();
            largest = Math.Max(largest, (long)bounds[i].Width * bounds[i].Height);
        }
        // Encoding a picture needs roughly ten bytes of working memory per pixel. Run as many encoders in parallel
        // as the cores allow, but never so many that very large canvases exhaust memory.
        int degree = (int)Math.Clamp(EncodeMemoryBudget / (largest * 10), 1, Environment.ProcessorCount);
        var parallel = new ParallelOptions { CancellationToken = ct, MaxDegreeOfParallelism = degree };

        var encoded = new byte[uniques.Count][];
        int done = 0;
        int total = uniques.Count + 3;

        // Encode in batches in parallel, then write each batch to the archive in order.
        using var zip = new ZipArchive(output, ZipArchiveMode.Create, leaveOpen: true);
        WriteJson(zip, ProjectFileFormat.ManifestEntry, new ManifestDto
        {
            App = AppName,
            SavedUtc = DateTime.UtcNow.ToString("O")
        });

        const int batch = 24;
        for (int start = 0; start < uniques.Count; start += batch)
        {
            ct.ThrowIfCancellationRequested();
            int end = Math.Min(uniques.Count, start + batch);
            Parallel.For(start, end, parallel, i =>
            {
                var buf = uniques[i].Surface.ReadRegion(bounds[i]);
                encoded[i] = PngCodec.Encode(buf, new PngEncodeOptions { Compression = options.Compression });
            });
            for (int i = start; i < end; i++)
            {
                var entry = zip.CreateEntry(ImagePath(i), CompressionLevel.NoCompression);
                using (var es = entry.Open()) es.Write(encoded[i], 0, encoded[i].Length);
                encoded[i] = Array.Empty<byte>();
                progress?.Report(++done / (double)total);
            }
        }

        var dto = new ProjectDto
        {
            Width = project.Width,
            Height = project.Height,
            Fps = project.Fps,
            FrameCount = project.FrameCount,
            Loop = project.Loop,
            Background = new BackgroundDto { Mode = project.Background.Mode.ToString(), Color = project.Background.Color.ToHex() },
            Onion = new OnionDto
            {
                Enabled = project.Onion.Enabled,
                PreviousFrames = project.Onion.PreviousFrames,
                NextFrames = project.Onion.NextFrames,
                Opacity = project.Onion.Opacity,
                Colorize = project.Onion.Colorize
            },
            CurrentFrame = currentFrame,
            ActiveLayerId = activeLayerId.ToString("N")
        };
        foreach (var layer in project.Layers)
        {
            var l = new LayerDto
            {
                Id = layer.Id.ToString("N"),
                Name = layer.Name,
                Visible = layer.Visible,
                Locked = layer.Locked,
                Opacity = layer.Opacity
            };
            foreach (var (frame, cel) in layer.Track.Keyframes)
            {
                int idx = celIndex[cel];
                if (idx < 0) l.Cels.Add(new CelDto { Frame = frame });
                else l.Cels.Add(new CelDto
                {
                    Frame = frame,
                    Image = ImagePath(idx),
                    X = bounds[idx].X,
                    Y = bounds[idx].Y,
                    Width = bounds[idx].Width,
                    Height = bounds[idx].Height
                });
            }
            dto.Layers.Add(l);
        }
        WriteJson(zip, ProjectFileFormat.ProjectEntry, dto);
        progress?.Report(++done / (double)total);

        if (options.IncludePreview)
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                var frame = Compositor.ComposeFrame(project, Math.Clamp(currentFrame, 0, project.FrameCount - 1), withBackground: true);
                double scale = Math.Min(1.0, 256.0 / Math.Max(frame.Width, frame.Height));
                var small = scale < 1.0
                    ? Resampler.Scale(frame, Math.Max(1, (int)(frame.Width * scale)), Math.Max(1, (int)(frame.Height * scale)))
                    : frame;
                var entry = zip.CreateEntry(ProjectFileFormat.PreviewEntry, CompressionLevel.NoCompression);
                using var es = entry.Open();
                byte[] png = PngCodec.Encode(small, new PngEncodeOptions { Compression = PngCompression.Fast });
                es.Write(png, 0, png.Length);
            }
            catch (Exception) when (!ct.IsCancellationRequested)
            {
                // The preview is a convenience; never fail a save because of it.
            }
        }
        progress?.Report(1.0);
    }

    private static string ImagePath(int index) => $"{ProjectFileFormat.CelFolder}{index + 1:D5}.png";

    private static void WriteJson<T>(ZipArchive zip, string name, T value)
    {
        var entry = zip.CreateEntry(name, CompressionLevel.Optimal);
        using var s = entry.Open();
        JsonSerializer.Serialize(s, value, ProjectFileFormat.Json);
    }

    private static string HashSurface(TiledSurface surface)
    {
        using var h = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        Span<byte> header = stackalloc byte[8];
        BitConverter.TryWriteBytes(header[..4], surface.Width);
        BitConverter.TryWriteBytes(header[4..], surface.Height);
        h.AppendData(header);
        var idx = new byte[4];
        for (int i = 0; i < surface.TileCount; i++)
        {
            var t = surface.GetTile(i);
            if (t == null || t.IsBlank()) continue;
            BitConverter.TryWriteBytes(idx, i);
            h.AppendData(idx);
            h.AppendData(System.Runtime.InteropServices.MemoryMarshal.AsBytes(t.Data.AsSpan()));
        }
        return Convert.ToHexString(h.GetHashAndReset());
    }

    // ------------------------------------------------------------------ loading

    public static LoadedProject Load(Stream input, IProgress<double>? progress = null, CancellationToken ct = default)
    {
        try
        {
            return LoadCore(input, progress, ct);
        }
        catch (ProjectFileException) { throw; }
        catch (OperationCanceledException) { throw; }
        catch (InvalidDataException ex)
        {
            throw new ProjectFileException("This file is not a valid AnimDraw project, or it is damaged. " + ex.Message, ex);
        }
        catch (JsonException ex)
        {
            throw new ProjectFileException("The project's settings could not be read. The file may be damaged.", ex);
        }
        catch (NotSupportedException ex)
        {
            throw new ProjectFileException(ex.Message, ex);
        }
        catch (ArgumentException ex)
        {
            throw new ProjectFileException("The project contains values that are not valid: " + ex.Message, ex);
        }
        catch (OutOfMemoryException ex)
        {
            throw new ProjectFileException("There is not enough memory to open this project. Close other programs and try again.", ex);
        }
        catch (Exception ex)
        {
            // The file is untrusted input: whatever goes wrong while reading it, the user gets a message, not a crash.
            throw new ProjectFileException("The project could not be read. The file may be damaged. (" + ex.Message + ")", ex);
        }
    }

    private static LoadedProject LoadCore(Stream input, IProgress<double>? progress, CancellationToken ct)
    {
        using var zip = new ZipArchive(input, ZipArchiveMode.Read, leaveOpen: true);

        var manifestEntry = zip.GetEntry(ProjectFileFormat.ManifestEntry)
            ?? throw new ProjectFileException("This file is not an AnimDraw project (manifest missing).");
        var manifest = ReadJson<ManifestDto>(manifestEntry);
        if (!string.Equals(manifest.Format, ProjectFileFormat.FormatName, StringComparison.Ordinal))
            throw new ProjectFileException("This file is not an AnimDraw project.");
        if (manifest.Version > ProjectFileFormat.CurrentVersion)
            throw new ProjectFileException(
                $"This project was saved by a newer version of AnimDraw Studio (file format {manifest.Version}). Please update the program to open it.");

        var projectEntry = zip.GetEntry(ProjectFileFormat.ProjectEntry)
            ?? throw new ProjectFileException("The project data is missing from the file.");
        var dto = ReadJson<ProjectDto>(projectEntry);

        // JSON can hold explicit nulls; treat them as "missing" so a damaged file cannot cause a null reference.
        dto.Layers ??= new();
        dto.Layers.RemoveAll(l => l == null);
        dto.Background ??= new();
        dto.Onion ??= new();
        foreach (var l in dto.Layers)
        {
            l.Cels ??= new();
            l.Cels.RemoveAll(c => c == null);
        }

        if (!ProjectLimits.IsValidSize(dto.Width, dto.Height, out string? sizeProblem))
            throw new ProjectFileException("The project's canvas size is not supported. " + sizeProblem);
        if (dto.FrameCount < 1 || dto.FrameCount > ProjectLimits.MaxFrames)
            throw new ProjectFileException($"The project has an unsupported number of frames ({dto.FrameCount}).");
        if (dto.Layers.Count < 1 || dto.Layers.Count > ProjectLimits.MaxLayers)
            throw new ProjectFileException($"The project has an unsupported number of layers ({dto.Layers.Count}).");

        var project = new Project(dto.Width, dto.Height)
        {
            Fps = ProjectLimits.ClampFps(dto.Fps),
            FrameCount = dto.FrameCount,
            Loop = dto.Loop
        };
        project.Background = ParseBackground(dto.Background);
        project.Onion = new OnionSkinSettings
        {
            Enabled = dto.Onion.Enabled,
            PreviousFrames = dto.Onion.PreviousFrames,
            NextFrames = dto.Onion.NextFrames,
            Opacity = dto.Onion.Opacity,
            Colorize = dto.Onion.Colorize
        };
        project.Onion.Normalize();

        int totalCels = dto.Layers.Sum(l => l.Cels.Count);
        int doneCels = 0;
        var decoded = new Dictionary<string, TiledSurface>(StringComparer.Ordinal);
        var usedIds = new HashSet<Guid>();

        foreach (var l in dto.Layers)
        {
            Guid id = Guid.TryParse(l.Id, out var parsed) && usedIds.Add(parsed) ? parsed : NewUnusedId(usedIds);
            var layer = new Layer(id, string.IsNullOrWhiteSpace(l.Name) ? "Layer" : l.Name)
            {
                Visible = l.Visible,
                Locked = l.Locked,
                Opacity = double.IsNaN(l.Opacity) ? 1.0 : Math.Clamp(l.Opacity, 0, 1)
            };

            foreach (var c in l.Cels)
            {
                ct.ThrowIfCancellationRequested();
                if (c.Frame < 0 || c.Frame >= project.FrameCount) continue;

                Cel cel;
                if (string.IsNullOrEmpty(c.Image))
                {
                    cel = new Cel(project.Width, project.Height);
                }
                else
                {
                    if (!IsSafeImagePath(c.Image))
                        throw new ProjectFileException("The project refers to an image path that is not allowed.");
                    string key = $"{c.Image}|{c.X}|{c.Y}";
                    if (!decoded.TryGetValue(key, out var surface))
                    {
                        var imgEntry = zip.GetEntry(c.Image)
                            ?? throw new ProjectFileException($"A drawing ({c.Image}) is missing from the file.");
                        // Drawings are cropped to their artwork, so none can be larger than the canvas. A stored (uncompressed)
                        // RGBA picture needs at most five bytes per pixel, so anything bigger than that is not one of ours.
                        long canvasPixels = (long)project.Width * project.Height;
                        if (imgEntry.Length > canvasPixels * 5 + (1L << 20))
                            throw new ProjectFileException("A drawing in the file is unreasonably large.");
                        var bytes = new byte[imgEntry.Length];
                        using (var es = imgEntry.Open()) es.ReadExactly(bytes);
                        PixelBuffer img;
                        try { img = PngCodec.Decode(bytes, canvasPixels); }
                        catch (InvalidDataException ex)
                        {
                            throw new ProjectFileException($"A drawing ({c.Image}) is damaged or too large for the canvas. {ex.Message}", ex);
                        }
                        surface = TiledSurface.FromBuffer(img, project.Width, project.Height, c.X, c.Y);
                        surface.Freeze();
                        decoded[key] = surface;
                    }
                    cel = new Cel(surface.Clone());
                }
                layer.Track.Set(c.Frame, cel);
                progress?.Report(++doneCels / (double)Math.Max(1, totalCels));
            }
            project.Layers.Add(layer);
        }

        Guid? active = Guid.TryParse(dto.ActiveLayerId, out var a) ? a : null;
        return new LoadedProject(project, Math.Clamp(dto.CurrentFrame, 0, project.FrameCount - 1), active);
    }

    private static Guid NewUnusedId(HashSet<Guid> used)
    {
        Guid g;
        do { g = Guid.NewGuid(); } while (!used.Add(g));
        return g;
    }

    private static bool IsSafeImagePath(string path)
    {
        if (!path.StartsWith(ProjectFileFormat.CelFolder, StringComparison.Ordinal)) return false;
        string name = path[ProjectFileFormat.CelFolder.Length..];
        if (name.Length == 0 || name.Length > 64) return false;
        foreach (char ch in name)
            if (!(char.IsAsciiLetterOrDigit(ch) || ch == '.' || ch == '-' || ch == '_')) return false;
        return !name.Contains("..", StringComparison.Ordinal);
    }

    private static BackgroundSettings ParseBackground(BackgroundDto dto)
    {
        var color = ArgbColor.ParseOrDefault(dto.Color, ArgbColor.White);
        return Enum.TryParse<BackgroundMode>(dto.Mode, true, out var mode)
            ? mode switch
            {
                BackgroundMode.Transparent => BackgroundSettings.Transparent,
                BackgroundMode.White => BackgroundSettings.White,
                _ => BackgroundSettings.Custom(color)
            }
            : BackgroundSettings.White;
    }

    private static T ReadJson<T>(ZipArchiveEntry entry) where T : class
    {
        if (entry.Length > 64L * 1024 * 1024)
            throw new ProjectFileException("The project settings are unreasonably large.");
        using var s = entry.Open();
        return JsonSerializer.Deserialize<T>(s, ProjectFileFormat.Json)
            ?? throw new ProjectFileException("The project data is empty.");
    }

    /// <summary>Reads only the small preview picture from a project file (for recent-file lists). Null if there is none.</summary>
    public static PixelBuffer? TryReadPreview(Stream input)
    {
        try
        {
            using var zip = new ZipArchive(input, ZipArchiveMode.Read, leaveOpen: true);
            var e = zip.GetEntry(ProjectFileFormat.PreviewEntry);
            if (e == null || e.Length > 8 * 1024 * 1024) return null;
            using var es = e.Open();
            return PngCodec.Decode(es);
        }
        catch (Exception)
        {
            return null;
        }
    }
}
