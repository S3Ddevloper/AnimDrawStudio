using System.Text.Json;
using AnimDraw.Core.Editing;

namespace AnimDraw.Core.IO;

/// <summary>A recovery copy left behind by a session that did not shut down cleanly.</summary>
public sealed record RecoveryEntry(
    string SessionId,
    string DataPath,
    string MetaPath,
    string LockPath,
    string? OriginalPath,
    string ProjectName,
    DateTime SavedUtc);

internal sealed class RecoveryMeta
{
    public string? OriginalPath { get; set; }
    public string ProjectName { get; set; } = "Untitled";
    public string SavedUtc { get; set; } = "";
}

/// <summary>
/// Keeps a recent copy of the open project in a recovery folder so work survives a crash or power cut.
/// Each running program holds a lock file; a recovery copy whose lock is free belongs to a session that died.
/// </summary>
public sealed class RecoveryManager : IDisposable
{
    private static readonly JsonSerializerOptions Json = new() { PropertyNameCaseInsensitive = true };

    private FileStream? _lock;
    private long _lastStateId = -1;
    private long _lastContentVersion = -1;
    private long _lastStructureVersion = -1;
    private int _busy;

    public RecoveryManager(string folder, string? sessionId = null)
    {
        Folder = folder;
        SessionId = sessionId ?? Guid.NewGuid().ToString("N");
    }

    public string Folder { get; }
    public string SessionId { get; }

    /// <summary>
    /// When true, <see cref="Dispose"/> leaves this session's recovery copy in place instead of deleting it. The editor sets
    /// it when the program ends while there is unsaved work that nobody agreed to give up (Windows logging off, a fatal error),
    /// so the next start can offer that work back.
    /// </summary>
    public bool KeepFilesOnDispose { get; set; }

    /// <summary>Where this session's most recent recovery copy is written.</summary>
    public string DataFilePath => DataPath;

    private string DataPath => Path.Combine(Folder, SessionId + ".animdraw");
    private string MetaPath => Path.Combine(Folder, SessionId + ".json");
    private string LockPath => Path.Combine(Folder, SessionId + ".lock");

    /// <summary>Claims this session's lock so other instances know it is alive. Returns false if the folder is unusable.</summary>
    public bool Start()
    {
        try
        {
            Directory.CreateDirectory(Folder);
            _lock ??= new FileStream(LockPath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            return true;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return false;
        }
    }

    /// <summary>True when the document changed since the last recovery copy was written.</summary>
    public bool NeedsAutosave(Document doc) =>
        doc.IsDirty && (doc.History.StateId != _lastStateId ||
                        doc.ContentVersion != _lastContentVersion ||
                        doc.StructureVersion != _lastStructureVersion);

    /// <summary>
    /// Writes a recovery copy on a worker thread. The document is snapshotted here (cheap) and the caller keeps
    /// working. Returns false if a previous autosave is still running or nothing changed.
    /// </summary>
    public async Task<bool> AutosaveAsync(Document doc, string? originalPath, string projectName, CancellationToken ct = default)
    {
        if (_lock == null || !NeedsAutosave(doc)) return false;
        if (Interlocked.Exchange(ref _busy, 1) == 1) return false;
        try
        {
            long state = doc.History.StateId, content = doc.ContentVersion, structure = doc.StructureVersion;
            var snapshot = doc.CreateSnapshot();
            int frame = doc.CurrentFrame;
            Guid active = doc.ActiveLayer.Id;

            await Task.Run(() =>
            {
                string temp = DataPath + ".tmp";
                using (var fs = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None))
                    ProjectSerializer.Save(snapshot, fs, frame, active,
                        new SaveOptions { Compression = PngCompression.Fast, IncludePreview = false }, null, ct);
                if (File.Exists(DataPath)) File.Replace(temp, DataPath, null); else File.Move(temp, DataPath);

                var meta = new RecoveryMeta
                {
                    OriginalPath = originalPath,
                    ProjectName = projectName,
                    SavedUtc = DateTime.UtcNow.ToString("O")
                };
                File.WriteAllText(MetaPath, JsonSerializer.Serialize(meta, Json));
            }, ct).ConfigureAwait(false);

            _lastStateId = state;
            _lastContentVersion = content;
            _lastStructureVersion = structure;
            return true;
        }
        catch (OperationCanceledException) { return false; }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ProjectFileException)
        {
            return false; // autosave must never interrupt the user
        }
        finally
        {
            Volatile.Write(ref _busy, 0);
        }
    }

    /// <summary>Deletes this session's recovery copy (after a save or a clean exit).</summary>
    public void ClearCurrent()
    {
        TryDelete(DataPath);
        TryDelete(DataPath + ".tmp");
        TryDelete(MetaPath);
        _lastStateId = _lastContentVersion = _lastStructureVersion = -1;
    }

    /// <summary>Forgets what was last autosaved, so the next change writes a fresh copy.</summary>
    public void Reset()
    {
        ClearCurrent();
    }

    /// <summary>Recovery copies left by sessions that are no longer running.</summary>
    public IReadOnlyList<RecoveryEntry> FindRecoverable()
    {
        var result = new List<RecoveryEntry>();
        if (!Directory.Exists(Folder)) return result;

        foreach (string meta in Directory.EnumerateFiles(Folder, "*.json"))
        {
            string sid = Path.GetFileNameWithoutExtension(meta);
            if (sid == SessionId) continue;
            string data = Path.Combine(Folder, sid + ".animdraw");
            string lockPath = Path.Combine(Folder, sid + ".lock");
            if (!File.Exists(data)) continue;
            if (IsSessionAlive(lockPath)) continue;

            try
            {
                var m = JsonSerializer.Deserialize<RecoveryMeta>(File.ReadAllText(meta), Json) ?? new RecoveryMeta();
                DateTime saved = DateTime.TryParse(m.SavedUtc, null, System.Globalization.DateTimeStyles.RoundtripKind, out var t)
                    ? t : File.GetLastWriteTimeUtc(data);
                result.Add(new RecoveryEntry(sid, data, meta, lockPath, m.OriginalPath, m.ProjectName, saved));
            }
            catch (Exception ex) when (ex is JsonException or IOException or UnauthorizedAccessException)
            {
                // Unreadable metadata: still offer the data file.
                result.Add(new RecoveryEntry(sid, data, meta, lockPath, null, "Recovered project", File.GetLastWriteTimeUtc(data)));
            }
        }
        return result.OrderByDescending(e => e.SavedUtc).ToList();
    }

    private static bool IsSessionAlive(string lockPath)
    {
        if (!File.Exists(lockPath)) return false;
        try
        {
            using var probe = new FileStream(lockPath, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            return false; // we could take the lock, so nobody owns it
        }
        catch (IOException) { return true; }
        catch (UnauthorizedAccessException) { return true; }
    }

    public static LoadedProject Open(RecoveryEntry entry) => ProjectFileManager.Open(entry.DataPath);

    /// <summary>Throws away a recovery copy for good.</summary>
    public static void Discard(RecoveryEntry entry)
    {
        TryDelete(entry.DataPath);
        TryDelete(entry.DataPath + ".tmp");
        TryDelete(entry.MetaPath);
        TryDelete(entry.LockPath);
    }

    /// <summary>Removes stale recovery files older than <paramref name="maxAge"/>.</summary>
    public void PurgeOld(TimeSpan maxAge)
    {
        foreach (var e in FindRecoverable())
            if (DateTime.UtcNow - e.SavedUtc > maxAge) Discard(e);
    }

    private static void TryDelete(string path)
    {
        try { if (File.Exists(path)) File.Delete(path); }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    public void Dispose()
    {
        if (!KeepFilesOnDispose) ClearCurrent();
        var l = _lock;
        _lock = null;
        if (l != null)
        {
            l.Dispose();
            TryDelete(LockPath);
        }
    }
}
