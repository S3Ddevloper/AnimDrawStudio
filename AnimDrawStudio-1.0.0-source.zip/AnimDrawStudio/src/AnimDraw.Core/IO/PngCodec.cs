using System.IO.Compression;
using AnimDraw.Core.Imaging;

namespace AnimDraw.Core.IO;

public enum PngCompression
{
    /// <summary>Quickest to write, larger files.</summary>
    Fast,

    /// <summary>Good balance.</summary>
    Normal,

    /// <summary>Smallest files, slowest.</summary>
    Best
}

public sealed class PngEncodeOptions
{
    /// <summary>Store the alpha channel (RGBA). When false the image is written as opaque RGB.</summary>
    public bool Alpha { get; set; } = true;

    public PngCompression Compression { get; set; } = PngCompression.Normal;
}

/// <summary>A small, dependency-free PNG reader and writer for 8-bit images.</summary>
public static class PngCodec
{
    private static readonly byte[] Signature = { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A };
    private static readonly uint[] CrcTable = BuildCrcTable();

    private static uint[] BuildCrcTable()
    {
        var table = new uint[256];
        for (uint n = 0; n < 256; n++)
        {
            uint c = n;
            for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
            table[n] = c;
        }
        return table;
    }

    private static uint Crc(uint crc, ReadOnlySpan<byte> data)
    {
        uint c = crc;
        foreach (byte b in data) c = CrcTable[(c ^ b) & 0xFF] ^ (c >> 8);
        return c;
    }

    // ------------------------------------------------------------------ encoding

    public static byte[] Encode(PixelBuffer image, PngEncodeOptions? options = null)
    {
        using var ms = new MemoryStream();
        Encode(ms, image, options);
        return ms.ToArray();
    }

    public static void Encode(Stream output, PixelBuffer image, PngEncodeOptions? options = null)
    {
        options ??= new PngEncodeOptions();
        int bpp = options.Alpha ? 4 : 3;
        int w = image.Width, h = image.Height;

        byte[] rgba = image.ToStraightRgba();
        int stride = w * bpp;
        var raw = new byte[(stride + 1) * h];

        var candidates = new byte[4][];
        for (int i = 0; i < 4; i++) candidates[i] = new byte[stride];
        var row = new byte[stride];
        var prev = new byte[stride];

        for (int y = 0; y < h; y++)
        {
            if (options.Alpha) Buffer.BlockCopy(rgba, y * w * 4, row, 0, stride);
            else
                for (int x = 0, si = y * w * 4, di = 0; x < w; x++, si += 4, di += 3)
                {
                    row[di] = rgba[si]; row[di + 1] = rgba[si + 1]; row[di + 2] = rgba[si + 2];
                }

            int bestFilter;
            if (options.Compression == PngCompression.Fast)
            {
                bestFilter = 1;
                FilterRow(1, row, prev, candidates[1], bpp);
            }
            else
            {
                long bestScore = long.MaxValue;
                bestFilter = 0;
                for (int f = 0; f < 4; f++)
                {
                    FilterRow(f, row, prev, candidates[f], bpp);
                    long score = 0;
                    foreach (byte b in candidates[f]) score += b < 128 ? b : 256 - b;
                    if (score < bestScore) { bestScore = score; bestFilter = f; }
                }
            }

            int o = y * (stride + 1);
            // Candidate 3 is Paeth, which the PNG format numbers 4 (3 is "Average").
            raw[o] = (byte)(bestFilter == 3 ? 4 : bestFilter);
            Buffer.BlockCopy(candidates[bestFilter], 0, raw, o + 1, stride);
            (row, prev) = (prev, row);
        }

        var level = options.Compression switch
        {
            PngCompression.Fast => CompressionLevel.Fastest,
            PngCompression.Best => CompressionLevel.SmallestSize,
            _ => CompressionLevel.Optimal
        };
        byte[] compressed;
        using (var ms = new MemoryStream())
        {
            using (var z = new ZLibStream(ms, level, leaveOpen: true)) z.Write(raw, 0, raw.Length);
            compressed = ms.ToArray();
        }

        output.Write(Signature, 0, Signature.Length);
        var ihdr = new byte[13];
        WriteBe(ihdr, 0, (uint)w);
        WriteBe(ihdr, 4, (uint)h);
        ihdr[8] = 8;
        ihdr[9] = (byte)(options.Alpha ? 6 : 2);
        WriteChunk(output, "IHDR", ihdr);
        WriteChunk(output, "IDAT", compressed);
        WriteChunk(output, "IEND", Array.Empty<byte>());
    }

    private static void FilterRow(int filter, byte[] row, byte[] prev, byte[] dst, int bpp)
    {
        int n = row.Length;
        switch (filter)
        {
            case 0:
                Buffer.BlockCopy(row, 0, dst, 0, n);
                break;
            case 1:
                for (int i = 0; i < n; i++) dst[i] = (byte)(row[i] - (i >= bpp ? row[i - bpp] : 0));
                break;
            case 2:
                for (int i = 0; i < n; i++) dst[i] = (byte)(row[i] - prev[i]);
                break;
            default:
                for (int i = 0; i < n; i++)
                {
                    int a = i >= bpp ? row[i - bpp] : 0, b = prev[i], c = i >= bpp ? prev[i - bpp] : 0;
                    dst[i] = (byte)(row[i] - Paeth(a, b, c));
                }
                break;
        }
    }

    private static int Paeth(int a, int b, int c)
    {
        int p = a + b - c;
        int pa = Math.Abs(p - a), pb = Math.Abs(p - b), pc = Math.Abs(p - c);
        return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
    }

    private static void WriteBe(byte[] buf, int offset, uint value)
    {
        buf[offset] = (byte)(value >> 24);
        buf[offset + 1] = (byte)(value >> 16);
        buf[offset + 2] = (byte)(value >> 8);
        buf[offset + 3] = (byte)value;
    }

    private static void WriteChunk(Stream s, string type, byte[] data)
    {
        var len = new byte[4];
        WriteBe(len, 0, (uint)data.Length);
        s.Write(len, 0, 4);
        var t = new[] { (byte)type[0], (byte)type[1], (byte)type[2], (byte)type[3] };
        s.Write(t, 0, 4);
        s.Write(data, 0, data.Length);
        uint crc = Crc(0xFFFFFFFFu, t);
        crc = Crc(crc, data) ^ 0xFFFFFFFFu;
        var c = new byte[4];
        WriteBe(c, 0, crc);
        s.Write(c, 0, 4);
    }

    // ------------------------------------------------------------------ decoding

    /// <summary>Largest picture, in pixels, that <see cref="Decode(Stream, long)"/> accepts unless the caller sets a lower limit.</summary>
    public const long DefaultMaxPixels = 200_000_000;

    public static PixelBuffer Decode(byte[] data, long maxPixels = DefaultMaxPixels)
    {
        using var ms = new MemoryStream(data, writable: false);
        return Decode(ms, maxPixels);
    }

    /// <summary>
    /// Reads an 8-bit or 16-bit PNG. Chunk checksums are verified, so a damaged picture is reported instead of
    /// silently producing garbage, and <paramref name="maxPixels"/> stops a file that claims an absurd size from
    /// allocating gigabytes before anything has been read.
    /// </summary>
    public static PixelBuffer Decode(Stream input, long maxPixels = DefaultMaxPixels)
    {
        var sig = new byte[8];
        ReadExactly(input, sig, 8);
        for (int i = 0; i < 8; i++)
            if (sig[i] != Signature[i]) throw new InvalidDataException("This is not a PNG image.");

        int width = 0, height = 0, bitDepth = 0, colorType = 0, interlace = 0;
        byte[]? palette = null, trns = null;
        using var idat = new MemoryStream();
        bool sawHeader = false, sawEnd = false;

        var head = new byte[8];
        while (!sawEnd)
        {
            ReadExactly(input, head, 8);
            uint length = ReadBe(head, 0);
            string type = new string(new[] { (char)head[4], (char)head[5], (char)head[6], (char)head[7] });
            if (length > int.MaxValue / 2) throw new InvalidDataException("PNG chunk is too large.");
            // A chunk cannot be longer than what is left of the data; this stops a bogus length from allocating a huge array.
            if (input.CanSeek && length + 4L > input.Length - input.Position)
                throw new InvalidDataException("The PNG data ends unexpectedly.");
            var body = new byte[length];
            ReadExactly(input, body, (int)length);
            var crcBytes = new byte[4];
            ReadExactly(input, crcBytes, 4);

            uint actualCrc = Crc(Crc(0xFFFFFFFFu, head.AsSpan(4, 4)), body) ^ 0xFFFFFFFFu;
            if (ReadBe(crcBytes, 0) != actualCrc)
                throw new InvalidDataException($"The PNG image is damaged (bad checksum in its {type.Trim()} block).");

            switch (type)
            {
                case "IHDR":
                    if (length < 13) throw new InvalidDataException("PNG header is damaged.");
                    width = (int)ReadBe(body, 0);
                    height = (int)ReadBe(body, 4);
                    bitDepth = body[8];
                    colorType = body[9];
                    interlace = body[12];
                    sawHeader = true;
                    break;
                case "PLTE": palette = body; break;
                case "tRNS": trns = body; break;
                case "IDAT": idat.Write(body, 0, body.Length); break;
                case "IEND": sawEnd = true; break;
            }
        }

        if (!sawHeader) throw new InvalidDataException("PNG header is missing.");
        if (width <= 0 || height <= 0 || (long)width * height > Math.Min(maxPixels, DefaultMaxPixels))
            throw new InvalidDataException("PNG size is not valid or larger than allowed.");
        if (interlace != 0) throw new NotSupportedException("Interlaced PNG images are not supported.");
        if (bitDepth != 8 && bitDepth != 16)
            throw new NotSupportedException($"PNG bit depth {bitDepth} is not supported (use 8-bit images).");

        int channels = colorType switch { 0 => 1, 2 => 3, 3 => 1, 4 => 2, 6 => 4, _ => throw new NotSupportedException("Unknown PNG colour type.") };
        if (colorType == 3 && bitDepth != 8) throw new NotSupportedException("Only 8-bit palette PNG images are supported.");
        int bytesPerPixel = channels * (bitDepth / 8);
        int stride = width * bytesPerPixel;

        var raw = new byte[(long)(stride + 1) * height];
        idat.Position = 0;
        using (var z = new ZLibStream(idat, CompressionMode.Decompress))
            ReadExactly(z, raw, raw.Length);

        var cur = new byte[stride];
        var prev = new byte[stride];
        var image = new PixelBuffer(width, height);
        for (int y = 0; y < height; y++)
        {
            int o = y * (stride + 1);
            int filter = raw[o];
            Buffer.BlockCopy(raw, o + 1, cur, 0, stride);
            Unfilter(filter, cur, prev, bytesPerPixel);

            for (int x = 0; x < width; x++)
            {
                int p = x * bytesPerPixel;
                int step = bitDepth / 8;
                int a = 255, r, g, b;
                switch (colorType)
                {
                    case 0: r = g = b = cur[p]; break;
                    case 2: r = cur[p]; g = cur[p + step]; b = cur[p + 2 * step]; break;
                    case 3:
                        int idx = cur[p];
                        if (palette == null || idx * 3 + 2 >= palette.Length) throw new InvalidDataException("PNG palette is damaged.");
                        r = palette[idx * 3]; g = palette[idx * 3 + 1]; b = palette[idx * 3 + 2];
                        if (trns != null && idx < trns.Length) a = trns[idx];
                        break;
                    case 4: r = g = b = cur[p]; a = cur[p + step]; break;
                    default: r = cur[p]; g = cur[p + step]; b = cur[p + 2 * step]; a = cur[p + 3 * step]; break;
                }
                image.Pixels[y * width + x] = Px.FromStraight(a, r, g, b);
            }
            (cur, prev) = (prev, cur);
        }
        return image;
    }

    private static void Unfilter(int filter, byte[] row, byte[] prev, int bpp)
    {
        int n = row.Length;
        switch (filter)
        {
            case 0: break;
            case 1:
                for (int i = bpp; i < n; i++) row[i] = (byte)(row[i] + row[i - bpp]);
                break;
            case 2:
                for (int i = 0; i < n; i++) row[i] = (byte)(row[i] + prev[i]);
                break;
            case 3:
                for (int i = 0; i < n; i++)
                    row[i] = (byte)(row[i] + (((i >= bpp ? row[i - bpp] : 0) + prev[i]) >> 1));
                break;
            case 4:
                for (int i = 0; i < n; i++)
                {
                    int a = i >= bpp ? row[i - bpp] : 0, b = prev[i], c = i >= bpp ? prev[i - bpp] : 0;
                    row[i] = (byte)(row[i] + Paeth(a, b, c));
                }
                break;
            default:
                throw new InvalidDataException("PNG uses an unknown row filter.");
        }
    }

    private static uint ReadBe(byte[] b, int o) =>
        ((uint)b[o] << 24) | ((uint)b[o + 1] << 16) | ((uint)b[o + 2] << 8) | b[o + 3];

    private static void ReadExactly(Stream s, byte[] buffer, int count)
    {
        int read = 0;
        while (read < count)
        {
            int n = s.Read(buffer, read, count - read);
            if (n <= 0) throw new InvalidDataException("The PNG data ends unexpectedly.");
            read += n;
        }
    }
}
