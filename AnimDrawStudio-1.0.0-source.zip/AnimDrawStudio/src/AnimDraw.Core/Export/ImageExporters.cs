using System.Text.Json;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.IO;
using AnimDraw.Core.Model;

namespace AnimDraw.Core.Export;

/// <summary>Where each frame sits on a sprite sheet.</summary>
public sealed record SpriteSheetLayout(int Columns, int Rows, int CellWidth, int CellHeight, int Padding, int Width, int Height, int FrameCount)
{
    public const int MaxSide = 16384;
    public const long MaxPixels = 40_000_000;

    public static SpriteSheetLayout Compute(int frames, int cellWidth, int cellHeight, int columns, int padding)
    {
        frames = Math.Max(1, frames);
        padding = Math.Max(0, padding);
        int cols = columns > 0 ? Math.Min(columns, frames) : (int)Math.Ceiling(Math.Sqrt(frames));
        int rows = (frames + cols - 1) / cols;
        long w = (long)cols * cellWidth + (long)(cols - 1) * padding;
        long h = (long)rows * cellHeight + (long)(rows - 1) * padding;
        return new SpriteSheetLayout(cols, rows, cellWidth, cellHeight, padding,
            (int)Math.Min(w, int.MaxValue), (int)Math.Min(h, int.MaxValue), frames);
    }

    public (int X, int Y) CellOrigin(int index) =>
        ((index % Columns) * (CellWidth + Padding), (index / Columns) * (CellHeight + Padding));

    public bool IsWithinLimits(out string? problem)
    {
        if (Width > MaxSide || Height > MaxSide || (long)Width * Height > MaxPixels)
        {
            problem = $"The sprite sheet would be {Width} x {Height} pixels, which is too large. " +
                      "Use fewer frames, a smaller frame size, or a different number of columns.";
            return false;
        }
        problem = null;
        return true;
    }
}

internal static class PngExporter
{
    /// <summary>A single frame as one PNG file.</summary>
    public static void WriteSingle(ExportContext ctx, string path)
    {
        var o = ctx.Options;
        var picture = ctx.CreateRenderer(o.Transparent).Render(ctx.Sources[0]);
        ctx.Ct.ThrowIfCancellationRequested();
        ctx.Report(0.5, "Writing PNG...", 0, 1);
        byte[] png = PngCodec.Encode(picture, new PngEncodeOptions { Alpha = o.Transparent, Compression = o.PngCompression });
        File.WriteAllBytes(path, png);
        ctx.Report(1, "Done", 1, 1);
    }

    /// <summary>The file names of a PNG sequence: prefix_0001.png, prefix_0002.png, ...</summary>
    public static string[] SequenceNames(string prefix, int count)
    {
        int digits = Math.Max(4, count.ToString().Length);
        var names = new string[count];
        for (int i = 0; i < count; i++) names[i] = $"{prefix}_{(i + 1).ToString("D" + digits)}.png";
        return names;
    }

    /// <summary>Every frame as its own PNG, written into <paramref name="folder"/>. Returns the file names in order.</summary>
    public static IReadOnlyList<string> WriteSequence(ExportContext ctx, string folder)
    {
        var o = ctx.Options;
        var renderer = ctx.CreateRenderer(o.Transparent);
        var png = new PngEncodeOptions { Alpha = o.Transparent, Compression = o.PngCompression };
        int total = ctx.Sources.Count;
        string[] names = SequenceNames(o.FileNamePrefix, total);

        // Rendering and PNG compression both happen on worker threads; files are written in order.
        int depth = FramePipeline.ChooseDepth(o.Width, o.Height);
        int i = 0;
        foreach (byte[] bytes in FramePipeline.Render(ctx.Sources, src => PngCodec.Encode(renderer.Render(src), png), depth, ctx.Ct))
        {
            File.WriteAllBytes(Path.Combine(folder, names[i]), bytes);
            i++;
            ctx.Report((double)i / total, $"Writing frame {i} of {total}...", i, total);
        }
        return names;
    }
}

internal static class SpriteSheetExporter
{
    public static void Write(ExportContext ctx, string imagePath, string? jsonPath, string imageFileNameForJson)
    {
        var o = ctx.Options;
        int total = ctx.Sources.Count;
        var layout = SpriteSheetLayout.Compute(total, o.Width, o.Height, o.Columns, o.Padding);
        if (!layout.IsWithinLimits(out string? problem)) throw new ExportException(ExportProblem.InvalidOptions, problem!);

        var renderer = ctx.CreateRenderer(o.Transparent);
        var sheet = new PixelBuffer(layout.Width, layout.Height);
        if (!o.Transparent)
        {
            // An opaque sheet is opaque everywhere, including the gaps between frames.
            sheet.Fill(ctx.Project.Background.Mode == BackgroundMode.Transparent ? 0xFFFFFFFFu : ctx.Project.Background.PremultipliedPixel);
        }

        int depth = FramePipeline.ChooseDepth(o.Width, o.Height);
        int i = 0;
        foreach (var picture in FramePipeline.Render(ctx.Sources, renderer.Render, depth, ctx.Ct))
        {
            var (x, y) = layout.CellOrigin(i);
            sheet.BlendFrom(picture, x, y);
            i++;
            ctx.Report(0.8 * i / total, $"Placing frame {i} of {total}...", i, total);
        }

        ctx.Ct.ThrowIfCancellationRequested();
        ctx.Report(0.85, "Compressing the sprite sheet...", total, total);
        byte[] png = PngCodec.Encode(sheet, new PngEncodeOptions { Alpha = o.Transparent, Compression = o.PngCompression });
        File.WriteAllBytes(imagePath, png);

        if (jsonPath != null)
        {
            string[] names = PngExporter.SequenceNames(o.FileNamePrefix, total);
            int durationMs = (int)Math.Round(1000.0 / Math.Max(1.0, o.Fps));
            var frames = new List<object>(total);
            for (int k = 0; k < total; k++)
            {
                var (fx, fy) = layout.CellOrigin(k);
                frames.Add(new
                {
                    filename = Path.GetFileNameWithoutExtension(names[k]),
                    frame = new { x = fx, y = fy, w = layout.CellWidth, h = layout.CellHeight },
                    sourceFrame = ctx.Sources[k],
                    duration = durationMs
                });
            }
            var doc = new
            {
                frames,
                meta = new
                {
                    app = "AnimDraw Studio",
                    image = imageFileNameForJson,
                    format = o.Transparent ? "RGBA8888" : "RGB888",
                    size = new { w = layout.Width, h = layout.Height },
                    cell = new { w = layout.CellWidth, h = layout.CellHeight },
                    columns = layout.Columns,
                    rows = layout.Rows,
                    padding = layout.Padding,
                    frameCount = total,
                    fps = o.Fps
                }
            };
            File.WriteAllText(jsonPath, JsonSerializer.Serialize(doc, new JsonSerializerOptions { WriteIndented = true }));
        }
        ctx.Report(1, "Done", total, total);
    }
}
