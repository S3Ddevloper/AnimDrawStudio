using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;
using AnimDraw.Core.Rendering;

namespace AnimDraw.Core.Export;

/// <summary>Turns project frames into finished output pictures: flattened, backgrounded or transparent, and scaled.</summary>
public sealed class FrameRenderer
{
    private readonly Project _project;
    private readonly int _width;
    private readonly int _height;
    private readonly bool _transparent;
    private readonly ResampleMode _mode;

    public FrameRenderer(Project project, int width, int height, bool transparent, bool smoothScaling)
    {
        _project = project;
        _width = width;
        _height = height;
        _transparent = transparent;
        _mode = smoothScaling ? ResampleMode.Smooth : ResampleMode.Nearest;
    }

    public int Width => _width;
    public int Height => _height;
    public bool Transparent => _transparent;

    /// <summary>Renders one frame. Safe to call from several threads at once.</summary>
    public PixelBuffer Render(int frame)
    {
        var picture = Compositor.ComposeFrame(_project, frame, withBackground: !_transparent);

        // A picture that must be opaque but whose project background is "transparent" is put on white.
        if (!_transparent && _project.Background.Mode == BackgroundMode.Transparent)
        {
            var flat = new PixelBuffer(picture.Width, picture.Height);
            flat.Fill(0xFFFFFFFFu);
            flat.BlendFrom(picture, 0, 0);
            picture = flat;
        }

        if (picture.Width != _width || picture.Height != _height)
            picture = Resampler.Scale(picture, _width, _height, _mode);
        return picture;
    }
}

/// <summary>Chooses which project frame supplies each output frame, and how long each one is shown.</summary>
public static class ExportTimeline
{
    /// <summary>
    /// The project frame behind each output frame. When the output rate equals the project rate this is simply
    /// start..end; otherwise frames are repeated or skipped so the animation keeps its real-time length.
    /// </summary>
    public static IReadOnlyList<int> MapFrames(int start, int end, double projectFps, double outputFps)
    {
        int count = end - start + 1;
        if (count <= 0) return Array.Empty<int>();
        if (Math.Abs(projectFps - outputFps) < 1e-6 || outputFps <= 0 || projectFps <= 0)
            return Enumerable.Range(start, count).ToArray();

        int outCount = Math.Max(1, (int)Math.Round(count * outputFps / projectFps));
        var map = new int[outCount];
        for (int k = 0; k < outCount; k++)
        {
            int src = start + (int)Math.Floor(k * projectFps / outputFps + 1e-9);
            map[k] = Math.Clamp(src, start, end);
        }
        return map;
    }

    /// <summary>
    /// GIF frame delays in hundredths of a second. A rate such as 12 fps needs 8.33, so delays alternate between 8 and 9
    /// and the total stays exact. Browsers treat delays below 2 as 10, so none is shorter than 2.
    /// </summary>
    public static int[] GifDelays(int frameCount, double fps)
    {
        var delays = new int[frameCount];
        int emitted = 0;
        for (int k = 0; k < frameCount; k++)
        {
            int target = (int)Math.Round((k + 1) * 100.0 / fps);
            int d = Math.Max(2, target - emitted);
            delays[k] = d;
            emitted += d;
        }
        return delays;
    }

    /// <summary>The highest frame rate a GIF can show reliably (a delay of 2/100 s).</summary>
    public const double MaxGifFps = 50;
}

/// <summary>Renders frames on several threads while handing them out in order, using bounded memory.</summary>
public static class FramePipeline
{
    /// <summary>
    /// Yields <paramref name="render"/>(source) for every entry in order. Up to <paramref name="depth"/> frames are
    /// rendered ahead on the thread pool. A source frame that repeats the previous one is not rendered again, and the
    /// same result instance is returned, so callers must treat results as read-only.
    /// </summary>
    public static IEnumerable<T> Render<T>(IReadOnlyList<int> sources, Func<int, T> render, int depth, CancellationToken ct)
    {
        depth = Math.Max(1, depth);
        var queue = new Queue<Task<T>>();
        int next = 0;
        int lastSource = -1;
        Task<T>? lastTask = null;
        try
        {
            while (next < sources.Count || queue.Count > 0)
            {
                ct.ThrowIfCancellationRequested();
                while (next < sources.Count && queue.Count < depth)
                {
                    int src = sources[next++];
                    if (lastTask != null && src == lastSource)
                    {
                        queue.Enqueue(lastTask);
                    }
                    else
                    {
                        int captured = src;
                        lastTask = Task.Run(() => render(captured), CancellationToken.None);
                        lastSource = src;
                        queue.Enqueue(lastTask);
                    }
                }
                var task = queue.Dequeue();
                T item = task.GetAwaiter().GetResult();
                yield return item;
            }
        }
        finally
        {
            // Let renders that are still running finish quietly so their exceptions are never left unobserved.
            foreach (var t in queue)
            {
                try { t.GetAwaiter().GetResult(); } catch (Exception) { }
            }
        }
    }

    /// <summary>How many frames to keep in flight: as many as there are cores, within a memory budget.</summary>
    public static int ChooseDepth(int width, int height, long memoryBudgetBytes = 256L * 1024 * 1024)
    {
        long frameBytes = Math.Max(1L, (long)width * height * 4 * 2); // the composed picture and its scaled copy
        return (int)Math.Clamp(memoryBudgetBytes / frameBytes, 1, Math.Max(2, Environment.ProcessorCount));
    }
}
