namespace AnimDraw.Core.Export;

/// <summary>GIF-flavoured LZW compression of palette indices, written as the sub-blocks a GIF image expects.</summary>
public sealed class GifLzwEncoder
{
    private const int TableBits = 13;
    private const int TableMask = (1 << TableBits) - 1;

    private readonly int[] _keys = new int[1 << TableBits];     // key + 1, or 0 for an empty slot
    private readonly ushort[] _codes = new ushort[1 << TableBits];
    private readonly byte[] _block = new byte[255];

    private Stream _out = Stream.Null;
    private int _blockLength;
    private int _bitBuffer;
    private int _bitCount;
    private int _codeSize;

    /// <summary>Writes the minimum-code-size byte, the compressed data in sub-blocks, and the block terminator.</summary>
    public void Encode(ReadOnlySpan<byte> pixels, Stream output, int minCodeSize = 8)
    {
        if (minCodeSize < 2 || minCodeSize > 8) throw new ArgumentOutOfRangeException(nameof(minCodeSize));
        _out = output;
        _blockLength = 0;
        _bitBuffer = 0;
        _bitCount = 0;
        output.WriteByte((byte)minCodeSize);

        int clear = 1 << minCodeSize;
        int eoi = clear + 1;
        int next = eoi + 1;
        _codeSize = minCodeSize + 1;
        Array.Clear(_keys);

        Emit(clear);
        if (pixels.Length == 0)
        {
            Emit(eoi);
            Flush();
            return;
        }

        int mask = clear - 1;
        int prefix = pixels[0] & mask;
        for (int i = 1; i < pixels.Length; i++)
        {
            int k = pixels[i] & mask;
            int key = (prefix << 8) | k;
            int slot = (int)(((uint)key * 2654435761u) >> (32 - TableBits));
            bool found = false;
            while (true)
            {
                int stored = _keys[slot];
                if (stored == 0) break;
                if (stored == key + 1) { found = true; break; }
                slot = (slot + 1) & TableMask;
            }

            if (found)
            {
                prefix = _codes[slot];
                continue;
            }

            Emit(prefix);
            if (next == 4096)
            {
                // The table is full: tell the decoder to start over.
                Emit(clear);
                Array.Clear(_keys);
                next = eoi + 1;
                _codeSize = minCodeSize + 1;
            }
            else
            {
                // The code size grows when the first code that needs another bit is created. The decoder is one step
                // behind the encoder, so the change has to be made at this moment, after the previous code was written.
                if (next >= (1 << _codeSize)) _codeSize++;
                _keys[slot] = key + 1;
                _codes[slot] = (ushort)next;
                next++;
            }
            prefix = k;
        }

        Emit(prefix);
        Emit(eoi);
        Flush();
    }

    private void Emit(int code)
    {
        _bitBuffer |= code << _bitCount;
        _bitCount += _codeSize;
        while (_bitCount >= 8)
        {
            AddByte((byte)(_bitBuffer & 0xFF));
            _bitBuffer >>= 8;
            _bitCount -= 8;
        }
    }

    private void AddByte(byte b)
    {
        _block[_blockLength++] = b;
        if (_blockLength == 255) WriteBlock();
    }

    private void WriteBlock()
    {
        if (_blockLength == 0) return;
        _out.WriteByte((byte)_blockLength);
        _out.Write(_block, 0, _blockLength);
        _blockLength = 0;
    }

    private void Flush()
    {
        if (_bitCount > 0)
        {
            AddByte((byte)(_bitBuffer & 0xFF));
            _bitBuffer = 0;
            _bitCount = 0;
        }
        WriteBlock();
        _out.WriteByte(0); // block terminator
    }
}

/// <summary>
/// Writes an animated GIF one frame at a time. Frames that repeat the previous one only lengthen its delay, and in
/// opaque animations only the part of the picture that changed is stored, which keeps files small.
/// </summary>
public sealed class GifFrameWriter
{
    private sealed class Pending
    {
        public int X, Y, Width, Height;
        public byte[] Data = Array.Empty<byte>();
        public bool HasTransparency;
        public int Disposal;
        public int DelayCs;
    }

    private readonly Stream _out;
    private readonly int _width;
    private readonly int _height;
    private readonly bool _transparentMode;
    private readonly GifLzwEncoder _lzw = new();
    private byte[]? _previous;
    private Pending? _pending;
    private bool _finished;

    /// <param name="paletteRgb">The 768-byte colour table; index 0 must be the transparent slot.</param>
    /// <param name="transparentMode">True when pictures contain see-through pixels (index 0).</param>
    public GifFrameWriter(Stream output, int width, int height, byte[] paletteRgb, bool loop, bool transparentMode)
    {
        if (width < 1 || height < 1 || width > 65535 || height > 65535) throw new ArgumentOutOfRangeException(nameof(width), "GIF size is out of range.");
        if (paletteRgb.Length != 768) throw new ArgumentException("The palette must hold 256 colours.", nameof(paletteRgb));
        _out = output;
        _width = width;
        _height = height;
        _transparentMode = transparentMode;

        WriteAscii("GIF89a");
        WriteU16(width);
        WriteU16(height);
        _out.WriteByte(0xF7);   // global colour table present, 8 bits per colour, 256 entries
        _out.WriteByte(0);      // background colour index
        _out.WriteByte(0);      // pixel aspect ratio
        _out.Write(paletteRgb, 0, 768);

        if (loop)
        {
            _out.Write(new byte[] { 0x21, 0xFF, 0x0B });
            WriteAscii("NETSCAPE2.0");
            _out.Write(new byte[] { 0x03, 0x01, 0x00, 0x00, 0x00 }); // repeat forever
        }
    }

    /// <summary>Adds a frame. <paramref name="indices"/> is copied, so the caller may reuse it.</summary>
    public void AddFrame(byte[] indices, int delayCs)
    {
        if (_finished) throw new InvalidOperationException("The GIF is already finished.");
        if (indices.Length < _width * _height) throw new ArgumentException("Frame is smaller than the GIF.", nameof(indices));
        delayCs = Math.Clamp(delayCs, 1, 65535);
        int count = _width * _height;
        var current = indices.AsSpan(0, count);

        if (_previous != null && current.SequenceEqual(_previous))
        {
            _pending!.DelayCs = Math.Min(65535, _pending.DelayCs + delayCs);
            return;
        }

        FlushPending();
        Pending next;
        if (!_transparentMode)
        {
            next = _previous == null ? MakeFull(current) : MakeChangedPart(current, _previous);
        }
        else
        {
            next = MakeOpaquePart(current);
        }
        next.DelayCs = delayCs;
        _pending = next;
        _previous ??= new byte[count];
        current.CopyTo(_previous);
    }

    public void Finish()
    {
        if (_finished) return;
        FlushPending();
        _out.WriteByte(0x3B);
        _out.Flush();
        _finished = true;
    }

    private Pending MakeFull(ReadOnlySpan<byte> current)
    {
        var p = new Pending { X = 0, Y = 0, Width = _width, Height = _height, HasTransparency = false, Disposal = 1 };
        p.Data = Compress(current);
        return p;
    }

    /// <summary>Opaque animation: store only the rectangle that changed; unchanged pixels inside it are transparent.</summary>
    private Pending MakeChangedPart(ReadOnlySpan<byte> current, byte[] previous)
    {
        int minX = _width, minY = _height, maxX = -1, maxY = -1;
        for (int y = 0; y < _height; y++)
        {
            int row = y * _width;
            // quick skip of unchanged rows
            if (current.Slice(row, _width).SequenceEqual(previous.AsSpan(row, _width))) continue;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
            for (int x = 0; x < _width; x++)
            {
                if (current[row + x] != previous[row + x])
                {
                    if (x < minX) minX = x;
                    break;
                }
            }
            for (int x = _width - 1; x >= 0; x--)
            {
                if (current[row + x] != previous[row + x])
                {
                    if (x > maxX) maxX = x;
                    break;
                }
            }
        }

        int w = maxX - minX + 1, h = maxY - minY + 1;
        var sub = new byte[w * h];
        for (int y = 0; y < h; y++)
        {
            int src = (minY + y) * _width + minX;
            int dst = y * w;
            for (int x = 0; x < w; x++)
            {
                byte c = current[src + x];
                sub[dst + x] = c == previous[src + x] ? (byte)GifPalette.TransparentIndex : c;
            }
        }
        var p = new Pending { X = minX, Y = minY, Width = w, Height = h, HasTransparency = true, Disposal = 1 };
        p.Data = Compress(sub);
        return p;
    }

    /// <summary>Transparent animation: store the rectangle around the artwork; the next frame clears it first.</summary>
    private Pending MakeOpaquePart(ReadOnlySpan<byte> current)
    {
        int minX = _width, minY = _height, maxX = -1, maxY = -1;
        for (int y = 0; y < _height; y++)
        {
            int row = y * _width;
            for (int x = 0; x < _width; x++)
            {
                if (current[row + x] == GifPalette.TransparentIndex) continue;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }

        Pending p;
        if (maxX < 0)
        {
            // An empty frame: a single see-through pixel keeps the timing.
            p = new Pending { X = 0, Y = 0, Width = 1, Height = 1, HasTransparency = true, Disposal = 2 };
            p.Data = Compress(new byte[] { GifPalette.TransparentIndex });
            return p;
        }

        int w = maxX - minX + 1, h = maxY - minY + 1;
        var sub = new byte[w * h];
        for (int y = 0; y < h; y++)
            current.Slice((minY + y) * _width + minX, w).CopyTo(sub.AsSpan(y * w, w));
        p = new Pending { X = minX, Y = minY, Width = w, Height = h, HasTransparency = true, Disposal = 2 };
        p.Data = Compress(sub);
        return p;
    }

    private byte[] Compress(ReadOnlySpan<byte> pixels)
    {
        using var ms = new MemoryStream(Math.Max(256, pixels.Length / 4));
        _lzw.Encode(pixels, ms);
        return ms.ToArray();
    }

    private void FlushPending()
    {
        var p = _pending;
        if (p == null) return;
        _pending = null;

        // Graphic control extension: disposal method, transparency flag, delay, transparent colour index.
        _out.Write(new byte[] { 0x21, 0xF9, 0x04 });
        _out.WriteByte((byte)((p.Disposal << 2) | (p.HasTransparency ? 1 : 0)));
        WriteU16(p.DelayCs);
        _out.WriteByte(GifPalette.TransparentIndex);
        _out.WriteByte(0);

        // Image descriptor (no local colour table, not interlaced).
        _out.WriteByte(0x2C);
        WriteU16(p.X);
        WriteU16(p.Y);
        WriteU16(p.Width);
        WriteU16(p.Height);
        _out.WriteByte(0);
        _out.Write(p.Data, 0, p.Data.Length);
    }

    private void WriteU16(int value)
    {
        _out.WriteByte((byte)(value & 0xFF));
        _out.WriteByte((byte)((value >> 8) & 0xFF));
    }

    private void WriteAscii(string s)
    {
        foreach (char c in s) _out.WriteByte((byte)c);
    }
}
