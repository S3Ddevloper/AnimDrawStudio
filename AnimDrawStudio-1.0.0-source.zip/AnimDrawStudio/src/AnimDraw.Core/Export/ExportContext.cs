using AnimDraw.Core.Model;

namespace AnimDraw.Core.Export;

/// <summary>A failure with a message that can be shown to the user as it is.</summary>
internal sealed class ExportException : Exception
{
    public ExportProblem Problem { get; }

    public ExportException(ExportProblem problem, string message, Exception? inner = null) : base(message, inner)
    {
        Problem = problem;
    }
}

/// <summary>What the individual exporters share: the frozen project, normalised options and progress reporting.</summary>
internal sealed class ExportContext
{
    public ExportContext(Project project, ExportOptions options, IReadOnlyList<int> sources,
        IProgress<ExportProgress>? progress, CancellationToken ct, List<string> warnings)
    {
        Project = project;
        Options = options;
        Sources = sources;
        Progress = progress;
        Ct = ct;
        Warnings = warnings;
    }

    public Project Project { get; }
    public ExportOptions Options { get; }

    /// <summary>For each output frame, the project frame that supplies it.</summary>
    public IReadOnlyList<int> Sources { get; }

    public IProgress<ExportProgress>? Progress { get; }
    public CancellationToken Ct { get; }
    public List<string> Warnings { get; }

    public void Report(double fraction, string message, int done, int total) =>
        Progress?.Report(new ExportProgress(Math.Clamp(fraction, 0, 1), message, done, total));

    public FrameRenderer CreateRenderer(bool transparent) =>
        new(Project, Options.Width, Options.Height, transparent, Options.SmoothScaling);
}
