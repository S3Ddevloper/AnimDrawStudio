using System.Collections.Concurrent;
using System.Diagnostics;

namespace AnimDraw.Core.Export;

/// <summary>A working ffmpeg and the video encoders it offers.</summary>
public sealed record FfmpegInfo(string Path, string Version, bool HasLibx264, bool HasOpenH264, bool HasMpeg4)
{
    public bool CanWriteMp4 => HasLibx264 || HasOpenH264 || HasMpeg4;
}

/// <summary>
/// Finds ffmpeg for MP4 export. AnimDraw Studio does not contain FFmpeg itself; it looks, in this order, at the path
/// chosen in the export dialog, an "ffmpeg" folder (or the file itself) beside the program, and the PATH.
/// </summary>
public static class FfmpegLocator
{
    public const string DownloadPage = "https://ffmpeg.org/download.html";

    private static readonly ConcurrentDictionary<string, FfmpegInfo?> Cache = new(StringComparer.OrdinalIgnoreCase);

    public static string ExecutableName => OperatingSystem.IsWindows() ? "ffmpeg.exe" : "ffmpeg";

    /// <summary>Every place that is tried, best first (files that do not exist are still listed).</summary>
    public static IEnumerable<string> Candidates(string? userPath, string? appFolder = null)
    {
        if (!string.IsNullOrWhiteSpace(userPath))
        {
            string p = userPath.Trim().Trim('"');
            yield return Directory.Exists(p) ? System.IO.Path.Combine(p, ExecutableName) : p;
        }

        string baseDir = appFolder ?? AppContext.BaseDirectory;
        yield return System.IO.Path.Combine(baseDir, "ffmpeg", ExecutableName);
        yield return System.IO.Path.Combine(baseDir, "ffmpeg", "bin", ExecutableName);
        yield return System.IO.Path.Combine(baseDir, ExecutableName);

        string? path = Environment.GetEnvironmentVariable("PATH");
        if (!string.IsNullOrEmpty(path))
        {
            foreach (string dir in path.Split(System.IO.Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
            {
                string? candidate = null;
                try { candidate = System.IO.Path.Combine(dir.Trim().Trim('"'), ExecutableName); }
                catch (ArgumentException) { }
                if (candidate != null) yield return candidate;
            }
        }
    }

    /// <summary>Returns the first candidate that really runs, or null if there is none.</summary>
    public static FfmpegInfo? Find(string? userPath, string? appFolder = null)
    {
        foreach (string candidate in Candidates(userPath, appFolder))
        {
            if (!File.Exists(candidate)) continue;
            var info = Probe(candidate);
            if (info != null) return info;
        }
        return null;
    }

    /// <summary>Runs ffmpeg briefly to confirm it works and to see which encoders it has. Null if it does not run.</summary>
    public static FfmpegInfo? Probe(string path)
    {
        string key;
        try
        {
            var fi = new FileInfo(path);
            key = fi.FullName + "|" + fi.LastWriteTimeUtc.Ticks + "|" + fi.Length;
        }
        catch (Exception) { return null; }
        return Cache.GetOrAdd(key, _ => ProbeCore(path));
    }

    private static FfmpegInfo? ProbeCore(string path)
    {
        string? version = Run(path, new[] { "-hide_banner", "-version" }, 8000);
        if (version == null || !version.Contains("ffmpeg", StringComparison.OrdinalIgnoreCase)) return null;
        string firstLine = version.Split('\n')[0].Trim();

        string encoders = Run(path, new[] { "-hide_banner", "-encoders" }, 15000) ?? "";
        bool Has(string name) => encoders.Split('\n').Any(l =>
        {
            var parts = l.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            return parts.Length >= 2 && parts[0].StartsWith('V') && parts[1] == name;
        });
        return new FfmpegInfo(path, firstLine, Has("libx264"), Has("libopenh264"), Has("mpeg4"));
    }

    /// <summary>Runs a program, returns its standard output, or null if it could not be started, failed, or took too long.</summary>
    private static string? Run(string exe, string[] args, int timeoutMs)
    {
        try
        {
            var psi = new ProcessStartInfo(exe)
            {
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                RedirectStandardInput = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            foreach (string a in args) psi.ArgumentList.Add(a);
            using var p = Process.Start(psi);
            if (p == null) return null;
            p.StandardInput.Close();
            var stderr = p.StandardError.ReadToEndAsync();
            var stdout = p.StandardOutput.ReadToEndAsync();
            if (!p.WaitForExit(timeoutMs))
            {
                try { p.Kill(entireProcessTree: true); } catch (Exception) { }
                return null;
            }
            stdout.Wait(2000);
            stderr.Wait(2000);
            return p.ExitCode == 0 ? stdout.Result : null;
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException or IOException or UnauthorizedAccessException)
        {
            return null;
        }
    }

    /// <summary>The text shown when MP4 export cannot find ffmpeg.</summary>
    public static string MissingMessage(string? triedPath)
    {
        string tried = string.IsNullOrWhiteSpace(triedPath) ? "" : $" (the path \"{triedPath}\" does not work)";
        return "MP4 export needs FFmpeg, a free video tool, and it was not found" + tried + ". " +
               $"Download a build for Windows from {DownloadPage}, then either put ffmpeg.exe in an \"ffmpeg\" folder next to AnimDraw Studio, " +
               "or choose its location in the export window. Animated GIF, PNG and sprite sheet export work without it.";
    }
}
