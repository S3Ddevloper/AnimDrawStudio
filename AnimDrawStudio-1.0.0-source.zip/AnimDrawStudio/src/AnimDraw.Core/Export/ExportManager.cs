using System.Diagnostics;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Model;

namespace AnimDraw.Core.Export;

/// <summary>
/// What an export will do, worked out without doing it: the cleaned-up options, how many frames it produces, the files it
/// will write, and anything that is wrong or was adjusted. The export window uses this to show a summary and to enable
/// the Export button only when the settings are usable.
/// </summary>
public sealed record ExportPlan(
    ExportOptions Options,
    IReadOnlyList<int> Sources,
    TimeSpan Duration,
    IReadOnlyList<string> Problems,
    IReadOnlyList<string> Warnings,
    IReadOnlyList<string> OutputFiles)
{
    public bool IsValid => Problems.Count == 0;
    public int OutputFrames => Sources.Count;
}

/// <summary>Runs exports in the background, reports progress, can be cancelled, and never throws for ordinary problems.</summary>
public static class ExportManager
{
    // The Windows rules are applied on every platform so a project exported anywhere makes files that Windows accepts too.
    private static readonly char[] InvalidNameChars =
        Path.GetInvalidFileNameChars().Union("\\/:*?\"<>|".ToCharArray()).ToArray();

    // ------------------------------------------------------------------ planning

    public static ExportPlan Plan(Project project, ExportOptions requested)
    {
        var o = requested.Clone();
        var problems = new List<string>();
        var warnings = new List<string>();
        int last = project.FrameCount - 1;

        o.StartFrame = Math.Clamp(o.StartFrame, 0, last);
        o.EndFrame = Math.Clamp(o.EndFrame, 0, last);
        if (o.Format == ExportFormat.Png) o.EndFrame = o.StartFrame;
        if (o.EndFrame < o.StartFrame) problems.Add("The last frame cannot come before the first frame.");

        if (o.Width <= 0) o.Width = project.Width;
        if (o.Height <= 0) o.Height = project.Height;
        if (o.Width > ExportOptions.MaxOutputDimension || o.Height > ExportOptions.MaxOutputDimension)
            problems.Add($"The picture size can be at most {ExportOptions.MaxOutputDimension} x {ExportOptions.MaxOutputDimension} pixels.");
        else if ((long)o.Width * o.Height > ProjectLimits.MaxPixels)
            problems.Add($"A picture of {o.Width} x {o.Height} has more than {ProjectLimits.MaxPixels / 1_000_000} million pixels, which is too large to export.");

        bool timed = o.Format is ExportFormat.Gif or ExportFormat.Mp4;
        if (double.IsNaN(o.Fps) || o.Fps < ProjectLimits.MinFps || o.Fps > ProjectLimits.MaxFps)
        {
            if (timed) problems.Add($"The frame rate must be between {ProjectLimits.MinFps:0} and {ProjectLimits.MaxFps:0} frames per second.");
            else o.Fps = ProjectLimits.ClampFps(o.Fps);
        }
        o.Quality = Math.Clamp(o.Quality, 1, 100);
        o.Padding = Math.Clamp(o.Padding, 0, 512);
        o.Columns = Math.Clamp(o.Columns, 0, 1024);
        o.FileNamePrefix = CleanPrefix(o.FileNamePrefix);

        switch (o.Format)
        {
            case ExportFormat.Gif:
                if (o.Fps > ExportTimeline.MaxGifFps && problems.Count == 0)
                {
                    warnings.Add($"GIF files cannot reliably play faster than {ExportTimeline.MaxGifFps:0} frames per second, so {ExportTimeline.MaxGifFps:0} is used.");
                    o.Fps = ExportTimeline.MaxGifFps;
                }
                break;

            case ExportFormat.Mp4:
                if (o.Transparent)
                {
                    warnings.Add("MP4 video cannot be transparent, so the background is included.");
                    o.Transparent = false;
                }
                if ((o.Width % 2 != 0 || o.Height % 2 != 0) && o.Width > 0 && o.Height > 0 && problems.Count == 0)
                {
                    int w = (o.Width + 1) & ~1, h = (o.Height + 1) & ~1;
                    warnings.Add($"MP4 video needs an even width and height, so the size was changed from {o.Width} x {o.Height} to {w} x {h}.");
                    o.Width = w;
                    o.Height = h;
                }
                break;
        }

        IReadOnlyList<int> sources = problems.Count > 0
            ? Array.Empty<int>()
            : timed
                ? ExportTimeline.MapFrames(o.StartFrame, o.EndFrame, project.Fps, o.Fps)
                : ExportTimeline.MapFrames(o.StartFrame, o.EndFrame, project.Fps, project.Fps);

        var files = new List<string>();
        if (string.IsNullOrWhiteSpace(o.OutputPath))
        {
            problems.Add(o.Format == ExportFormat.PngSequence ? "Choose a folder for the pictures." : "Choose where to save the file.");
        }
        else
        {
            string full = "";
            try { full = Path.GetFullPath(o.OutputPath.Trim()); }
            catch (Exception ex) when (ex is ArgumentException or NotSupportedException or PathTooLongException)
            {
                problems.Add("That file or folder name is not valid.");
            }

            if (full.Length > 0)
            {
                if (o.Format == ExportFormat.PngSequence)
                {
                    if (File.Exists(full)) problems.Add("A file with that name exists, but a folder is needed for the pictures.");
                    else if (sources.Count > 0)
                        files.AddRange(PngExporter.SequenceNames(o.FileNamePrefix, sources.Count).Select(n => Path.Combine(full, n)));
                    o.OutputPath = full;
                }
                else
                {
                    string ext = ExportOptions.DefaultExtension(o.Format);
                    if (!full.EndsWith(ext, StringComparison.OrdinalIgnoreCase)) full += ext;
                    if (Directory.Exists(full)) problems.Add("A folder with that name exists. Choose a different file name.");
                    o.OutputPath = full;
                    files.Add(full);
                    if (o.Format == ExportFormat.SpriteSheet && o.WriteSpriteSheetJson) files.Add(Path.ChangeExtension(full, ".json"));
                }
            }
        }

        if (o.Format == ExportFormat.SpriteSheet && sources.Count > 0)
        {
            var layout = SpriteSheetLayout.Compute(sources.Count, o.Width, o.Height, o.Columns, o.Padding);
            if (!layout.IsWithinLimits(out string? sheetProblem)) problems.Add(sheetProblem!);
        }

        double perSecond = timed ? o.Fps : project.Fps;
        if (!(perSecond >= 1.0)) perSecond = 1.0; // also catches NaN, which can only occur when a problem has already been reported
        var duration = TimeSpan.FromSeconds(sources.Count / perSecond);
        return new ExportPlan(o, sources, duration, problems, warnings, files);
    }

    /// <summary>Existing files that the export would replace, so the user can be asked first.</summary>
    public static IReadOnlyList<string> FindExistingOutputs(Project project, ExportOptions options)
    {
        var plan = Plan(project, options);
        return plan.OutputFiles.Where(File.Exists).ToList();
    }

    /// <summary>The file names a PNG sequence will use, for example frame_0001.png, frame_0002.png, ...</summary>
    public static string[] SequenceFileNames(string prefix, int count) => PngExporter.SequenceNames(CleanPrefix(prefix), count);

    private static string CleanPrefix(string? prefix)
    {
        if (string.IsNullOrWhiteSpace(prefix)) return "frame";
        var chars = prefix.Trim().Select(c => Array.IndexOf(InvalidNameChars, c) >= 0 ? '_' : c).ToArray();
        string cleaned = new string(chars).Trim('.', ' ');
        return cleaned.Length == 0 ? "frame" : cleaned.Length > 60 ? cleaned[..60] : cleaned;
    }

    // ------------------------------------------------------------------ running

    /// <summary>
    /// Exports without freezing the window: the project is snapshotted here (quick) and everything else runs on
    /// worker threads. Progress is reported through <paramref name="progress"/> and the export can be cancelled.
    /// </summary>
    public static async Task<ExportResult> ExportAsync(Document doc, ExportOptions options,
        IProgress<ExportProgress>? progress = null, CancellationToken ct = default)
    {
        doc.CommitActiveEdit();
        var snapshot = doc.CreateSnapshot();
        var copy = options.Clone();
        return await Task.Run(() => Export(snapshot, copy, progress, ct)).ConfigureAwait(true);
    }

    /// <summary>Runs an export on the calling thread. Problems come back in the result; nothing is thrown for them.</summary>
    public static ExportResult Export(Project project, ExportOptions requested,
        IProgress<ExportProgress>? progress = null, CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        var plan = Plan(project, requested);
        var warnings = plan.Warnings.ToList();
        if (!plan.IsValid) return Fail(ExportProblem.InvalidOptions, string.Join(" ", plan.Problems), warnings, sw);

        var o = plan.Options;
        var temporaries = new List<string>();
        string? stagingFolder = null;
        string? createdFolder = null;
        bool succeeded = false;
        try
        {
            ct.ThrowIfCancellationRequested();
            var ctx = new ExportContext(project, o, plan.Sources, progress, ct, warnings);
            ctx.Report(0, "Starting...", 0, plan.Sources.Count);

            switch (o.Format)
            {
                case ExportFormat.PngSequence:
                    if (!Directory.Exists(o.OutputPath)) createdFolder = o.OutputPath;
                    stagingFolder = Path.Combine(o.OutputPath, ".animdraw-export-" + Guid.NewGuid().ToString("N")[..8]);
                    WriteSequence(ctx, o, stagingFolder);
                    break;

                case ExportFormat.SpriteSheet:
                {
                    string image = o.OutputPath;
                    Directory.CreateDirectory(Path.GetDirectoryName(image)!);
                    string imageTemp = TempNameFor(image);
                    temporaries.Add(imageTemp);
                    string? json = o.WriteSpriteSheetJson ? Path.ChangeExtension(image, ".json") : null;
                    string? jsonTemp = json == null ? null : TempNameFor(json);
                    if (jsonTemp != null) temporaries.Add(jsonTemp);
                    SpriteSheetExporter.Write(ctx, imageTemp, jsonTemp, Path.GetFileName(image));
                    File.Move(imageTemp, image, overwrite: true);
                    temporaries.Remove(imageTemp);
                    if (json != null && jsonTemp != null)
                    {
                        File.Move(jsonTemp, json, overwrite: true);
                        temporaries.Remove(jsonTemp);
                    }
                    break;
                }

                default:
                    WriteSingleFile(ctx, o, temporaries);
                    break;
            }

            ctx.Report(1, "Done", plan.Sources.Count, plan.Sources.Count);
            succeeded = true;
            long bytes = 0;
            foreach (string f in plan.OutputFiles)
            {
                try { if (File.Exists(f)) bytes += new FileInfo(f).Length; } catch (IOException) { }
            }
            return new ExportResult
            {
                Status = ExportStatus.Success,
                Problem = ExportProblem.None,
                Message = Describe(o, plan, bytes),
                Files = plan.OutputFiles,
                Warnings = warnings,
                TotalBytes = bytes,
                FramesWritten = plan.Sources.Count,
                Elapsed = sw.Elapsed
            };
        }
        catch (ExportException ex) { return Fail(ex.Problem, ex.Message, warnings, sw); }
        catch (OperationCanceledException)
        {
            return new ExportResult { Status = ExportStatus.Cancelled, Message = "The export was cancelled.", Warnings = warnings, Elapsed = sw.Elapsed };
        }
        catch (UnauthorizedAccessException)
        {
            return Fail(ExportProblem.FileAccess,
                "AnimDraw Studio is not allowed to write there. Choose another folder, or check that the file is not read-only or open in another program.", warnings, sw);
        }
        catch (DirectoryNotFoundException)
        {
            return Fail(ExportProblem.FileAccess, "The folder could not be found. Choose a different location.", warnings, sw);
        }
        catch (PathTooLongException)
        {
            return Fail(ExportProblem.FileAccess, "The file path is too long. Choose a shorter name or a folder closer to the top of the drive.", warnings, sw);
        }
        catch (IOException ex)
        {
            bool diskFull = (ex.HResult & 0xFFFF) is 0x27 or 0x70;
            return diskFull
                ? Fail(ExportProblem.DiskFull, "The disk is full. Free some space, or export to a different drive.", warnings, sw)
                : Fail(ExportProblem.FileAccess, "The export could not be written: " + ex.Message, warnings, sw);
        }
        catch (OutOfMemoryException)
        {
            return Fail(ExportProblem.Unexpected,
                "There is not enough memory to export at this size. Try a smaller picture size, fewer frames, or close other programs.", warnings, sw);
        }
        catch (Exception ex)
        {
            return Fail(ExportProblem.Unexpected, "The export failed unexpectedly: " + ex.Message, warnings, sw);
        }
        finally
        {
            foreach (string t in temporaries)
            {
                try { if (File.Exists(t)) File.Delete(t); } catch (Exception) { }
            }
            if (stagingFolder != null)
            {
                try { if (Directory.Exists(stagingFolder)) Directory.Delete(stagingFolder, recursive: true); } catch (Exception) { }
            }
            if (!succeeded && createdFolder != null)
            {
                // Do not leave an empty folder behind when the export created it and then failed or was cancelled.
                try
                {
                    if (Directory.Exists(createdFolder) && !Directory.EnumerateFileSystemEntries(createdFolder).Any())
                        Directory.Delete(createdFolder);
                }
                catch (Exception) { }
            }
        }
    }

    private static void WriteSingleFile(ExportContext ctx, ExportOptions o, List<string> temporaries)
    {
        string final = o.OutputPath;
        FfmpegInfo? ffmpeg = null;
        if (o.Format == ExportFormat.Mp4)
        {
            ffmpeg = FfmpegLocator.Find(o.FfmpegPath)
                     ?? throw new ExportException(ExportProblem.FfmpegMissing, FfmpegLocator.MissingMessage(o.FfmpegPath));
        }

        Directory.CreateDirectory(Path.GetDirectoryName(final)!);
        string temp = TempNameFor(final);
        temporaries.Add(temp);

        switch (o.Format)
        {
            case ExportFormat.Gif:
                using (var fs = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 1 << 16))
                {
                    GifExporter.Write(ctx, fs);
                    fs.Flush(true);
                }
                break;
            case ExportFormat.Png:
                PngExporter.WriteSingle(ctx, temp);
                break;
            case ExportFormat.Mp4:
                Mp4Exporter.Write(ctx, ffmpeg!, temp);
                break;
            default:
                throw new ExportException(ExportProblem.InvalidOptions, "This export format is not supported.");
        }

        File.Move(temp, final, overwrite: true);
        temporaries.Remove(temp);
    }

    /// <summary>Writes the pictures into a hidden staging folder, then moves them into place, so a failed or cancelled export leaves nothing half-done.</summary>
    private static void WriteSequence(ExportContext ctx, ExportOptions o, string staging)
    {
        string folder = o.OutputPath;
        Directory.CreateDirectory(staging); // also creates the output folder
        var names = PngExporter.WriteSequence(ctx, staging);
        ctx.Ct.ThrowIfCancellationRequested();
        foreach (string name in names)
            File.Move(Path.Combine(staging, name), Path.Combine(folder, name), overwrite: true);
    }

    private static string TempNameFor(string finalPath)
    {
        string dir = Path.GetDirectoryName(finalPath)!;
        return Path.Combine(dir, "." + Path.GetFileName(finalPath) + "." + Guid.NewGuid().ToString("N")[..8] + ".partial");
    }

    private static string Describe(ExportOptions o, ExportPlan plan, long bytes)
    {
        string size = bytes >= 1024 * 1024 ? $"{bytes / (1024.0 * 1024.0):0.0} MB" : $"{Math.Max(1, bytes / 1024)} KB";
        return o.Format switch
        {
            ExportFormat.Gif => $"Saved an animated GIF of {plan.OutputFrames} frames ({size}).",
            ExportFormat.Mp4 => $"Saved an MP4 video of {plan.OutputFrames} frames ({size}).",
            ExportFormat.Png => $"Saved the PNG picture ({size}).",
            ExportFormat.PngSequence => $"Saved {plan.OutputFrames} PNG pictures to the folder ({size}).",
            ExportFormat.SpriteSheet => $"Saved a sprite sheet of {plan.OutputFrames} frames ({size}).",
            _ => "Export finished."
        };
    }

    private static ExportResult Fail(ExportProblem problem, string message, List<string> warnings, Stopwatch sw) => new()
    {
        Status = ExportStatus.Failed,
        Problem = problem,
        Message = message,
        Warnings = warnings,
        Elapsed = sw.Elapsed
    };
}
