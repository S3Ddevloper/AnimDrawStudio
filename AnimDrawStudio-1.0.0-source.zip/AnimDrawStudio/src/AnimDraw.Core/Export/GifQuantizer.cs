using AnimDraw.Core.Imaging;

namespace AnimDraw.Core.Export;

/// <summary>
/// A GIF colour table: entry 0 is reserved for "transparent", entries 1..ColorCount hold colours.
/// Built by <see cref="PaletteBuilder"/>; maps pictures to palette indices.
/// </summary>
public sealed class GifPalette
{
    public const int TransparentIndex = 0;

    private static readonly byte[] Bayer8 =
    {
         0, 32,  8, 40,  2, 34, 10, 42,
        48, 16, 56, 24, 50, 18, 58, 26,
        12, 44,  4, 36, 14, 46,  6, 38,
        60, 28, 52, 20, 62, 30, 54, 22,
         3, 35, 11, 43,  1, 33,  9, 41,
        51, 19, 59, 27, 49, 17, 57, 25,
        15, 47,  7, 39, 13, 45,  5, 37,
        63, 31, 55, 23, 61, 29, 53, 21
    };

    /// <summary>
    /// A pixel is only dithered when its nearest palette colour is further away than this (sum of the three channel
    /// differences). Flat colours that the palette matches closely stay perfectly flat; gradients get smoothed.
    /// </summary>
    private const int DitherThreshold = 4;

    private readonly byte[] _rgb = new byte[256 * 3];
    private readonly byte[] _lut = new byte[32768];
    private Dictionary<int, byte>? _exact;

    internal GifPalette() { }

    /// <summary>The 256-entry table (768 bytes) as written into the GIF.</summary>
    public byte[] Rgb => _rgb;

    /// <summary>Number of real colours (not counting the transparent slot).</summary>
    public int ColorCount { get; internal set; }

    /// <summary>True when the pictures held no more colours than the palette, so every colour is represented exactly.</summary>
    public bool IsExact => _exact != null;

    internal void SetColor(int index, int r, int g, int b)
    {
        _rgb[index * 3] = (byte)r;
        _rgb[index * 3 + 1] = (byte)g;
        _rgb[index * 3 + 2] = (byte)b;
    }

    internal void UseExactColors(Dictionary<int, byte> map) => _exact = map;

    /// <summary>Fills the 15-bit lookup so every colour has a nearest palette entry.</summary>
    internal void BuildLookup(int[] binCount, long[] sumR, long[] sumG, long[] sumB)
    {
        int n = ColorCount;
        var pr = new int[n];
        var pg = new int[n];
        var pb = new int[n];
        for (int i = 0; i < n; i++)
        {
            pr[i] = _rgb[(i + 1) * 3];
            pg[i] = _rgb[(i + 1) * 3 + 1];
            pb[i] = _rgb[(i + 1) * 3 + 2];
        }

        for (int bin = 0; bin < 32768; bin++)
        {
            int r, g, b;
            if (binCount[bin] > 0)
            {
                // The average of the colours that really fell in this bin represents it better than the bin's centre.
                r = (int)(sumR[bin] / binCount[bin]);
                g = (int)(sumG[bin] / binCount[bin]);
                b = (int)(sumB[bin] / binCount[bin]);
            }
            else
            {
                r = ((bin >> 10) << 3) | 4;
                g = (((bin >> 5) & 31) << 3) | 4;
                b = ((bin & 31) << 3) | 4;
            }
            _lut[bin] = (byte)(Nearest(r, g, b, pr, pg, pb) + 1);
        }
    }

    private static int Nearest(int r, int g, int b, int[] pr, int[] pg, int[] pb)
    {
        int best = 0;
        int bestD = int.MaxValue;
        for (int i = 0; i < pr.Length; i++)
        {
            int dr = r - pr[i], dg = g - pg[i], db = b - pb[i];
            int d = dr * dr * 2 + dg * dg * 4 + db * db * 3;
            if (d < bestD)
            {
                bestD = d;
                best = i;
                if (d == 0) break;
            }
        }
        return best;
    }

    /// <summary>
    /// Converts a finished picture to palette indices. With <paramref name="transparentMode"/> pixels that are mostly
    /// see-through become index 0. <paramref name="ditherStrength"/> (0 = off) adds an ordered pattern to colours the
    /// palette cannot match closely, which smooths gradients without disturbing flat areas or moving between frames.
    /// </summary>
    public void Map(PixelBuffer picture, byte[] indices, bool transparentMode, int ditherStrength)
    {
        if (indices.Length < picture.Pixels.Length) throw new ArgumentException("indices is too small", nameof(indices));
        var px = picture.Pixels;
        int w = picture.Width;
        int h = picture.Height;
        var exact = _exact;
        byte[] lut = _lut;
        byte[] rgb = _rgb;

        for (int y = 0; y < h; y++)
        {
            int row = y * w;
            int bayerRow = (y & 7) << 3;
            for (int x = 0; x < w; x++)
            {
                uint p = px[row + x];
                int a = (int)(p >> 24);
                int r, g, b;
                if (a == 255)
                {
                    r = (int)(p >> 16) & 255;
                    g = (int)(p >> 8) & 255;
                    b = (int)p & 255;
                }
                else
                {
                    if (a < 128 && transparentMode)
                    {
                        indices[row + x] = TransparentIndex;
                        continue;
                    }
                    Px.ToStraight(p, out _, out r, out g, out b);
                }

                if (exact != null && exact.TryGetValue((r << 16) | (g << 8) | b, out byte hit))
                {
                    indices[row + x] = hit;
                    continue;
                }

                byte c = lut[((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3)];
                if (ditherStrength > 0)
                {
                    int e = c * 3;
                    int err = Math.Abs(r - rgb[e]) + Math.Abs(g - rgb[e + 1]) + Math.Abs(b - rgb[e + 2]);
                    if (err > DitherThreshold)
                    {
                        // (matrix value - 31.5) / 64 spreads the offset evenly over +/- strength/2
                        int offset = ((Bayer8[bayerRow + (x & 7)] * 2 - 63) * ditherStrength) / 128;
                        int r2 = Math.Clamp(r + offset, 0, 255);
                        int g2 = Math.Clamp(g + offset, 0, 255);
                        int b2 = Math.Clamp(b + offset, 0, 255);
                        c = lut[((r2 >> 3) << 10) | ((g2 >> 3) << 5) | (b2 >> 3)];
                    }
                }
                indices[row + x] = c;
            }
        }
    }
}

/// <summary>Collects the colours of sample pictures and builds a palette with median cut.</summary>
public sealed class PaletteBuilder
{
    private readonly int _maxColors;
    private readonly bool _transparentMode;
    private readonly int[] _count = new int[32768];
    private readonly long[] _sumR = new long[32768];
    private readonly long[] _sumG = new long[32768];
    private readonly long[] _sumB = new long[32768];
    private HashSet<int>? _distinct = new();

    /// <param name="maxColors">Colours wanted, 1 to 255 (index 0 is the transparent slot).</param>
    public PaletteBuilder(int maxColors, bool transparentMode)
    {
        _maxColors = Math.Clamp(maxColors, 1, 255);
        _transparentMode = transparentMode;
    }

    public void AddPicture(PixelBuffer picture)
    {
        var px = picture.Pixels;
        int lastKey = -1;
        for (int i = 0; i < px.Length; i++)
        {
            uint p = px[i];
            int a = (int)(p >> 24);
            int r, g, b;
            if (a == 255)
            {
                r = (int)(p >> 16) & 255;
                g = (int)(p >> 8) & 255;
                b = (int)p & 255;
            }
            else
            {
                if (a < 128 && _transparentMode) continue;
                Px.ToStraight(p, out _, out r, out g, out b);
            }

            int rgb24 = (r << 16) | (g << 8) | b;
            int bin = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3);
            _count[bin]++;
            _sumR[bin] += r;
            _sumG[bin] += g;
            _sumB[bin] += b;

            if (_distinct != null && rgb24 != lastKey)
            {
                lastKey = rgb24;
                _distinct.Add(rgb24);
                if (_distinct.Count > _maxColors) _distinct = null; // too many for an exact palette
            }
        }
    }

    private struct Entry
    {
        public int R, G, B;          // 5-bit channel values
        public long Count, SumR, SumG, SumB;
    }

    private sealed class Box
    {
        public int Lo, Hi;           // entries[Lo..Hi)
        public long Count;
        public int Range;            // largest channel extent, 5-bit units
        public int Axis;             // 0 = R, 1 = G, 2 = B
    }

    public GifPalette Build()
    {
        var palette = new GifPalette();

        // Few colours: use them exactly.
        if (_distinct != null)
        {
            var map = new Dictionary<int, byte>();
            int n = 0;
            foreach (int c in _distinct.OrderBy(v => v))
            {
                n++;
                palette.SetColor(n, (c >> 16) & 255, (c >> 8) & 255, c & 255);
                map[c] = (byte)n;
            }
            if (n == 0)
            {
                // No opaque pixels at all (an empty transparent animation): keep one dummy colour so the table is valid.
                n = 1;
                palette.SetColor(1, 0, 0, 0);
            }
            palette.ColorCount = n;
            palette.UseExactColors(map);
            palette.BuildLookup(_count, _sumR, _sumG, _sumB);
            return palette;
        }

        var entries = new List<Entry>();
        for (int bin = 0; bin < 32768; bin++)
        {
            if (_count[bin] == 0) continue;
            entries.Add(new Entry
            {
                R = bin >> 10, G = (bin >> 5) & 31, B = bin & 31,
                Count = _count[bin], SumR = _sumR[bin], SumG = _sumG[bin], SumB = _sumB[bin]
            });
        }
        var arr = entries.ToArray();

        var boxes = new List<Box> { MakeBox(arr, 0, arr.Length) };
        while (boxes.Count < _maxColors)
        {
            Box? best = null;
            double bestScore = 0;
            foreach (var b in boxes)
            {
                if (b.Hi - b.Lo < 2) continue;
                double score = (double)b.Count * (b.Range + 1);
                if (score > bestScore) { bestScore = score; best = b; }
            }
            if (best == null) break;

            // Sort along the widest channel and cut where half of the pixels lie on each side.
            int axis = best.Axis;
            Array.Sort(arr, best.Lo, best.Hi - best.Lo, Comparer<Entry>.Create((p, q) =>
                axis == 0 ? p.R.CompareTo(q.R) : axis == 1 ? p.G.CompareTo(q.G) : p.B.CompareTo(q.B)));
            long half = best.Count / 2, run = 0;
            int cut = best.Lo + 1;
            for (int i = best.Lo; i < best.Hi - 1; i++)
            {
                run += arr[i].Count;
                cut = i + 1;
                if (run >= half) break;
            }
            cut = Math.Clamp(cut, best.Lo + 1, best.Hi - 1);

            boxes.Remove(best);
            boxes.Add(MakeBox(arr, best.Lo, cut));
            boxes.Add(MakeBox(arr, cut, best.Hi));
        }

        int index = 0;
        foreach (var box in boxes.OrderByDescending(b => b.Count))
        {
            long sr = 0, sg = 0, sb = 0, cnt = 0;
            for (int i = box.Lo; i < box.Hi; i++)
            {
                sr += arr[i].SumR; sg += arr[i].SumG; sb += arr[i].SumB; cnt += arr[i].Count;
            }
            index++;
            if (cnt == 0) cnt = 1;
            palette.SetColor(index, (int)((sr + cnt / 2) / cnt), (int)((sg + cnt / 2) / cnt), (int)((sb + cnt / 2) / cnt));
        }
        if (index == 0)
        {
            index = 1;
            palette.SetColor(1, 0, 0, 0);
        }
        palette.ColorCount = index;
        palette.BuildLookup(_count, _sumR, _sumG, _sumB);
        return palette;
    }

    private static Box MakeBox(Entry[] arr, int lo, int hi)
    {
        int rMin = 31, rMax = 0, gMin = 31, gMax = 0, bMin = 31, bMax = 0;
        long count = 0;
        for (int i = lo; i < hi; i++)
        {
            var e = arr[i];
            count += e.Count;
            if (e.R < rMin) rMin = e.R; if (e.R > rMax) rMax = e.R;
            if (e.G < gMin) gMin = e.G; if (e.G > gMax) gMax = e.G;
            if (e.B < bMin) bMin = e.B; if (e.B > bMax) bMax = e.B;
        }
        // Green is the channel the eye resolves best, then red, then blue.
        double rr = (rMax - rMin) * 0.85, gg = (gMax - gMin) * 1.0, bb = (bMax - bMin) * 0.7;
        int axis = gg >= rr && gg >= bb ? 1 : rr >= bb ? 0 : 2;
        int range = (int)Math.Round(Math.Max(rr, Math.Max(gg, bb)));
        return new Box { Lo = lo, Hi = hi, Count = count, Range = range, Axis = axis };
    }
}
