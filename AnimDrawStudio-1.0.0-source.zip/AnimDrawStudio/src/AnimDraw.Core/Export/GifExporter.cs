namespace AnimDraw.Core.Export;

/// <summary>Writes an animated GIF: one pass picks a palette from sample frames, a second renders and encodes every frame.</summary>
internal static class GifExporter
{
    public static void Write(ExportContext ctx, Stream output)
    {
        var o = ctx.Options;
        var renderer = ctx.CreateRenderer(o.Transparent);
        int depth = FramePipeline.ChooseDepth(o.Width, o.Height);
        int total = ctx.Sources.Count;

        // Quality sets how many colours may be used and how strongly gradients are dithered.
        int maxColors = o.Quality >= 75 ? 255 : o.Quality >= 50 ? 127 : o.Quality >= 25 ? 63 : 31;
        int dither = o.Quality >= 90 ? 26 : o.Quality >= 50 ? 22 : 0;

        // Pass 1: the palette comes from up to 32 frames spread over the animation.
        var distinct = ctx.Sources.Distinct().ToList();
        int sampleCount = (int)Math.Clamp(120_000_000L / Math.Max(1L, (long)o.Width * o.Height), 2, 32);
        var samples = PickEvenly(distinct, sampleCount);
        var builder = new PaletteBuilder(maxColors, o.Transparent);
        int sampled = 0;
        foreach (var picture in FramePipeline.Render(samples, renderer.Render, depth, ctx.Ct))
        {
            builder.AddPicture(picture);
            ctx.Report(0.15 * ++sampled / samples.Count, "Choosing colours...", 0, total);
        }
        var palette = builder.Build();

        // Pass 2: render, map to the palette, compress.
        double fps = Math.Min(o.Fps, ExportTimeline.MaxGifFps);
        int[] delays = ExportTimeline.GifDelays(total, fps);
        var writer = new GifFrameWriter(output, o.Width, o.Height, palette.Rgb, o.Loop, o.Transparent);
        var indices = new byte[o.Width * o.Height];
        int done = 0;
        foreach (var picture in FramePipeline.Render(ctx.Sources, renderer.Render, depth, ctx.Ct))
        {
            palette.Map(picture, indices, o.Transparent, dither);
            writer.AddFrame(indices, delays[done]);
            done++;
            ctx.Report(0.15 + 0.85 * done / total, $"Encoding frame {done} of {total}...", done, total);
        }
        writer.Finish();
    }

    internal static List<int> PickEvenly(List<int> items, int count)
    {
        if (items.Count <= count) return items;
        var picked = new List<int>(count);
        for (int i = 0; i < count; i++)
            picked.Add(items[(int)Math.Round(i * (items.Count - 1) / (double)(count - 1))]);
        return picked.Distinct().ToList();
    }
}
