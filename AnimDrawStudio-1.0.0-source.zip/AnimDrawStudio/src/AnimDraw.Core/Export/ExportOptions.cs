using AnimDraw.Core.IO;
using AnimDraw.Core.Model;

namespace AnimDraw.Core.Export;

public enum ExportFormat
{
    /// <summary>Animated GIF.</summary>
    Gif,

    /// <summary>H.264 video in an MP4 file (needs FFmpeg).</summary>
    Mp4,

    /// <summary>One frame as a PNG picture.</summary>
    Png,

    /// <summary>Every frame as a numbered PNG file in a folder.</summary>
    PngSequence,

    /// <summary>All frames in one PNG picture, laid out in a grid.</summary>
    SpriteSheet
}

/// <summary>Everything that decides what an export produces.</summary>
public sealed class ExportOptions
{
    public const int MaxOutputDimension = 8192;

    public ExportFormat Format { get; set; } = ExportFormat.Gif;

    /// <summary>The file to write (GIF, MP4, PNG, sprite sheet) or the folder to fill (PNG sequence).</summary>
    public string OutputPath { get; set; } = "";

    /// <summary>Output picture size in pixels. Frames are scaled when it differs from the canvas.</summary>
    public int Width { get; set; }
    public int Height { get; set; }

    /// <summary>Playback rate of the result (GIF and MP4).</summary>
    public double Fps { get; set; } = 12;

    /// <summary>First and last frame to export, zero-based and inclusive. A PNG uses only the first.</summary>
    public int StartFrame { get; set; }
    public int EndFrame { get; set; }

    /// <summary>Leave the background out, so only the artwork remains (not possible for MP4).</summary>
    public bool Transparent { get; set; }

    /// <summary>1 (smallest file) to 100 (best picture). Used for GIF and MP4.</summary>
    public int Quality { get; set; } = 85;

    /// <summary>File size versus speed for PNG output; the picture is identical either way.</summary>
    public PngCompression PngCompression { get; set; } = PngCompression.Normal;

    /// <summary>Repeat a GIF forever (otherwise it plays once).</summary>
    public bool Loop { get; set; } = true;

    /// <summary>Smooth scaling (best for drawings) or nearest-neighbour (crisp for pixel art).</summary>
    public bool SmoothScaling { get; set; } = true;

    /// <summary>Name given to the files of a PNG sequence: prefix_0001.png, prefix_0002.png, ...</summary>
    public string FileNamePrefix { get; set; } = "frame";

    /// <summary>Sprite sheet columns; 0 chooses a roughly square grid.</summary>
    public int Columns { get; set; }

    /// <summary>Gap in pixels between sprite sheet cells.</summary>
    public int Padding { get; set; }

    /// <summary>Also write a .json file describing where each frame is on the sprite sheet.</summary>
    public bool WriteSpriteSheetJson { get; set; } = true;

    /// <summary>Location of ffmpeg for MP4 export; when empty the program looks beside itself and on the PATH.</summary>
    public string? FfmpegPath { get; set; }

    public ExportOptions Clone() => (ExportOptions)MemberwiseClone();

    /// <summary>Sensible starting values for the export dialog.</summary>
    public static ExportOptions CreateDefault(Project project, ExportFormat format, int currentFrame = 0)
    {
        var o = new ExportOptions
        {
            Format = format,
            Width = project.Width,
            Height = project.Height,
            Fps = project.Fps,
            StartFrame = 0,
            EndFrame = project.FrameCount - 1,
            Transparent = project.Background.Mode == BackgroundMode.Transparent && format != ExportFormat.Mp4
        };
        if (format == ExportFormat.Png)
        {
            o.StartFrame = o.EndFrame = Math.Clamp(currentFrame, 0, project.FrameCount - 1);
        }
        return o;
    }

    public static string DefaultExtension(ExportFormat format) => format switch
    {
        ExportFormat.Gif => ".gif",
        ExportFormat.Mp4 => ".mp4",
        ExportFormat.Png => ".png",
        ExportFormat.SpriteSheet => ".png",
        _ => ""
    };

    public static string DisplayName(ExportFormat format) => format switch
    {
        ExportFormat.Gif => "Animated GIF",
        ExportFormat.Mp4 => "MP4 video",
        ExportFormat.Png => "PNG image (one frame)",
        ExportFormat.PngSequence => "PNG sequence (one file per frame)",
        ExportFormat.SpriteSheet => "Sprite sheet (all frames in one PNG)",
        _ => format.ToString()
    };
}

public sealed record ExportProgress(double Fraction, string Message, int FramesDone, int FramesTotal);

public enum ExportStatus
{
    Success,
    Cancelled,
    Failed
}

/// <summary>Why an export failed, so the interface can offer the right help.</summary>
public enum ExportProblem
{
    None,
    InvalidOptions,
    FfmpegMissing,
    FfmpegFailed,
    FileAccess,
    DiskFull,
    Unexpected
}

public sealed class ExportResult
{
    public ExportStatus Status { get; init; }
    public ExportProblem Problem { get; init; }

    /// <summary>A sentence or two that can be shown to the user as it is.</summary>
    public string Message { get; init; } = "";

    /// <summary>Everything that was written.</summary>
    public IReadOnlyList<string> Files { get; init; } = Array.Empty<string>();

    /// <summary>Notes about adjustments that were made (for example an MP4 size rounded to even numbers).</summary>
    public IReadOnlyList<string> Warnings { get; init; } = Array.Empty<string>();

    public long TotalBytes { get; init; }
    public int FramesWritten { get; init; }
    public TimeSpan Elapsed { get; init; }

    public bool Succeeded => Status == ExportStatus.Success;
}
