using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;

namespace AnimDraw.Core.Export;

/// <summary>Encodes an MP4 by piping raw frames into ffmpeg, so no temporary pictures are written to disk.</summary>
internal static class Mp4Exporter
{
    /// <summary>Quality 1..100 to the x264 "constant rate factor" (lower is better): 100 gives 14, 85 gives 17, 1 gives 35.</summary>
    public static int CrfFor(int quality) => (int)Math.Round(35 - (Math.Clamp(quality, 1, 100) - 1) * 21.0 / 99);

    public static List<string> BuildArguments(FfmpegInfo ffmpeg, ExportOptions o, string outputPath)
    {
        string fps = o.Fps.ToString("0.###", CultureInfo.InvariantCulture);
        var args = new List<string>
        {
            "-hide_banner", "-loglevel", "error", "-nostats", "-y",
            "-f", "rawvideo", "-pixel_format", "bgra",
            "-video_size", $"{o.Width}x{o.Height}",
            "-framerate", fps,
            "-i", "pipe:0",
            "-an",
            // Convert RGB to video colours with the BT.709 matrix and say so in the file, so players show the true colours.
            "-vf", "scale=out_color_matrix=bt709:out_range=tv,format=yuv420p"
        };

        if (ffmpeg.HasLibx264)
        {
            args.AddRange(new[] { "-c:v", "libx264", "-preset", "medium", "-tune", "animation", "-crf", CrfFor(o.Quality).ToString(CultureInfo.InvariantCulture) });
        }
        else if (ffmpeg.HasOpenH264)
        {
            double bitrate = Math.Max(200_000, o.Width * (double)o.Height * Math.Max(1, o.Fps) * 0.1 * (0.3 + o.Quality / 60.0));
            args.AddRange(new[] { "-c:v", "libopenh264", "-b:v", ((long)bitrate).ToString(CultureInfo.InvariantCulture) });
        }
        else
        {
            int q = (int)Math.Round(31 - Math.Clamp(o.Quality, 1, 100) * 0.29);
            args.AddRange(new[] { "-c:v", "mpeg4", "-q:v", Math.Clamp(q, 2, 31).ToString(CultureInfo.InvariantCulture) });
        }

        args.AddRange(new[]
        {
            "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv",
            "-movflags", "+faststart",
            "-f", "mp4",
            outputPath
        });
        return args;
    }

    public static void Write(ExportContext ctx, FfmpegInfo ffmpeg, string outputPath)
    {
        var o = ctx.Options;
        if (!ffmpeg.CanWriteMp4)
            throw new ExportException(ExportProblem.FfmpegFailed,
                "The FFmpeg at \"" + ffmpeg.Path + "\" has no video encoder that can make MP4 files. Use a full build of FFmpeg, for example one from " + FfmpegLocator.DownloadPage + ".");
        if (!ffmpeg.HasLibx264)
            ctx.Warnings.Add("This FFmpeg has no H.264 (x264) encoder, so a more basic encoder was used. The file may be larger or play in fewer programs.");

        var renderer = ctx.CreateRenderer(transparent: false);
        int depth = FramePipeline.ChooseDepth(o.Width, o.Height);
        int total = ctx.Sources.Count;

        var psi = new ProcessStartInfo(ffmpeg.Path)
        {
            RedirectStandardInput = true,
            RedirectStandardError = true,
            RedirectStandardOutput = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };
        foreach (string a in BuildArguments(ffmpeg, o, outputPath)) psi.ArgumentList.Add(a);

        Process process;
        try
        {
            process = Process.Start(psi) ?? throw new ExportException(ExportProblem.FfmpegFailed, "FFmpeg could not be started.");
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException)
        {
            throw new ExportException(ExportProblem.FfmpegFailed, "FFmpeg could not be started: " + ex.Message, ex);
        }

        using (process)
        {
            var tail = new Queue<string>();
            process.ErrorDataReceived += (_, e) =>
            {
                if (string.IsNullOrWhiteSpace(e.Data)) return;
                lock (tail)
                {
                    tail.Enqueue(e.Data.Trim());
                    while (tail.Count > 8) tail.Dequeue();
                }
            };
            process.OutputDataReceived += (_, _) => { }; // drained so ffmpeg can never block on a full pipe
            process.BeginErrorReadLine();
            process.BeginOutputReadLine();

            static void KillQuietly(Process p)
            {
                try { if (!p.HasExited) p.Kill(entireProcessTree: true); }
                catch (Exception) { }
            }

            static void KillAndWait(Process p)
            {
                KillQuietly(p);
                // Give the process a moment to let go of its output file before the caller deletes it.
                try { p.WaitForExit(5000); } catch (Exception) { }
            }

            using var killOnCancel = ctx.Ct.Register(() => KillQuietly(process));

            string TailText()
            {
                lock (tail) return string.Join(" ", tail);
            }

            try
            {
                bool writeFailed = false;
                try
                {
                    var stdin = process.StandardInput.BaseStream;
                    int done = 0;
                    foreach (var picture in FramePipeline.Render(ctx.Sources, renderer.Render, depth, ctx.Ct))
                    {
                        stdin.Write(MemoryMarshal.AsBytes(picture.Pixels.AsSpan()));
                        done++;
                        ctx.Report(0.95 * done / total, $"Encoding frame {done} of {total}...", done, total);
                    }
                    stdin.Flush();
                    stdin.Close();
                }
                catch (IOException) { writeFailed = true; }              // ffmpeg stopped reading: its own message says why
                catch (ObjectDisposedException) { writeFailed = true; }

                ctx.Ct.ThrowIfCancellationRequested();

                ctx.Report(0.97, "Finishing the video...", total, total);
                process.WaitForExit();
                ctx.Ct.ThrowIfCancellationRequested();

                if (writeFailed || process.ExitCode != 0)
                {
                    string why = TailText();
                    throw new ExportException(ExportProblem.FfmpegFailed,
                        "FFmpeg could not create the video." + (why.Length > 0 ? " It said: " + why : $" (exit code {process.ExitCode})"));
                }
            }
            finally
            {
                // Whatever happened above, never leave ffmpeg running.
                KillAndWait(process);
            }
        }

        var info = new FileInfo(outputPath);
        if (!info.Exists || info.Length == 0)
            throw new ExportException(ExportProblem.FfmpegFailed, "FFmpeg finished but did not produce a video file.");
        ctx.Report(1, "Done", total, total);
    }
}
