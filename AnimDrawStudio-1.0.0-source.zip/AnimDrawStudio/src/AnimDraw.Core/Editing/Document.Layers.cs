using AnimDraw.Core.Model;

namespace AnimDraw.Core.Editing;

public sealed partial class Document
{
    public const int MaxLayerNameLength = 64;

    public bool CanAddLayer => Project.Layers.Count < ProjectLimits.MaxLayers;
    public bool CanDeleteLayer => Project.Layers.Count > 1;

    private static string? CleanName(string? name)
    {
        if (name == null) return null;
        string n = name.Trim();
        if (n.Length == 0) return null;
        return n.Length > MaxLayerNameLength ? n[..MaxLayerNameLength] : n;
    }

    /// <summary>Makes a layer the one that drawing tools paint on. Not an undo step.</summary>
    public void SetActiveLayer(Layer layer)
    {
        if (!Project.Layers.Contains(layer) || layer.Id == _activeLayerId) return;
        CommitActiveEdit();
        _activeLayerId = layer.Id;
        Raise(ChangeKind.ActiveLayer);
    }

    /// <summary>Adds an empty layer above the active one and makes it active. Returns null at the layer limit.</summary>
    public Layer? AddLayer(string? name = null)
    {
        if (!CanAddLayer) return null;
        Layer? added = null;
        Apply("New Layer", () =>
        {
            added = new Layer(CleanName(name) ?? Project.NextLayerName());
            Project.Layers.Insert(Project.IndexOfLayer(ActiveLayer) + 1, added);
            _activeLayerId = added.Id;
            return true;
        });
        return added;
    }

    /// <summary>Deletes a layer. The last remaining layer cannot be deleted.</summary>
    public bool DeleteLayer(Layer layer)
    {
        if (!CanDeleteLayer || !Project.Layers.Contains(layer)) return false;
        return Apply("Delete Layer", () =>
        {
            int index = Project.IndexOfLayer(layer);
            Project.Layers.RemoveAt(index);
            if (_activeLayerId == layer.Id)
                _activeLayerId = Project.Layers[Math.Min(index, Project.Layers.Count - 1)].Id;
            return true;
        });
    }

    /// <summary>Copies a layer (all its keyframes) directly above the original.</summary>
    public Layer? DuplicateLayer(Layer layer)
    {
        if (!CanAddLayer || !Project.Layers.Contains(layer)) return null;
        Layer? copy = null;
        Apply("Duplicate Layer", () =>
        {
            string baseName = layer.Name.Length > MaxLayerNameLength - 5 ? layer.Name[..(MaxLayerNameLength - 5)] : layer.Name;
            copy = layer.Duplicate(baseName + " copy");
            Project.Layers.Insert(Project.IndexOfLayer(layer) + 1, copy);
            _activeLayerId = copy.Id;
            return true;
        });
        return copy;
    }

    public bool RenameLayer(Layer layer, string newName)
    {
        string? clean = CleanName(newName);
        if (clean == null || clean == layer.Name || !Project.Layers.Contains(layer)) return false;
        return Apply("Rename Layer", () => { layer.Name = clean; return true; });
    }

    public bool SetLayerVisible(Layer layer, bool visible)
    {
        if (layer.Visible == visible || !Project.Layers.Contains(layer)) return false;
        return Apply(visible ? "Show Layer" : "Hide Layer", () => { layer.Visible = visible; return true; });
    }

    public bool SetLayerLocked(Layer layer, bool locked)
    {
        if (layer.Locked == locked || !Project.Layers.Contains(layer)) return false;
        return Apply(locked ? "Lock Layer" : "Unlock Layer", () => { layer.Locked = locked; return true; });
    }

    /// <summary>Sets layer opacity (0 to 1). Pass <paramref name="coalesce"/> while dragging a slider so it becomes one undo step.</summary>
    public bool SetLayerOpacity(Layer layer, double opacity, bool coalesce = false)
    {
        opacity = double.IsNaN(opacity) ? 1 : Math.Clamp(opacity, 0, 1);
        if (Math.Abs(layer.Opacity - opacity) < 1e-6 || !Project.Layers.Contains(layer)) return false;
        return Apply("Layer Opacity", () => { layer.Opacity = opacity; return true; },
            coalesce ? "opacity:" + layer.Id : null);
    }

    /// <summary>Moves a layer to a new position in the stack (index 0 is the bottom layer).</summary>
    public bool MoveLayer(Layer layer, int newIndex)
    {
        int old = Project.IndexOfLayer(layer);
        if (old < 0) return false;
        newIndex = Math.Clamp(newIndex, 0, Project.Layers.Count - 1);
        if (newIndex == old) return false;
        return Apply("Move Layer", () =>
        {
            Project.Layers.RemoveAt(old);
            Project.Layers.Insert(newIndex, layer);
            return true;
        });
    }

    public bool MoveLayerUp(Layer layer) => MoveLayer(layer, Project.IndexOfLayer(layer) + 1);

    public bool MoveLayerDown(Layer layer) => MoveLayer(layer, Project.IndexOfLayer(layer) - 1);

    /// <summary>
    /// Merges a layer into the one below it for every frame, then removes it. Frames where the upper layer
    /// shows something get their own keyframe on the lower layer.
    /// </summary>
    public bool MergeDown(Layer layer)
    {
        int index = Project.IndexOfLayer(layer);
        if (index <= 0) return false;
        var lower = Project.Layers[index - 1];
        return Apply("Merge Layer Down", () =>
        {
            var frames = new SortedSet<int>();
            foreach (var (f, _) in layer.Track.Keyframes) frames.Add(f);
            foreach (var (f, _) in lower.Track.Keyframes) frames.Add(f);

            var mergedTrack = new CelTrack();
            foreach (int f in frames)
            {
                var top = layer.Visible ? layer.GetCelAt(f) : null;
                var bottom = lower.GetCelAt(f);
                if (top == null && bottom == null) continue;
                var result = bottom?.Clone() ?? new Cel(Project.Width, Project.Height);
                if (top != null)
                {
                    var buf = top.Surface.ToBuffer();
                    result.Surface.BlendBuffer(buf, 0, 0, null, layer.Opacity255);
                }
                mergedTrack.Set(f, result);
            }
            lower.Track.CopyFrom(mergedTrack);
            Project.Layers.RemoveAt(index);
            _activeLayerId = lower.Id;
            return true;
        });
    }
}
