using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;

namespace AnimDraw.Core.Editing;

public enum CanvasResizeMode
{
    /// <summary>Keep pixels as they are; shrinking crops, enlarging adds empty space.</summary>
    CropOrExtend,

    /// <summary>Scale every drawing to the new size.</summary>
    ScaleContent
}

public sealed partial class Document
{
    // ----- pixel editing -----

    /// <summary>
    /// Starts a pixel edit on the active layer at the current frame. Returns null (with a message for the
    /// user) when the layer is locked or hidden. Drawing on a layer with nothing on this frame creates a
    /// keyframe; drawing on a held frame creates one too when <see cref="AutoKeyframe"/> is on.
    /// </summary>
    public EditSession? BeginEdit(out string? error)
    {
        error = null;
        if (_activeEdit != null)
        {
            // A previous edit never got its pointer-up (focus loss, for example): finish it first.
            _activeEdit.Commit("Edit");
        }

        var layer = ActiveLayer;
        if (layer.Locked)
        {
            error = $"Layer \"{layer.Name}\" is locked. Unlock it to draw on it.";
            return null;
        }
        if (!layer.Visible)
        {
            error = $"Layer \"{layer.Name}\" is hidden. Show it to draw on it.";
            return null;
        }

        int frame = CurrentFrame;
        var cel = layer.GetCelAt(frame);
        bool created = false;
        if (cel == null)
        {
            cel = new Cel(Project.Width, Project.Height);
            layer.Track.Set(frame, cel);
            created = true;
        }
        else if (AutoKeyframe && !layer.Track.IsKeyframe(frame))
        {
            cel = cel.Clone();
            layer.Track.Set(frame, cel);
            created = true;
        }

        var session = new EditSession(this, layer, frame, cel, created);
        _activeEdit = session;
        if (created)
        {
            StructureVersion++;
            Raise(ChangeKind.Structure);
        }
        return session;
    }

    /// <summary>The drawing a tool would modify right now, without creating anything. Null when the layer is empty here.</summary>
    public Cel? PeekActiveCel() => ActiveLayer.GetCelAt(CurrentFrame);

    // ----- selection -----

    public void SelectRect(IntRect rect)
    {
        var r = rect.Intersect(CanvasBounds);
        if (r.IsEmpty) { Deselect(); return; }
        if (Selection == r) return;
        Selection = r;
        Raise(ChangeKind.Selection);
    }

    public void SelectAll() => SelectRect(CanvasBounds);

    public void Deselect()
    {
        if (Selection == null) return;
        Selection = null;
        Raise(ChangeKind.Selection);
    }

    /// <summary>Copies the selected area (or the whole drawing when nothing is selected) of the active layer. Null when it is empty.</summary>
    public PixelBuffer? CopySelection()
    {
        var cel = PeekActiveCel();
        if (cel == null) return null;
        var region = Selection ?? CanvasBounds;
        var buf = cel.Surface.ReadRegion(region);
        return buf.IsBlank() ? null : buf;
    }

    /// <summary>Copies the selection and removes it from the active layer.</summary>
    public bool CutSelection(out PixelBuffer? copied)
    {
        copied = CopySelection();
        if (copied == null) return false;
        return ClearRegion(Selection ?? CanvasBounds, "Cut");
    }

    /// <summary>Erases a rectangle on the active layer as one undo step. Returns false if nothing changed.</summary>
    public bool ClearRegion(IntRect region, string name = "Clear")
    {
        var cel = PeekActiveCel();
        if (cel == null) return false;
        if (cel.Surface.ReadRegion(region.Intersect(CanvasBounds)).IsBlank()) return false;

        var session = BeginEdit(out _);
        if (session == null) return false;
        session.Surface.ClearRect(region, session.Recorder);
        session.AddDirty(region);
        session.TakeDirty();
        return session.Commit(name);
    }

    /// <summary>Clears the selection, or the whole drawing of the active layer on this frame when nothing is selected.</summary>
    public bool ClearActiveLayerFrame() => ClearRegion(Selection ?? CanvasBounds, "Clear Layer");

    /// <summary>Clears every unlocked, visible layer's drawing on the current frame.</summary>
    public bool ClearFrame()
    {
        CommitActiveEdit();
        var original = ActiveLayerIdForRestore();
        bool any = false;
        History.BeginGroup("Clear Frame");
        try
        {
            foreach (var layer in Project.Layers.ToList())
            {
                if (layer.Locked || !layer.Visible) continue;
                _activeLayerId = layer.Id;
                if (ClearRegion(CanvasBounds, "Clear Layer")) any = true;
            }
        }
        finally
        {
            _activeLayerId = original;
            History.EndGroup();
        }
        Raise(ChangeKind.ActiveLayer);
        return any;
    }

    private Guid ActiveLayerIdForRestore() => _activeLayerId;

    /// <summary>Draws a pasted image on the active layer at (x, y) and selects it. Returns false if the layer cannot be edited.</summary>
    public bool PasteBuffer(PixelBuffer buffer, int x, int y, string name = "Paste")
    {
        var session = BeginEdit(out _);
        if (session == null) return false;
        session.Surface.BlendBuffer(buffer, x, y, session.Recorder);
        var rect = new IntRect(x, y, buffer.Width, buffer.Height).Intersect(CanvasBounds);
        session.AddDirty(rect);
        session.TakeDirty();
        bool changed = session.Commit(name);
        if (changed) SelectRect(rect);
        return changed;
    }

    /// <summary>Copies the selected artwork and pastes it on the same layer, offset so the copy is visible.</summary>
    public bool DuplicateSelection(int offsetX = 16, int offsetY = 16)
    {
        var buf = CopySelection();
        if (buf == null) return false;
        var region = Selection ?? CanvasBounds;
        return PasteBuffer(buf, region.X + offsetX, region.Y + offsetY, "Duplicate");
    }

    /// <summary>
    /// Moves the artwork inside a region by an offset as one undo step (arrow-key nudging). The selection, if any,
    /// moves with it.
    /// </summary>
    public bool MoveContent(IntRect region, int dx, int dy, string name = "Move")
    {
        if (dx == 0 && dy == 0) return false;
        if (PeekActiveCel() == null) return false;
        var session = BeginEdit(out _);
        if (session == null) return false;

        var lifted = session.Surface.ReadRegion(region);
        if (lifted.IsBlank())
        {
            session.Cancel();
            return false;
        }
        session.Surface.ClearRect(region, session.Recorder);
        var target = region.Offset(dx, dy);
        session.Surface.BlendBuffer(lifted, target.X, target.Y, session.Recorder);
        session.AddDirty(region);
        session.AddDirty(target);
        session.TakeDirty();
        bool changed = session.Commit(name);
        if (Selection != null) SelectRect(target);
        return changed;
    }

    /// <summary>Nudges the selection's artwork (or the whole drawing when nothing is selected).</summary>
    public bool NudgeSelection(int dx, int dy) => MoveContent(Selection ?? CanvasBounds, dx, dy, "Nudge");

    // ----- canvas size -----

    /// <summary>
    /// Changes the canvas size. <paramref name="anchorX"/> and <paramref name="anchorY"/> (0, 1, 2 = start,
    /// middle, end) say where existing artwork stays when cropping or extending.
    /// </summary>
    public bool ResizeCanvas(int newWidth, int newHeight, CanvasResizeMode mode, int anchorX = 1, int anchorY = 1)
    {
        if (!ProjectLimits.IsValidSize(newWidth, newHeight, out _)) return false;
        if (newWidth == Project.Width && newHeight == Project.Height) return false;
        int oldW = Project.Width, oldH = Project.Height;

        return Apply("Resize Canvas", () =>
        {
            int ox = anchorX <= 0 ? 0 : anchorX == 1 ? (newWidth - oldW) / 2 : newWidth - oldW;
            int oy = anchorY <= 0 ? 0 : anchorY == 1 ? (newHeight - oldH) / 2 : newHeight - oldH;

            var jobs = new List<(Layer Layer, int Frame, Cel Old)>();
            foreach (var layer in Project.Layers)
                foreach (var (frame, cel) in layer.Track.Keyframes) jobs.Add((layer, frame, cel));

            var results = new Cel[jobs.Count];
            Parallel.For(0, jobs.Count, i =>
            {
                var old = jobs[i].Old.Surface;
                if (mode == CanvasResizeMode.CropOrExtend || old.IsBlank())
                {
                    results[i] = new Cel(old.Resized(newWidth, newHeight, ox, oy));
                }
                else
                {
                    var scaled = Resampler.Scale(old.ToBuffer(), newWidth, newHeight);
                    results[i] = new Cel(TiledSurface.FromBuffer(scaled));
                }
            });

            Project.SetSize(newWidth, newHeight);
            for (int i = 0; i < jobs.Count; i++) jobs[i].Layer.Track.Set(jobs[i].Frame, results[i]);
            return true;
        });
    }
}
