using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;

namespace AnimDraw.Core.Editing;

public sealed partial class Document
{
    public int FrameCount => Project.FrameCount;

    public bool CanAddFrame => Project.FrameCount < ProjectLimits.MaxFrames;
    public bool CanDeleteFrame => Project.FrameCount > 1;

    /// <summary>Moves to a frame (clamped to the timeline). Not an undo step.</summary>
    public void GoToFrame(int frame)
    {
        frame = Math.Clamp(frame, 0, Project.FrameCount - 1);
        if (frame == CurrentFrame) return;
        CommitActiveEdit();
        CurrentFrame = frame;
        Raise(ChangeKind.Frame);
    }

    /// <summary>
    /// Inserts a new frame after <paramref name="frame"/>. The active layer gets a blank keyframe there,
    /// every other layer keeps showing what it showed (its drawing is held across the new frame).
    /// </summary>
    public bool InsertBlankFrameAfter(int frame)
    {
        if (!CanAddFrame) return false;
        frame = Math.Clamp(frame, 0, Project.FrameCount - 1);
        return Apply("Add Frame", () =>
        {
            ShiftTimeline(frame + 1, +1);
            var active = ActiveLayer;
            if (!active.Locked) active.Track.Set(frame + 1, new Cel(Project.Width, Project.Height));
            CurrentFrame = frame + 1;
            return true;
        });
    }

    /// <summary>
    /// Inserts a copy of a frame after it. Layers that have their own drawing on the frame, and the active
    /// layer, get an independent copy so the new frame can be edited without touching the original.
    /// </summary>
    public bool DuplicateFrame(int frame)
    {
        if (!CanAddFrame) return false;
        frame = Math.Clamp(frame, 0, Project.FrameCount - 1);
        return Apply("Duplicate Frame", () =>
        {
            ShiftTimeline(frame + 1, +1);
            var active = ActiveLayer;
            foreach (var layer in Project.Layers)
            {
                var shown = layer.GetCelAt(frame);
                if (shown == null) continue;
                if (layer.Track.IsKeyframe(frame) || ReferenceEquals(layer, active))
                    layer.Track.Set(frame + 1, shown.Clone());
            }
            CurrentFrame = frame + 1;
            return true;
        });
    }

    /// <summary>
    /// Deletes a frame. A drawing that was held across following frames moves up so those frames keep
    /// looking the same. The last remaining frame cannot be deleted.
    /// </summary>
    public bool DeleteFrame(int frame)
    {
        if (!CanDeleteFrame || frame < 0 || frame >= Project.FrameCount) return false;
        return Apply("Delete Frame", () =>
        {
            int oldCount = Project.FrameCount;
            foreach (var layer in Project.Layers)
            {
                bool hasKey = layer.Track.IsKeyframe(frame);
                bool spanContinues = hasKey && frame + 1 < oldCount && !layer.Track.IsKeyframe(frame + 1);
                if (hasKey && !spanContinues) layer.Track.Remove(frame);
                layer.Track.ShiftFrom(frame + 1, -1);
            }
            Project.FrameCount = oldCount - 1;
            CurrentFrame = Math.Min(frame, Project.FrameCount - 1);
            return true;
        });
    }

    private void ShiftTimeline(int fromFrame, int delta)
    {
        foreach (var layer in Project.Layers) layer.Track.ShiftFrom(fromFrame, delta);
        Project.FrameCount += delta;
    }

    /// <summary>Sets the total number of frames. Shrinking removes drawings on the frames that disappear.</summary>
    public bool SetFrameCount(int count)
    {
        count = Math.Clamp(count, 1, ProjectLimits.MaxFrames);
        if (count == Project.FrameCount) return false;
        return Apply("Set Frame Count", () =>
        {
            if (count < Project.FrameCount)
                foreach (var layer in Project.Layers) layer.Track.RemoveAfter(count - 1);
            Project.FrameCount = count;
            CurrentFrame = Math.Min(CurrentFrame, count - 1);
            return true;
        });
    }

    /// <summary>Makes a keyframe on a layer at a frame, starting as a copy of the drawing shown there.</summary>
    public bool InsertKeyframe(Layer layer, int frame)
    {
        if (!Project.Layers.Contains(layer) || frame < 0 || frame >= Project.FrameCount) return false;
        if (layer.Track.IsKeyframe(frame)) return false;
        return Apply("Insert Keyframe", () =>
        {
            var shown = layer.GetCelAt(frame);
            layer.Track.Set(frame, shown?.Clone() ?? new Cel(Project.Width, Project.Height));
            return true;
        });
    }

    /// <summary>Makes an empty keyframe on a layer at a frame (replacing the drawing if a keyframe is already there).</summary>
    public bool InsertBlankKeyframe(Layer layer, int frame)
    {
        if (!Project.Layers.Contains(layer) || frame < 0 || frame >= Project.FrameCount) return false;
        return Apply("Insert Blank Keyframe", () =>
        {
            layer.Track.Set(frame, new Cel(Project.Width, Project.Height));
            return true;
        });
    }

    /// <summary>Removes the keyframe on a layer at a frame; the previous drawing is then held across it.</summary>
    public bool RemoveKeyframe(Layer layer, int frame)
    {
        if (!Project.Layers.Contains(layer) || !layer.Track.IsKeyframe(frame)) return false;
        return Apply("Remove Keyframe", () => layer.Track.Remove(frame));
    }

    // ----- project settings (undoable) -----

    public bool SetFps(double fps)
    {
        fps = ProjectLimits.ClampFps(fps);
        if (Math.Abs(fps - Project.Fps) < 1e-9) return false;
        return Apply("Frame Rate", () => { Project.Fps = fps; return true; }, "fps");
    }

    public bool SetLoop(bool loop)
    {
        if (loop == Project.Loop) return false;
        return Apply("Loop", () => { Project.Loop = loop; return true; });
    }

    public bool SetBackground(BackgroundSettings background)
    {
        if (background == Project.Background) return false;
        return Apply("Canvas Background", () => { Project.Background = background; return true; });
    }

    /// <summary>Changes onion-skin options. These are view settings, so they are not undoable but do mark the project modified.</summary>
    public void UpdateOnionSkin(Action<OnionSkinSettings> change)
    {
        change(Project.Onion);
        Project.Onion.Normalize();
        StructureVersion++;
        _forcedDirty = true;
        _modifiedCounter++;
        Raise(ChangeKind.Settings | ChangeKind.History);
    }
}
