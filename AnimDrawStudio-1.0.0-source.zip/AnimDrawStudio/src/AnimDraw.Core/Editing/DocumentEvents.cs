using AnimDraw.Core.Geometry;

namespace AnimDraw.Core.Editing;

[Flags]
public enum ChangeKind
{
    None = 0,

    /// <summary>Pixels of the current frame changed; <see cref="DocumentChangedEventArgs.Dirty"/> says where.</summary>
    Pixels = 1,

    /// <summary>Layers, keyframes or the frame count changed.</summary>
    Structure = 2,

    /// <summary>The current frame number changed.</summary>
    Frame = 4,

    ActiveLayer = 8,
    Selection = 16,

    /// <summary>The undo/redo stack or the saved/modified state changed.</summary>
    History = 32,

    /// <summary>Frame rate, background, loop or onion-skin settings changed.</summary>
    Settings = 64,

    All = Pixels | Structure | Frame | ActiveLayer | Selection | History | Settings
}

public sealed class DocumentChangedEventArgs : EventArgs
{
    public DocumentChangedEventArgs(ChangeKind kind, IntRect dirty)
    {
        Kind = kind;
        Dirty = dirty;
    }

    public ChangeKind Kind { get; }

    /// <summary>Changed canvas area. Only meaningful for <see cref="ChangeKind.Pixels"/>; empty otherwise.</summary>
    public IntRect Dirty { get; }

    /// <summary>True when the whole displayed image must be rebuilt rather than just <see cref="Dirty"/>.</summary>
    public bool NeedsFullRedraw =>
        (Kind & (ChangeKind.Structure | ChangeKind.Frame | ChangeKind.ActiveLayer | ChangeKind.Settings)) != 0;
}
