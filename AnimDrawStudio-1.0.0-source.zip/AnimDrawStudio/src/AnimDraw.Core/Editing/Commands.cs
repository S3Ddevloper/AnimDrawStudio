using System.Diagnostics;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;

namespace AnimDraw.Core.Editing;

/// <summary>
/// Everything about a project except pixel data: layer list and properties, keyframe positions,
/// frame count, canvas size and frame rate. Drawings are referenced, not copied, so a snapshot is tiny.
/// </summary>
internal sealed class StructureSnapshot
{
    private sealed class LayerState
    {
        public Layer Layer = null!;
        public string Name = "";
        public bool Visible;
        public bool Locked;
        public double Opacity;
        public CelTrack Track = null!;
    }

    private int _width, _height, _frameCount, _currentFrame;
    private double _fps;
    private bool _loop;
    private BackgroundSettings _background = BackgroundSettings.White;
    private Guid _activeLayer;
    private List<LayerState> _layers = new();

    public long ApproximateBytes { get; private set; }

    public static StructureSnapshot Capture(Document doc)
    {
        var p = doc.Project;
        var s = new StructureSnapshot
        {
            _width = p.Width,
            _height = p.Height,
            _fps = p.Fps,
            _loop = p.Loop,
            _background = p.Background,
            _frameCount = p.FrameCount,
            _currentFrame = doc.CurrentFrame,
            _activeLayer = doc.ActiveLayer.Id
        };
        long bytes = 128;
        foreach (var l in p.Layers)
        {
            s._layers.Add(new LayerState
            {
                Layer = l,
                Name = l.Name,
                Visible = l.Visible,
                Locked = l.Locked,
                Opacity = l.Opacity,
                Track = l.Track.Clone()
            });
            bytes += 96 + l.Track.Count * 16L;
        }
        s.ApproximateBytes = bytes;
        return s;
    }

    public void Restore(Document doc)
    {
        var p = doc.Project;
        if (p.Width != _width || p.Height != _height) p.SetSize(_width, _height);
        p.Fps = _fps;
        p.Loop = _loop;
        p.Background = _background;
        p.FrameCount = _frameCount;
        p.Layers.Clear();
        foreach (var st in _layers)
        {
            st.Layer.Name = st.Name;
            st.Layer.Visible = st.Visible;
            st.Layer.Locked = st.Locked;
            st.Layer.Opacity = st.Opacity;
            st.Layer.Track.CopyFrom(st.Track);
            p.Layers.Add(st.Layer);
        }
        doc.RestoreNavigation(_currentFrame, _activeLayer);
    }
}

/// <summary>An undoable structural or property change (layers, frames, keyframes, settings).</summary>
internal sealed class StructureCommand : IUndoable
{
    private readonly Document _doc;
    private readonly StructureSnapshot _before;
    private StructureSnapshot _after;
    private long _lastTick;

    public StructureCommand(Document doc, string name, StructureSnapshot before, StructureSnapshot after, string? mergeKey = null)
    {
        _doc = doc;
        Name = name;
        _before = before;
        _after = after;
        MergeKey = mergeKey;
        _lastTick = Stopwatch.GetTimestamp();
    }

    public string Name { get; }
    public string? MergeKey { get; }
    public long ByteCost => _before.ApproximateBytes + _after.ApproximateBytes;

    public void Undo()
    {
        _before.Restore(_doc);
        _doc.NotifyStructureRestored();
    }

    public void Redo()
    {
        _after.Restore(_doc);
        _doc.NotifyStructureRestored();
    }

    public bool TryMerge(IUndoable next)
    {
        if (MergeKey == null || next is not StructureCommand n || n.MergeKey != MergeKey) return false;
        double seconds = (double)(n._lastTick - _lastTick) / Stopwatch.Frequency;
        if (seconds > 2.0) return false;
        _after = n._after;
        _lastTick = n._lastTick;
        return true;
    }
}

/// <summary>An undoable change to the pixels of one drawing.</summary>
internal sealed class PixelEditCommand : IUndoable
{
    private readonly Document _doc;
    private readonly Layer _layer;
    private readonly int _frame;
    private readonly Cel _cel;
    private readonly bool _createdKeyframe;
    private readonly List<TileDelta> _deltas;
    private readonly IntRect _dirty;

    public PixelEditCommand(Document doc, string name, Layer layer, int frame, Cel cel, bool createdKeyframe,
        List<TileDelta> deltas, IntRect dirty)
    {
        _doc = doc;
        Name = name;
        _layer = layer;
        _frame = frame;
        _cel = cel;
        _createdKeyframe = createdKeyframe;
        _deltas = deltas;
        _dirty = dirty;
    }

    public string Name { get; }

    public long ByteCost
    {
        get
        {
            long tiles = 0;
            foreach (var d in _deltas)
            {
                if (d.Before != null) tiles++;
                if (d.After != null) tiles++;
            }
            return tiles * Tile.PixelCount * 4 + 256;
        }
    }

    public void Undo()
    {
        _cel.Surface.ApplyDeltas(_deltas, undo: true);
        if (_createdKeyframe) _layer.Track.Remove(_frame);
        _doc.NotifyPixelsRestored(_dirty, structureChanged: _createdKeyframe);
    }

    public void Redo()
    {
        _cel.Surface.ApplyDeltas(_deltas, undo: false);
        if (_createdKeyframe) _layer.Track.Set(_frame, _cel);
        _doc.NotifyPixelsRestored(_dirty, structureChanged: _createdKeyframe);
    }
}
