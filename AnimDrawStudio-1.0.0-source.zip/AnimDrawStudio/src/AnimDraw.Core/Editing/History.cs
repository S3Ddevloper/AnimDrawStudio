namespace AnimDraw.Core.Editing;

/// <summary>One undoable step.</summary>
public interface IUndoable
{
    string Name { get; }

    /// <summary>Rough memory held by this step, used to cap the history size.</summary>
    long ByteCost { get; }

    void Undo();
    void Redo();

    /// <summary>Lets a step absorb the one that follows it (slider drags become a single step). Returns true if absorbed.</summary>
    bool TryMerge(IUndoable next) => false;
}

/// <summary>Groups several steps so they undo and redo together.</summary>
public sealed class CompositeCommand : IUndoable
{
    private readonly List<IUndoable> _steps;

    public CompositeCommand(string name, List<IUndoable> steps)
    {
        Name = name;
        _steps = steps;
    }

    public string Name { get; }
    public long ByteCost => _steps.Sum(s => s.ByteCost);
    public int StepCount => _steps.Count;

    public void Undo()
    {
        for (int i = _steps.Count - 1; i >= 0; i--) _steps[i].Undo();
    }

    public void Redo()
    {
        foreach (var s in _steps) s.Redo();
    }
}

/// <summary>Undo/redo stack with a size cap, step grouping and a "saved state" marker for the dirty flag.</summary>
public sealed class HistoryStack
{
    private sealed class Entry
    {
        public IUndoable Command = null!;
        public long Id;
    }

    private readonly List<Entry> _undo = new();
    private readonly List<Entry> _redo = new();
    private long _nextId = 1;
    private long _bytes;
    private List<IUndoable>? _group;
    private string _groupName = "";
    private int _groupDepth;

    public int MaxEntries { get; set; } = 300;
    public long MaxBytes { get; set; } = 768L * 1024 * 1024;

    public event Action? Changed;

    public bool CanUndo => _undo.Count > 0;
    public bool CanRedo => _redo.Count > 0;
    public string? UndoName => _undo.Count > 0 ? _undo[^1].Command.Name : null;
    public string? RedoName => _redo.Count > 0 ? _redo[^1].Command.Name : null;
    public int UndoCount => _undo.Count;
    public int RedoCount => _redo.Count;
    public long ApproximateBytes => _bytes;

    /// <summary>Identifies the current state (0 when nothing has been done). Equal ids mean identical documents.</summary>
    public long StateId => _undo.Count > 0 ? _undo[^1].Id : 0;

    public bool IsGrouping => _groupDepth > 0;

    public void Push(IUndoable command)
    {
        if (_groupDepth > 0)
        {
            _group!.Add(command);
            return;
        }

        if (_undo.Count > 0 && _redo.Count == 0 && _undo[^1].Command.TryMerge(command))
        {
            _undo[^1].Id = _nextId++; // content changed, so it is a new state
            Changed?.Invoke();
            return;
        }

        foreach (var e in _redo) _bytes -= e.Command.ByteCost;
        _redo.Clear();
        _undo.Add(new Entry { Command = command, Id = _nextId++ });
        _bytes += command.ByteCost;
        Trim();
        Changed?.Invoke();
    }

    /// <summary>Starts collecting pushed steps into one. Calls may nest; only the outermost one counts.</summary>
    public void BeginGroup(string name)
    {
        if (_groupDepth == 0)
        {
            _group = new List<IUndoable>();
            _groupName = name;
        }
        _groupDepth++;
    }

    public void EndGroup()
    {
        if (_groupDepth == 0) return;
        _groupDepth--;
        if (_groupDepth > 0) return;
        var steps = _group!;
        _group = null;
        if (steps.Count == 1) Push(steps[0]);
        else if (steps.Count > 1) Push(new CompositeCommand(_groupName, steps));
    }

    public bool Undo()
    {
        if (_undo.Count == 0) return false;
        var e = _undo[^1];
        _undo.RemoveAt(_undo.Count - 1);
        _bytes -= e.Command.ByteCost;
        try { e.Command.Undo(); }
        finally
        {
            _redo.Add(e);
            _bytes += e.Command.ByteCost;
            Changed?.Invoke();
        }
        return true;
    }

    public bool Redo()
    {
        if (_redo.Count == 0) return false;
        var e = _redo[^1];
        _redo.RemoveAt(_redo.Count - 1);
        _bytes -= e.Command.ByteCost;
        try { e.Command.Redo(); }
        finally
        {
            _undo.Add(e);
            _bytes += e.Command.ByteCost;
            Changed?.Invoke();
        }
        return true;
    }

    public void Clear()
    {
        _undo.Clear();
        _redo.Clear();
        _bytes = 0;
        Changed?.Invoke();
    }

    private void Trim()
    {
        while (_undo.Count > 1 && (_undo.Count > MaxEntries || _bytes > MaxBytes))
        {
            _bytes -= _undo[0].Command.ByteCost;
            _undo.RemoveAt(0);
        }
    }
}
