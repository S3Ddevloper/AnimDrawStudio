using AnimDraw.Core.Geometry;
using AnimDraw.Core.Model;

namespace AnimDraw.Core.Editing;

/// <summary>
/// An open project plus everything needed to edit it: undo history, the current frame, the active layer
/// and the selection. All edits go through this class so every change is undoable and listeners are told.
/// </summary>
public sealed partial class Document
{
    private Guid _activeLayerId;
    private long _savedStateId;
    private bool _forcedDirty;
    private EditSession? _activeEdit;

    public Document(Project project)
    {
        Project = project ?? throw new ArgumentNullException(nameof(project));
        if (project.Layers.Count == 0) project.Layers.Add(new Layer("Layer 1"));
        project.FrameCount = Math.Clamp(project.FrameCount, 1, ProjectLimits.MaxFrames);
        _activeLayerId = project.Layers[^1].Id;
        History = new HistoryStack();
        History.Changed += () => Raise(ChangeKind.History);
    }

    public Project Project { get; }
    public HistoryStack History { get; }

    /// <summary>Zero-based index of the frame being edited.</summary>
    public int CurrentFrame { get; private set; }

    /// <summary>When on, drawing on a held frame first makes a keyframe there so earlier frames stay untouched.</summary>
    public bool AutoKeyframe { get; set; } = true;

    /// <summary>The selected rectangle in canvas pixels, or null.</summary>
    public IntRect? Selection { get; private set; }

    /// <summary>Changes whenever drawn pixels change (committed edits, undo, redo, structure).</summary>
    public long ContentVersion { get; private set; }

    /// <summary>Changes whenever layers, keyframes or settings change.</summary>
    public long StructureVersion { get; private set; }

    public bool HasActiveEdit => _activeEdit != null;

    public event EventHandler<DocumentChangedEventArgs>? Changed;

    public Layer ActiveLayer => Project.FindLayer(_activeLayerId) ?? Project.Layers[^1];

    public int CanvasWidth => Project.Width;
    public int CanvasHeight => Project.Height;
    public IntRect CanvasBounds => new(0, 0, Project.Width, Project.Height);

    // ----- saved / modified state -----

    public bool IsDirty => _forcedDirty || History.StateId != _savedStateId;

    /// <summary>Identifies the document state that was written to disk by a save that may still be running.</summary>
    public readonly record struct SaveToken(long StateId, long ModifiedCounter);

    private long _modifiedCounter;

    /// <summary>Call on the UI thread when a save starts (together with <see cref="CreateSnapshot"/>).</summary>
    public SaveToken BeginSave() => new(History.StateId, _modifiedCounter);

    /// <summary>Marks the state captured by <see cref="BeginSave"/> as saved. Edits made while saving stay unsaved.</summary>
    public void CompleteSave(SaveToken token)
    {
        _savedStateId = token.StateId;
        if (_modifiedCounter == token.ModifiedCounter) _forcedDirty = false;
        Raise(ChangeKind.History);
    }

    public void MarkSaved() => CompleteSave(BeginSave());

    /// <summary>Flags changes that are not part of the undo history (such as view settings) as unsaved.</summary>
    public void MarkModified()
    {
        _forcedDirty = true;
        _modifiedCounter++;
        Raise(ChangeKind.History);
    }

    // ----- notifications -----

    private void Raise(ChangeKind kind, IntRect dirty = default) =>
        Changed?.Invoke(this, new DocumentChangedEventArgs(kind, dirty));

    internal void NotifyPixelsLive(IntRect dirty) => Raise(ChangeKind.Pixels, dirty);

    internal void NotifyPixelsCommitted(IntRect dirty)
    {
        ContentVersion++;
        Raise(ChangeKind.Pixels, dirty);
    }

    internal void NotifyPixelsRestored(IntRect dirty, bool structureChanged)
    {
        ContentVersion++;
        if (structureChanged)
        {
            StructureVersion++;
            Raise(ChangeKind.Pixels | ChangeKind.Structure, dirty);
        }
        else Raise(ChangeKind.Pixels, dirty);
    }

    internal void NotifyStructureRestored()
    {
        StructureVersion++;
        ContentVersion++;
        ClampSelectionToCanvas();
        Raise(ChangeKind.Structure | ChangeKind.Settings | ChangeKind.Frame | ChangeKind.ActiveLayer | ChangeKind.Pixels);
    }

    internal void RestoreNavigation(int frame, Guid activeLayer)
    {
        CurrentFrame = Math.Clamp(frame, 0, Project.FrameCount - 1);
        _activeLayerId = Project.FindLayer(activeLayer) != null ? activeLayer : Project.Layers[^1].Id;
    }

    private void ClampSelectionToCanvas()
    {
        if (Selection is IntRect s)
        {
            var c = s.Intersect(CanvasBounds);
            Selection = c.IsEmpty ? null : c;
        }
    }

    // ----- history -----

    /// <summary>Runs a structural change as one undo step. The mutation returns false to abort without recording.</summary>
    private bool Apply(string name, Func<bool> mutate, string? mergeKey = null)
    {
        CommitActiveEdit();
        var before = StructureSnapshot.Capture(this);
        if (!mutate()) return false;
        var after = StructureSnapshot.Capture(this);
        History.Push(new StructureCommand(this, name, before, after, mergeKey));
        StructureVersion++;
        ContentVersion++;
        ClampSelectionToCanvas();
        Raise(ChangeKind.Structure | ChangeKind.Settings | ChangeKind.Frame | ChangeKind.ActiveLayer | ChangeKind.Pixels);
        return true;
    }

    public bool Undo()
    {
        CommitActiveEdit();
        return History.Undo();
    }

    public bool Redo()
    {
        CommitActiveEdit();
        return History.Redo();
    }

    /// <summary>Finishes an in-progress edit (for example when the user presses Ctrl+Z mid-stroke).</summary>
    public void CommitActiveEdit()
    {
        _activeEdit?.Commit("Edit");
    }

    internal void EndEdit(EditSession session)
    {
        if (ReferenceEquals(_activeEdit, session)) _activeEdit = null;
    }

    // ----- snapshot for background work -----

    /// <summary>
    /// A frozen copy of the project that can be read from another thread (autosave, export) while the
    /// user keeps drawing. Pixel data is shared copy-on-write, so this is cheap.
    /// </summary>
    public Project CreateSnapshot()
    {
        var p = new Project(Project.Width, Project.Height)
        {
            Fps = Project.Fps,
            FrameCount = Project.FrameCount,
            Loop = Project.Loop,
            Background = Project.Background,
            Onion = Project.Onion.Clone()
        };
        foreach (var l in Project.Layers)
        {
            var copy = new Layer(l.Id, l.Name) { Visible = l.Visible, Locked = l.Locked, Opacity = l.Opacity };
            foreach (var (frame, cel) in l.Track.Keyframes) copy.Track.Set(frame, cel.Clone());
            p.Layers.Add(copy);
        }
        return p;
    }
}
