using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;

namespace AnimDraw.Core.Editing;

/// <summary>
/// One pixel edit (a brush stroke, a shape, a fill, a move...) on the drawing that is current for the
/// active layer. It records the original tiles so the edit can be previewed and reverted while it is
/// in progress, and becomes a single undo step when committed.
/// </summary>
public sealed class EditSession
{
    private readonly Document _doc;
    private readonly Layer _layer;
    private readonly Cel _cel;
    private readonly int _frame;
    private readonly bool _createdKeyframe;
    private IntRect _dirty = IntRect.Empty;
    private IntRect _everTouched = IntRect.Empty;
    private bool _finished;

    internal EditSession(Document doc, Layer layer, int frame, Cel cel, bool createdKeyframe)
    {
        _doc = doc;
        _layer = layer;
        _frame = frame;
        _cel = cel;
        _createdKeyframe = createdKeyframe;
        Clip = doc.Selection ?? new IntRect(0, 0, doc.Project.Width, doc.Project.Height);
        Clip = Clip.Intersect(new IntRect(0, 0, doc.Project.Width, doc.Project.Height));
    }

    public TiledSurface Surface => _cel.Surface;
    public TileRecorder Recorder { get; } = new();
    public Layer Layer => _layer;
    public int Frame => _frame;
    public bool CreatedKeyframe => _createdKeyframe;
    public bool IsFinished => _finished;

    /// <summary>Drawing is limited to this area (the selection, or the whole canvas).</summary>
    public IntRect Clip { get; }

    /// <summary>Everything changed since the last <see cref="TakeDirty"/>.</summary>
    public IntRect Dirty => _dirty;

    public void AddDirty(IntRect r)
    {
        r = r.Intersect(Surface.Bounds);
        if (r.IsEmpty) return;
        _dirty = _dirty.Union(r);
        _everTouched = _everTouched.Union(r);
    }

    /// <summary>Returns the changed area and tells listeners to repaint it.</summary>
    public IntRect TakeDirty()
    {
        var d = _dirty;
        _dirty = IntRect.Empty;
        if (!d.IsEmpty) _doc.NotifyPixelsLive(d);
        return d;
    }

    /// <summary>Puts the drawing back to how it was when the session began (used to redraw shape and move previews).</summary>
    public void Revert()
    {
        foreach (int index in Recorder.Indices) AddDirty(Surface.TileBounds(index));
        Surface.Revert(Recorder);
        Recorder.Clear();
    }

    /// <summary>Ends the edit and records it as one undo step. Returns false when nothing changed.</summary>
    public bool Commit(string name)
    {
        if (_finished) return false;
        _finished = true;
        _doc.EndEdit(this);

        foreach (int index in Recorder.Indices) _everTouched = _everTouched.Union(Surface.TileBounds(index));
        var deltas = Surface.Finish(Recorder);
        if (deltas.Count == 0)
        {
            if (_createdKeyframe)
            {
                _layer.Track.Remove(_frame);
                _doc.NotifyStructureRestored();
            }
            return false;
        }

        var cmd = new PixelEditCommand(_doc, name, _layer, _frame, _cel, _createdKeyframe, deltas, _everTouched);
        _doc.History.Push(cmd);
        _doc.NotifyPixelsCommitted(_everTouched);
        return true;
    }

    /// <summary>Abandons the edit, restoring the drawing (and removing a keyframe made just for it).</summary>
    public void Cancel()
    {
        if (_finished) return;
        _finished = true;
        _doc.EndEdit(this);

        var area = IntRect.Empty;
        foreach (int index in Recorder.Indices) area = area.Union(Surface.TileBounds(index));
        Surface.Revert(Recorder);
        Recorder.Clear();
        if (_createdKeyframe)
        {
            _layer.Track.Remove(_frame);
            _doc.NotifyStructureRestored();
        }
        else if (!area.IsEmpty)
        {
            _doc.NotifyPixelsLive(area);
        }
    }
}
