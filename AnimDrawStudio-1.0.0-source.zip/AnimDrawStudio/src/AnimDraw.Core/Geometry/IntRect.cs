namespace AnimDraw.Core.Geometry;

/// <summary>Integer pixel rectangle. Right and Bottom are exclusive.</summary>
public readonly struct IntRect : IEquatable<IntRect>
{
    public static readonly IntRect Empty = new(0, 0, 0, 0);

    public int X { get; }
    public int Y { get; }
    public int Width { get; }
    public int Height { get; }

    public IntRect(int x, int y, int width, int height)
    {
        X = x;
        Y = y;
        Width = Math.Max(0, width);
        Height = Math.Max(0, height);
    }

    public int Right => X + Width;
    public int Bottom => Y + Height;
    public bool IsEmpty => Width <= 0 || Height <= 0;
    public long Area => (long)Width * Height;

    public static IntRect FromLTRB(int left, int top, int right, int bottom) =>
        new(left, top, right - left, bottom - top);

    public bool Contains(int px, int py) => px >= X && py >= Y && px < Right && py < Bottom;

    public bool Contains(IntRect other) =>
        !other.IsEmpty && other.X >= X && other.Y >= Y && other.Right <= Right && other.Bottom <= Bottom;

    public bool IntersectsWith(IntRect other) =>
        !IsEmpty && !other.IsEmpty && other.X < Right && other.Right > X && other.Y < Bottom && other.Bottom > Y;

    public IntRect Intersect(IntRect other)
    {
        int l = Math.Max(X, other.X);
        int t = Math.Max(Y, other.Y);
        int r = Math.Min(Right, other.Right);
        int b = Math.Min(Bottom, other.Bottom);
        return r <= l || b <= t ? Empty : FromLTRB(l, t, r, b);
    }

    /// <summary>Smallest rectangle containing both. An empty operand is ignored.</summary>
    public IntRect Union(IntRect other)
    {
        if (IsEmpty) return other;
        if (other.IsEmpty) return this;
        return FromLTRB(Math.Min(X, other.X), Math.Min(Y, other.Y),
                        Math.Max(Right, other.Right), Math.Max(Bottom, other.Bottom));
    }

    public IntRect Inflate(int dx, int dy) => new(X - dx, Y - dy, Width + 2 * dx, Height + 2 * dy);

    public IntRect Offset(int dx, int dy) => new(X + dx, Y + dy, Width, Height);

    public bool Equals(IntRect o) => X == o.X && Y == o.Y && Width == o.Width && Height == o.Height;
    public override bool Equals(object? obj) => obj is IntRect r && Equals(r);
    public override int GetHashCode() => HashCode.Combine(X, Y, Width, Height);
    public static bool operator ==(IntRect a, IntRect b) => a.Equals(b);
    public static bool operator !=(IntRect a, IntRect b) => !a.Equals(b);
    public override string ToString() => $"[{X},{Y} {Width}x{Height}]";
}
