using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;

namespace AnimDraw.Core.Rendering;

/// <summary>Flattens the visible layers of a frame into one image.</summary>
public static class Compositor
{
    /// <summary>
    /// Draws frame <paramref name="frame"/> of <paramref name="project"/> into <paramref name="dst"/> (same size as the canvas),
    /// limited to <paramref name="region"/>. The region is first cleared, or filled with the background colour when
    /// <paramref name="withBackground"/> is set.
    /// </summary>
    public static void Compose(Project project, int frame, PixelBuffer dst, IntRect region, bool withBackground)
    {
        region = region.Intersect(dst.Bounds);
        if (region.IsEmpty) return;

        if (withBackground) dst.Fill(region, project.Background.PremultipliedPixel);
        else dst.Clear(region);

        foreach (var layer in project.Layers)
        {
            if (!layer.Visible) continue;
            int opacity = layer.Opacity255;
            if (opacity <= 0) continue;
            var cel = layer.GetCelAt(frame);
            if (cel == null) continue;
            BlendSurface(cel.Surface, dst, region, opacity);
        }
    }

    /// <summary>Composes a whole frame into a new image.</summary>
    public static PixelBuffer ComposeFrame(Project project, int frame, bool withBackground)
    {
        var buf = new PixelBuffer(project.Width, project.Height);
        Compose(project, frame, buf, buf.Bounds, withBackground);
        return buf;
    }

    /// <summary>The flattened colour of a single canvas pixel (premultiplied), without composing the whole image.</summary>
    public static uint SamplePixel(Project project, int frame, int x, int y, bool withBackground)
    {
        uint result = withBackground ? project.Background.PremultipliedPixel : 0u;
        foreach (var layer in project.Layers)
        {
            if (!layer.Visible) continue;
            int opacity = layer.Opacity255;
            if (opacity <= 0) continue;
            var cel = layer.GetCelAt(frame);
            if (cel == null) continue;
            uint s = cel.Surface.GetPixel(x, y);
            if (s == 0) continue;
            result = Px.SourceOver(result, Px.Scale(s, opacity));
        }
        return result;
    }

    /// <summary>Source-over blends a drawing onto an image, restricted to a region.</summary>
    public static void BlendSurface(TiledSurface src, PixelBuffer dst, IntRect region, int opacity255)
    {
        if (!src.TryGetTileRange(region, out int tx0, out int ty0, out int tx1, out int ty1)) return;
        int dw = dst.Width;
        var pixels = dst.Pixels;
        for (int ty = ty0; ty <= ty1; ty++)
        for (int tx = tx0; tx <= tx1; tx++)
        {
            int index = src.TileIndex(tx, ty);
            var tile = src.GetTile(index);
            if (tile == null) continue;
            var part = src.TileBounds(index).Intersect(region);
            for (int y = part.Y; y < part.Bottom; y++)
            {
                int ti = ((y & Tile.Mask) << Tile.Shift) + (part.X & Tile.Mask);
                int di = y * dw + part.X;
                var data = tile.Data;
                if (opacity255 >= 255)
                {
                    for (int i = 0; i < part.Width; i++, ti++, di++)
                    {
                        uint s = data[ti];
                        if (s == 0) continue;
                        pixels[di] = (s >> 24) == 255 ? s : Px.SourceOver(pixels[di], s);
                    }
                }
                else
                {
                    for (int i = 0; i < part.Width; i++, ti++, di++)
                    {
                        uint s = data[ti];
                        if (s == 0) continue;
                        pixels[di] = Px.SourceOver(pixels[di], Px.Scale(s, opacity255));
                    }
                }
            }
        }
    }
}
