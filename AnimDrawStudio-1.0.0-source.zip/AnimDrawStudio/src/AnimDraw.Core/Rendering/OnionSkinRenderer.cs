using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;

namespace AnimDraw.Core.Rendering;

/// <summary>
/// Draws the neighbouring frames as translucent ghosts so the next drawing can be lined up with them.
/// Drawings that are held unchanged across frames (a static background, say) are left out so only
/// what actually moves is ghosted.
/// </summary>
public sealed class OnionSkinRenderer
{
    public static readonly ArgbColor PreviousTint = ArgbColor.FromRgb(255, 70, 70);
    public static readonly ArgbColor NextTint = ArgbColor.FromRgb(60, 130, 255);

    private PixelBuffer? _scratch;

    /// <summary>
    /// Fills <paramref name="dst"/> (canvas-sized, premultiplied) with the ghosts for <paramref name="frame"/> inside
    /// <paramref name="region"/>. Returns false, with the region cleared, when there is nothing to show.
    /// </summary>
    public bool Render(Project project, int frame, PixelBuffer dst, IntRect region)
    {
        region = region.Intersect(dst.Bounds);
        if (region.IsEmpty) return false;
        dst.Clear(region);

        var onion = project.Onion;
        if (!onion.Enabled) return false;

        var ghosts = new List<(int Frame, int Distance, bool Previous)>();
        for (int k = onion.PreviousFrames; k >= 1; k--)
        {
            int g = frame - k;
            if (g >= 0 && g < project.FrameCount) ghosts.Add((g, k, true));
        }
        for (int k = onion.NextFrames; k >= 1; k--)
        {
            int g = frame + k;
            if (g >= 0 && g < project.FrameCount) ghosts.Add((g, k, false));
        }
        if (ghosts.Count == 0) return false;

        if (_scratch == null || _scratch.Width != dst.Width || _scratch.Height != dst.Height)
            _scratch = new PixelBuffer(dst.Width, dst.Height);

        bool drewAnything = false;
        foreach (var (g, distance, previous) in ghosts)
        {
            _scratch.Clear(region);
            bool any = false;
            foreach (var layer in project.Layers)
            {
                if (!layer.Visible) continue;
                int opacity = layer.Opacity255;
                if (opacity <= 0) continue;
                var ghostCel = layer.GetCelAt(g);
                if (ghostCel == null || ReferenceEquals(ghostCel, layer.GetCelAt(frame))) continue;
                Compositor.BlendSurface(ghostCel.Surface, _scratch, region, opacity);
                any = true;
            }
            if (!any) continue;

            double falloff = Math.Max(0.2, 1.0 - 0.2 * (distance - 1));
            int weight = (int)Math.Round(Math.Clamp(onion.Opacity * falloff, 0, 1) * 255);
            if (weight <= 0) continue;
            uint tint = onion.Colorize
                ? Px.Pack(255, (previous ? PreviousTint : NextTint).R, (previous ? PreviousTint : NextTint).G, (previous ? PreviousTint : NextTint).B)
                : 0;

            for (int y = region.Y; y < region.Bottom; y++)
            {
                int row = y * dst.Width;
                for (int x = region.X; x < region.Right; x++)
                {
                    uint s = _scratch.Pixels[row + x];
                    if (s == 0) continue;
                    uint ghost = onion.Colorize ? Px.Scale(tint, (int)(s >> 24)) : s;
                    ghost = Px.Scale(ghost, weight);
                    dst.Pixels[row + x] = Px.SourceOver(dst.Pixels[row + x], ghost);
                }
            }
            drewAnything = true;
        }
        return drewAnything;
    }
}
