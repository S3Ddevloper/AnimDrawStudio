using System.Collections.Concurrent;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;

namespace AnimDraw.Core.Rendering;

/// <summary>
/// Pre-renders flattened frames for smooth playback. It reads a frozen snapshot of the project (see
/// <c>Document.CreateSnapshot</c>), so a background thread can compose upcoming frames while the interface
/// stays responsive. Memory use is capped: only a window of frames ahead of the playhead is kept.
/// </summary>
public sealed class FrameCache : IDisposable
{
    private readonly Project _project;
    private readonly bool _withBackground;
    private readonly long _frameBytes;
    private readonly int _capacity;
    private readonly ConcurrentDictionary<int, PixelBuffer> _frames = new();
    private readonly ManualResetEventSlim _wake = new(false);
    private CancellationTokenSource? _cts;
    private Task? _worker;
    private int _playhead;
    private volatile bool _loop = true;

    public FrameCache(Project snapshot, bool withBackground = true, long budgetBytes = 256L * 1024 * 1024)
    {
        _project = snapshot;
        _withBackground = withBackground;
        _frameBytes = (long)snapshot.Width * snapshot.Height * 4;
        _capacity = (int)Math.Clamp(budgetBytes / Math.Max(1, _frameBytes), 2, Math.Max(2, snapshot.FrameCount));
    }

    public int Capacity => _capacity;
    public int CachedCount => _frames.Count;
    public bool IsPrefetching => _worker is { IsCompleted: false };

    public bool TryGetCached(int frame, out PixelBuffer buffer)
    {
        bool ok = _frames.TryGetValue(frame, out var b);
        buffer = b!;
        return ok;
    }

    /// <summary>The flattened frame; composed right now if the background thread has not reached it yet.</summary>
    public PixelBuffer Get(int frame)
    {
        frame = Math.Clamp(frame, 0, _project.FrameCount - 1);
        if (_frames.TryGetValue(frame, out var cached)) return cached;
        var fresh = Compositor.ComposeFrame(_project, frame, _withBackground);
        // The window may be full; keep the one the caller needs without growing without bound.
        MakeRoom(Volatile.Read(ref _playhead), exceptFrame: frame);
        _frames[frame] = fresh;
        return fresh;
    }

    /// <summary>Starts (or restarts) filling the cache ahead of <paramref name="playhead"/>.</summary>
    public void StartPrefetch(int playhead, bool loop)
    {
        _loop = loop;
        Volatile.Write(ref _playhead, playhead);
        _wake.Set();
        if (IsPrefetching) return;

        _cts?.Dispose();
        _cts = new CancellationTokenSource();
        var token = _cts.Token;
        _worker = Task.Factory.StartNew(() => Run(token), token, TaskCreationOptions.LongRunning, TaskScheduler.Default);
    }

    /// <summary>Tell the prefetcher where playback is now (cheap; call on every frame change).</summary>
    public void UpdatePlayhead(int playhead)
    {
        Volatile.Write(ref _playhead, playhead);
        _wake.Set();
    }

    public void StopPrefetch()
    {
        var cts = _cts;
        if (cts == null) return;
        cts.Cancel();
        _wake.Set();
        try { _worker?.Wait(2000); } catch (AggregateException) { }
        _worker = null;
    }

    private void Run(CancellationToken ct)
    {
        int n = _project.FrameCount;
        try
        {
            while (!ct.IsCancellationRequested)
            {
                _wake.Reset();
                int head = Volatile.Read(ref _playhead);
                bool didWork = false;

                for (int d = 0; d < _capacity && !ct.IsCancellationRequested; d++)
                {
                    int f = head + d;
                    if (f >= n)
                    {
                        if (!_loop) break;
                        f %= n;
                    }
                    if (_frames.ContainsKey(f)) continue;

                    MakeRoom(head, exceptFrame: f);
                    _frames[f] = Compositor.ComposeFrame(_project, f, _withBackground);
                    didWork = true;
                    if (Volatile.Read(ref _playhead) != head) break; // the playhead moved: re-plan
                }

                if (!didWork) _wake.Wait(250, ct); // sleeps until the playhead moves
            }
        }
        catch (OperationCanceledException) { }
    }

    /// <summary>Drops the frames that are furthest behind the playhead until there is room for one more.</summary>
    private void MakeRoom(int head, int exceptFrame)
    {
        int n = _project.FrameCount;
        while (_frames.Count >= _capacity)
        {
            int victim = -1, worst = -1;
            foreach (int k in _frames.Keys)
            {
                if (k == exceptFrame) continue;
                int distance = _loop ? (((k - head) % n) + n) % n : (k >= head ? k - head : int.MaxValue / 2);
                if (distance > worst) { worst = distance; victim = k; }
            }
            if (victim < 0 || !_frames.TryRemove(victim, out _)) break;
        }
    }

    public void Dispose()
    {
        StopPrefetch();
        _cts?.Dispose();
        _wake.Dispose();
        _frames.Clear();
    }
}
