using System.Globalization;

namespace AnimDraw.Core.Imaging;

/// <summary>Straight (non-premultiplied) 8-bit ARGB colour used for UI, settings and files.</summary>
public readonly record struct ArgbColor(byte A, byte R, byte G, byte B)
{
    public static readonly ArgbColor Transparent = new(0, 0, 0, 0);
    public static readonly ArgbColor White = new(255, 255, 255, 255);
    public static readonly ArgbColor Black = new(255, 0, 0, 0);

    public static ArgbColor FromRgb(byte r, byte g, byte b) => new(255, r, g, b);

    public ArgbColor WithAlpha(byte a) => new(a, R, G, B);

    public uint ToPremultiplied() => Px.FromStraight(A, R, G, B);

    public static ArgbColor FromPremultiplied(uint p)
    {
        Px.ToStraight(p, out int a, out int r, out int g, out int b);
        return new ArgbColor((byte)a, (byte)r, (byte)g, (byte)b);
    }

    /// <summary>#RRGGBB when opaque, otherwise #AARRGGBB.</summary>
    public string ToHex() => A == 255
        ? $"#{R:X2}{G:X2}{B:X2}"
        : $"#{A:X2}{R:X2}{G:X2}{B:X2}";

    /// <summary>Accepts #RGB, #RRGGBB and #AARRGGBB (the leading # is optional).</summary>
    public static bool TryParse(string? text, out ArgbColor color)
    {
        color = default;
        if (string.IsNullOrWhiteSpace(text)) return false;
        string s = text.Trim();
        if (s.StartsWith('#')) s = s[1..];
        try
        {
            if (s.Length == 3)
            {
                int r = int.Parse(s.Substring(0, 1), NumberStyles.HexNumber, CultureInfo.InvariantCulture);
                int g = int.Parse(s.Substring(1, 1), NumberStyles.HexNumber, CultureInfo.InvariantCulture);
                int b = int.Parse(s.Substring(2, 1), NumberStyles.HexNumber, CultureInfo.InvariantCulture);
                color = new ArgbColor(255, (byte)(r * 17), (byte)(g * 17), (byte)(b * 17));
                return true;
            }
            if (s.Length == 6 || s.Length == 8)
            {
                uint v = uint.Parse(s, NumberStyles.HexNumber, CultureInfo.InvariantCulture);
                if (s.Length == 6) v |= 0xFF000000u;
                color = new ArgbColor((byte)(v >> 24), (byte)(v >> 16), (byte)(v >> 8), (byte)v);
                return true;
            }
        }
        catch (FormatException) { }
        catch (OverflowException) { }
        return false;
    }

    public static ArgbColor ParseOrDefault(string? text, ArgbColor fallback) =>
        TryParse(text, out var c) ? c : fallback;

    /// <summary>Hue 0..360, saturation and value 0..1.</summary>
    public (double H, double S, double V) ToHsv()
    {
        double r = R / 255.0, g = G / 255.0, b = B / 255.0;
        double max = Math.Max(r, Math.Max(g, b));
        double min = Math.Min(r, Math.Min(g, b));
        double d = max - min;
        double h;
        if (d < 1e-9) h = 0;
        else if (max == r) h = 60 * (((g - b) / d) % 6);
        else if (max == g) h = 60 * (((b - r) / d) + 2);
        else h = 60 * (((r - g) / d) + 4);
        if (h < 0) h += 360;
        double s = max <= 0 ? 0 : d / max;
        return (h, s, max);
    }

    public static ArgbColor FromHsv(double h, double s, double v, byte alpha = 255)
    {
        h = ((h % 360) + 360) % 360;
        s = Math.Clamp(s, 0, 1);
        v = Math.Clamp(v, 0, 1);
        double c = v * s;
        double x = c * (1 - Math.Abs((h / 60) % 2 - 1));
        double m = v - c;
        double r, g, b;
        if (h < 60) { r = c; g = x; b = 0; }
        else if (h < 120) { r = x; g = c; b = 0; }
        else if (h < 180) { r = 0; g = c; b = x; }
        else if (h < 240) { r = 0; g = x; b = c; }
        else if (h < 300) { r = x; g = 0; b = c; }
        else { r = c; g = 0; b = x; }
        return new ArgbColor(alpha,
            (byte)Math.Round((r + m) * 255), (byte)Math.Round((g + m) * 255), (byte)Math.Round((b + m) * 255));
    }
}
