namespace AnimDraw.Core.Imaging;

/// <summary>
/// Remembers the original tile (or null for "was empty") of every tile an edit touches, so the edit can
/// be reverted or turned into an undo record. Tiles are never mutated once recorded: the surface swaps in
/// a private copy on first touch.
/// </summary>
public sealed class TileRecorder
{
    private readonly Dictionary<int, Tile?> _original = new();

    public int Count => _original.Count;
    public bool IsEmpty => _original.Count == 0;
    public IEnumerable<int> Indices => _original.Keys;

    public bool Contains(int tileIndex) => _original.ContainsKey(tileIndex);

    internal void Record(int tileIndex, Tile? original) => _original[tileIndex] = original;

    public Tile? GetOriginal(int tileIndex) => _original.TryGetValue(tileIndex, out var t) ? t : null;

    public void Clear() => _original.Clear();
}

/// <summary>One tile's before/after pair inside a committed edit.</summary>
public readonly record struct TileDelta(int Index, Tile? Before, Tile? After);
