using System.Runtime.CompilerServices;

namespace AnimDraw.Core.Imaging;

/// <summary>
/// Pixel math for packed premultiplied BGRA pixels stored in a <see cref="uint"/> as 0xAARRGGBB
/// (which is exactly the in-memory byte order BGRA on little-endian machines, so it can be handed
/// straight to WPF's Pbgra32 bitmaps).
/// </summary>
public static class Px
{
    public const uint Transparent = 0u;

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static uint Pack(int a, int r, int g, int b) =>
        ((uint)a << 24) | ((uint)r << 16) | ((uint)g << 8) | (uint)b;

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static int A(uint p) => (int)(p >> 24);

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static int R(uint p) => (int)((p >> 16) & 0xFF);

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static int G(uint p) => (int)((p >> 8) & 0xFF);

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static int B(uint p) => (int)(p & 0xFF);

    /// <summary>Exact rounded x*y/255 for 0..255 inputs.</summary>
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static int Mul255(int x, int y)
    {
        int t = x * y + 128;
        return (t + (t >> 8)) >> 8;
    }

    /// <summary>Premultiplies straight (non-premultiplied) channels into a packed pixel.</summary>
    public static uint FromStraight(int a, int r, int g, int b)
    {
        if (a >= 255) return Pack(255, r, g, b);
        if (a <= 0) return 0u;
        return Pack(a, Mul255(r, a), Mul255(g, a), Mul255(b, a));
    }

    /// <summary>Converts a packed premultiplied pixel back to straight channels.</summary>
    public static void ToStraight(uint p, out int a, out int r, out int g, out int b)
    {
        a = A(p);
        if (a == 0) { r = g = b = 0; return; }
        r = R(p); g = G(p); b = B(p);
        if (a == 255) return;
        r = Math.Min(255, (r * 255 + a / 2) / a);
        g = Math.Min(255, (g * 255 + a / 2) / a);
        b = Math.Min(255, (b * 255 + a / 2) / a);
    }

    /// <summary>Multiplies all four channels by f/255 (f in 0..255).</summary>
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static uint MulPacked(uint p, uint f)
    {
        uint rb = (p & 0x00FF00FFu) * f + 0x00800080u;
        rb = ((rb + ((rb >> 8) & 0x00FF00FFu)) >> 8) & 0x00FF00FFu;
        uint ag = ((p >> 8) & 0x00FF00FFu) * f + 0x00800080u;
        ag = (ag + ((ag >> 8) & 0x00FF00FFu)) & 0xFF00FF00u;
        return rb | ag;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static uint Scale(uint p, int f)
    {
        if (f >= 255) return p;
        if (f <= 0) return 0u;
        return MulPacked(p, (uint)f);
    }

    /// <summary>Porter-Duff source-over for premultiplied pixels.</summary>
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static uint SourceOver(uint dst, uint src)
    {
        uint sa = src >> 24;
        if (sa == 255u) return src;
        if (sa == 0u) return dst;
        return src + MulPacked(dst, 255u - sa);
    }

    /// <summary>Removes coverage c/255 of the pixel (destination-out), used by the eraser.</summary>
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static uint DestinationOut(uint dst, int coverage)
    {
        if (coverage <= 0) return dst;
        if (coverage >= 255) return 0u;
        return MulPacked(dst, (uint)(255 - coverage));
    }

    /// <summary>Linear interpolation between two premultiplied pixels, t in 0..255.</summary>
    public static uint Lerp(uint a, uint b, int t)
    {
        if (t <= 0) return a;
        if (t >= 255) return b;
        return MulPacked(a, (uint)(255 - t)) + MulPacked(b, (uint)t);
    }

    /// <summary>Largest per-channel absolute difference between two packed pixels.</summary>
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static int MaxChannelDiff(uint a, uint b)
    {
        if (a == b) return 0;
        int da = Math.Abs(A(a) - A(b));
        int dr = Math.Abs(R(a) - R(b));
        int dg = Math.Abs(G(a) - G(b));
        int db = Math.Abs(B(a) - B(b));
        return Math.Max(Math.Max(da, dr), Math.Max(dg, db));
    }
}
