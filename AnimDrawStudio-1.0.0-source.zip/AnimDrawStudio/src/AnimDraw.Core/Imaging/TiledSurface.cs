using AnimDraw.Core.Geometry;

namespace AnimDraw.Core.Imaging;

/// <summary>
/// A sparse, copy-on-write raster surface: a grid of 128x128 tiles where empty tiles are null.
/// All pixels are premultiplied BGRA (<see cref="Px"/>). One surface holds the artwork of one cel.
/// </summary>
public sealed class TiledSurface
{
    private readonly Tile?[] _grid;

    public int Width { get; }
    public int Height { get; }
    public int TilesX { get; }
    public int TilesY { get; }

    public TiledSurface(int width, int height)
    {
        if (width <= 0 || height <= 0)
            throw new ArgumentOutOfRangeException(nameof(width), "Surface size must be positive.");
        Width = width;
        Height = height;
        TilesX = (width + Tile.Size - 1) >> Tile.Shift;
        TilesY = (height + Tile.Size - 1) >> Tile.Shift;
        _grid = new Tile?[TilesX * TilesY];
    }

    public IntRect Bounds => new(0, 0, Width, Height);
    public int TileCount => _grid.Length;

    public int TileIndex(int tx, int ty) => ty * TilesX + tx;

    /// <summary>Pixel bounds of a tile, clipped to the surface.</summary>
    public IntRect TileBounds(int index)
    {
        int tx = index % TilesX, ty = index / TilesX;
        int x = tx << Tile.Shift, y = ty << Tile.Shift;
        return new IntRect(x, y, Math.Min(Tile.Size, Width - x), Math.Min(Tile.Size, Height - y));
    }

    public Tile? GetTile(int index) => _grid[index];

    public int AllocatedTiles
    {
        get
        {
            int n = 0;
            foreach (var t in _grid) if (t != null) n++;
            return n;
        }
    }

    public long AllocatedBytes => (long)AllocatedTiles * Tile.PixelCount * 4;

    /// <summary>Inclusive tile coordinate range covering a pixel rectangle; false when it misses the surface.</summary>
    public bool TryGetTileRange(IntRect r, out int tx0, out int ty0, out int tx1, out int ty1)
    {
        r = r.Intersect(Bounds);
        if (r.IsEmpty) { tx0 = ty0 = tx1 = ty1 = 0; return false; }
        tx0 = r.X >> Tile.Shift;
        ty0 = r.Y >> Tile.Shift;
        tx1 = (r.Right - 1) >> Tile.Shift;
        ty1 = (r.Bottom - 1) >> Tile.Shift;
        return true;
    }

    public uint GetPixel(int x, int y)
    {
        if ((uint)x >= (uint)Width || (uint)y >= (uint)Height) return 0u;
        var t = _grid[(y >> Tile.Shift) * TilesX + (x >> Tile.Shift)];
        return t == null ? 0u : t.Data[((y & Tile.Mask) << Tile.Shift) | (x & Tile.Mask)];
    }

    /// <summary>Installs a tile taken from history or another surface. It is frozen so the next writer copies it.</summary>
    public void SetTile(int index, Tile? tile)
    {
        if (tile != null) tile.Frozen = true;
        _grid[index] = tile;
    }

    /// <summary>
    /// Returns a tile that is safe to modify. With a recorder, the first touch stores the original tile and
    /// hands out a private copy; without one, shared (frozen) tiles are copied before writing.
    /// </summary>
    public Tile GetTileForWrite(int index, TileRecorder? recorder)
    {
        var t = _grid[index];
        if (recorder != null)
        {
            if (!recorder.Contains(index))
            {
                recorder.Record(index, t);
                t = t == null ? new Tile() : t.Copy();
                _grid[index] = t;
                return t;
            }
            if (t == null) { t = new Tile(); _grid[index] = t; return t; }
            if (t.Frozen) { t = t.Copy(); _grid[index] = t; }
            return t;
        }

        if (t == null) { t = new Tile(); _grid[index] = t; }
        else if (t.Frozen) { t = t.Copy(); _grid[index] = t; }
        return t;
    }

    /// <summary>Puts every touched tile back the way it was before the recorded edit began.</summary>
    public void Revert(TileRecorder recorder)
    {
        foreach (int index in recorder.Indices)
            _grid[index] = recorder.GetOriginal(index);
    }

    /// <summary>
    /// Ends a recorded edit: drops tiles that ended up blank or unchanged, freezes the survivors and returns
    /// the list of real changes (empty when the edit changed nothing).
    /// </summary>
    public List<TileDelta> Finish(TileRecorder recorder)
    {
        var deltas = new List<TileDelta>(recorder.Count);
        foreach (int index in recorder.Indices)
        {
            var before = recorder.GetOriginal(index);
            var after = _grid[index];

            if (after != null && after.IsBlank())
            {
                after = null;
                _grid[index] = null;
            }
            if (before != null && after != null && before.Data.AsSpan().SequenceEqual(after.Data))
            {
                _grid[index] = before;
                continue;
            }
            if (before == null && after == null) continue;

            if (after != null) after.Frozen = true;
            if (before != null) before.Frozen = true;
            deltas.Add(new TileDelta(index, before, after));
        }
        recorder.Clear();
        return deltas;
    }

    public void ApplyDeltas(IReadOnlyList<TileDelta> deltas, bool undo)
    {
        foreach (var d in deltas) SetTile(d.Index, undo ? d.Before : d.After);
    }

    /// <summary>Makes every tile shared-and-immutable so copies and snapshots are O(tiles).</summary>
    public void Freeze()
    {
        foreach (var t in _grid) if (t != null) t.Frozen = true;
    }

    /// <summary>A copy that shares pixel data with this surface until either side is edited.</summary>
    public TiledSurface Clone()
    {
        Freeze();
        var c = new TiledSurface(Width, Height);
        Array.Copy(_grid, c._grid, _grid.Length);
        return c;
    }

    public void Clear()
    {
        Array.Clear(_grid);
    }

    public bool IsBlank()
    {
        foreach (var t in _grid) if (t != null && !t.IsBlank()) return false;
        return true;
    }

    public IntRect GetContentBounds()
    {
        IntRect result = IntRect.Empty;
        for (int i = 0; i < _grid.Length; i++)
        {
            var t = _grid[i];
            if (t == null) continue;
            var tb = TileBounds(i);
            int minX = Tile.Size, minY = Tile.Size, maxX = -1, maxY = -1;
            for (int y = 0; y < tb.Height; y++)
            {
                var row = t.Data.AsSpan(y << Tile.Shift, tb.Width);
                int first = row.IndexOfAnyExcept(0u);
                if (first < 0) continue;
                int last = row.LastIndexOfAnyExcept(0u);
                if (first < minX) minX = first;
                if (last > maxX) maxX = last;
                if (y < minY) minY = y;
                maxY = y;
            }
            if (maxX < 0) continue;
            result = result.Union(IntRect.FromLTRB(tb.X + minX, tb.Y + minY, tb.X + maxX + 1, tb.Y + maxY + 1));
        }
        return result;
    }

    /// <summary>Copies a region into <paramref name="dst"/>; empty tiles become transparent. Overwrites the target area.</summary>
    public void CopyRegionTo(PixelBuffer dst, IntRect src, int dstX, int dstY)
    {
        var clipped = src.Intersect(Bounds);
        // Area of the request that falls outside the surface is transparent.
        dst.Clear(new IntRect(dstX, dstY, src.Width, src.Height));
        if (clipped.IsEmpty) return;
        int ox = dstX - src.X, oy = dstY - src.Y;
        TryGetTileRange(clipped, out int tx0, out int ty0, out int tx1, out int ty1);
        for (int ty = ty0; ty <= ty1; ty++)
        for (int tx = tx0; tx <= tx1; tx++)
        {
            var t = _grid[TileIndex(tx, ty)];
            if (t == null) continue;
            var part = TileBounds(TileIndex(tx, ty)).Intersect(clipped);
            for (int y = part.Y; y < part.Bottom; y++)
            {
                var srcRow = t.Data.AsSpan(((y & Tile.Mask) << Tile.Shift) + (part.X & Tile.Mask), part.Width);
                int dy = y + oy, dx = part.X + ox;
                if ((uint)dy >= (uint)dst.Height) continue;
                int skipL = Math.Max(0, -dx);
                int count = Math.Min(part.Width, dst.Width - dx) - skipL;
                if (count <= 0) continue;
                srcRow.Slice(skipL, count).CopyTo(dst.Pixels.AsSpan(dy * dst.Width + dx + skipL, count));
            }
        }
    }

    public PixelBuffer ReadRegion(IntRect r)
    {
        var buf = new PixelBuffer(Math.Max(1, r.Width), Math.Max(1, r.Height));
        CopyRegionTo(buf, r, 0, 0);
        return buf;
    }

    public PixelBuffer ToBuffer() => ReadRegion(Bounds);

    public static TiledSurface FromBuffer(PixelBuffer buf, int width, int height, int offsetX = 0, int offsetY = 0)
    {
        var s = new TiledSurface(width, height);
        s.BlendBuffer(buf, offsetX, offsetY, null, 255, replace: true);
        return s;
    }

    public static TiledSurface FromBuffer(PixelBuffer buf) => FromBuffer(buf, buf.Width, buf.Height);

    /// <summary>Erases a rectangle (whole tiles are dropped, partial tiles cleared).</summary>
    public void ClearRect(IntRect r, TileRecorder? recorder)
    {
        r = r.Intersect(Bounds);
        if (r.IsEmpty) return;
        TryGetTileRange(r, out int tx0, out int ty0, out int tx1, out int ty1);
        for (int ty = ty0; ty <= ty1; ty++)
        for (int tx = tx0; tx <= tx1; tx++)
        {
            int index = TileIndex(tx, ty);
            if (_grid[index] == null) continue;
            var part = TileBounds(index).Intersect(r);
            var tile = GetTileForWrite(index, recorder);
            for (int y = part.Y; y < part.Bottom; y++)
                Array.Clear(tile.Data, ((y & Tile.Mask) << Tile.Shift) + (part.X & Tile.Mask), part.Width);
        }
    }

    /// <summary>Draws a buffer onto the surface at (x, y): source-over by default, or replacing the pixels.</summary>
    public void BlendBuffer(PixelBuffer src, int x, int y, TileRecorder? recorder, int opacity255 = 255, bool replace = false)
    {
        var target = new IntRect(x, y, src.Width, src.Height).Intersect(Bounds);
        if (target.IsEmpty || opacity255 <= 0) return;
        TryGetTileRange(target, out int tx0, out int ty0, out int tx1, out int ty1);
        for (int ty = ty0; ty <= ty1; ty++)
        for (int tx = tx0; tx <= tx1; tx++)
        {
            int index = TileIndex(tx, ty);
            var part = TileBounds(index).Intersect(target);
            if (part.IsEmpty) continue;

            // Skip tiles where there is nothing to draw, so blank sources do not allocate tiles.
            bool any = false;
            for (int yy = part.Y; yy < part.Bottom && !any; yy++)
            {
                var row = src.Pixels.AsSpan((yy - y) * src.Width + (part.X - x), part.Width);
                if (row.IndexOfAnyExcept(0u) >= 0) any = true;
            }
            if (!any && !(replace && _grid[index] != null)) continue;

            var tile = GetTileForWrite(index, recorder);
            for (int yy = part.Y; yy < part.Bottom; yy++)
            {
                int si = (yy - y) * src.Width + (part.X - x);
                int di = ((yy & Tile.Mask) << Tile.Shift) + (part.X & Tile.Mask);
                for (int i = 0; i < part.Width; i++, si++, di++)
                {
                    uint s = src.Pixels[si];
                    if (opacity255 < 255) s = Px.Scale(s, opacity255);
                    if (replace) tile.Data[di] = s;
                    else if (s != 0) tile.Data[di] = Px.SourceOver(tile.Data[di], s);
                }
            }
        }
        if (recorder == null) PruneBlankTiles(target);
    }

    private void PruneBlankTiles(IntRect area)
    {
        if (!TryGetTileRange(area, out int tx0, out int ty0, out int tx1, out int ty1)) return;
        for (int ty = ty0; ty <= ty1; ty++)
        for (int tx = tx0; tx <= tx1; tx++)
        {
            int index = TileIndex(tx, ty);
            if (_grid[index] != null && _grid[index]!.IsBlank()) _grid[index] = null;
        }
    }

    /// <summary>
    /// Returns a new surface of another size with this surface's pixels moved by (offsetX, offsetY);
    /// anything pushed outside the new bounds is cropped. Used for canvas resizing.
    /// </summary>
    public TiledSurface Resized(int newWidth, int newHeight, int offsetX, int offsetY)
    {
        var result = new TiledSurface(newWidth, newHeight);
        for (int i = 0; i < _grid.Length; i++)
        {
            var t = _grid[i];
            if (t == null) continue;
            var tb = TileBounds(i);
            var destArea = tb.Offset(offsetX, offsetY).Intersect(result.Bounds);
            if (destArea.IsEmpty) continue;

            for (int y = destArea.Y; y < destArea.Bottom; y++)
            {
                int sy = y - offsetY;
                int sxStart = destArea.X - offsetX;
                var srcRow = t.Data.AsSpan(((sy & Tile.Mask) << Tile.Shift) + (sxStart & Tile.Mask), destArea.Width);
                int dx = destArea.X, remaining = destArea.Width, consumed = 0;
                while (remaining > 0)
                {
                    int dtx = dx >> Tile.Shift;
                    int within = dx & Tile.Mask;
                    int n = Math.Min(remaining, Tile.Size - within);
                    var dtile = result.GetTileForWrite(result.TileIndex(dtx, y >> Tile.Shift), null);
                    srcRow.Slice(consumed, n).CopyTo(dtile.Data.AsSpan(((y & Tile.Mask) << Tile.Shift) + within, n));
                    dx += n; consumed += n; remaining -= n;
                }
            }
        }
        result.PruneBlankTiles(result.Bounds);
        return result;
    }
}
