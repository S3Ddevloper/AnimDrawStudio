namespace AnimDraw.Core.Imaging;

/// <summary>
/// A 128x128 block of premultiplied BGRA pixels. Layers store only the tiles that contain artwork,
/// which keeps big canvases cheap, and tiles are copy-on-write so that undo history, duplicated
/// frames and background snapshots can share pixel data until somebody edits it.
/// </summary>
public sealed class Tile
{
    public const int Shift = 7;
    public const int Size = 1 << Shift;
    public const int Mask = Size - 1;
    public const int PixelCount = Size * Size;

    public uint[] Data { get; }

    /// <summary>True once this tile may be referenced from more than one place; writers must copy it first.</summary>
    public bool Frozen { get; set; }

    public Tile() => Data = new uint[PixelCount];

    private Tile(uint[] data) => Data = data;

    public Tile Copy() => new((uint[])Data.Clone());

    public bool IsBlank() => Data.AsSpan().IndexOfAnyExcept(0u) < 0;
}
