namespace AnimDraw.Core.Imaging;

public enum ResampleMode
{
    /// <summary>Hard pixels; best for pixel art.</summary>
    Nearest,

    /// <summary>Bilinear when enlarging, area averaging when shrinking.</summary>
    Smooth
}

/// <summary>Image scaling on premultiplied BGRA buffers.</summary>
public static class Resampler
{
    private readonly struct Taps
    {
        public readonly int[] Start;
        public readonly int[] Count;
        public readonly float[][] Weight;

        public Taps(int[] start, int[] count, float[][] weight)
        {
            Start = start;
            Count = count;
            Weight = weight;
        }
    }

    public static PixelBuffer Scale(PixelBuffer src, int newWidth, int newHeight, ResampleMode mode = ResampleMode.Smooth)
    {
        if (newWidth <= 0 || newHeight <= 0) throw new ArgumentOutOfRangeException(nameof(newWidth));
        if (newWidth == src.Width && newHeight == src.Height) return src.Clone();
        return mode == ResampleMode.Nearest ? ScaleNearest(src, newWidth, newHeight) : ScaleSmooth(src, newWidth, newHeight);
    }

    private static PixelBuffer ScaleNearest(PixelBuffer src, int w, int h)
    {
        var dst = new PixelBuffer(w, h);
        var xmap = new int[w];
        for (int x = 0; x < w; x++) xmap[x] = Math.Min(src.Width - 1, (int)((x + 0.5) * src.Width / w));
        for (int y = 0; y < h; y++)
        {
            int sy = Math.Min(src.Height - 1, (int)((y + 0.5) * src.Height / h));
            int so = sy * src.Width, d = y * w;
            for (int x = 0; x < w; x++) dst.Pixels[d + x] = src.Pixels[so + xmap[x]];
        }
        return dst;
    }

    private static Taps BuildTaps(int srcLen, int dstLen)
    {
        var start = new int[dstLen];
        var count = new int[dstLen];
        var weights = new float[dstLen][];
        double scale = (double)srcLen / dstLen;
        for (int d = 0; d < dstLen; d++)
        {
            if (scale <= 1.0)
            {
                double c = (d + 0.5) * scale - 0.5;
                int i0 = (int)Math.Floor(c);
                float t = (float)(c - i0);
                int a = Math.Clamp(i0, 0, srcLen - 1), b = Math.Clamp(i0 + 1, 0, srcLen - 1);
                if (a == b) { start[d] = a; count[d] = 1; weights[d] = new[] { 1f }; }
                else { start[d] = a; count[d] = 2; weights[d] = new[] { 1f - t, t }; }
            }
            else
            {
                double s0 = d * scale, s1 = (d + 1) * scale;
                int i0 = (int)Math.Floor(s0);
                int i1 = Math.Min(srcLen, (int)Math.Ceiling(s1));
                int n = Math.Max(1, i1 - i0);
                var w = new float[n];
                float sum = 0;
                for (int i = 0; i < n; i++)
                {
                    double overlap = Math.Min(i0 + i + 1, s1) - Math.Max(i0 + i, s0);
                    w[i] = (float)Math.Max(0, overlap);
                    sum += w[i];
                }
                if (sum <= 0) { w[0] = 1; sum = 1; }
                for (int i = 0; i < n; i++) w[i] /= sum;
                start[d] = i0;
                count[d] = n;
                weights[d] = w;
            }
        }
        return new Taps(start, count, weights);
    }

    private static PixelBuffer ScaleSmooth(PixelBuffer src, int w, int h)
    {
        var tx = BuildTaps(src.Width, w);
        var ty = BuildTaps(src.Height, h);

        // Horizontal pass: srcHeight rows of w pixels, four floats (B,G,R,A) each.
        var mid = new float[(long)src.Height * w * 4];
        Parallel.For(0, src.Height, y =>
        {
            int so = y * src.Width;
            long mo = (long)y * w * 4;
            for (int x = 0; x < w; x++)
            {
                float a = 0, r = 0, g = 0, b = 0;
                var wt = tx.Weight[x];
                int s = tx.Start[x];
                for (int k = 0; k < tx.Count[x]; k++)
                {
                    uint p = src.Pixels[so + s + k];
                    float f = wt[k];
                    a += f * (p >> 24);
                    r += f * ((p >> 16) & 0xFF);
                    g += f * ((p >> 8) & 0xFF);
                    b += f * (p & 0xFF);
                }
                mid[mo++] = b; mid[mo++] = g; mid[mo++] = r; mid[mo++] = a;
            }
        });

        var dst = new PixelBuffer(w, h);
        Parallel.For(0, h, y =>
        {
            var wt = ty.Weight[y];
            int s = ty.Start[y], n = ty.Count[y];
            for (int x = 0; x < w; x++)
            {
                float a = 0, r = 0, g = 0, b = 0;
                for (int k = 0; k < n; k++)
                {
                    long mo = ((long)(s + k) * w + x) * 4;
                    float f = wt[k];
                    b += f * mid[mo]; g += f * mid[mo + 1]; r += f * mid[mo + 2]; a += f * mid[mo + 3];
                }
                int ia = Math.Clamp((int)(a + 0.5f), 0, 255);
                int ir = Math.Min(ia, Math.Clamp((int)(r + 0.5f), 0, 255));
                int ig = Math.Min(ia, Math.Clamp((int)(g + 0.5f), 0, 255));
                int ib = Math.Min(ia, Math.Clamp((int)(b + 0.5f), 0, 255));
                dst.Pixels[y * w + x] = Px.Pack(ia, ir, ig, ib);
            }
        });
        return dst;
    }
}
