using System.Runtime.InteropServices;
using AnimDraw.Core.Geometry;

namespace AnimDraw.Core.Imaging;

/// <summary>A flat, canvas-sized (or smaller) image of premultiplied BGRA pixels.</summary>
public sealed class PixelBuffer
{
    public int Width { get; }
    public int Height { get; }
    public uint[] Pixels { get; }

    public PixelBuffer(int width, int height)
    {
        if (width <= 0 || height <= 0)
            throw new ArgumentOutOfRangeException(nameof(width), "Image size must be positive.");
        long count = (long)width * height;
        if (count > int.MaxValue / 4)
            throw new ArgumentOutOfRangeException(nameof(width), "Image is too large.");
        Width = width;
        Height = height;
        Pixels = new uint[count];
    }

    public IntRect Bounds => new(0, 0, Width, Height);

    public uint GetPixel(int x, int y) =>
        (uint)x < (uint)Width && (uint)y < (uint)Height ? Pixels[y * Width + x] : 0u;

    public void SetPixel(int x, int y, uint p)
    {
        if ((uint)x < (uint)Width && (uint)y < (uint)Height) Pixels[y * Width + x] = p;
    }

    public void Clear() => Array.Clear(Pixels);

    public void Clear(IntRect r)
    {
        r = r.Intersect(Bounds);
        for (int y = r.Y; y < r.Bottom; y++)
            Array.Clear(Pixels, y * Width + r.X, r.Width);
    }

    public void Fill(uint premultiplied) => Array.Fill(Pixels, premultiplied);

    public void Fill(IntRect r, uint premultiplied)
    {
        r = r.Intersect(Bounds);
        for (int y = r.Y; y < r.Bottom; y++)
            Array.Fill(Pixels, premultiplied, y * Width + r.X, r.Width);
    }

    public PixelBuffer Clone()
    {
        var c = new PixelBuffer(Width, Height);
        Array.Copy(Pixels, c.Pixels, Pixels.Length);
        return c;
    }

    /// <summary>Copies a sub-rectangle into a new buffer (parts outside this image stay transparent).</summary>
    public PixelBuffer Crop(IntRect r)
    {
        var result = new PixelBuffer(Math.Max(1, r.Width), Math.Max(1, r.Height));
        var src = r.Intersect(Bounds);
        for (int y = src.Y; y < src.Bottom; y++)
            Array.Copy(Pixels, y * Width + src.X, result.Pixels, (y - r.Y) * result.Width + (src.X - r.X), src.Width);
        return result;
    }

    /// <summary>Source-over blend of another buffer onto this one at (x, y).</summary>
    public void BlendFrom(PixelBuffer src, int x, int y, int opacity255 = 255)
    {
        var dstRect = new IntRect(x, y, src.Width, src.Height).Intersect(Bounds);
        if (dstRect.IsEmpty || opacity255 <= 0) return;
        for (int dy = dstRect.Y; dy < dstRect.Bottom; dy++)
        {
            int si = (dy - y) * src.Width + (dstRect.X - x);
            int di = dy * Width + dstRect.X;
            for (int i = 0; i < dstRect.Width; i++, si++, di++)
            {
                uint s = src.Pixels[si];
                if (s == 0) continue;
                if (opacity255 < 255) s = Px.Scale(s, opacity255);
                Pixels[di] = Px.SourceOver(Pixels[di], s);
            }
        }
    }

    /// <summary>Raw premultiplied BGRA bytes (what WPF's Pbgra32 and FFmpeg's bgra expect).</summary>
    public byte[] ToBgraBytes()
    {
        var bytes = new byte[Pixels.Length * 4];
        MemoryMarshal.AsBytes(Pixels.AsSpan()).CopyTo(bytes);
        return bytes;
    }

    /// <summary>Straight (non-premultiplied) RGBA bytes, as PNG and GIF encoders want them.</summary>
    public byte[] ToStraightRgba()
    {
        var bytes = new byte[Pixels.Length * 4];
        int o = 0;
        foreach (uint p in Pixels)
        {
            Px.ToStraight(p, out int a, out int r, out int g, out int b);
            bytes[o++] = (byte)r;
            bytes[o++] = (byte)g;
            bytes[o++] = (byte)b;
            bytes[o++] = (byte)a;
        }
        return bytes;
    }

    public static PixelBuffer FromStraightRgba(byte[] rgba, int width, int height)
    {
        if (rgba.Length < width * height * 4) throw new ArgumentException("Not enough pixel data.", nameof(rgba));
        var buf = new PixelBuffer(width, height);
        int o = 0;
        for (int i = 0; i < buf.Pixels.Length; i++, o += 4)
            buf.Pixels[i] = Px.FromStraight(rgba[o + 3], rgba[o], rgba[o + 1], rgba[o + 2]);
        return buf;
    }

    /// <summary>Wraps premultiplied BGRA bytes (e.g. copied out of a WPF bitmap).</summary>
    public static PixelBuffer FromBgraBytes(byte[] bgra, int width, int height)
    {
        if (bgra.Length < width * height * 4) throw new ArgumentException("Not enough pixel data.", nameof(bgra));
        var buf = new PixelBuffer(width, height);
        MemoryMarshal.Cast<byte, uint>(bgra.AsSpan(0, width * height * 4)).CopyTo(buf.Pixels);
        return buf;
    }

    /// <summary>True when every pixel is fully transparent.</summary>
    public bool IsBlank() => Pixels.AsSpan().IndexOfAnyExcept(0u) < 0;

    /// <summary>Smallest rectangle containing all non-transparent pixels, or Empty.</summary>
    public IntRect GetContentBounds()
    {
        int minX = Width, minY = Height, maxX = -1, maxY = -1;
        for (int y = 0; y < Height; y++)
        {
            var row = Pixels.AsSpan(y * Width, Width);
            int first = row.IndexOfAnyExcept(0u);
            if (first < 0) continue;
            int last = row.LastIndexOfAnyExcept(0u);
            minX = Math.Min(minX, first);
            maxX = Math.Max(maxX, last);
            minY = Math.Min(minY, y);
            maxY = y;
        }
        return maxX < 0 ? IntRect.Empty : IntRect.FromLTRB(minX, minY, maxX + 1, maxY + 1);
    }
}
