using System.IO;
using System.Windows;
using AnimDraw.App.Services;
using AnimDraw.App.Windows;
using AnimDraw.Core.App;
using AnimDraw.Core.IO;
using AnimDraw.Core.Settings;

namespace AnimDraw.App;

public partial class App : Application
{
    private Editor? _editor;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        CrashLog.Install(this, () => MainWindow);

        var settingsManager = new SettingsManager();
        settingsManager.Load();
        ThemeManager.Apply(settingsManager.Settings.Theme, out _);

        try
        {
            _editor = new Editor(settingsManager);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidOperationException or ArgumentException)
        {
            CrashLog.Write("The program could not start", ex);
            MessageDialog.Error(null, "AnimDraw Studio cannot start", "The program could not set itself up: " + ex.Message, ex.ToString());
            Shutdown(1);
            return;
        }

        // Look for work left behind by a crash before this session claims its own recovery files.
        IReadOnlyList<RecoveryEntry> recoverable = _editor.FindRecoverable();
        _editor.Recovery.Start();

        string? startupFile = e.Args
            .Select(a => a.Trim('"'))
            .FirstOrDefault(a => a.EndsWith(ProjectFileFormat.Extension, StringComparison.OrdinalIgnoreCase) && File.Exists(a));

        var window = new MainWindow(_editor, startupFile, recoverable, settingsManager.LoadProblem);
        MainWindow = window;
        window.Show();
    }

    /// <summary>
    /// Windows is logging off or shutting down. WPF closes the windows without waiting for any question, so the latest
    /// work is written to the recovery folder first; the next start offers it back.
    /// </summary>
    protected override void OnSessionEnding(SessionEndingCancelEventArgs e)
    {
        base.OnSessionEnding(e);
        try
        {
            _editor?.SaveRecoveryCopyNow(TimeSpan.FromSeconds(3));
        }
        catch (Exception ex)
        {
            CrashLog.Write("The recovery copy could not be written while Windows was ending the session", ex);
        }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        try
        {
            _editor?.Dispose();
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            // Shutting down: nothing useful to do about a file that cannot be cleaned up.
        }
        base.OnExit(e);
    }
}
