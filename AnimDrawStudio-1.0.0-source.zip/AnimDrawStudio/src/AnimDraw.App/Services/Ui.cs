using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using AnimDraw.App.Controls;
using AnimDraw.Core.Imaging;

namespace AnimDraw.App.Services;

/// <summary>Small builders for the controls that appear everywhere, so the look and the behaviour stay the same in every window.</summary>
public static class Ui
{
    public static Style? StyleOf(object key) => Application.Current?.TryFindResource(key) as Style;

    /// <summary>Makes a property follow a theme brush, so it changes with the theme without any further code.</summary>
    public static T Themed<T>(this T element, DependencyProperty property, string key) where T : FrameworkElement
    {
        element.SetResourceReference(property, key);
        return element;
    }

    public static void ApplyStyle(FrameworkElement element, string key)
    {
        if (StyleOf(key) is { } style) element.Style = style;
    }

    // ----- buttons -----

    public static Button IconButton(string icon, string tip, Action click, double iconSize = 18)
    {
        var button = new Button { Content = new IconView(icon, iconSize), ToolTip = tip, Focusable = false };
        ApplyStyle(button, ThemeKeys.IconButtonStyle);
        button.Click += (_, _) => click();
        return button;
    }

    public static ToggleButton IconToggle(string icon, string tip, bool isChecked, Action<bool> changed, double iconSize = 18)
    {
        var button = new ToggleButton { Content = new IconView(icon, iconSize), ToolTip = tip, Focusable = false, IsChecked = isChecked };
        ApplyStyle(button, ThemeKeys.IconToggleStyle);
        button.Click += (_, _) => changed(button.IsChecked == true);
        return button;
    }

    public static Button TextButton(string text, Action click, bool primary = false, double minWidth = 84)
    {
        var button = new Button { Content = text, MinWidth = minWidth };
        if (primary) ApplyStyle(button, ThemeKeys.PrimaryButtonStyle);
        button.Click += (_, _) => click();
        return button;
    }

    /// <summary>A button with an icon and a text, for dialogs and the transport row.</summary>
    public static Button IconTextButton(string icon, string text, Action click, bool primary = false)
    {
        var panel = new StackPanel { Orientation = Orientation.Horizontal };
        panel.Children.Add(new IconView(icon, 16) { Margin = new Thickness(0, 0, 6, 0), VerticalAlignment = VerticalAlignment.Center });
        panel.Children.Add(new TextBlock { Text = text, VerticalAlignment = VerticalAlignment.Center });
        var button = new Button { Content = panel, Padding = new Thickness(10, 4, 12, 4) };
        if (primary) ApplyStyle(button, ThemeKeys.PrimaryButtonStyle);
        button.Click += (_, _) => click();
        return button;
    }

    // ----- text -----

    public static TextBlock Label(string text, bool dim = false, double size = 0, bool bold = false)
    {
        var block = new TextBlock { Text = text, VerticalAlignment = VerticalAlignment.Center };
        block.SetResourceReference(TextBlock.ForegroundProperty, dim ? ThemeKeys.TextDim : ThemeKeys.Text);
        if (size > 0) block.FontSize = size;
        if (bold) block.FontWeight = FontWeights.SemiBold;
        return block;
    }

    public static TextBlock Wrapped(string text, bool dim = false, double maxWidth = 0)
    {
        var block = Label(text, dim);
        block.TextWrapping = TextWrapping.Wrap;
        if (maxWidth > 0) block.MaxWidth = maxWidth;
        return block;
    }

    public static void Tip(FrameworkElement element, string text, string? shortcut = null)
    {
        element.ToolTip = string.IsNullOrEmpty(shortcut) ? text : text + "  (" + shortcut + ")";
    }

    // ----- lines and boxes -----

    public static Border VerticalLine(double margin = 4)
    {
        var line = new Border { Width = 1, Margin = new Thickness(margin, 4, margin, 4), VerticalAlignment = VerticalAlignment.Stretch };
        line.SetResourceReference(Border.BackgroundProperty, ThemeKeys.Border);
        return line;
    }

    public static Border HorizontalLine(double margin = 4)
    {
        var line = new Border { Height = 1, Margin = new Thickness(4, margin, 4, margin), HorizontalAlignment = HorizontalAlignment.Stretch };
        line.SetResourceReference(Border.BackgroundProperty, ThemeKeys.Border);
        return line;
    }

    /// <summary>A rectangle with a theme background and an optional theme border.</summary>
    public static Border Box(string backgroundKey, string? borderKey = null, Thickness? borderThickness = null)
    {
        var box = new Border();
        box.SetResourceReference(Border.BackgroundProperty, backgroundKey);
        if (borderKey != null)
        {
            box.SetResourceReference(Border.BorderBrushProperty, borderKey);
            box.BorderThickness = borderThickness ?? new Thickness(1);
        }
        return box;
    }

    /// <summary>The title strip at the top of a side panel, with optional buttons at its right end.</summary>
    public static Border PanelHeader(string title, params UIElement[] actions)
    {
        var grid = MakeGrid("*,Auto");
        var text = Label(title, bold: true);
        text.Margin = new Thickness(10, 0, 0, 0);
        text.Place(grid, 0, 0);
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 4, 0) };
        foreach (var action in actions) buttons.Children.Add(action);
        buttons.Place(grid, 0, 1);

        var header = Box(ThemeKeys.PanelHeader, ThemeKeys.Border, new Thickness(0, 0, 0, 1));
        header.Height = 30;
        header.Child = grid;
        return header;
    }

    // ----- grids -----

    /// <summary>Makes a grid from size lists such as "Auto,*,Auto" or "120,2*".</summary>
    public static Grid MakeGrid(string columns, string rows = "")
    {
        var grid = new Grid();
        foreach (var length in ParseLengths(columns)) grid.ColumnDefinitions.Add(new ColumnDefinition { Width = length });
        foreach (var length in ParseLengths(rows)) grid.RowDefinitions.Add(new RowDefinition { Height = length });
        return grid;
    }

    private static IEnumerable<GridLength> ParseLengths(string list)
    {
        foreach (string raw in list.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            if (raw.Equals("Auto", StringComparison.OrdinalIgnoreCase)) yield return GridLength.Auto;
            else if (raw.EndsWith('*'))
            {
                string number = raw[..^1];
                double weight = number.Length == 0 ? 1 : double.Parse(number, CultureInfo.InvariantCulture);
                yield return new GridLength(weight, GridUnitType.Star);
            }
            else yield return new GridLength(double.Parse(raw, CultureInfo.InvariantCulture), GridUnitType.Pixel);
        }
    }

    public static T Place<T>(this T element, Grid grid, int row, int column, int rowSpan = 1, int columnSpan = 1) where T : UIElement
    {
        Grid.SetRow(element, row);
        Grid.SetColumn(element, column);
        if (rowSpan > 1) Grid.SetRowSpan(element, rowSpan);
        if (columnSpan > 1) Grid.SetColumnSpan(element, columnSpan);
        grid.Children.Add(element);
        return element;
    }

    // ----- colours -----

    public static Color ToColor(ArgbColor c) => Color.FromArgb(c.A, c.R, c.G, c.B);

    public static ArgbColor FromColor(Color c) => new(c.A, c.R, c.G, c.B);

    public static SolidColorBrush ToBrush(ArgbColor c)
    {
        var brush = new SolidColorBrush(ToColor(c));
        brush.Freeze();
        return brush;
    }

    // ----- misc -----

    /// <summary>Runs an action on the UI thread without waiting for it.</summary>
    public static void Later(Action action, System.Windows.Threading.DispatcherPriority priority = System.Windows.Threading.DispatcherPriority.Background)
    {
        var dispatcher = Application.Current?.Dispatcher;
        if (dispatcher == null) return;
        dispatcher.BeginInvoke(action, priority);
    }
}
