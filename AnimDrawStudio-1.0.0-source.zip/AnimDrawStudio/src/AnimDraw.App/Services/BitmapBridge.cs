using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;

namespace AnimDraw.App.Services;

/// <summary>Moves pixels between the engine's <see cref="PixelBuffer"/> and WPF bitmaps.</summary>
public static class BitmapBridge
{
    /// <summary>The pixel format of the engine's buffers: premultiplied B, G, R, A bytes.</summary>
    public static readonly PixelFormat Format = PixelFormats.Pbgra32;

    public static WriteableBitmap CreateBitmap(int width, int height) =>
        new(Math.Max(1, width), Math.Max(1, height), 96, 96, Format, null);

    /// <summary>Copies a rectangle of a buffer into a bitmap of the same size.</summary>
    public static void CopyRegion(PixelBuffer source, WriteableBitmap target, IntRect region)
    {
        region = region.Intersect(new IntRect(0, 0, Math.Min(source.Width, target.PixelWidth), Math.Min(source.Height, target.PixelHeight)));
        if (region.IsEmpty) return;

        // uint[] and int[] have the same layout, and the runtime accepts the cast; this lets Marshal.Copy move whole rows.
        int[] data = (int[])(object)source.Pixels;
        target.Lock();
        try
        {
            IntPtr basePointer = target.BackBuffer;
            int stride = target.BackBufferStride;
            for (int y = region.Y; y < region.Bottom; y++)
            {
                Marshal.Copy(data, y * source.Width + region.X, basePointer + y * stride + region.X * 4, region.Width);
            }
            target.AddDirtyRect(new Int32Rect(region.X, region.Y, region.Width, region.Height));
        }
        finally
        {
            target.Unlock();
        }
    }

    public static void CopyAll(PixelBuffer source, WriteableBitmap target) =>
        CopyRegion(source, target, new IntRect(0, 0, source.Width, source.Height));

    /// <summary>A frozen copy of a buffer that can be handed to the clipboard or an Image.</summary>
    public static BitmapSource ToBitmapSource(PixelBuffer buffer)
    {
        var bitmap = BitmapSource.Create(buffer.Width, buffer.Height, 96, 96, Format, null, buffer.ToBgraBytes(), buffer.Width * 4);
        bitmap.Freeze();
        return bitmap;
    }

    /// <summary>Reads any WPF bitmap into a buffer. Returns null for an empty or absurdly large picture.</summary>
    public static PixelBuffer? FromBitmapSource(BitmapSource source, long maxPixels = 100_000_000)
    {
        int w = source.PixelWidth, h = source.PixelHeight;
        if (w <= 0 || h <= 0 || (long)w * h > maxPixels) return null;
        BitmapSource converted = source.Format == Format ? source : new FormatConvertedBitmap(source, Format, null, 0);
        var bytes = new byte[w * h * 4];
        converted.CopyPixels(bytes, w * 4, 0);
        return PixelBuffer.FromBgraBytes(bytes, w, h);
    }

    /// <summary>
    /// Loads a picture file (PNG, JPEG, BMP, GIF, TIFF). Throws for files WPF cannot read. The file is read through a stream
    /// rather than a Uri, so names with characters such as # or % work, and the file is not left locked.
    /// </summary>
    public static PixelBuffer? LoadPicture(string path)
    {
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
        var decoder = new BitmapImage();
        decoder.BeginInit();
        decoder.CacheOption = BitmapCacheOption.OnLoad;   // reads everything now, so the stream can be closed afterwards
        decoder.CreateOptions = BitmapCreateOptions.IgnoreColorProfile;
        decoder.StreamSource = stream;
        decoder.EndInit();
        decoder.Freeze();
        return FromBitmapSource(decoder);
    }
}
