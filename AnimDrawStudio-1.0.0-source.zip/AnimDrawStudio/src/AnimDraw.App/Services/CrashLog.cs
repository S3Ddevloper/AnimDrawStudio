using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Threading;
using AnimDraw.App.Windows;
using AnimDraw.Core.Settings;

namespace AnimDraw.App.Services;

/// <summary>
/// Catches the mistakes that would otherwise close the program without a word: they are written to a log file and shown in a
/// message that says what happened, and the program carries on whenever that is safe. Work in progress is protected by autosave.
/// </summary>
public static class CrashLog
{
    private static readonly object Gate = new();
    private static readonly Queue<DateTime> Recent = new();
    private static bool _showing;

    public static string Folder => Path.Combine(SettingsManager.DefaultDataFolder, "logs");

    /// <summary>Writes a report and returns its path, or null when even that was not possible.</summary>
    public static string? Write(string what, Exception? ex)
    {
        try
        {
            lock (Gate)
            {
                Directory.CreateDirectory(Folder);
                PruneOldLogs();
                string path = Path.Combine(Folder, $"error-{DateTime.Now:yyyyMMdd-HHmmss-fff}.log");
                var sb = new StringBuilder();
                sb.AppendLine("AnimDraw Studio error report");
                sb.AppendLine("Time:    " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                sb.AppendLine("Version: " + AppInfo.Version);
                sb.AppendLine("System:  " + Environment.OSVersion + ", " + (Environment.Is64BitProcess ? "64" : "32") + "-bit, .NET " + Environment.Version);
                sb.AppendLine("What:    " + what);
                sb.AppendLine();
                sb.AppendLine(ex?.ToString() ?? "(no exception)");
                File.WriteAllText(path, sb.ToString());
                return path;
            }
        }
        catch (Exception logEx) when (logEx is IOException or UnauthorizedAccessException or System.Security.SecurityException)
        {
            return null;
        }
    }

    private static void PruneOldLogs()
    {
        try
        {
            var files = new DirectoryInfo(Folder).GetFiles("error-*.log").OrderByDescending(f => f.LastWriteTimeUtc).Skip(30);
            foreach (var f in files) f.Delete();
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { }
    }

    /// <summary>Installs the handlers for mistakes on the UI thread, on other threads and in background tasks.</summary>
    public static void Install(Application app, Func<Window?> mainWindow)
    {
        app.DispatcherUnhandledException += (_, e) =>
        {
            e.Handled = HandleUiException(e.Exception, mainWindow());
        };
        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
        {
            Write("Unhandled exception (the program is closing)", e.ExceptionObject as Exception);
        };
        TaskScheduler.UnobservedTaskException += (_, e) =>
        {
            Write("A background task failed", e.Exception);
            e.SetObserved();
        };
    }

    private static bool HandleUiException(Exception ex, Window? owner)
    {
        string? path = Write("Unhandled exception on the interface thread", ex);
        Debug.WriteLine(ex);

        lock (Gate)
        {
            var now = DateTime.UtcNow;
            Recent.Enqueue(now);
            while (Recent.Count > 0 && (now - Recent.Peek()).TotalSeconds > 10) Recent.Dequeue();
            if (_showing) return true; // already telling the user; just keep going
        }

        bool repeating;
        lock (Gate) repeating = Recent.Count >= 4;

        try
        {
            lock (Gate) _showing = true;
            string where = path != null ? $"\n\nA report was saved to:\n{path}" : "";
            if (repeating)
            {
                MessageDialog.Error(owner, "AnimDraw Studio has to close",
                    "The same problem keeps happening, so the program will close now. Your latest work was saved by autosave and is offered again the next time you start the program." + where,
                    ex.Message);
                return false;
            }
            MessageDialog.Error(owner, "Something went wrong",
                "An unexpected problem occurred. You can keep working, but it is a good idea to save your project soon." + where,
                ex.Message);
            return true;
        }
        catch (Exception)
        {
            return false;
        }
        finally
        {
            lock (Gate) _showing = false;
        }
    }
}
