using System.Windows;
using System.Windows.Media;

namespace AnimDraw.App.Services;

/// <summary>Draws the built-in icons into a drawing context, for views that paint themselves (the timeline).</summary>
public static class IconPainter
{
    /// <summary>Draws icon <paramref name="name"/> with its top-left corner at (x, y), <paramref name="size"/> units wide and tall.</summary>
    public static void Draw(DrawingContext dc, string name, Brush brush, double x, double y, double size)
    {
        var parts = Icons.Get(name);
        if (parts.Count == 0) return;
        double scale = size / Icons.Grid;
        var outline = new Pen(brush, 2.0) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round, LineJoin = PenLineJoin.Round };
        var edge = new Pen(brush, 1.0) { LineJoin = PenLineJoin.Round };

        dc.PushTransform(new TranslateTransform(x, y));
        dc.PushTransform(new ScaleTransform(scale, scale));
        foreach (var part in parts)
        {
            if (part.Filled) dc.DrawGeometry(brush, edge, part.Geometry);
            else dc.DrawGeometry(null, outline, part.Geometry);
        }
        dc.Pop();
        dc.Pop();
    }
}
