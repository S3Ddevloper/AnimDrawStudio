namespace AnimDraw.App.Services;

/// <summary>The names of the theme colours. Dark.xaml and Light.xaml define every one of them (a build-time check keeps the two in step).</summary>
public static class ThemeKeys
{
    public const string Window = "Brush.Window";
    public const string Panel = "Brush.Panel";
    public const string PanelHeader = "Brush.PanelHeader";
    public const string Workspace = "Brush.Workspace";
    public const string Border = "Brush.Border";
    public const string BorderStrong = "Brush.BorderStrong";
    public const string Text = "Brush.Text";
    public const string TextDim = "Brush.TextDim";
    public const string TextDisabled = "Brush.TextDisabled";
    public const string Accent = "Brush.Accent";
    public const string AccentHover = "Brush.AccentHover";
    public const string AccentSoft = "Brush.AccentSoft";
    public const string AccentText = "Brush.AccentText";
    public const string Control = "Brush.Control";
    public const string ControlHover = "Brush.ControlHover";
    public const string ControlPressed = "Brush.ControlPressed";
    public const string ControlChecked = "Brush.ControlChecked";
    public const string Input = "Brush.Input";
    public const string MenuBg = "Brush.MenuBg";
    public const string MenuHover = "Brush.MenuHover";
    public const string MenuBorder = "Brush.MenuBorder";
    public const string ToolTipBg = "Brush.ToolTipBg";
    public const string ToolTipText = "Brush.ToolTipText";
    public const string Danger = "Brush.Danger";
    public const string Warning = "Brush.Warning";
    public const string Success = "Brush.Success";
    public const string TlRuler = "Brush.TlRuler";
    public const string TlCell = "Brush.TlCell";
    public const string TlCellAlt = "Brush.TlCellAlt";
    public const string TlGrid = "Brush.TlGrid";
    public const string TlHold = "Brush.TlHold";
    public const string TlRowActive = "Brush.TlRowActive";
    public const string TlKey = "Brush.TlKey";
    public const string TlPlayhead = "Brush.TlPlayhead";
    public const string TlCurrentCell = "Brush.TlCurrentCell";

    public const string IconButtonStyle = "Style.IconButton";
    public const string IconToggleStyle = "Style.IconToggle";
    public const string PrimaryButtonStyle = "Style.PrimaryButton";
    public const string ToolRadioStyle = "Style.ToolRadio";
}
