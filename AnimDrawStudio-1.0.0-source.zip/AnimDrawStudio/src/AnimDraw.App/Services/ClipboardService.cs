using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Media.Imaging;
using AnimDraw.Core.App;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.IO;

namespace AnimDraw.App.Services;

/// <summary>
/// Puts artwork on the Windows clipboard (as a PNG, so other programs can paste it) and reads pictures back from it.
/// A private marker tells the program that the picture on the clipboard is its own copy, which is pasted without losing
/// any transparency.
/// </summary>
public static class ClipboardService
{
    private const string MarkerFormat = "AnimDrawStudio.ClipboardId";
    private const string PngFormat = "PNG";

    public enum Source
    {
        None,
        Own,
        Foreign
    }

    /// <summary>Publishes what was copied inside the program. Returns false when Windows would not give access to the clipboard.</summary>
    public static bool Publish(PixelClipboard clip)
    {
        if (clip.Image == null) return false;
        try
        {
            var data = new DataObject();
            data.SetData(MarkerFormat, clip.Id.ToString("N"));
            data.SetData(DataFormats.Bitmap, BitmapBridge.ToBitmapSource(clip.Image));
            using var png = new MemoryStream(PngCodec.Encode(clip.Image));
            data.SetData(PngFormat, png);
            Clipboard.SetDataObject(data, true);
            return true;
        }
        catch (Exception ex) when (ex is COMException or ExternalException or InvalidOperationException or OutOfMemoryException)
        {
            return false;
        }
    }

    /// <summary>Says whether the clipboard holds this program's own copy, someone else's picture, or no picture.</summary>
    public static Source Inspect(PixelClipboard clip)
    {
        try
        {
            if (Clipboard.ContainsData(MarkerFormat) && Clipboard.GetData(MarkerFormat) is string id &&
                clip.HasImage && string.Equals(id, clip.Id.ToString("N"), StringComparison.OrdinalIgnoreCase))
                return Source.Own;
            if (Clipboard.ContainsData(PngFormat) || Clipboard.ContainsImage()) return Source.Foreign;
        }
        catch (Exception ex) when (ex is COMException or ExternalException or InvalidOperationException)
        {
            // The clipboard is busy; treat it as having nothing usable.
        }
        return Source.None;
    }

    /// <summary>Reads a picture another program put on the clipboard. Null when there is none or it cannot be read.</summary>
    public static PixelBuffer? ReadForeignPicture()
    {
        try
        {
            if (Clipboard.ContainsData(PngFormat) && Clipboard.GetData(PngFormat) is MemoryStream stream)
            {
                stream.Position = 0;
                try
                {
                    return PngCodec.Decode(stream);
                }
                catch (Exception ex) when (ex is InvalidDataException or IOException or NotSupportedException or ArgumentException)
                {
                    // Not a PNG after all: fall back to the bitmap format below.
                }
            }
            if (Clipboard.ContainsImage())
            {
                BitmapSource? image = Clipboard.GetImage();
                if (image != null) return BitmapBridge.FromBitmapSource(image);
            }
        }
        catch (Exception ex) when (ex is COMException or ExternalException or InvalidOperationException or OutOfMemoryException or NotSupportedException)
        {
            // Busy or unreadable clipboard.
        }
        return null;
    }
}
