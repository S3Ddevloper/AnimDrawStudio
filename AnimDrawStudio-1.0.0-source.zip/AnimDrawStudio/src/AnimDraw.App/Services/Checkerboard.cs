using System.Windows;
using System.Windows.Media;

namespace AnimDraw.App.Services;

/// <summary>The grey and white squares that show where a picture is see-through.</summary>
public static class Checkerboard
{
    /// <summary>A frozen brush of 16 x 16 tiles with 8-pixel squares. Draw it after translating to the corner of the area it fills.</summary>
    public static Brush Brush { get; } = Make();

    private static Brush Make()
    {
        var light = new GeometryDrawing(new SolidColorBrush(Color.FromRgb(0xFF, 0xFF, 0xFF)), null,
            new RectangleGeometry(new Rect(0, 0, 16, 16)));
        var squares = new GeometryGroup();
        squares.Children.Add(new RectangleGeometry(new Rect(0, 0, 8, 8)));
        squares.Children.Add(new RectangleGeometry(new Rect(8, 8, 8, 8)));
        var dark = new GeometryDrawing(new SolidColorBrush(Color.FromRgb(0xCC, 0xCC, 0xCC)), null, squares);
        var group = new DrawingGroup();
        group.Children.Add(light);
        group.Children.Add(dark);
        var brush = new DrawingBrush(group)
        {
            TileMode = TileMode.Tile,
            Viewbox = new Rect(0, 0, 16, 16),
            ViewboxUnits = BrushMappingMode.Absolute,
            Viewport = new Rect(0, 0, 16, 16),
            ViewportUnits = BrushMappingMode.Absolute
        };
        brush.Freeze();
        return brush;
    }
}
