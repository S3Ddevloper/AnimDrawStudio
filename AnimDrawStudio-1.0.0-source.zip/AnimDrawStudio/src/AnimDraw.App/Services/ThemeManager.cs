using System.Windows;
using System.Windows.Media;
using AnimDraw.Core.Settings;

namespace AnimDraw.App.Services;

/// <summary>Switches between the dark and the light look while the program runs, and hands colours to the custom-drawn views.</summary>
public static class ThemeManager
{
    private const string PackRoot = "pack://application:,,,/AnimDrawStudio;component/Themes/";

    public static AppTheme Current { get; private set; } = AppTheme.Dark;

    /// <summary>Raised after the colours were replaced; custom-drawn views repaint themselves.</summary>
    public static event Action? ThemeChanged;

    /// <summary>
    /// Loads a theme's colours into the application resources. Returns false (and leaves the current look in place)
    /// when the theme file cannot be read.
    /// </summary>
    public static bool Apply(AppTheme theme, out string? problem)
    {
        problem = null;
        var app = Application.Current;
        if (app == null) { problem = "The application is not running."; return false; }
        try
        {
            var dictionary = new ResourceDictionary
            {
                Source = new Uri(PackRoot + (theme == AppTheme.Dark ? "Dark.xaml" : "Light.xaml"), UriKind.Absolute)
            };
            var merged = app.Resources.MergedDictionaries;
            // The colours are always the first merged dictionary; the control styles after them refer to them by key.
            if (merged.Count > 0) merged[0] = dictionary;
            else merged.Add(dictionary);
        }
        catch (Exception ex)
        {
            problem = ex.Message;
            return false;
        }
        Current = theme;
        ThemeChanged?.Invoke();
        return true;
    }

    /// <summary>Looks a brush up in the current theme. A visible magenta stands in when a key is missing, which makes mistakes obvious.</summary>
    public static Brush Brush(string key)
    {
        var app = Application.Current;
        return app?.TryFindResource(key) as Brush ?? Brushes.Magenta;
    }

    public static Color Color(string key) => Brush(key) is SolidColorBrush solid ? solid.Color : Colors.Magenta;

    public static void ApplyWindowChrome(Window window) => Native.SetDarkTitleBar(window, Current == AppTheme.Dark);
}
