using System.IO;
using System.Windows;
using Microsoft.Win32;
using AnimDraw.App.Windows;
using AnimDraw.Core.IO;

namespace AnimDraw.App.Services;

/// <summary>The Windows file and folder pickers, set up the way this program wants them.</summary>
public static class FileDialogs
{
    public const string ProjectFilter = "AnimDraw project (*.animdraw)|*.animdraw|All files (*.*)|*.*";
    public const string PictureFilter = "Pictures (*.png;*.jpg;*.jpeg;*.bmp;*.gif)|*.png;*.jpg;*.jpeg;*.bmp;*.gif|All files (*.*)|*.*";

    private static string? ExistingFolder(string? folder) =>
        !string.IsNullOrWhiteSpace(folder) && Directory.Exists(folder) ? folder : null;

    public static string? OpenProject(Window? owner, string? initialFolder)
    {
        var dialog = new OpenFileDialog
        {
            Title = "Open AnimDraw project",
            Filter = ProjectFilter,
            CheckFileExists = true,
            InitialDirectory = ExistingFolder(initialFolder) ?? Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        };
        return Show(dialog, owner) ? dialog.FileName : null;
    }

    /// <summary>
    /// Asks where to save a project and returns the full file name including the ".animdraw" extension, or null when cancelled.
    /// <paramref name="currentFile"/> is the project's present file, which may be replaced without asking again.
    /// </summary>
    public static string? SaveProject(Window? owner, string suggestedName, string? initialFolder, string? currentFile = null)
    {
        string suggestion = suggestedName.EndsWith(ProjectFileFormat.Extension, StringComparison.OrdinalIgnoreCase)
            ? suggestedName
            : suggestedName + ProjectFileFormat.Extension;

        var dialog = new SaveFileDialog
        {
            Title = "Save AnimDraw project",
            Filter = "AnimDraw project (*.animdraw)|*.animdraw",
            DefaultExt = ProjectFileFormat.Extension,
            AddExtension = true,
            OverwritePrompt = true,
            FileName = suggestion,
            InitialDirectory = ExistingFolder(initialFolder) ?? Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        };
        if (!Show(dialog, owner)) return null;

        string chosen = dialog.FileName;
        string normalized;
        try
        {
            normalized = ProjectFileManager.NormalizePath(chosen);
        }
        catch (ProjectFileException)
        {
            return chosen; // an empty name: the save itself explains the problem
        }

        // The dialog only checks the name as it was typed. A name such as "walk v1.2" already has an "extension" (.2), so
        // ".animdraw" is added afterwards, and the file that will really be written was never checked.
        if (!string.Equals(normalized, chosen, StringComparison.OrdinalIgnoreCase) && File.Exists(normalized) && !IsSameFile(normalized, currentFile))
        {
            bool replace = MessageDialog.Confirm(owner, "Replace file?",
                $"A file named \"{Path.GetFileName(normalized)}\" already exists in this folder. Do you want to replace it?",
                "Replace", "Cancel", MessageKind.Warning);
            if (!replace) return null;
        }
        return normalized;
    }

    private static bool IsSameFile(string a, string? b)
    {
        if (string.IsNullOrWhiteSpace(b)) return false;
        try
        {
            return string.Equals(Path.GetFullPath(a), Path.GetFullPath(b), StringComparison.OrdinalIgnoreCase);
        }
        catch (Exception ex) when (ex is ArgumentException or NotSupportedException or PathTooLongException)
        {
            return false;
        }
    }

    /// <summary>Asks for the file an export should write. The filter lists the one extension that fits.</summary>
    public static string? SaveExport(Window? owner, string title, string filterText, string extension, string suggestedName, string? initialFolder)
    {
        var dialog = new SaveFileDialog
        {
            Title = title,
            Filter = $"{filterText} (*{extension})|*{extension}",
            DefaultExt = extension,
            AddExtension = true,
            OverwritePrompt = true,
            FileName = suggestedName,
            InitialDirectory = ExistingFolder(initialFolder) ?? Environment.GetFolderPath(Environment.SpecialFolder.MyPictures)
        };
        return Show(dialog, owner) ? dialog.FileName : null;
    }

    public static string? PickFolder(Window? owner, string title, string? initialFolder)
    {
        var dialog = new OpenFolderDialog
        {
            Title = title,
            InitialDirectory = ExistingFolder(initialFolder) ?? Environment.GetFolderPath(Environment.SpecialFolder.MyPictures)
        };
        bool? result = owner != null ? dialog.ShowDialog(owner) : dialog.ShowDialog();
        return result == true ? dialog.FolderName : null;
    }

    public static string? OpenFile(Window? owner, string title, string filter, string? initialFolder)
    {
        var dialog = new OpenFileDialog
        {
            Title = title,
            Filter = filter,
            CheckFileExists = true,
            InitialDirectory = ExistingFolder(initialFolder) ?? Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        };
        return Show(dialog, owner) ? dialog.FileName : null;
    }

    private static bool Show(FileDialog dialog, Window? owner)
    {
        bool? result = owner != null ? dialog.ShowDialog(owner) : dialog.ShowDialog();
        return result == true;
    }
}
