using System.Windows;
using System.Windows.Media;

namespace AnimDraw.App.Services;

/// <summary>
/// The program's icons, drawn from plain path data on a 24 x 24 grid (no image files). A part that starts with "F:" is a
/// filled shape; every other part is an outline drawn with a round pen. <see cref="Controls.IconView"/> paints them in
/// the current text colour, so they follow the theme and the hover and disabled states automatically.
/// </summary>
public static class Icons
{
    public const double Grid = 24;

    public readonly record struct Part(Geometry Geometry, bool Filled);

    private static readonly Dictionary<string, string[]> Definitions = new()
    {
        ["brush"] = new[] { "M 18.5 2.8 L 21.2 5.5 L 11.8 14.9 L 9.1 12.2 Z", "M 9.1 12.2 C 6.4 11.9 4.6 13.8 4.6 16.2 C 4.6 18.4 3.6 19.6 2.4 20.4 C 6.8 21.6 11.8 20.4 11.8 14.9" },
        ["pencil"] = new[] { "M 17 3 a 2.85 2.83 0 1 1 4 4 L 7.5 20.5 L 2 22 L 3.5 16.5 Z", "M 15 5 L 19 9" },
        ["eraser"] = new[] { "M 7 21 L 2.7 16.7 C 1.7 15.7 1.7 14.2 2.7 13.3 L 12.3 3.7 C 13.3 2.7 14.8 2.7 15.7 3.7 L 21.3 9.3 C 22.3 10.3 22.3 11.8 21.3 12.7 L 13 21", "M 22 21 H 7", "M 5 11 L 14 20" },
        ["line"] = new[] { "M 5.5 18.5 L 18.5 5.5", "M 3.5 16.5 H 7.5 V 20.5 H 3.5 Z", "M 16.5 3.5 H 20.5 V 7.5 H 16.5 Z" },
        ["rect"] = new[] { "M 4 6 H 20 V 18 H 4 Z" },
        ["ellipse"] = new[] { "M 3 12 a 9 7 0 1 0 18 0 a 9 7 0 1 0 -18 0 Z" },
        ["fill"] = new[] { "M 19 11 L 11 3 L 2.4 11.6 a 2 2 0 0 0 0 2.8 L 7.6 19.6 c 0.8 0.8 2 0.8 2.8 0 L 19 11 Z", "M 5 2 L 10 7", "M 2 13 H 17", "M 22 20 a 2 2 0 1 1 -4 0 c 0 -1.6 1.7 -2.4 2 -4 c 0.3 1.6 2 2.4 2 4 Z" },
        ["eyedropper"] = new[] { "M 2 22 L 3 21 H 6 L 15 12", "M 3 21 V 18 L 12 9", "M 15 6 L 18.4 2.6 a 2.1 2.1 0 1 1 3 3 L 18 9 L 18.4 9.4 a 2.1 2.1 0 1 1 -3 3 L 11.6 8.6 a 2.1 2.1 0 1 1 3 -3 L 15 6 Z" },
        ["select"] = new[] { "M 4 4 H 7 M 10.5 4 H 13.5 M 17 4 H 20 V 7 M 20 10.5 V 13.5 M 20 17 V 20 H 17 M 13.5 20 H 10.5 M 7 20 H 4 V 17 M 4 13.5 V 10.5 M 4 7 V 4" },
        ["move"] = new[] { "M 12 3 V 21 M 3 12 H 21 M 12 3 L 9 6 M 12 3 L 15 6 M 12 21 L 9 18 M 12 21 L 15 18 M 3 12 L 6 9 M 3 12 L 6 15 M 21 12 L 18 9 M 21 12 L 18 15" },
        ["hand"] = new[] { "M 18 11 V 6 a 2 2 0 0 0 -2 -2 a 2 2 0 0 0 -2 2", "M 14 10 V 4 a 2 2 0 0 0 -2 -2 a 2 2 0 0 0 -2 2 V 6", "M 10 10.5 V 6 a 2 2 0 0 0 -2 -2 a 2 2 0 0 0 -2 2 V 14", "M 18 8 a 2 2 0 1 1 4 0 V 14 a 8 8 0 0 1 -8 8 H 12 c -2.8 0 -4.5 -0.86 -5.99 -2.34 L 2.41 16.06 a 2 2 0 0 1 2.83 -2.82 L 7 15" },
        ["zoom"] = new[] { "M 10.5 18 a 7.5 7.5 0 1 0 0 -15 a 7.5 7.5 0 0 0 0 15 Z", "M 16 16 L 21 21" },
        ["zoom-in"] = new[] { "M 10.5 18 a 7.5 7.5 0 1 0 0 -15 a 7.5 7.5 0 0 0 0 15 Z", "M 16 16 L 21 21", "M 10.5 7.5 V 13.5 M 7.5 10.5 H 13.5" },
        ["zoom-out"] = new[] { "M 10.5 18 a 7.5 7.5 0 1 0 0 -15 a 7.5 7.5 0 0 0 0 15 Z", "M 16 16 L 21 21", "M 7.5 10.5 H 13.5" },
        ["new"] = new[] { "M 14 3 H 7 a 2 2 0 0 0 -2 2 V 19 a 2 2 0 0 0 2 2 H 17 a 2 2 0 0 0 2 -2 V 8 Z", "M 14 3 V 8 H 19", "M 12 12 V 18 M 9 15 H 15" },
        ["open"] = new[] { "M 3 7 a 2 2 0 0 1 2 -2 H 9 L 11 7.5 H 19 a 2 2 0 0 1 2 2 V 17 a 2 2 0 0 1 -2 2 H 5 a 2 2 0 0 1 -2 -2 Z" },
        ["save"] = new[] { "M 5 3 H 16 L 21 8 V 19 a 2 2 0 0 1 -2 2 H 5 a 2 2 0 0 1 -2 -2 V 5 a 2 2 0 0 1 2 -2 Z", "M 7 3 V 8 H 15 V 3", "M 7 21 V 14 H 17 V 21" },
        ["undo"] = new[] { "M 9 14 L 4 9 L 9 4", "M 4 9 H 15 a 5 5 0 0 1 0 10 H 11" },
        ["redo"] = new[] { "M 15 14 L 20 9 L 15 4", "M 20 9 H 9 a 5 5 0 0 0 0 10 H 13" },
        ["cut"] = new[] { "M 9 6 a 3 3 0 1 1 -6 0 a 3 3 0 0 1 6 0 Z", "M 9 18 a 3 3 0 1 1 -6 0 a 3 3 0 0 1 6 0 Z", "M 8.1 8.1 L 20 20", "M 8.1 15.9 L 20 4" },
        ["copy"] = new[] { "M 5 15 H 4 a 1 1 0 0 1 -1 -1 V 4 a 1 1 0 0 1 1 -1 H 14 a 1 1 0 0 1 1 1 V 5", "M 10 9 H 20 a 1 1 0 0 1 1 1 V 20 a 1 1 0 0 1 -1 1 H 10 a 1 1 0 0 1 -1 -1 V 10 a 1 1 0 0 1 1 -1 Z" },
        ["paste"] = new[] { "M 8 4 H 6 a 2 2 0 0 0 -2 2 V 19 a 2 2 0 0 0 2 2 H 18 a 2 2 0 0 0 2 -2 V 6 a 2 2 0 0 0 -2 -2 H 16", "M 9 2 H 15 a 1 1 0 0 1 1 1 V 5 a 1 1 0 0 1 -1 1 H 9 a 1 1 0 0 1 -1 -1 V 3 a 1 1 0 0 1 1 -1 Z" },
        ["export"] = new[] { "M 12 15 V 3", "M 7 8 L 12 3 L 17 8", "M 5 14 V 19 a 2 2 0 0 0 2 2 H 17 a 2 2 0 0 0 2 -2 V 14" },
        ["settings"] = new[] { "M 4 7 H 11 M 15 7 H 20 M 4 17 H 8 M 12 17 H 20", "M 13 4 V 10", "M 10 14 V 20" },
        ["duplicate"] = new[] { "M 4 4 H 14 V 14 H 4 Z", "M 10 10 H 20 V 20 H 10 Z" },
        ["first"] = new[] { "F:M 4.5 5 H 7 V 19 H 4.5 Z", "F:M 19.5 5.5 V 18.5 L 8.5 12 Z" },
        ["last"] = new[] { "F:M 17 5 H 19.5 V 19 H 17 Z", "F:M 4.5 5.5 V 18.5 L 15.5 12 Z" },
        ["prev"] = new[] { "M 15 5 L 8 12 L 15 19" },
        ["next"] = new[] { "M 9 5 L 16 12 L 9 19" },
        ["play"] = new[] { "F:M 7 4.5 L 19.5 12 L 7 19.5 Z" },
        ["pause"] = new[] { "F:M 6 4.5 H 10 V 19.5 H 6 Z", "F:M 14 4.5 H 18 V 19.5 H 14 Z" },
        ["stop"] = new[] { "F:M 6 6 H 18 V 18 H 6 Z" },
        ["loop"] = new[] { "M 17 2 L 21 6 L 17 10", "M 3 11 V 9 a 4 4 0 0 1 4 -4 H 21", "M 7 22 L 3 18 L 7 14", "M 21 13 V 15 a 4 4 0 0 1 -4 4 H 3" },
        ["frame-add"] = new[] { "M 5 4 H 19 V 20 H 5 Z", "M 12 9 V 15 M 9 12 H 15" },
        ["frame-del"] = new[] { "M 5 4 H 19 V 20 H 5 Z", "M 9 12 H 15" },
        ["keyframe"] = new[] { "F:M 12 4 L 20 12 L 12 20 L 4 12 Z" },
        ["keyframe-blank"] = new[] { "M 12 4 L 20 12 L 12 20 L 4 12 Z" },
        ["onion"] = new[] { "M 9 6 a 6 6 0 1 0 0 12 a 6 6 0 0 0 0 -12 Z", "M 15 6 a 6 6 0 1 0 0 12 a 6 6 0 0 0 0 -12 Z" },
        ["eye"] = new[] { "M 2 12 C 5 6 8.5 4.5 12 4.5 C 15.5 4.5 19 6 22 12 C 19 18 15.5 19.5 12 19.5 C 8.5 19.5 5 18 2 12 Z", "M 12 9 a 3 3 0 1 1 0 6 a 3 3 0 0 1 0 -6 Z" },
        ["eye-off"] = new[] { "M 2 12 C 5 6 8.5 4.5 12 4.5 C 15.5 4.5 19 6 22 12 C 19 18 15.5 19.5 12 19.5 C 8.5 19.5 5 18 2 12 Z", "M 12 9 a 3 3 0 1 1 0 6 a 3 3 0 0 1 0 -6 Z", "M 3.5 3.5 L 20.5 20.5" },
        ["lock"] = new[] { "M 6 11 H 18 a 1 1 0 0 1 1 1 V 20 a 1 1 0 0 1 -1 1 H 6 a 1 1 0 0 1 -1 -1 V 12 a 1 1 0 0 1 1 -1 Z", "M 8 11 V 7 a 4 4 0 0 1 8 0 V 11" },
        ["unlock"] = new[] { "M 6 11 H 18 a 1 1 0 0 1 1 1 V 20 a 1 1 0 0 1 -1 1 H 6 a 1 1 0 0 1 -1 -1 V 12 a 1 1 0 0 1 1 -1 Z", "M 8 11 V 7 a 4 4 0 0 1 7.6 -1.8" },
        ["layers"] = new[] { "M 12 2.5 L 21.5 7.5 L 12 12.5 L 2.5 7.5 Z", "M 2.5 12 L 12 17 L 21.5 12", "M 2.5 16.5 L 12 21.5 L 21.5 16.5" },
        ["plus"] = new[] { "M 12 5 V 19 M 5 12 H 19" },
        ["minus"] = new[] { "M 5 12 H 19" },
        ["trash"] = new[] { "M 4 7 H 20", "M 10 11 V 17 M 14 11 V 17", "M 6 7 L 7 20 a 1 1 0 0 0 1 1 H 16 a 1 1 0 0 0 1 -1 L 18 7", "M 9 7 V 4 H 15 V 7" },
        ["up"] = new[] { "M 12 19 V 5", "M 6 11 L 12 5 L 18 11" },
        ["down"] = new[] { "M 12 5 V 19", "M 6 13 L 12 19 L 18 13" },
        ["merge"] = new[] { "M 12 3 V 13", "M 7 8 L 12 13 L 17 8", "M 5 19 H 19" },
        ["rename"] = new[] { "M 4 20 H 20", "M 6 16 L 6.8 12.4 L 15.5 3.7 a 1.7 1.7 0 0 1 2.4 2.4 L 9.2 14.8 Z" },
        ["fit"] = new[] { "M 4 9 V 4 H 9 M 15 4 H 20 V 9 M 20 15 V 20 H 15 M 9 20 H 4 V 15" },
        ["grid"] = new[] { "M 4 4 H 20 V 20 H 4 Z", "M 4 12 H 20 M 12 4 V 20" },
        ["preview"] = new[] { "M 3 12 a 9 9 0 1 0 18 0 a 9 9 0 1 0 -18 0 Z", "F:M 10 8.5 L 16 12 L 10 15.5 Z" },
        ["swap"] = new[] { "M 7 4 L 3 8 L 7 12", "M 3 8 H 17", "M 17 12 L 21 16 L 17 20", "M 21 16 H 7" },
        ["film"] = new[] { "M 4 4 H 20 V 20 H 4 Z", "M 8 4 V 20 M 16 4 V 20", "M 4 8 H 8 M 4 12 H 8 M 4 16 H 8 M 16 8 H 20 M 16 12 H 20 M 16 16 H 20" },
        ["close"] = new[] { "M 6 6 L 18 18 M 18 6 L 6 18" },
        ["check"] = new[] { "M 5 12.5 L 10 17.5 L 19 7" },
        ["warning"] = new[] { "M 12 3.5 L 21.5 20 H 2.5 Z", "M 12 9.5 V 14", "M 12 17.2 V 17.3" },
        ["info"] = new[] { "M 3 12 a 9 9 0 1 0 18 0 a 9 9 0 1 0 -18 0 Z", "M 12 11 V 17", "M 12 7.4 V 7.5" },
        ["error"] = new[] { "M 3 12 a 9 9 0 1 0 18 0 a 9 9 0 1 0 -18 0 Z", "M 9 9 L 15 15 M 15 9 L 9 15" },
        ["question"] = new[] { "M 3 12 a 9 9 0 1 0 18 0 a 9 9 0 1 0 -18 0 Z", "M 9.3 9.2 a 2.8 2.8 0 0 1 5.4 1 c 0 1.9 -2.7 2.4 -2.7 4", "M 12 17.4 V 17.5" },
        ["chevron-down"] = new[] { "M 6 9 L 12 15 L 18 9" },
        ["folder-open"] = new[] { "M 3 7 a 2 2 0 0 1 2 -2 H 9 L 11 7.5 H 19 a 2 2 0 0 1 2 2 V 10", "M 3 19 L 5.5 11 H 22.5 L 20 19 Z" },
        ["keyboard"] = new[] { "M 3 6 H 21 a 1 1 0 0 1 1 1 V 17 a 1 1 0 0 1 -1 1 H 3 a 1 1 0 0 1 -1 -1 V 7 a 1 1 0 0 1 1 -1 Z", "M 6 10 H 6.1 M 10 10 H 10.1 M 14 10 H 14.1 M 18 10 H 18.1", "M 7 14 H 17" },
    };

    private static readonly Dictionary<string, Part[]> Cache = new();

    public static IEnumerable<string> Names => Definitions.Keys;

    public static bool Exists(string? name) => name != null && Definitions.ContainsKey(name);

    /// <summary>The shapes of an icon, or an empty list for an unknown name.</summary>
    public static IReadOnlyList<Part> Get(string? name)
    {
        if (string.IsNullOrEmpty(name) || !Definitions.TryGetValue(name, out var defs)) return Array.Empty<Part>();
        lock (Cache)
        {
            if (Cache.TryGetValue(name, out var cached)) return cached;
            var parts = new Part[defs.Length];
            for (int i = 0; i < defs.Length; i++)
            {
                bool filled = defs[i].StartsWith("F:", StringComparison.Ordinal);
                var geometry = Geometry.Parse(filled ? defs[i][2..] : defs[i]);
                geometry.Freeze();
                parts[i] = new Part(geometry, filled);
            }
            Cache[name] = parts;
            return parts;
        }
    }
}
