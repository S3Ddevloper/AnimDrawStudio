using AnimDraw.Core.App;
using AnimDraw.Core.Tools;

namespace AnimDraw.App.Services;

public sealed record ToolEntry(ToolKind Kind, string Icon, string Name, CommandId Command);

/// <summary>The tools in the order they appear in the palette, with their icons and the command that selects them.</summary>
public static class ToolCatalog
{
    /// <summary>Groups of tools; a separator is drawn between groups.</summary>
    public static readonly IReadOnlyList<IReadOnlyList<ToolEntry>> Groups = new IReadOnlyList<ToolEntry>[]
    {
        new[]
        {
            new ToolEntry(ToolKind.Select, "select", "Select", CommandId.ToolSelect),
            new ToolEntry(ToolKind.Move, "move", "Move", CommandId.ToolMove)
        },
        new[]
        {
            new ToolEntry(ToolKind.Brush, "brush", "Brush", CommandId.ToolBrush),
            new ToolEntry(ToolKind.Pencil, "pencil", "Pencil", CommandId.ToolPencil),
            new ToolEntry(ToolKind.Eraser, "eraser", "Eraser", CommandId.ToolEraser)
        },
        new[]
        {
            new ToolEntry(ToolKind.Line, "line", "Line", CommandId.ToolLine),
            new ToolEntry(ToolKind.Rectangle, "rect", "Rectangle", CommandId.ToolRectangle),
            new ToolEntry(ToolKind.Ellipse, "ellipse", "Ellipse", CommandId.ToolEllipse)
        },
        new[]
        {
            new ToolEntry(ToolKind.Fill, "fill", "Fill (paint bucket)", CommandId.ToolFill),
            new ToolEntry(ToolKind.Eyedropper, "eyedropper", "Eyedropper", CommandId.ToolEyedropper)
        },
        new[]
        {
            new ToolEntry(ToolKind.Hand, "hand", "Hand (pan)", CommandId.ToolHand),
            new ToolEntry(ToolKind.Zoom, "zoom", "Zoom", CommandId.ToolZoom)
        }
    };

    public static IEnumerable<ToolEntry> All => Groups.SelectMany(g => g);

    public static ToolEntry Get(ToolKind kind) => All.First(t => t.Kind == kind);
}
