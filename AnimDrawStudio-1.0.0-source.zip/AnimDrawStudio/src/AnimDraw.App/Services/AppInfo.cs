using System.Reflection;

namespace AnimDraw.App.Services;

/// <summary>Name and version of the program, read from the assembly.</summary>
public static class AppInfo
{
    public const string Name = "AnimDraw Studio";
    public const string Tagline = "2D drawing and frame-by-frame animation";

    public static string Version
    {
        get
        {
            var assembly = Assembly.GetEntryAssembly() ?? Assembly.GetExecutingAssembly();
            string? informational = assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion;
            if (!string.IsNullOrWhiteSpace(informational))
            {
                int plus = informational.IndexOf('+');
                return plus > 0 ? informational[..plus] : informational;
            }
            return assembly.GetName().Version?.ToString(3) ?? "1.0.0";
        }
    }
}
