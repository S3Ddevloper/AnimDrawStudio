using System.Windows.Media;
using AnimDraw.Core.Imaging;

namespace AnimDraw.App.Services;

/// <summary>Makes the small preview pictures in the layer list. It averages only the parts of a drawing that exist, so empty layers cost nothing.</summary>
public static class LayerThumbnail
{
    /// <summary>
    /// The size a thumbnail needs for a canvas so that it fits in a box while keeping the canvas's proportions. It is never
    /// larger than the canvas itself: <see cref="Render"/> averages pixels down and would leave gaps if it had to stretch a
    /// tiny canvas (a 16 x 16 icon, say) up to the box.
    /// </summary>
    public static (int Width, int Height) SizeFor(int canvasWidth, int canvasHeight, int boxWidth, int boxHeight)
    {
        double scale = Math.Min(1.0, Math.Min(boxWidth / (double)Math.Max(1, canvasWidth), boxHeight / (double)Math.Max(1, canvasHeight)));
        int w = Math.Clamp((int)Math.Round(canvasWidth * scale), 1, boxWidth);
        int h = Math.Clamp((int)Math.Round(canvasHeight * scale), 1, boxHeight);
        return (w, h);
    }

    /// <summary>Averages the surface down to <paramref name="width"/> x <paramref name="height"/> premultiplied pixels.</summary>
    public static uint[] Render(TiledSurface surface, int width, int height)
    {
        var result = new uint[width * height];
        int sw = surface.Width, sh = surface.Height;

        var columnOf = new int[sw];
        var rowOf = new int[sh];
        var columnCount = new int[width];
        var rowCount = new int[height];
        for (int x = 0; x < sw; x++) { int c = (int)((long)x * width / sw); columnOf[x] = c; columnCount[c]++; }
        for (int y = 0; y < sh; y++) { int r = (int)((long)y * height / sh); rowOf[y] = r; rowCount[r]++; }

        var sumA = new int[width * height];
        var sumR = new int[width * height];
        var sumG = new int[width * height];
        var sumB = new int[width * height];
        bool any = false;

        for (int index = 0; index < surface.TileCount; index++)
        {
            Tile? tile = surface.GetTile(index);
            if (tile == null) continue;
            var bounds = surface.TileBounds(index);
            for (int y = 0; y < bounds.Height; y++)
            {
                int rowBase = rowOf[bounds.Y + y] * width;
                int dataBase = y * Tile.Size;
                for (int x = 0; x < bounds.Width; x++)
                {
                    uint p = tile.Data[dataBase + x];
                    if (p == 0) continue;
                    int cell = rowBase + columnOf[bounds.X + x];
                    sumA[cell] += (int)(p >> 24);
                    sumR[cell] += (int)((p >> 16) & 0xFF);
                    sumG[cell] += (int)((p >> 8) & 0xFF);
                    sumB[cell] += (int)(p & 0xFF);
                    any = true;
                }
            }
        }
        if (!any) return result;

        for (int cy = 0; cy < height; cy++)
        {
            for (int cx = 0; cx < width; cx++)
            {
                int cell = cy * width + cx;
                int count = Math.Max(1, columnCount[cx] * rowCount[cy]);
                result[cell] = Px.Pack(sumA[cell] / count, sumR[cell] / count, sumG[cell] / count, sumB[cell] / count);
            }
        }
        return result;
    }
}

/// <summary>The grey-and-white squares that show through transparent areas.</summary>
public static class CheckerBrushes
{
    public static readonly Brush Small = Make(4, System.Windows.Media.Color.FromRgb(0xFF, 0xFF, 0xFF), System.Windows.Media.Color.FromRgb(0xC8, 0xC8, 0xC8));

    private static Brush Make(double square, System.Windows.Media.Color light, System.Windows.Media.Color dark)
    {
        double tile = square * 2;
        var lightBackground = new GeometryDrawing(new SolidColorBrush(light), null, new RectangleGeometry(new System.Windows.Rect(0, 0, tile, tile)));
        var squares = new GeometryGroup();
        squares.Children.Add(new RectangleGeometry(new System.Windows.Rect(0, 0, square, square)));
        squares.Children.Add(new RectangleGeometry(new System.Windows.Rect(square, square, square, square)));
        var darkSquares = new GeometryDrawing(new SolidColorBrush(dark), null, squares);
        var group = new DrawingGroup();
        group.Children.Add(lightBackground);
        group.Children.Add(darkSquares);
        var brush = new DrawingBrush(group)
        {
            TileMode = TileMode.Tile,
            Viewbox = new System.Windows.Rect(0, 0, tile, tile),
            ViewboxUnits = BrushMappingMode.Absolute,
            Viewport = new System.Windows.Rect(0, 0, tile, tile),
            ViewportUnits = BrushMappingMode.Absolute
        };
        brush.Freeze();
        return brush;
    }
}
