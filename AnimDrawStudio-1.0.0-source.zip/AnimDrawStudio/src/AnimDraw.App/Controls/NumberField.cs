using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace AnimDraw.App.Controls;

/// <summary>
/// A text box for one number: it accepts only values inside a range, commits on Enter or when it loses focus, undoes an
/// entry that is not a number, and steps with the arrow keys and the mouse wheel.
/// </summary>
public sealed class NumberField
{
    private double _value;
    private bool _updating;

    public NumberField(double value, double minimum, double maximum, int decimals = 0, double step = 1, double width = 70)
    {
        Minimum = minimum;
        Maximum = maximum;
        Decimals = Math.Max(0, decimals);
        Step = step;
        Box = new TextBox { Width = width, VerticalContentAlignment = VerticalAlignment.Center, TextAlignment = TextAlignment.Right, MaxLength = 12 };
        _value = Clamp(value);
        Box.Text = Format(_value);

        Box.LostKeyboardFocus += (_, _) => Commit();
        Box.GotKeyboardFocus += (_, _) => Box.SelectAll();
        Box.PreviewMouseLeftButtonDown += (_, e) =>
        {
            if (!Box.IsKeyboardFocusWithin)
            {
                Box.Focus();
                e.Handled = true;
            }
        };
        Box.PreviewKeyDown += OnKeyDown;
        Box.PreviewMouseWheel += (_, e) =>
        {
            if (!Box.IsKeyboardFocusWithin) return;
            Commit();
            Nudge(e.Delta > 0 ? 1 : -1, Keyboard.Modifiers.HasFlag(ModifierKeys.Shift));
            e.Handled = true;
        };
    }

    public TextBox Box { get; }
    public double Minimum { get; set; }
    public double Maximum { get; set; }
    public int Decimals { get; set; }
    public double Step { get; set; }

    /// <summary>Show 12 instead of 12.00 (up to <see cref="Decimals"/> decimals are kept when they are needed).</summary>
    public bool TrimZeros { get; set; }

    /// <summary>Raised after the user has committed a new value (not when the value is set from code).</summary>
    public event Action<double>? ValueChanged;

    public double Value => _value;

    public int IntValue => (int)Math.Round(_value);

    /// <summary>Sets the value from code without raising <see cref="ValueChanged"/>.</summary>
    public void SetValue(double value)
    {
        _value = Clamp(value);
        _updating = true;
        Box.Text = Format(_value);
        _updating = false;
    }

    public bool IsEnabled
    {
        get => Box.IsEnabled;
        set => Box.IsEnabled = value;
    }

    private double Clamp(double v)
    {
        if (double.IsNaN(v) || double.IsInfinity(v)) v = Minimum;
        v = Math.Clamp(v, Minimum, Maximum);
        return Decimals == 0 ? Math.Round(v) : Math.Round(v, Decimals);
    }

    private string Format(double v) =>
        TrimZeros && Decimals > 0
            ? v.ToString("0." + new string('#', Decimals), CultureInfo.CurrentCulture)
            : v.ToString("F" + Decimals, CultureInfo.CurrentCulture);

    private void OnKeyDown(object sender, KeyEventArgs e)
    {
        switch (e.Key)
        {
            case Key.Enter:
                Commit();
                Box.SelectAll();
                e.Handled = true;
                break;
            case Key.Escape:
                _updating = true;
                Box.Text = Format(_value);
                _updating = false;
                Box.SelectAll();
                e.Handled = true;
                break;
            case Key.Up:
                Commit();
                Nudge(1, Keyboard.Modifiers.HasFlag(ModifierKeys.Shift));
                e.Handled = true;
                break;
            case Key.Down:
                Commit();
                Nudge(-1, Keyboard.Modifiers.HasFlag(ModifierKeys.Shift));
                e.Handled = true;
                break;
        }
    }

    private void Nudge(int direction, bool big)
    {
        double next = Clamp(_value + direction * Step * (big ? 10 : 1));
        if (next == _value) return;
        _value = next;
        _updating = true;
        Box.Text = Format(_value);
        _updating = false;
        Box.SelectAll();
        ValueChanged?.Invoke(_value);
    }

    /// <summary>Reads the text. A number outside the range is brought into it; text that is not a number is replaced by the last good value.</summary>
    public void Commit()
    {
        if (_updating) return;
        string text = Box.Text.Trim();
        if (!TryParse(text, out double parsed))
        {
            Box.Text = Format(_value);
            return;
        }
        double clamped = Clamp(parsed);
        Box.Text = Format(clamped);
        if (clamped == _value) return;
        _value = clamped;
        ValueChanged?.Invoke(_value);
    }

    private static bool TryParse(string text, out double value)
    {
        if (double.TryParse(text, NumberStyles.Float, CultureInfo.CurrentCulture, out value)) return true;
        return double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value);
    }
}
