using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using AnimDraw.App.Services;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;

namespace AnimDraw.App.Controls;

/// <summary>
/// Shows one flattened frame of the animation, either fitted to the space it has or at a fixed zoom, centred, on a
/// checkerboard when the background is transparent. It draws only what it is given; playback logic lives in the preview
/// window. Zoom counts physical screen pixels per picture pixel, so 100% shows each pixel on one screen pixel even on a
/// scaled display.
/// </summary>
public sealed class PreviewSurface : FrameworkElement
{
    public const double MinZoom = 0.05;
    public const double MaxZoom = 32;

    /// <summary>Space kept free around the picture when it is fitted, in view units.</summary>
    private const double Gap = 14;

    private static readonly Brush ShadowBrush = FrozenBrush(Color.FromArgb(34, 0, 0, 0));
    private static readonly Pen EdgePen = FrozenPen(Color.FromArgb(120, 0, 0, 0), 1.0);

    private WriteableBitmap? _bitmap;
    private int _width = 1;
    private int _height = 1;
    private BackgroundSettings _background = BackgroundSettings.White;
    private bool _fit = true;
    private double _zoom = 1;
    private double _shownZoom = 1;
    private BitmapScalingMode _scaling = BitmapScalingMode.Linear;
    private ArgbColor _fillColor;
    private Brush? _fillBrush;

    public PreviewSurface()
    {
        ClipToBounds = true;
        SnapsToDevicePixels = false;
        UseLayoutRounding = false;
    }

    /// <summary>The zoom in use changed because the space it fits into changed (or a zoom was set).</summary>
    public event Action? ZoomChanged;

    /// <summary>True when the picture is fitted to the available space.</summary>
    public bool IsFit => _fit;

    /// <summary>The zoom that is on screen right now, as physical pixels per picture pixel (1 = 100%).</summary>
    public double EffectiveZoom => _shownZoom;

    public int PictureWidth => _width;
    public int PictureHeight => _height;

    /// <summary>Fits the picture into the space available, large or small.</summary>
    public void SetFit()
    {
        _fit = true;
        InvalidateMeasure();
        InvalidateVisual();
    }

    /// <summary>Shows the picture at a fixed zoom (1 = 100%).</summary>
    public void SetZoom(double zoom)
    {
        _fit = false;
        _zoom = Math.Clamp(double.IsNaN(zoom) ? 1 : zoom, MinZoom, MaxZoom);
        InvalidateMeasure();
        InvalidateVisual();
    }

    /// <summary>Starts a picture of a new size. The picture stays empty until <see cref="ShowFrame"/> is called.</summary>
    public void SetCanvas(int width, int height, BackgroundSettings background)
    {
        width = Math.Max(1, width);
        height = Math.Max(1, height);
        _background = background;
        if (_bitmap == null || width != _width || height != _height)
        {
            _width = width;
            _height = height;
            _bitmap = BitmapBridge.CreateBitmap(width, height);
            InvalidateMeasure();
        }
        InvalidateVisual();
    }

    /// <summary>Shows a frame. A frame of another size than the canvas is ignored.</summary>
    public void ShowFrame(PixelBuffer frame)
    {
        if (_bitmap == null || frame.Width != _bitmap.PixelWidth || frame.Height != _bitmap.PixelHeight) return;
        BitmapBridge.CopyAll(frame, _bitmap);
        InvalidateVisual();
    }

    private double Dpi() => Math.Max(0.25, VisualTreeHelper.GetDpi(this).DpiScaleX);

    protected override void OnDpiChanged(DpiScale oldDpi, DpiScale newDpi)
    {
        base.OnDpiChanged(oldDpi, newDpi);
        InvalidateMeasure();
        InvalidateVisual();
    }

    protected override Size MeasureOverride(Size available)
    {
        double dpi = Dpi();
        double previous = _shownZoom;

        if (_fit)
        {
            // Without a limit to fit into (inside a scroll viewer) the picture is simply shown at 100%.
            bool unlimited = double.IsInfinity(available.Width) || double.IsInfinity(available.Height);
            double zoom = 1;
            if (!unlimited)
            {
                double scaleX = Math.Max(1, available.Width - 2 * Gap) / _width;
                double scaleY = Math.Max(1, available.Height - 2 * Gap) / _height;
                zoom = Math.Min(scaleX, scaleY) * dpi;
            }
            _shownZoom = Math.Clamp(zoom, MinZoom, MaxZoom);
        }
        else
        {
            _shownZoom = _zoom;
        }

        var mode = _shownZoom >= 2.0 ? BitmapScalingMode.NearestNeighbor
            : _shownZoom < 1.0 ? BitmapScalingMode.HighQuality
            : BitmapScalingMode.Linear;
        if (mode != _scaling)
        {
            _scaling = mode;
            RenderOptions.SetBitmapScalingMode(this, mode);
        }

        if (Math.Abs(previous - _shownZoom) > 1e-9) ZoomChanged?.Invoke();

        double width = _width * _shownZoom / dpi + 2 * Gap;
        double height = _height * _shownZoom / dpi + 2 * Gap;
        if (_fit)
        {
            // Fill the space so the picture is centred in it.
            if (!double.IsInfinity(available.Width)) width = available.Width;
            if (!double.IsInfinity(available.Height)) height = available.Height;
        }
        return new Size(width, height);
    }

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        if (_bitmap == null) return;

        double dpi = Dpi();
        double pictureWidth = _width * _shownZoom / dpi;
        double pictureHeight = _height * _shownZoom / dpi;
        double x = Math.Max(0, (ActualWidth - pictureWidth) / 2);
        double y = Math.Max(0, (ActualHeight - pictureHeight) / 2);

        // Whole device pixels keep single pixels crisp at 100% and above.
        x = Math.Round(x * dpi) / dpi;
        y = Math.Round(y * dpi) / dpi;
        var rect = new Rect(x, y, pictureWidth, pictureHeight);

        for (int i = 3; i >= 1; i--)
            dc.DrawRectangle(ShadowBrush, null, new Rect(rect.X - i, rect.Y - i + 2, rect.Width + 2 * i, rect.Height + 2 * i));

        if (_background.Mode == BackgroundMode.Transparent)
        {
            dc.PushClip(new RectangleGeometry(rect));
            dc.PushTransform(new TranslateTransform(rect.X, rect.Y));
            dc.DrawRectangle(Checkerboard.Brush, null, new Rect(0, 0, rect.Width, rect.Height));
            dc.Pop();
            dc.Pop();
        }
        else
        {
            dc.DrawRectangle(FillBrush(_background.EffectiveColor), null, rect);
        }

        dc.DrawImage(_bitmap, rect);
        dc.DrawRectangle(null, EdgePen, rect);
    }

    private Brush FillBrush(ArgbColor color)
    {
        if (_fillBrush == null || _fillColor != color)
        {
            _fillBrush = Ui.ToBrush(color);
            _fillColor = color;
        }
        return _fillBrush;
    }

    private static Brush FrozenBrush(Color color)
    {
        var brush = new SolidColorBrush(color);
        brush.Freeze();
        return brush;
    }

    private static Pen FrozenPen(Color color, double thickness)
    {
        var brush = new SolidColorBrush(color);
        brush.Freeze();
        var pen = new Pen(brush, thickness);
        pen.Freeze();
        return pen;
    }
}
