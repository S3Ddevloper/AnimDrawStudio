using System.Windows;
using System.Windows.Controls;
using AnimDraw.App.Services;

namespace AnimDraw.App.Controls;

/// <summary>One line of a <see cref="FormGrid"/>. Showing or hiding it shows or hides everything on that line.</summary>
public sealed class FormRow
{
    private readonly UIElement[] _elements;

    public FormRow(params UIElement[] elements) => _elements = elements;

    /// <summary>The label on the left of a "label: control" row (null for rows that span both columns).</summary>
    public TextBlock? Label { get; init; }

    public bool Visible
    {
        get => _elements.Length > 0 && _elements[0].Visibility == Visibility.Visible;
        set
        {
            foreach (var element in _elements) element.Visibility = value ? Visibility.Visible : Visibility.Collapsed;
        }
    }
}

/// <summary>A two-column layout for dialogs: a label on the left and its control on the right, one row after another.</summary>
public sealed class FormGrid : Grid
{
    private int _row;

    public FormGrid(double labelWidth = 130)
    {
        ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto, MinWidth = labelWidth });
        ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
    }

    private int NextRow()
    {
        RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        return _row++;
    }

    /// <summary>Adds "label: control". The tip is shown for both.</summary>
    public FormRow AddRow(string label, UIElement control, string? tip = null)
    {
        int row = NextRow();
        var text = Ui.Label(label);
        text.Margin = new Thickness(0, 5, 14, 5);
        text.VerticalAlignment = VerticalAlignment.Center;
        Put(text, row, 0, 1);

        if (control is FrameworkElement fe)
        {
            fe.Margin = new Thickness(0, 3, 0, 3);
            fe.HorizontalAlignment = HorizontalAlignment.Left;
            fe.VerticalAlignment = VerticalAlignment.Center;
            if (tip != null && fe.ToolTip == null) fe.ToolTip = tip;
        }
        if (tip != null) text.ToolTip = tip;
        Put(control, row, 1, 1);
        return new FormRow(text, control) { Label = text };
    }

    /// <summary>Adds an element across both columns (a check box, a hint, a wide control).</summary>
    public FormRow AddFull(UIElement element, double top = 3, double bottom = 3)
    {
        int row = NextRow();
        if (element is FrameworkElement fe) fe.Margin = new Thickness(0, top, 0, bottom);
        Put(element, row, 0, 2);
        return new FormRow(element);
    }

    /// <summary>A small heading that separates groups of rows.</summary>
    public FormRow AddSection(string title)
    {
        int row = NextRow();
        var text = Ui.Label(title, dim: true, size: 11.5, bold: true);
        text.Margin = new Thickness(0, _row > 1 ? 14 : 0, 0, 4);
        Put(text, row, 0, 2);
        return new FormRow(text);
    }

    /// <summary>Explanatory text in a dim colour.</summary>
    public FormRow AddHint(string text, double maxWidth = 440)
    {
        int row = NextRow();
        var hint = Ui.Wrapped(text, dim: true, maxWidth: maxWidth);
        hint.FontSize = 11.5;
        hint.HorizontalAlignment = HorizontalAlignment.Left;
        hint.Margin = new Thickness(0, 2, 0, 4);
        Put(hint, row, 0, 2);
        return new FormRow(hint);
    }

    private void Put(UIElement element, int row, int column, int columnSpan)
    {
        SetRow(element, row);
        SetColumn(element, column);
        if (columnSpan > 1) SetColumnSpan(element, columnSpan);
        Children.Add(element);
    }
}
