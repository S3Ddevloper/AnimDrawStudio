using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using AnimDraw.App.Services;
using AnimDraw.Core.App;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Model;

namespace AnimDraw.App.Controls;

/// <summary>
/// The frame grid: one row per layer (top layer first), one column per frame. A dot marks a keyframe, a coloured bar the frames
/// during which that drawing is held, the red line is the playhead. Click a cell to pick a layer and a frame, drag across the
/// ruler or the cells to scrub, right-click for the frame and keyframe commands. Scrolling is done by the scroll bars that
/// the surrounding panel connects through <see cref="ScrollMetricsChanged"/>.
/// </summary>
public sealed class TimelineView : FrameworkElement
{
    public const double RowHeight = 26;
    public const double RulerHeight = 24;
    public const double LabelWidth = 168;
    public const double MinCellWidth = 8;
    public const double MaxCellWidth = 48;

    private enum Region
    {
        None,
        Corner,
        Ruler,
        LayerName,
        EyeIcon,
        LockIcon,
        Cell
    }

    private enum DragMode
    {
        None,
        ScrubRuler,
        ScrubCells
    }

    private readonly Editor _editor;
    private readonly Action<CommandId> _run;
    private readonly ShortcutMap _shortcuts;
    private readonly Typeface _typeface = new(new FontFamily("Segoe UI"), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
    private readonly Dictionary<Cel, bool> _blankCache = new();

    private Document _document;
    private long _blankCacheVersion = -1;
    private double _cellWidth = 18;
    private double _hOffset;
    private double _vOffset;
    private DragMode _drag = DragMode.None;
    private int? _playbackFrame;

    public TimelineView(Editor editor, ShortcutMap shortcuts, Action<CommandId> runCommand)
    {
        _editor = editor;
        _shortcuts = shortcuts;
        _run = runCommand;
        _document = editor.Document;
        Focusable = false;
        ClipToBounds = true;
        MinHeight = 80;

        editor.DocumentReplaced += () =>
        {
            Attach(_editor.Document);
            _hOffset = 0;
            _vOffset = 0;
            ClampOffsets();
            Refresh();
        };
        ThemeManager.ThemeChanged += InvalidateVisual;
        Attach(_document);
    }

    // ----- public surface -----

    /// <summary>Raised when the size of the scrollable area or the scroll position changed, so the scroll bars can follow.</summary>
    public event Action? ScrollMetricsChanged;

    /// <summary>The frame being shown while the animation plays (the document's frame stays where it was). Null when not playing.</summary>
    public int? PlaybackFrame
    {
        get => _playbackFrame;
        set
        {
            if (_playbackFrame == value) return;
            _playbackFrame = value;
            if (value is int frame) EnsureFrameVisible(frame);
            InvalidateVisual();
        }
    }

    public double CellWidth
    {
        get => _cellWidth;
        set
        {
            double v = Math.Clamp(value, MinCellWidth, MaxCellWidth);
            if (Math.Abs(v - _cellWidth) < 0.01) return;
            // Keep the middle of the view where it is while zooming.
            double middleFrame = (_hOffset + ViewportWidth / 2) / _cellWidth;
            _cellWidth = v;
            _hOffset = middleFrame * _cellWidth - ViewportWidth / 2;
            ClampOffsets();
            InvalidateVisual();
            ScrollMetricsChanged?.Invoke();
        }
    }

    public double HorizontalOffset
    {
        get => _hOffset;
        set
        {
            double v = Math.Clamp(value, 0, Math.Max(0, ExtentWidth - ViewportWidth));
            if (Math.Abs(v - _hOffset) < 0.01) return;
            _hOffset = v;
            InvalidateVisual();
        }
    }

    public double VerticalOffset
    {
        get => _vOffset;
        set
        {
            double v = Math.Clamp(value, 0, Math.Max(0, ExtentHeight - ViewportHeight));
            if (Math.Abs(v - _vOffset) < 0.01) return;
            _vOffset = v;
            InvalidateVisual();
        }
    }

    /// <summary>Width of all frames plus some empty room at the right end, in view units.</summary>
    public double ExtentWidth => (_document.FrameCount + 6) * _cellWidth;

    public double ExtentHeight => _document.Project.Layers.Count * RowHeight;

    public double ViewportWidth => Math.Max(0, ActualWidth - LabelWidth);

    public double ViewportHeight => Math.Max(0, ActualHeight - RulerHeight);

    /// <summary>Scrolls sideways just enough to show a frame.</summary>
    public void EnsureFrameVisible(int frame)
    {
        double left = frame * _cellWidth;
        double right = left + _cellWidth;
        if (left < _hOffset) HorizontalOffset = Math.Max(0, left - _cellWidth * 2);
        else if (right > _hOffset + ViewportWidth) HorizontalOffset = right - ViewportWidth + _cellWidth * 2;
        ScrollMetricsChanged?.Invoke();
    }

    // ----- following the document -----

    private void Attach(Document document)
    {
        _document.Changed -= OnDocumentChanged;
        _document = document;
        _document.Changed += OnDocumentChanged;
    }

    private void Refresh()
    {
        ClampOffsets();
        InvalidateVisual();
        ScrollMetricsChanged?.Invoke();
    }

    private void OnDocumentChanged(object? sender, DocumentChangedEventArgs e)
    {
        const ChangeKind relevant = ChangeKind.Structure | ChangeKind.Frame | ChangeKind.ActiveLayer | ChangeKind.Settings | ChangeKind.Pixels;
        if ((e.Kind & relevant) == 0) return;

        if ((e.Kind & ChangeKind.Pixels) != 0 && (e.Kind & ~ChangeKind.Pixels) == 0)
        {
            // Strokes change nothing visible here, except that a blank keyframe gets a drawing: that is noticed once the stroke
            // is committed (the content version moves on). Drawing on an empty frame creates a keyframe through a Structure event.
            if (_blankCacheVersion != _document.ContentVersion) InvalidateVisual();
            return;
        }
        if ((e.Kind & ChangeKind.Frame) != 0 && _playbackFrame == null) EnsureFrameVisible(_document.CurrentFrame);
        if ((e.Kind & ChangeKind.ActiveLayer) != 0) EnsureActiveRowVisible();
        Refresh();
    }

    private void EnsureActiveRowVisible()
    {
        int row = RowOf(_document.ActiveLayer);
        double top = row * RowHeight;
        double bottom = top + RowHeight;
        if (top < _vOffset) VerticalOffset = top;
        else if (bottom > _vOffset + ViewportHeight) VerticalOffset = bottom - ViewportHeight;
    }

    private void ClampOffsets()
    {
        _hOffset = Math.Clamp(_hOffset, 0, Math.Max(0, ExtentWidth - ViewportWidth));
        _vOffset = Math.Clamp(_vOffset, 0, Math.Max(0, ExtentHeight - ViewportHeight));
    }

    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
    {
        base.OnRenderSizeChanged(sizeInfo);
        ClampOffsets();
        ScrollMetricsChanged?.Invoke();
    }

    protected override Size MeasureOverride(Size availableSize)
    {
        double w = double.IsInfinity(availableSize.Width) ? 400 : availableSize.Width;
        double h = double.IsInfinity(availableSize.Height) ? 160 : availableSize.Height;
        return new Size(w, h);
    }

    // ----- geometry -----

    private int DisplayFrame => _playbackFrame ?? _document.CurrentFrame;

    private int RowOf(Layer layer) => _document.Project.Layers.Count - 1 - _document.Project.IndexOfLayer(layer);

    private Layer LayerOfRow(int row) => _document.Project.Layers[_document.Project.Layers.Count - 1 - row];

    private double FrameX(int frame) => LabelWidth + frame * _cellWidth - _hOffset;

    private double RowY(int row) => RulerHeight + row * RowHeight - _vOffset;

    private bool IsBlank(Cel cel)
    {
        if (_blankCacheVersion != _document.ContentVersion)
        {
            _blankCache.Clear();
            _blankCacheVersion = _document.ContentVersion;
        }
        if (!_blankCache.TryGetValue(cel, out bool blank))
        {
            blank = cel.Surface.IsBlank();
            _blankCache[cel] = blank;
        }
        return blank;
    }

    // ----- drawing -----

    private static Brush WithAlpha(Brush brush, byte alpha)
    {
        if (brush is SolidColorBrush solid)
        {
            var c = solid.Color;
            return new SolidColorBrush(Color.FromArgb(alpha, c.R, c.G, c.B));
        }
        return brush;
    }

    private FormattedText Text(string text, Brush brush, double size = 11.5, double maxWidth = 0, bool bold = false)
    {
        var typeface = bold ? new Typeface(_typeface.FontFamily, FontStyles.Normal, FontWeights.SemiBold, FontStretches.Normal) : _typeface;
        var formatted = new FormattedText(text, CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, typeface, size, brush,
            VisualTreeHelper.GetDpi(this).PixelsPerDip);
        if (maxWidth > 0)
        {
            formatted.MaxTextWidth = maxWidth;
            formatted.MaxLineCount = 1;
            formatted.Trimming = TextTrimming.CharacterEllipsis;
        }
        return formatted;
    }

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        var project = _document.Project;
        int frameCount = project.FrameCount;
        int layerCount = project.Layers.Count;
        int current = DisplayFrame;

        Brush cell = ThemeManager.Brush(ThemeKeys.TlCell);
        Brush cellAlt = ThemeManager.Brush(ThemeKeys.TlCellAlt);
        Brush grid = ThemeManager.Brush(ThemeKeys.TlGrid);
        Brush hold = ThemeManager.Brush(ThemeKeys.TlHold);
        Brush rowActive = ThemeManager.Brush(ThemeKeys.TlRowActive);
        Brush keyBrush = ThemeManager.Brush(ThemeKeys.TlKey);
        Brush playhead = ThemeManager.Brush(ThemeKeys.TlPlayhead);
        Brush currentCell = ThemeManager.Brush(ThemeKeys.TlCurrentCell);
        Brush ruler = ThemeManager.Brush(ThemeKeys.TlRuler);
        Brush window = ThemeManager.Brush(ThemeKeys.Window);
        Brush panel = ThemeManager.Brush(ThemeKeys.Panel);
        Brush text = ThemeManager.Brush(ThemeKeys.Text);
        Brush dim = ThemeManager.Brush(ThemeKeys.TextDim);
        Brush disabled = ThemeManager.Brush(ThemeKeys.TextDisabled);
        Brush border = ThemeManager.Brush(ThemeKeys.Border);
        var gridPen = new Pen(grid, 1);

        double width = ActualWidth, height = ActualHeight;
        var cellsArea = new Rect(LabelWidth, RulerHeight, Math.Max(0, width - LabelWidth), Math.Max(0, height - RulerHeight));

        int firstFrame = Math.Max(0, (int)Math.Floor(_hOffset / _cellWidth));
        int lastFrame = (int)Math.Ceiling((_hOffset + ViewportWidth) / _cellWidth);
        int firstRow = Math.Max(0, (int)Math.Floor(_vOffset / RowHeight));
        int lastRow = Math.Min(layerCount - 1, (int)Math.Ceiling((_vOffset + ViewportHeight) / RowHeight));
        Layer active = _document.ActiveLayer;

        // ---- cells ----
        dc.PushClip(new RectangleGeometry(cellsArea));
        dc.DrawRectangle(window, null, cellsArea);

        double timelineEnd = FrameX(frameCount);
        for (int row = firstRow; row <= lastRow; row++)
        {
            Layer layer = LayerOfRow(row);
            double y = RowY(row);

            // banded background: blocks of five frames alternate, so counting frames is easy
            for (int f = firstFrame - firstFrame % 5; f <= lastFrame && f < frameCount; f += 5)
            {
                double x0 = FrameX(f);
                double x1 = FrameX(Math.Min(frameCount, f + 5));
                dc.DrawRectangle((f / 5) % 2 == 0 ? cell : cellAlt, null, new Rect(x0, y, x1 - x0, RowHeight));
            }
            if (ReferenceEquals(layer, active))
            {
                dc.PushOpacity(0.55);
                dc.DrawRectangle(rowActive, null, new Rect(LabelWidth, y, Math.Max(0, Math.Min(timelineEnd, width) - LabelWidth), RowHeight));
                dc.Pop();
            }

            // held drawings and keyframes
            var track = layer.Track;
            for (int k = 0; k < track.Count; k++)
            {
                int keyFrame = track.FrameAt(k);
                if (keyFrame >= frameCount) break;
                int end = Math.Min(frameCount - 1, track.HoldEnd(keyFrame, frameCount));
                if (end < firstFrame || keyFrame > lastFrame) continue;

                double x0 = FrameX(keyFrame) + 1;
                double x1 = FrameX(end + 1) - 1;
                var bar = new Rect(x0, y + 3, Math.Max(2, x1 - x0), RowHeight - 6);
                dc.DrawRoundedRectangle(layer.Visible ? hold : WithAlpha(hold, 110), null, bar, 3, 3);

                // the dot: solid when the keyframe has a drawing, hollow when it is blank
                double cx = FrameX(keyFrame) + _cellWidth / 2;
                double cy = y + RowHeight / 2;
                double radius = Math.Clamp(_cellWidth * 0.2, 2.5, 5);
                if (IsBlank(track.CelAt(k))) dc.DrawEllipse(null, new Pen(keyBrush, 1.4), new Point(cx, cy), radius, radius);
                else dc.DrawEllipse(keyBrush, null, new Point(cx, cy), radius, radius);

                // the end of a held drawing
                if (end > keyFrame && _cellWidth >= 10)
                {
                    double ex = FrameX(end) + _cellWidth / 2;
                    dc.DrawRectangle(null, new Pen(keyBrush, 1), new Rect(ex - 2.5, cy - 4, 5, 8));
                }
            }
            dc.DrawLine(gridPen, new Point(LabelWidth, y + RowHeight), new Point(width, y + RowHeight));
        }

        // vertical frame lines
        if (_cellWidth >= 7)
        {
            double top = RulerHeight, bottom = Math.Min(height, RowY(lastRow) + RowHeight);
            for (int f = firstFrame; f <= lastFrame; f++)
            {
                double x = FrameX(f);
                dc.DrawLine(gridPen, new Point(x, top), new Point(x, bottom));
            }
        }

        // the current frame: a tinted column, an outlined cell on the active layer and the playhead line
        if (current >= 0 && current < frameCount)
        {
            double x = FrameX(current);
            dc.DrawRectangle(WithAlpha(currentCell, 36), null, new Rect(x, RulerHeight, _cellWidth, Math.Max(0, height - RulerHeight)));
            if (_playbackFrame == null)
            {
                int activeRow = RowOf(active);
                dc.DrawRectangle(null, new Pen(currentCell, 2), new Rect(x + 1, RowY(activeRow) + 1, _cellWidth - 2, RowHeight - 2));
            }
            dc.DrawLine(new Pen(playhead, 1.5), new Point(x + _cellWidth / 2, RulerHeight), new Point(x + _cellWidth / 2, height));
        }
        dc.Pop();

        // ---- ruler ----
        dc.PushClip(new RectangleGeometry(new Rect(LabelWidth, 0, Math.Max(0, width - LabelWidth), RulerHeight)));
        dc.DrawRectangle(ruler, null, new Rect(LabelWidth, 0, Math.Max(0, width - LabelWidth), RulerHeight));
        int step = _cellWidth >= 30 ? 1 : _cellWidth >= 14 ? 5 : 10;
        for (int f = firstFrame; f <= lastFrame && f < frameCount; f++)
        {
            double x = FrameX(f);
            bool numbered = (f + 1) % step == 0 || f == 0;
            dc.DrawLine(gridPen, new Point(x, numbered ? RulerHeight - 8 : RulerHeight - 4), new Point(x, RulerHeight));
            if (numbered && f != current)
            {
                var label = Text((f + 1).ToString(CultureInfo.InvariantCulture), dim, 10.5);
                dc.DrawText(label, new Point(x + 3, 3));
            }
        }
        if (current >= 0 && current < frameCount)
        {
            double x = FrameX(current);
            double w = Math.Max(_cellWidth, 22);
            var flag = new Rect(x + _cellWidth / 2 - w / 2, 2, w, RulerHeight - 6);
            dc.DrawRoundedRectangle(playhead, null, flag, 3, 3);
            var label = Text((current + 1).ToString(CultureInfo.InvariantCulture), Brushes.White, 10.5, bold: true);
            dc.DrawText(label, new Point(flag.X + (flag.Width - label.Width) / 2, flag.Y + (flag.Height - label.Height) / 2));
        }
        dc.Pop();

        // ---- layer names (drawn last so that scrolling cells slide under them) ----
        dc.PushClip(new RectangleGeometry(new Rect(0, 0, LabelWidth, height)));
        dc.DrawRectangle(panel, null, new Rect(0, RulerHeight, LabelWidth, Math.Max(0, height - RulerHeight)));
        dc.DrawRectangle(ruler, null, new Rect(0, 0, LabelWidth, RulerHeight));
        dc.DrawText(Text("Layers", dim, 11, bold: true), new Point(10, 4));
        for (int row = firstRow; row <= lastRow; row++)
        {
            Layer layer = LayerOfRow(row);
            double y = RowY(row);
            var rowRect = new Rect(0, y, LabelWidth, RowHeight);
            dc.DrawRectangle(ReferenceEquals(layer, active) ? rowActive : panel, null, rowRect);
            dc.DrawLine(gridPen, new Point(0, y + RowHeight), new Point(LabelWidth, y + RowHeight));

            Brush nameBrush = layer.Visible ? text : disabled;
            var label = Text(layer.Name, nameBrush, 12, LabelWidth - 66);
            dc.DrawText(label, new Point(8, y + (RowHeight - label.Height) / 2));
            IconPainter.Draw(dc, layer.Visible ? "eye" : "eye-off", layer.Visible ? dim : disabled, LabelWidth - 56, y + 5, 16);
            IconPainter.Draw(dc, layer.Locked ? "lock" : "unlock", layer.Locked ? ThemeManager.Brush(ThemeKeys.Warning) : disabled, LabelWidth - 30, y + 5, 16);
        }
        dc.Pop();

        // separators between the label column, ruler and cells
        var borderPen = new Pen(border, 1);
        dc.DrawLine(borderPen, new Point(LabelWidth, 0), new Point(LabelWidth, height));
        dc.DrawLine(borderPen, new Point(0, RulerHeight), new Point(width, RulerHeight));
    }

    // ----- hit testing -----

    private (Region Region, int Row, int Frame) HitTest(Point p)
    {
        if (p.X < 0 || p.Y < 0 || p.X > ActualWidth || p.Y > ActualHeight) return (Region.None, -1, -1);
        int frame = (int)Math.Floor((p.X - LabelWidth + _hOffset) / _cellWidth);
        int layerCount = _document.Project.Layers.Count;
        int row = (int)Math.Floor((p.Y - RulerHeight + _vOffset) / RowHeight);
        bool rowValid = row >= 0 && row < layerCount;

        if (p.X < LabelWidth)
        {
            if (p.Y < RulerHeight) return (Region.Corner, -1, -1);
            if (!rowValid) return (Region.None, -1, -1);
            if (p.X >= LabelWidth - 58 && p.X < LabelWidth - 32) return (Region.EyeIcon, row, -1);
            if (p.X >= LabelWidth - 32) return (Region.LockIcon, row, -1);
            return (Region.LayerName, row, -1);
        }
        if (p.Y < RulerHeight) return (Region.Ruler, -1, frame);
        return rowValid ? (Region.Cell, row, frame) : (Region.None, -1, frame);
    }

    private int FrameAtX(double x) =>
        Math.Clamp((int)Math.Floor((x - LabelWidth + _hOffset) / _cellWidth), 0, _document.FrameCount - 1);

    // ----- mouse -----

    protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonDown(e);
        if (_editor.IsPlaying) _editor.PausePlayback();
        var (region, row, frame) = HitTest(e.GetPosition(this));
        switch (region)
        {
            case Region.Ruler:
                _drag = DragMode.ScrubRuler;
                CaptureMouse();
                _document.GoToFrame(FrameAtX(e.GetPosition(this).X));
                break;
            case Region.Cell when frame >= 0 && frame < _document.FrameCount:
                _document.SetActiveLayer(LayerOfRow(row));
                _document.GoToFrame(frame);
                if (e.ClickCount == 2 && !_document.ActiveLayer.Track.IsKeyframe(frame)) _run(CommandId.InsertKeyframe);
                _drag = DragMode.ScrubCells;
                CaptureMouse();
                break;
            case Region.Cell:
                _document.SetActiveLayer(LayerOfRow(row));
                break;
            case Region.LayerName:
                _document.SetActiveLayer(LayerOfRow(row));
                if (e.ClickCount == 2) _run(CommandId.RenameLayer);
                break;
            case Region.EyeIcon:
            {
                Layer layer = LayerOfRow(row);
                _document.SetLayerVisible(layer, !layer.Visible);
                break;
            }
            case Region.LockIcon:
            {
                Layer layer = LayerOfRow(row);
                _document.SetLayerLocked(layer, !layer.Locked);
                break;
            }
        }
        e.Handled = true;
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (_drag == DragMode.None || e.LeftButton != MouseButtonState.Pressed) return;
        Point p = e.GetPosition(this);
        // scrub, and scroll when the pointer pushes against the edge
        if (p.X > ActualWidth - 8) HorizontalOffset += _cellWidth;
        else if (p.X < LabelWidth + 8) HorizontalOffset -= _cellWidth;
        _document.GoToFrame(FrameAtX(p.X));
        ScrollMetricsChanged?.Invoke();
    }

    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonUp(e);
        if (_drag != DragMode.None)
        {
            _drag = DragMode.None;
            ReleaseMouseCapture();
        }
    }

    protected override void OnLostMouseCapture(MouseEventArgs e)
    {
        base.OnLostMouseCapture(e);
        // Capture can be taken away (a dialog opened, another window was activated): the scrub is over.
        _drag = DragMode.None;
    }

    protected override void OnMouseRightButtonDown(MouseButtonEventArgs e)
    {
        base.OnMouseRightButtonDown(e);
        var (region, row, frame) = HitTest(e.GetPosition(this));
        if (region == Region.Cell && frame >= 0 && frame < _document.FrameCount)
        {
            _document.SetActiveLayer(LayerOfRow(row));
            _document.GoToFrame(frame);
            e.Handled = true;
        }
        else if (region is Region.LayerName or Region.EyeIcon or Region.LockIcon)
        {
            _document.SetActiveLayer(LayerOfRow(row));
        }
    }

    protected override void OnMouseRightButtonUp(MouseButtonEventArgs e)
    {
        base.OnMouseRightButtonUp(e);
        var (region, _, frame) = HitTest(e.GetPosition(this));
        if (region == Region.Cell && frame >= 0 && frame < _document.FrameCount)
        {
            ShowCellMenu();
            e.Handled = true;
        }
    }

    protected override void OnMouseWheel(MouseWheelEventArgs e)
    {
        base.OnMouseWheel(e);
        ModifierKeys modifiers = Keyboard.Modifiers;
        if ((modifiers & ModifierKeys.Control) != 0)
        {
            CellWidth *= e.Delta > 0 ? 1.12 : 1 / 1.12;
        }
        else if ((modifiers & ModifierKeys.Shift) != 0)
        {
            HorizontalOffset -= e.Delta / 120.0 * _cellWidth * 3;
        }
        else
        {
            VerticalOffset -= e.Delta / 120.0 * RowHeight * 2;
        }
        ScrollMetricsChanged?.Invoke();
        e.Handled = true;
    }

    private void ShowCellMenu()
    {
        var menu = new ContextMenu();
        void Item(string header, CommandId command)
        {
            var item = new MenuItem { Header = header, InputGestureText = _shortcuts.DisplayTextOf(command) };
            item.Click += (_, _) => _run(command);
            menu.Items.Add(item);
        }
        Item("Add frame after", CommandId.InsertFrame);
        Item("Duplicate frame", CommandId.DuplicateFrame);
        Item("Delete frame", CommandId.DeleteFrame);
        menu.Items.Add(new Separator());
        Item("Make keyframe (copy of the held drawing)", CommandId.InsertKeyframe);
        Item("Make blank keyframe", CommandId.InsertBlankKeyframe);
        Item("Remove keyframe", CommandId.RemoveKeyframe);
        menu.PlacementTarget = this;
        menu.IsOpen = true;
    }
}
