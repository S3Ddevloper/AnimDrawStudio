using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using AnimDraw.App.Services;
using AnimDraw.Core.Export;

namespace AnimDraw.App.Controls;

/// <summary>
/// Lets the person say where ffmpeg is (MP4 export needs it) and shows whether it was found and works. The check runs in
/// the background, so typing a path never freezes the window.
/// </summary>
public sealed class FfmpegSelector : StackPanel
{
    private readonly TextBox _path = new() { Width = 330, VerticalContentAlignment = VerticalAlignment.Center };
    private readonly TextBlock _status = Ui.Wrapped("", dim: true, maxWidth: 430);
    private readonly Window? _owner;
    private int _version;

    public FfmpegSelector(Window? owner, string? initialPath)
    {
        _owner = owner;
        Orientation = Orientation.Vertical;
        _path.Text = initialPath ?? "";
        _path.ToolTip = "Leave empty to look next to AnimDraw Studio and in the PATH. You can paste the path of ffmpeg.exe, or of the folder that contains it.";

        var row = new StackPanel { Orientation = Orientation.Horizontal };
        row.Children.Add(_path);
        var browse = new Button { Content = "Browse...", Margin = new Thickness(8, 0, 0, 0), MinWidth = 78 };
        browse.Click += (_, _) => Browse();
        row.Children.Add(browse);
        Children.Add(row);

        _status.FontSize = 11.5;
        _status.Margin = new Thickness(0, 6, 0, 0);
        Children.Add(_status);

        var link = Ui.Label("Get FFmpeg (opens the download page)");
        link.SetResourceReference(TextBlock.ForegroundProperty, ThemeKeys.Accent);
        link.TextDecorations = TextDecorations.Underline;
        link.Cursor = Cursors.Hand;
        link.FontSize = 11.5;
        link.Margin = new Thickness(0, 4, 0, 0);
        link.HorizontalAlignment = HorizontalAlignment.Left;
        link.MouseLeftButtonUp += (_, _) => Native.OpenUrl(FfmpegLocator.DownloadPage);
        Children.Add(link);

        _path.LostKeyboardFocus += (_, _) => _ = RefreshAsync();
        _path.KeyDown += (_, e) =>
        {
            if (e.Key != Key.Enter) return;
            _ = RefreshAsync();
            e.Handled = true;
        };
        Loaded += (_, _) => _ = RefreshAsync();
    }

    /// <summary>The text of the path box, or null when it is empty.</summary>
    public string? Path => string.IsNullOrWhiteSpace(_path.Text) ? null : _path.Text.Trim().Trim('"');

    /// <summary>What the last check found, or null when ffmpeg was not found (or the check is still running).</summary>
    public FfmpegInfo? Info { get; private set; }

    /// <summary>Raised when a check has finished.</summary>
    public event Action? StatusChanged;

    private void Browse()
    {
        string? start = null;
        try
        {
            if (Path != null) start = System.IO.Path.GetDirectoryName(Path);
        }
        catch (ArgumentException)
        {
            // A path with odd characters: just open at the default place.
        }
        string? chosen = FileDialogs.OpenFile(_owner, "Find ffmpeg", "ffmpeg (ffmpeg.exe)|ffmpeg.exe|Programs (*.exe)|*.exe", start);
        if (chosen == null) return;
        _path.Text = chosen;
        _ = RefreshAsync();
    }

    /// <summary>Looks for ffmpeg again with the current path.</summary>
    public async Task RefreshAsync()
    {
        int version = ++_version;
        string? userPath = Path;
        Info = null;
        _status.Text = "Looking for FFmpeg...";
        _status.SetResourceReference(TextBlock.ForegroundProperty, ThemeKeys.TextDim);

        FfmpegInfo? found = null;
        try
        {
            found = await Task.Run(() => FfmpegLocator.Find(userPath));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or System.ComponentModel.Win32Exception or InvalidOperationException)
        {
            found = null;
        }
        if (version != _version) return; // a newer check replaced this one

        Info = found;
        if (found == null)
        {
            _status.Text = userPath == null
                ? "FFmpeg was not found. MP4 export needs it; GIF, PNG and sprite sheet export work without it."
                : "FFmpeg was not found at that path. MP4 export needs it; GIF, PNG and sprite sheet export work without it.";
            _status.SetResourceReference(TextBlock.ForegroundProperty, ThemeKeys.Warning);
        }
        else if (!found.CanWriteMp4)
        {
            _status.Text = "Found, but this FFmpeg has no H.264 or MPEG-4 encoder, so it cannot write MP4 files: " + found.Path;
            _status.SetResourceReference(TextBlock.ForegroundProperty, ThemeKeys.Warning);
        }
        else
        {
            _status.Text = "Ready: " + found.Path;
            _status.SetResourceReference(TextBlock.ForegroundProperty, ThemeKeys.Success);
        }
        StatusChanged?.Invoke();
    }
}
