using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using AnimDraw.App.Services;

namespace AnimDraw.App.Controls;

/// <summary>
/// A veil over the whole window with a small card in the middle ("Saving...", a progress bar and an optional Cancel
/// button). It keeps clicks away from the program underneath while a file is being opened or saved.
/// </summary>
public sealed class BusyOverlay : Grid
{
    private readonly TextBlock _message;
    private readonly TextBlock _detail;
    private readonly ProgressBar _bar;
    private readonly Button _cancel;
    private Action? _onCancel;

    public BusyOverlay()
    {
        Visibility = Visibility.Collapsed;
        Background = new SolidColorBrush(Color.FromArgb(120, 0, 0, 0));
        Panel.SetZIndex(this, 100);

        var card = Ui.Box(ThemeKeys.Panel, ThemeKeys.BorderStrong);
        card.CornerRadius = new CornerRadius(8);
        card.Padding = new Thickness(26, 20, 26, 18);
        card.MinWidth = 320;
        card.MaxWidth = 520;
        card.HorizontalAlignment = HorizontalAlignment.Center;
        card.VerticalAlignment = VerticalAlignment.Center;
        card.Effect = new System.Windows.Media.Effects.DropShadowEffect { BlurRadius = 18, ShadowDepth = 4, Opacity = 0.45, Color = Colors.Black };

        var stack = new StackPanel();
        _message = Ui.Label("", size: 14, bold: true);
        _message.TextWrapping = TextWrapping.Wrap;
        stack.Children.Add(_message);

        _detail = Ui.Label("", dim: true);
        _detail.TextWrapping = TextWrapping.Wrap;
        _detail.Margin = new Thickness(0, 4, 0, 0);
        _detail.Visibility = Visibility.Collapsed;
        stack.Children.Add(_detail);

        _bar = new ProgressBar { Minimum = 0, Maximum = 100, Height = 8, Margin = new Thickness(0, 14, 0, 0) };
        stack.Children.Add(_bar);

        _cancel = new Button { Content = "Cancel", MinWidth = 84, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 14, 0, 0) };
        _cancel.Click += (_, _) =>
        {
            _cancel.IsEnabled = false;
            _onCancel?.Invoke();
        };
        stack.Children.Add(_cancel);

        card.Child = stack;
        Children.Add(card);
    }

    public bool IsShown => Visibility == Visibility.Visible;

    /// <summary>Shows the veil. <paramref name="cancel"/> is called when the person presses Cancel; pass null for work that cannot be stopped.</summary>
    public void Show(string message, string? detail, Action? cancel)
    {
        _message.Text = message;
        _detail.Text = detail ?? "";
        _detail.Visibility = string.IsNullOrEmpty(detail) ? Visibility.Collapsed : Visibility.Visible;
        _onCancel = cancel;
        _cancel.Visibility = cancel == null ? Visibility.Collapsed : Visibility.Visible;
        _cancel.IsEnabled = true;
        _bar.Value = 0;
        Visibility = Visibility.Visible;
    }

    public void SetProgress(double fraction) => _bar.Value = Math.Clamp(fraction, 0, 1) * 100;

    public void Hide()
    {
        Visibility = Visibility.Collapsed;
        _onCancel = null;
    }
}
