using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using AnimDraw.App.Services;
using AnimDraw.Core.App;
using AnimDraw.Core.Drawing;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;
using AnimDraw.Core.Rendering;
using AnimDraw.Core.Tools;

namespace AnimDraw.App.Controls;

/// <summary>
/// The drawing area. It shows the flattened current frame (plus onion skins, selection, grid and the brush outline) with
/// zoom and pan, and turns mouse, pen and touch input into pointer events for the active tool. All drawing logic lives in
/// the engine; this class only displays it and forwards input.
/// </summary>
public sealed class CanvasView : FrameworkElement
{
    private enum Drag
    {
        None,
        Tool,
        Pan,
        ZoomRect
    }

    private readonly Viewport _viewport = new();
    private readonly OnionSkinRenderer _onionRenderer = new();
    private readonly DispatcherTimer _antsTimer;

    private Editor? _editor;
    private Document? _document;

    private PixelBuffer? _buffer;
    private WriteableBitmap? _bitmap;
    private PixelBuffer? _onionBuffer;
    private WriteableBitmap? _onionBitmap;
    private bool _hasOnion;

    private IntRect _pendingDirty = IntRect.Empty;
    private bool _pendingFull;
    private bool _flushQueued;
    private bool _showingPlayback;
    private bool _needsFit = true;

    private Drag _drag = Drag.None;
    private MouseButton _toolButton;
    private Point _panAnchor;
    private double _panStartX, _panStartY;
    private Point _zoomRectStart, _zoomRectNow;
    private bool _zoomOutRect;
    private Point _lastViewPoint;
    private float _lastPressure = 1f;
    private bool _pointerInside;
    private Point _pointerView;
    private double _antsOffset;
    private bool _showGrid;
    private bool _spaceHeld;

    // Colours of the on-canvas helpers; rebuilt when the theme changes.
    private Brush _workspaceBrush = Brushes.DimGray;
    private static readonly Brush ShadowBrush = FrozenBrush(Color.FromArgb(34, 0, 0, 0));
    private static readonly Pen GridPen = FrozenPen(Color.FromArgb(70, 128, 128, 128), 1.0);
    private static readonly Pen CanvasEdgePen = FrozenPen(Color.FromArgb(120, 0, 0, 0), 1.0);
    private static readonly Pen CursorOuterPen = FrozenPen(Color.FromArgb(200, 0, 0, 0), 1.0);
    private static readonly Pen CursorInnerPen = FrozenPen(Color.FromArgb(220, 255, 255, 255), 1.0);

    public CanvasView()
    {
        Focusable = true;
        FocusVisualStyle = null;
        ClipToBounds = true;
        SnapsToDevicePixels = false;
        Cursor = Cursors.Cross;

        // A pen should draw immediately: no press-and-hold right-click, no flicks, no touch feedback halo.
        Stylus.SetIsPressAndHoldEnabled(this, false);
        Stylus.SetIsFlicksEnabled(this, false);
        Stylus.SetIsTapFeedbackEnabled(this, false);
        Stylus.SetIsTouchFeedbackEnabled(this, false);

        _antsTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(160) };
        _antsTimer.Tick += (_, _) =>
        {
            if (_document?.Selection != null && IsVisible && !_showingPlayback)
            {
                _antsOffset = (_antsOffset + 1) % 8;
                InvalidateVisual();
            }
        };

        Loaded += (_, _) =>
        {
            _viewport.DpiScale = VisualTreeHelper.GetDpi(this).DpiScaleX;
            _antsTimer.Start();
        };
        Unloaded += (_, _) => _antsTimer.Stop();
        ThemeManager.ThemeChanged += OnThemeChanged;
        OnThemeChanged();
    }

    // ----- public surface -----

    /// <summary>Raised when zoom, pan or the canvas size changed.</summary>
    public event Action? ViewChanged;

    /// <summary>Raised with the pointer position in canvas pixels, or null when the pointer left the canvas view.</summary>
    public event Action<Point?>? PointerCanvasMoved;

    /// <summary>Raised when drawing playback had to be stopped because the user started to draw.</summary>
    public event Action? PlaybackInterrupted;

    public double Zoom => _viewport.Zoom;

    public string ZoomText => _viewport.ZoomText;

    public bool ShowPixelGrid
    {
        get => _showGrid;
        set
        {
            if (_showGrid == value) return;
            _showGrid = value;
            InvalidateVisual();
        }
    }

    /// <summary>True while the space bar is held: the pointer pans instead of drawing.</summary>
    public bool SpaceHeld
    {
        get => _spaceHeld;
        set
        {
            if (_spaceHeld == value) return;
            _spaceHeld = value;
            UpdateCursor();
            InvalidateVisual();
        }
    }

    /// <summary>Connects the view to the editor. Call once; the view follows the editor when another project is opened.</summary>
    public void Attach(Editor editor)
    {
        _editor = editor;
        editor.DocumentReplaced += OnDocumentReplaced;
        editor.Tools.ToolChanged += _ => { UpdateCursor(); InvalidateVisual(); };
        editor.ToolSettings.Changed += () => InvalidateVisual();
        BindDocument(editor.Document);
    }

    /// <summary>The middle of the visible part of the canvas, in canvas pixels (for pasting in the middle of the view).</summary>
    public Point VisibleCenter()
    {
        var visible = _viewport.VisibleCanvasRect();
        if (visible.IsEmpty) return new Point(_viewport.CanvasWidth / 2.0, _viewport.CanvasHeight / 2.0);
        return new Point(visible.X + visible.Width / 2.0, visible.Y + visible.Height / 2.0);
    }

    public void ZoomIn() => StepZoom(+1);

    public void ZoomOut() => StepZoom(-1);

    public void ZoomFit()
    {
        _viewport.FitToView();
        AfterViewChange();
    }

    /// <summary>Shows the canvas at an exact zoom (1 = 100%), centred.</summary>
    public void ZoomExact(double zoom)
    {
        _viewport.SetZoomCentered(zoom);
        AfterViewChange();
    }

    /// <summary>Zooms around the middle of the view.</summary>
    public void ZoomCenter(double zoom)
    {
        _viewport.ZoomToCenter(zoom);
        AfterViewChange();
    }

    /// <summary>Shows a frame from the playback cache instead of the project (null returns to normal display).</summary>
    public void ShowPlaybackFrame(PixelBuffer? frame)
    {
        if (frame == null)
        {
            if (!_showingPlayback) return;
            _showingPlayback = false;
            _pendingFull = true;
            ScheduleFlush();
            return;
        }
        _showingPlayback = true;
        _hasOnion = false;
        EnsureBuffers();
        if (_bitmap == null || frame.Width != _bitmap.PixelWidth || frame.Height != _bitmap.PixelHeight) return;
        BitmapBridge.CopyAll(frame, _bitmap);
        InvalidateVisual();
    }

    /// <summary>Redraws everything from the project (after settings such as onion skin or the background changed).</summary>
    public void RefreshAll()
    {
        _pendingFull = true;
        ScheduleFlush();
    }

    // ----- document binding -----

    private void OnDocumentReplaced()
    {
        if (_editor == null) return;
        BindDocument(_editor.Document);
    }

    private void BindDocument(Document document)
    {
        if (_document != null) _document.Changed -= OnDocumentChanged;
        _document = document;
        _document.Changed += OnDocumentChanged;

        _showingPlayback = false;
        _viewport.SetCanvasSize(document.CanvasWidth, document.CanvasHeight);
        _viewport.DpiScale = VisualTreeHelper.GetDpi(this).DpiScaleX;
        _needsFit = true;
        _buffer = null;
        _bitmap = null;
        _onionBuffer = null;
        _onionBitmap = null;
        _hasOnion = false;
        _pendingFull = true;
        _pendingDirty = IntRect.Empty;
        if (ActualWidth > 0 && ActualHeight > 0)
        {
            _viewport.SetViewSize(ActualWidth, ActualHeight);
            _viewport.FitToView();
            _needsFit = false;
            AfterViewChange();
        }
        ScheduleFlush();
    }

    private void OnDocumentChanged(object? sender, DocumentChangedEventArgs e)
    {
        if (_document == null || e.Kind == ChangeKind.None) return;

        if ((e.Kind & ChangeKind.Structure) != 0 &&
            (_document.CanvasWidth != _viewport.CanvasWidth || _document.CanvasHeight != _viewport.CanvasHeight))
        {
            _viewport.SetCanvasSize(_document.CanvasWidth, _document.CanvasHeight);
            _buffer = null;
            _bitmap = null;
            _onionBuffer = null;
            _onionBitmap = null;
            _viewport.FitToView();
            AfterViewChange();
        }

        if (e.NeedsFullRedraw) _pendingFull = true;
        else if ((e.Kind & ChangeKind.Pixels) != 0 && !e.Dirty.IsEmpty)
            _pendingDirty = _pendingDirty.IsEmpty ? e.Dirty : _pendingDirty.Union(e.Dirty);

        if (_pendingFull || !_pendingDirty.IsEmpty) ScheduleFlush();
        else InvalidateVisual(); // selection or history changes only repaint the overlay
    }

    private void ScheduleFlush()
    {
        if (_flushQueued) return;
        _flushQueued = true;
        // Input-priority callbacks wait their turn behind pointer events that are already queued, so a fast stroke
        // updates the picture once per burst of events instead of once per event.
        Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(Flush));
    }

    private void EnsureBuffers()
    {
        if (_document == null) return;
        int w = _document.CanvasWidth, h = _document.CanvasHeight;
        if (_buffer == null || _buffer.Width != w || _buffer.Height != h || _bitmap == null)
        {
            _buffer = new PixelBuffer(w, h);
            _bitmap = BitmapBridge.CreateBitmap(w, h);
            _pendingFull = true;
        }
    }

    private void Flush()
    {
        _flushQueued = false;
        if (_document == null) return;
        EnsureBuffers();
        if (_buffer == null || _bitmap == null) return;

        bool full = _pendingFull;
        IntRect region = full ? _buffer.Bounds : _pendingDirty;
        _pendingFull = false;
        _pendingDirty = IntRect.Empty;

        if (_showingPlayback) return;

        if (!region.IsEmpty)
        {
            Compositor.Compose(_document.Project, _document.CurrentFrame, _buffer, region, withBackground: false);
            BitmapBridge.CopyRegion(_buffer, _bitmap, region);
        }
        if (full) UpdateOnionSkin();
        InvalidateVisual();
    }

    private void UpdateOnionSkin()
    {
        _hasOnion = false;
        if (_document == null || _showingPlayback) return;
        var project = _document.Project;
        if (!project.Onion.Enabled) return;
        if (_onionBuffer == null || _onionBuffer.Width != project.Width || _onionBuffer.Height != project.Height || _onionBitmap == null)
        {
            _onionBuffer = new PixelBuffer(project.Width, project.Height);
            _onionBitmap = BitmapBridge.CreateBitmap(project.Width, project.Height);
        }
        _hasOnion = _onionRenderer.Render(project, _document.CurrentFrame, _onionBuffer, _onionBuffer.Bounds);
        if (_hasOnion) BitmapBridge.CopyAll(_onionBuffer, _onionBitmap);
    }

    // ----- theme -----

    private void OnThemeChanged()
    {
        _workspaceBrush = ThemeManager.Brush(ThemeKeys.Workspace);
        InvalidateVisual();
    }

    // ----- layout and view changes -----

    protected override Size MeasureOverride(Size availableSize)
    {
        double w = double.IsInfinity(availableSize.Width) ? 0 : availableSize.Width;
        double h = double.IsInfinity(availableSize.Height) ? 0 : availableSize.Height;
        return new Size(w, h);
    }

    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
    {
        base.OnRenderSizeChanged(sizeInfo);
        _viewport.SetViewSize(ActualWidth, ActualHeight);
        if (_needsFit && ActualWidth > 8 && ActualHeight > 8)
        {
            _viewport.FitToView();
            _needsFit = false;
        }
        AfterViewChange();
    }

    protected override void OnDpiChanged(DpiScale oldDpi, DpiScale newDpi)
    {
        base.OnDpiChanged(oldDpi, newDpi);
        _viewport.DpiScale = newDpi.DpiScaleX;
        AfterViewChange();
    }

    private void StepZoom(int direction)
    {
        _viewport.ZoomStep(direction, ActualWidth / 2, ActualHeight / 2);
        AfterViewChange();
    }

    private void AfterViewChange()
    {
        // Keep the canvas on whole device pixels so single pixels stay crisp at 100% and above.
        double dpi = _viewport.DpiScale;
        double snapX = Math.Round(_viewport.OffsetX * dpi) / dpi - _viewport.OffsetX;
        double snapY = Math.Round(_viewport.OffsetY * dpi) / dpi - _viewport.OffsetY;
        if (Math.Abs(snapX) > 1e-9 || Math.Abs(snapY) > 1e-9) _viewport.PanBy(snapX, snapY);

        RenderOptions.SetBitmapScalingMode(this, _viewport.ShowsIndividualPixels ? BitmapScalingMode.NearestNeighbor
            : _viewport.Zoom < 1 ? BitmapScalingMode.HighQuality : BitmapScalingMode.Linear);
        InvalidateVisual();
        ViewChanged?.Invoke();
    }

    // ----- drawing the view -----

    private Rect CanvasRect()
    {
        var (x, y, w, h) = _viewport.CanvasRectInView();
        return new Rect(x, y, w, h);
    }

    private Rect CanvasToView(IntRect r)
    {
        double s = _viewport.Scale;
        return new Rect(_viewport.OffsetX + r.X * s, _viewport.OffsetY + r.Y * s, r.Width * s, r.Height * s);
    }

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        dc.DrawRectangle(_workspaceBrush, null, new Rect(0, 0, ActualWidth, ActualHeight));
        if (_document == null) return;

        Rect canvas = CanvasRect();
        if (canvas.Width < 1 || canvas.Height < 1) return;

        // soft shadow
        for (int i = 3; i >= 1; i--)
        {
            var shadow = new Rect(canvas.X - i, canvas.Y - i + 2, canvas.Width + 2 * i, canvas.Height + 2 * i);
            dc.DrawRectangle(ShadowBrush, null, shadow);
        }

        // background: white or a colour, or a checkerboard for a transparent canvas
        var background = _document.Project.Background;
        if (background.Mode == BackgroundMode.Transparent)
        {
            dc.PushClip(new RectangleGeometry(canvas));
            dc.PushTransform(new TranslateTransform(canvas.X, canvas.Y));
            dc.DrawRectangle(Checkerboard.Brush, null, new Rect(0, 0, canvas.Width, canvas.Height));
            dc.Pop();
            dc.Pop();
        }
        else
        {
            dc.DrawRectangle(BackgroundBrush(background.EffectiveColor), null, canvas);
        }

        if (_hasOnion && _onionBitmap != null && !_showingPlayback) dc.DrawImage(_onionBitmap, canvas);
        if (_bitmap != null) dc.DrawImage(_bitmap, canvas);
        dc.DrawRectangle(null, CanvasEdgePen, canvas);

        if (_showGrid && _viewport.CanShowPixelGrid) DrawPixelGrid(dc);
        if (!_showingPlayback) DrawSelection(dc);
        DrawZoomRect(dc);
        DrawBrushOutline(dc);
    }

    private ArgbColor _backgroundColor;
    private Brush? _backgroundBrush;

    private Brush BackgroundBrush(ArgbColor color)
    {
        if (_backgroundBrush == null || _backgroundColor != color)
        {
            _backgroundBrush = Ui.ToBrush(color);
            _backgroundColor = color;
        }
        return _backgroundBrush;
    }

    private void DrawPixelGrid(DrawingContext dc)
    {
        var visible = _viewport.VisibleCanvasRect();
        if (visible.IsEmpty) return;
        double s = _viewport.Scale;
        double ox = _viewport.OffsetX, oy = _viewport.OffsetY;
        double top = oy + visible.Y * s, bottom = oy + visible.Bottom * s;
        double left = ox + visible.X * s, right = ox + visible.Right * s;
        for (int x = visible.X; x <= visible.Right; x++)
            dc.DrawLine(GridPen, new Point(ox + x * s, top), new Point(ox + x * s, bottom));
        for (int y = visible.Y; y <= visible.Bottom; y++)
            dc.DrawLine(GridPen, new Point(left, oy + y * s), new Point(right, oy + y * s));
    }

    private void DrawSelection(DrawingContext dc)
    {
        if (_document?.Selection is not IntRect selection || selection.IsEmpty) return;
        Rect r = CanvasToView(selection);
        // A white line under a dashed black one stays visible on any colour.
        var white = new Pen(Brushes.White, 1.0);
        var dashed = new Pen(Brushes.Black, 1.0) { DashStyle = new DashStyle(new double[] { 4, 4 }, _antsOffset) };
        dc.DrawRectangle(null, white, r);
        dc.DrawRectangle(null, dashed, r);
    }

    private void DrawZoomRect(DrawingContext dc)
    {
        if (_drag != Drag.ZoomRect) return;
        var r = new Rect(_zoomRectStart, _zoomRectNow);
        if (r.Width < 2 && r.Height < 2) return;
        var pen = new Pen(Brushes.White, 1.0) { DashStyle = DashStyles.Dash };
        dc.DrawRectangle(null, CursorOuterPen, r);
        dc.DrawRectangle(null, pen, r);
    }

    private void DrawBrushOutline(DrawingContext dc)
    {
        if (!_pointerInside || _editor == null || _document == null) return;
        if (_drag is Drag.Pan or Drag.ZoomRect || _spaceHeld || _editor.IsPlaying) return;

        BrushSettings? brush = _editor.Tools.CurrentKind switch
        {
            ToolKind.Brush => _editor.ToolSettings.Brush,
            ToolKind.Pencil => _editor.ToolSettings.Pencil,
            ToolKind.Eraser => _editor.ToolSettings.Eraser,
            _ => null
        };
        if (brush == null) return;

        double diameter = brush.Size * _viewport.Scale;
        if (diameter < 4) return; // the cross-hair cursor is enough for tiny brushes
        double radius = diameter / 2;
        dc.DrawEllipse(null, CursorOuterPen, _pointerView, radius, radius);
        dc.DrawEllipse(null, CursorInnerPen, _pointerView, radius - 1, radius - 1);
    }

    // ----- input: mouse, pen and touch -----

    private void UpdateCursor()
    {
        if (_drag == Drag.Pan) { Cursor = Cursors.ScrollAll; return; }
        if (_spaceHeld) { Cursor = Cursors.Hand; return; }
        Cursor = _editor?.Tools.CurrentKind switch
        {
            ToolKind.Hand => Cursors.Hand,
            ToolKind.Move => Cursors.SizeAll,
            ToolKind.Zoom => Cursors.Cross,
            _ => Cursors.Cross
        };
    }

    private PointerInput MakeInput(Point view, float pressure, bool secondary, bool inverted)
    {
        var (cx, cy) = _viewport.ViewToCanvas(view.X, view.Y);
        var modifiers = Keyboard.Modifiers;
        return new PointerInput((float)cx, (float)cy, Math.Clamp(pressure, 0f, 1f),
            Shift: (modifiers & ModifierKeys.Shift) != 0,
            Ctrl: (modifiers & ModifierKeys.Control) != 0,
            Alt: (modifiers & ModifierKeys.Alt) != 0,
            Secondary: secondary,
            Inverted: inverted);
    }

    /// <summary>Reads the pen pressure and every sample the pen reported since the last event. A mouse reports full pressure.</summary>
    private void ReadPen(MouseEventArgs e, out float pressure, out bool inverted, out List<(Point Position, float Pressure)>? samples)
    {
        pressure = 1f;
        inverted = false;
        samples = null;
        StylusDevice? pen = e.StylusDevice;
        if (pen == null) return;
        try
        {
            // A finger reports no real pressure (Windows makes one up), so touch draws at full strength like a mouse.
            if (pen.TabletDevice?.Type == TabletDeviceType.Touch) return;
            inverted = pen.Inverted;
            StylusPointCollection points = pen.GetStylusPoints(this);
            if (points.Count == 0) return;
            samples = new List<(Point, float)>(points.Count);
            foreach (StylusPoint p in points) samples.Add((new Point(p.X, p.Y), p.PressureFactor));
            pressure = samples[^1].Pressure;
        }
        catch (InvalidOperationException)
        {
            // The pen went away between the event and this call; treat it as a mouse.
        }
    }

    private bool ShouldPan(MouseButton button) =>
        button == MouseButton.Middle ||
        (button == MouseButton.Left && (_spaceHeld || _editor?.Tools.CurrentKind == ToolKind.Hand));

    protected override void OnMouseDown(MouseButtonEventArgs e)
    {
        base.OnMouseDown(e);
        if (_editor == null || _document == null || _drag != Drag.None) return;
        Focus();
        Point pos = e.GetPosition(this);

        if (ShouldPan(e.ChangedButton))
        {
            BeginPan(pos);
            e.Handled = true;
            return;
        }
        if (e.ChangedButton != MouseButton.Left && e.ChangedButton != MouseButton.Right) return;

        if (_editor.IsPlaying)
        {
            // Drawing needs a still picture: stop where the animation is and let the next click draw.
            _editor.PausePlayback();
            PlaybackInterrupted?.Invoke();
            e.Handled = true;
            return;
        }

        if (_editor.Tools.CurrentKind == ToolKind.Zoom)
        {
            _drag = Drag.ZoomRect;
            _zoomOutRect = e.ChangedButton == MouseButton.Right || (Keyboard.Modifiers & ModifierKeys.Alt) != 0;
            _zoomRectStart = _zoomRectNow = pos;
            CaptureMouse();
            e.Handled = true;
            return;
        }

        ReadPen(e, out float pressure, out bool inverted, out _);
        _lastPressure = pressure;
        _lastViewPoint = pos;
        _toolButton = e.ChangedButton;
        _drag = Drag.Tool;
        CaptureMouse();
        RunTool(() => _editor.Tools.PointerDown(MakeInput(pos, pressure, e.ChangedButton == MouseButton.Right, inverted)));
        e.Handled = true;
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        Point pos = e.GetPosition(this);
        _pointerInside = true;
        _pointerView = pos;
        var (cx, cy) = _viewport.ViewToCanvas(pos.X, pos.Y);
        PointerCanvasMoved?.Invoke(new Point(cx, cy));

        switch (_drag)
        {
            case Drag.Pan:
                MovePan(pos);
                break;
            case Drag.ZoomRect:
                _zoomRectNow = pos;
                InvalidateVisual();
                break;
            case Drag.Tool when _editor != null:
                ForwardToolMoves(e, pos);
                break;
            default:
                InvalidateVisual(); // moves the brush outline
                break;
        }
    }

    private void ForwardToolMoves(MouseEventArgs e, Point pos)
    {
        if (_editor == null) return;
        ReadPen(e, out float pressure, out bool inverted, out var samples);
        bool secondary = _toolButton == MouseButton.Right;
        if (samples != null && samples.Count > 1)
        {
            // A fast pen reports several samples per event; using all of them keeps curves smooth.
            foreach (var (position, samplePressure) in samples)
            {
                Point p = position;
                float pr = samplePressure;
                RunTool(() => _editor.Tools.PointerMove(MakeInput(p, pr, secondary, inverted)));
            }
        }
        else
        {
            RunTool(() => _editor.Tools.PointerMove(MakeInput(pos, pressure, secondary, inverted)));
        }
        _lastViewPoint = pos;
        _lastPressure = pressure;
        InvalidateVisual();
    }

    protected override void OnMouseUp(MouseButtonEventArgs e)
    {
        base.OnMouseUp(e);
        Point pos = e.GetPosition(this);
        switch (_drag)
        {
            case Drag.Pan when e.ChangedButton == MouseButton.Middle || e.ChangedButton == MouseButton.Left:
                EndDrag();
                e.Handled = true;
                break;
            case Drag.ZoomRect:
                FinishZoomRect(pos);
                e.Handled = true;
                break;
            case Drag.Tool when e.ChangedButton == _toolButton && _editor != null:
                ReadPen(e, out _, out bool inverted, out _);
                _drag = Drag.None;
                RunTool(() => _editor.Tools.PointerUp(MakeInput(pos, _lastPressure, _toolButton == MouseButton.Right, inverted)));
                ReleaseMouseCapture();
                e.Handled = true;
                InvalidateVisual();
                break;
        }
    }

    protected override void OnLostMouseCapture(MouseEventArgs e)
    {
        base.OnLostMouseCapture(e);
        // Capture can be taken away (a dialog opened, the window lost focus): finish the stroke instead of leaving it dangling.
        if (_drag == Drag.Tool && _editor != null)
        {
            _drag = Drag.None;
            RunTool(() => _editor.Tools.PointerUp(MakeInput(_lastViewPoint, _lastPressure, _toolButton == MouseButton.Right, false)));
        }
        else if (_drag != Drag.None)
        {
            _drag = Drag.None;
            UpdateCursor();
        }
        InvalidateVisual();
    }

    protected override void OnMouseLeave(MouseEventArgs e)
    {
        base.OnMouseLeave(e);
        if (_drag == Drag.None)
        {
            _pointerInside = false;
            PointerCanvasMoved?.Invoke(null);
            InvalidateVisual();
        }
    }

    protected override void OnMouseEnter(MouseEventArgs e)
    {
        base.OnMouseEnter(e);
        _pointerInside = true;
    }

    protected override void OnMouseWheel(MouseWheelEventArgs e)
    {
        base.OnMouseWheel(e);
        Point pos = e.GetPosition(this);
        ModifierKeys modifiers = Keyboard.Modifiers;
        if ((modifiers & ModifierKeys.Shift) != 0) _viewport.PanBy(e.Delta * 0.6, 0);
        else if ((modifiers & ModifierKeys.Alt) != 0) _viewport.PanBy(0, e.Delta * 0.6);
        else _viewport.ZoomTo(_viewport.Zoom * Math.Pow(1.0019, e.Delta), pos.X, pos.Y);
        AfterViewChange();
        e.Handled = true;
    }

    // ----- pan and zoom drags -----

    private void BeginPan(Point pos)
    {
        _drag = Drag.Pan;
        _panAnchor = pos;
        _panStartX = _viewport.OffsetX;
        _panStartY = _viewport.OffsetY;
        CaptureMouse();
        UpdateCursor();
    }

    private void MovePan(Point pos)
    {
        double wantX = _panStartX + (pos.X - _panAnchor.X);
        double wantY = _panStartY + (pos.Y - _panAnchor.Y);
        _viewport.PanBy(wantX - _viewport.OffsetX, wantY - _viewport.OffsetY);
        AfterViewChange();
    }

    private void EndDrag()
    {
        _drag = Drag.None;
        ReleaseMouseCapture();
        UpdateCursor();
        InvalidateVisual();
    }

    private void FinishZoomRect(Point pos)
    {
        _zoomRectNow = pos;
        var rect = new Rect(_zoomRectStart, _zoomRectNow);
        bool outward = _zoomOutRect;
        _drag = Drag.None;
        ReleaseMouseCapture();

        if (rect.Width < 6 || rect.Height < 6)
        {
            // A click zooms one step in (or out) around the clicked point.
            _viewport.ZoomStep(outward ? -1 : +1, pos.X, pos.Y);
        }
        else if (outward)
        {
            _viewport.ZoomStep(-1, rect.X + rect.Width / 2, rect.Y + rect.Height / 2);
        }
        else
        {
            double factor = Math.Min(ActualWidth / rect.Width, ActualHeight / rect.Height);
            Point center = new(rect.X + rect.Width / 2, rect.Y + rect.Height / 2);
            _viewport.ZoomTo(_viewport.Zoom * factor, center.X, center.Y);
            _viewport.PanBy(ActualWidth / 2 - center.X, ActualHeight / 2 - center.Y);
        }
        AfterViewChange();
    }

    // ----- safety -----

    /// <summary>
    /// Runs a call into the tool code. A tool that fails must not take the program down or leave a stroke half-finished:
    /// the stroke is abandoned and the user is told.
    /// </summary>
    private void RunTool(Action action)
    {
        try
        {
            action();
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            _drag = Drag.None;
            if (IsMouseCaptured) ReleaseMouseCapture();
            try { _editor?.Tools.Cancel(); }
            catch (Exception) { /* already failing */ }
            CrashLog.Write("A drawing tool failed", ex);
            _editor?.Say("That stroke could not be completed (" + ex.Message + ").");
        }
    }

    // ----- helpers -----

    private static Brush FrozenBrush(Color color)
    {
        var brush = new SolidColorBrush(color);
        brush.Freeze();
        return brush;
    }

    private static Pen FrozenPen(Color color, double thickness)
    {
        var brush = new SolidColorBrush(color);
        brush.Freeze();
        var pen = new Pen(brush, thickness);
        pen.Freeze();
        return pen;
    }
}
