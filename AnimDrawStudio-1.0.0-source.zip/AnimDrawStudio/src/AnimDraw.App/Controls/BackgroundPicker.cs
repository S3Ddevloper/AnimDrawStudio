using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using AnimDraw.App.Services;
using AnimDraw.App.Windows;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;

namespace AnimDraw.App.Controls;

/// <summary>Chooses what lies behind the artwork: white, nothing (transparent) or a colour of your own.</summary>
public sealed class BackgroundPicker : StackPanel
{
    private readonly RadioButton _white = new() { Content = "White" };
    private readonly RadioButton _transparent = new() { Content = "Transparent (checkerboard)" };
    private readonly RadioButton _custom = new() { Content = "Colour" };
    private readonly Border _swatch = new() { Width = 26, Height = 20, CornerRadius = new CornerRadius(3), BorderThickness = new Thickness(1), Cursor = Cursors.Hand };
    private readonly Button _choose = new() { Content = "Choose...", MinWidth = 78 };
    private ArgbColor _color = ArgbColor.White;
    private bool _updating;

    public BackgroundPicker(BackgroundSettings initial)
    {
        Orientation = Orientation.Vertical;
        _swatch.SetResourceReference(Border.BorderBrushProperty, ThemeKeys.BorderStrong);

        _transparent.ToolTip = "No background. GIF and PNG exports keep the transparency; MP4 video has no transparency and uses white.";
        _white.Margin = new Thickness(0, 2, 0, 2);
        _transparent.Margin = new Thickness(0, 2, 0, 2);

        var customRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 2) };
        _custom.VerticalAlignment = VerticalAlignment.Center;
        _swatch.Margin = new Thickness(8, 0, 8, 0);
        _swatch.VerticalAlignment = VerticalAlignment.Center;
        _choose.VerticalAlignment = VerticalAlignment.Center;
        customRow.Children.Add(_custom);
        customRow.Children.Add(_swatch);
        customRow.Children.Add(_choose);

        Children.Add(_white);
        Children.Add(_transparent);
        Children.Add(customRow);

        foreach (var radio in new[] { _white, _transparent, _custom })
        {
            radio.GroupName = "background-" + GetHashCode();
            radio.Checked += (_, _) => { if (!_updating) Changed?.Invoke(); };
        }
        _choose.Click += (_, _) => ChooseColor();
        _swatch.MouseLeftButtonDown += (_, _) => ChooseColor();

        Value = initial;
    }

    /// <summary>Raised after the person picked something different.</summary>
    public event Action? Changed;

    public BackgroundSettings Value
    {
        get
        {
            if (_transparent.IsChecked == true) return BackgroundSettings.Transparent;
            if (_custom.IsChecked == true) return BackgroundSettings.Custom(_color);
            return BackgroundSettings.White;
        }
        set
        {
            _updating = true;
            try
            {
                if (value.Mode == BackgroundMode.Custom) _color = value.Color.WithAlpha(255);
                _white.IsChecked = value.Mode == BackgroundMode.White;
                _transparent.IsChecked = value.Mode == BackgroundMode.Transparent;
                _custom.IsChecked = value.Mode == BackgroundMode.Custom;
                _swatch.Background = Ui.ToBrush(_color);
            }
            finally
            {
                _updating = false;
            }
        }
    }

    private void ChooseColor()
    {
        var dialog = new ColorPickerDialog(Window.GetWindow(this), "Background colour", _color);
        if (dialog.ShowDialog() != true) return;
        _color = dialog.Result;
        _swatch.Background = Ui.ToBrush(_color);
        _updating = true;
        _custom.IsChecked = true;
        _updating = false;
        Changed?.Invoke();
    }
}
