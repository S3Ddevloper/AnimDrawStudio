using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using AnimDraw.Core.Imaging;

namespace AnimDraw.App.Controls;

/// <summary>The square in which saturation (left to right) and brightness (bottom to top) of the current hue are picked.</summary>
public sealed class SaturationValueBox : FrameworkElement
{
    private double _hue;
    private double _saturation;
    private double _value = 1;

    public SaturationValueBox()
    {
        Cursor = Cursors.Cross;
        ClipToBounds = false;
        MinHeight = 90;
        Focusable = false;
    }

    /// <summary>Raised while the user picks, and once more when the mouse button is released (<paramref name="finished"/>).</summary>
    public event Action<bool>? Picked;

    public double Hue
    {
        get => _hue;
        set { _hue = ((value % 360) + 360) % 360; InvalidateVisual(); }
    }

    public double Saturation
    {
        get => _saturation;
        set { _saturation = Math.Clamp(value, 0, 1); InvalidateVisual(); }
    }

    public double Brightness
    {
        get => _value;
        set { _value = Math.Clamp(value, 0, 1); InvalidateVisual(); }
    }

    protected override Size MeasureOverride(Size availableSize)
    {
        double w = double.IsInfinity(availableSize.Width) ? 200 : availableSize.Width;
        double h = double.IsInfinity(availableSize.Height) ? 140 : Math.Max(MinHeight, availableSize.Height);
        return new Size(w, h);
    }

    protected override void OnRender(DrawingContext dc)
    {
        var rect = new Rect(0, 0, ActualWidth, ActualHeight);
        if (rect.Width < 2 || rect.Height < 2) return;
        Color hueColor = ToColor(ArgbColor.FromHsv(_hue, 1, 1));
        dc.DrawRoundedRectangle(new LinearGradientBrush(Colors.White, hueColor, 0), null, rect, 3, 3);
        // Fade to black from transparent BLACK: fading from Colors.Transparent (transparent white) would wash the colours out half way down.
        dc.DrawRoundedRectangle(new LinearGradientBrush(Color.FromArgb(0, 0, 0, 0), Colors.Black, 90), null, rect, 3, 3);

        var center = new Point(_saturation * rect.Width, (1 - _value) * rect.Height);
        dc.DrawEllipse(null, new Pen(Brushes.Black, 3), center, 6, 6);
        dc.DrawEllipse(null, new Pen(Brushes.White, 1.5), center, 6, 6);
    }

    protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonDown(e);
        CaptureMouse();
        Pick(e.GetPosition(this), false);
        e.Handled = true;
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (IsMouseCaptured) Pick(e.GetPosition(this), false);
    }

    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonUp(e);
        if (!IsMouseCaptured) return;
        Pick(e.GetPosition(this), true);
        ReleaseMouseCapture();
        e.Handled = true;
    }

    private void Pick(Point p, bool finished)
    {
        if (ActualWidth < 1 || ActualHeight < 1) return;
        _saturation = Math.Clamp(p.X / ActualWidth, 0, 1);
        _value = Math.Clamp(1 - p.Y / ActualHeight, 0, 1);
        InvalidateVisual();
        Picked?.Invoke(finished);
    }

    private static Color ToColor(ArgbColor c) => Color.FromArgb(c.A, c.R, c.G, c.B);
}

/// <summary>A rainbow bar for choosing the hue.</summary>
public sealed class HueSlider : FrameworkElement
{
    private static readonly Brush Rainbow = MakeRainbow();
    private double _hue;

    public HueSlider()
    {
        Height = 16;
        Cursor = Cursors.Hand;
        Focusable = false;
    }

    public event Action<bool>? Picked;

    public double Hue
    {
        get => _hue;
        set { _hue = Math.Clamp(((value % 360) + 360) % 360, 0, 359.999); InvalidateVisual(); }
    }

    protected override Size MeasureOverride(Size availableSize) =>
        new(double.IsInfinity(availableSize.Width) ? 200 : availableSize.Width, 16);

    protected override void OnRender(DrawingContext dc)
    {
        var rect = new Rect(0, 3, ActualWidth, Math.Max(0, ActualHeight - 6));
        if (rect.Width < 2) return;
        dc.DrawRoundedRectangle(Rainbow, null, rect, 3, 3);

        double x = _hue / 360.0 * ActualWidth;
        var handle = new Rect(x - 3, 0, 6, ActualHeight);
        dc.DrawRoundedRectangle(null, new Pen(Brushes.Black, 3), handle, 2, 2);
        dc.DrawRoundedRectangle(null, new Pen(Brushes.White, 1.5), handle, 2, 2);
    }

    protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonDown(e);
        CaptureMouse();
        Pick(e.GetPosition(this), false);
        e.Handled = true;
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (IsMouseCaptured) Pick(e.GetPosition(this), false);
    }

    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonUp(e);
        if (!IsMouseCaptured) return;
        Pick(e.GetPosition(this), true);
        ReleaseMouseCapture();
        e.Handled = true;
    }

    private void Pick(Point p, bool finished)
    {
        if (ActualWidth < 1) return;
        Hue = Math.Clamp(p.X / ActualWidth, 0, 1) * 360;
        Picked?.Invoke(finished);
    }

    private static Brush MakeRainbow()
    {
        var brush = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = new Point(1, 0) };
        Color[] colors =
        {
            Color.FromRgb(255, 0, 0), Color.FromRgb(255, 255, 0), Color.FromRgb(0, 255, 0),
            Color.FromRgb(0, 255, 255), Color.FromRgb(0, 0, 255), Color.FromRgb(255, 0, 255), Color.FromRgb(255, 0, 0)
        };
        for (int i = 0; i < colors.Length; i++) brush.GradientStops.Add(new GradientStop(colors[i], i / (double)(colors.Length - 1)));
        brush.Freeze();
        return brush;
    }
}
