using System.Windows;
using System.Windows.Controls;

namespace AnimDraw.App.Controls;

/// <summary>A label, a slider and a number box that always show the same value. Can use a logarithmic scale for wide ranges such as brush size.</summary>
public sealed class SliderField : StackPanel
{
    private const double Resolution = 1000;

    private readonly Slider _slider;
    private readonly NumberField _number;
    private readonly double _min;
    private readonly double _max;
    private readonly bool _log;
    private readonly int _decimals;
    private bool _updating;
    private double _value;

    public SliderField(string label, double min, double max, double value, int decimals = 0, string suffix = "",
        bool logarithmic = false, double sliderWidth = 110, double step = 1, double labelWidth = 0, string? tip = null)
    {
        Orientation = Orientation.Horizontal;
        _min = min;
        _max = max;
        _log = logarithmic && min > 0;
        _decimals = decimals;
        _value = Math.Clamp(value, min, max);

        var text = Services.Ui.Label(label, dim: true);
        text.Margin = new Thickness(0, 0, 6, 0);
        if (labelWidth > 0) text.MinWidth = labelWidth;
        Children.Add(text);

        _slider = new Slider { Minimum = 0, Maximum = Resolution, Width = sliderWidth, Focusable = false, VerticalAlignment = VerticalAlignment.Center, SmallChange = Resolution / 100, LargeChange = Resolution / 10 };
        Children.Add(_slider);

        _number = new NumberField(_value, min, max, decimals, step, width: 52) { };
        _number.Box.Margin = new Thickness(8, 0, 0, 0);
        Children.Add(_number.Box);

        if (!string.IsNullOrEmpty(suffix))
        {
            var unit = Services.Ui.Label(suffix, dim: true);
            unit.Margin = new Thickness(4, 0, 0, 0);
            Children.Add(unit);
        }

        if (tip != null) ToolTip = tip;
        _slider.Value = ToSlider(_value);

        _slider.ValueChanged += (_, e) =>
        {
            if (_updating) return;
            double v = Round(FromSlider(e.NewValue));
            if (v == _value) return;
            _value = v;
            _updating = true;
            _number.SetValue(v);
            _updating = false;
            ValueChanged?.Invoke(v);
        };
        _number.ValueChanged += v =>
        {
            if (_updating) return;
            _value = v;
            _updating = true;
            _slider.Value = ToSlider(v);
            _updating = false;
            ValueChanged?.Invoke(v);
        };
    }

    /// <summary>Raised when the user changed the value (not when it is set from code).</summary>
    public event Action<double>? ValueChanged;

    public double Value => _value;

    public void SetValue(double value)
    {
        _value = Math.Clamp(value, _min, _max);
        _updating = true;
        _slider.Value = ToSlider(_value);
        _number.SetValue(_value);
        _updating = false;
    }

    private double Round(double v) => _decimals == 0 ? Math.Round(v) : Math.Round(v, _decimals);

    private double ToSlider(double v)
    {
        v = Math.Clamp(v, _min, _max);
        double t = _log
            ? (Math.Log(v) - Math.Log(_min)) / (Math.Log(_max) - Math.Log(_min))
            : (v - _min) / (_max - _min);
        return t * Resolution;
    }

    private double FromSlider(double position)
    {
        double t = Math.Clamp(position / Resolution, 0, 1);
        double v = _log
            ? Math.Exp(Math.Log(_min) + t * (Math.Log(_max) - Math.Log(_min)))
            : _min + t * (_max - _min);
        return Math.Clamp(v, _min, _max);
    }
}
