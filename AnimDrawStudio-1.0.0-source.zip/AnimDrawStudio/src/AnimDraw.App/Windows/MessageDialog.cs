using System.Windows;
using System.Windows.Controls;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;

namespace AnimDraw.App.Windows;

public enum MessageKind
{
    Info,
    Question,
    Warning,
    Error
}

public enum SaveChoice
{
    Save,
    DontSave,
    Cancel
}

/// <summary>The program's own message boxes: themed, with an optional details area, and a choice for "don't ask again".</summary>
public sealed class MessageDialog : DialogWindow
{
    private MessageDialog(Window? owner, string title, MessageKind kind, string text, string? details, string? optOutText)
        : base(owner, title)
    {
        var body = Ui.MakeGrid("Auto,*");
        body.Margin = new Thickness(24, 22, 24, 6);
        body.MinWidth = 380;
        body.MaxWidth = 560;

        string icon = kind switch
        {
            MessageKind.Error => "error",
            MessageKind.Warning => "warning",
            MessageKind.Question => "question",
            _ => "info"
        };
        string brush = kind switch
        {
            MessageKind.Error => ThemeKeys.Danger,
            MessageKind.Warning => ThemeKeys.Warning,
            _ => ThemeKeys.Accent
        };
        var picture = new IconView(icon, 32) { Margin = new Thickness(0, 0, 16, 0), VerticalAlignment = VerticalAlignment.Top };
        picture.SetResourceReference(IconView.ForegroundProperty, brush);
        picture.Place(body, 0, 0);

        var column = new StackPanel();
        column.Children.Add(Ui.Wrapped(text));
        if (!string.IsNullOrWhiteSpace(details))
        {
            var box = new TextBox
            {
                Text = details,
                IsReadOnly = true,
                TextWrapping = TextWrapping.Wrap,
                MaxHeight = 150,
                MinHeight = 60,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Margin = new Thickness(0, 6, 0, 0),
                Visibility = Visibility.Collapsed
            };
            var toggle = new System.Windows.Controls.Primitives.ToggleButton { Content = "Show details", Margin = new Thickness(0, 12, 0, 0), HorizontalAlignment = HorizontalAlignment.Left, Padding = new Thickness(10, 2, 10, 2), MinHeight = 24 };
            toggle.Click += (_, _) =>
            {
                bool show = toggle.IsChecked == true;
                box.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
                toggle.Content = show ? "Hide details" : "Show details";
            };
            column.Children.Add(toggle);
            column.Children.Add(box);
        }
        if (optOutText != null)
        {
            OptOut = new CheckBox { Content = optOutText, Margin = new Thickness(0, 14, 0, 0) };
            column.Children.Add(OptOut);
        }
        column.Place(body, 0, 1);
        SetBody(body);
    }

    public CheckBox? OptOut { get; }

    public SaveChoice Choice { get; private set; } = SaveChoice.Cancel;

    // ----- ready-made messages -----

    public static void Info(Window? owner, string title, string text, string? details = null)
    {
        var dialog = new MessageDialog(owner, title, MessageKind.Info, text, details, null);
        dialog.AddButton("OK", isDefault: true, isCancel: true, primary: true);
        dialog.ShowDialog();
    }

    public static void Warn(Window? owner, string title, string text, string? details = null)
    {
        var dialog = new MessageDialog(owner, title, MessageKind.Warning, text, details, null);
        dialog.AddButton("OK", isDefault: true, isCancel: true, primary: true);
        dialog.ShowDialog();
    }

    public static void Error(Window? owner, string title, string text, string? details = null)
    {
        var dialog = new MessageDialog(owner, title, MessageKind.Error, text, details, null);
        dialog.AddButton("OK", isDefault: true, isCancel: true, primary: true);
        dialog.ShowDialog();
    }

    /// <summary>Asks a yes-or-no question. The first button is the default.</summary>
    public static bool Confirm(Window? owner, string title, string text, string yes = "OK", string no = "Cancel", MessageKind kind = MessageKind.Question)
    {
        var dialog = new MessageDialog(owner, title, kind, text, null, null);
        bool result = false;
        dialog.AddButton(yes, () => { result = true; dialog.Accept(); }, primary: true, isDefault: true);
        dialog.AddButton(no, isCancel: true);
        dialog.ShowDialog();
        return result;
    }

    /// <summary>Like <see cref="Confirm"/> but lets the user switch the question off for the future.</summary>
    public static bool ConfirmWithOptOut(Window? owner, string title, string text, string yes, string no, string optOutText, out bool dontAskAgain)
    {
        var dialog = new MessageDialog(owner, title, MessageKind.Question, text, null, optOutText);
        bool result = false;
        dialog.AddButton(yes, () => { result = true; dialog.Accept(); }, primary: true, isDefault: true);
        dialog.AddButton(no, isCancel: true);
        dialog.ShowDialog();
        dontAskAgain = result && dialog.OptOut?.IsChecked == true;
        return result;
    }

    /// <summary>The "save changes?" question shown before unsaved work would be lost.</summary>
    public static SaveChoice AskSave(Window? owner, string projectName, string action)
    {
        var dialog = new MessageDialog(owner, "Unsaved changes", MessageKind.Warning,
            $"\"{projectName}\" has changes that were not saved.\n\nDo you want to save them before {action}?", null, null);
        dialog.AddButton("Save", () => { dialog.Choice = SaveChoice.Save; dialog.Accept(); }, primary: true, isDefault: true);
        dialog.AddButton("Don't save", () => { dialog.Choice = SaveChoice.DontSave; dialog.Accept(); });
        dialog.AddButton("Cancel", isCancel: true);
        dialog.ShowDialog();
        return dialog.Choice;
    }
}
