using System.Windows;
using System.Windows.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.App;

namespace AnimDraw.App.Windows;

/// <summary>Lists every keyboard shortcut by menu, plus the mouse and pen actions that are not in the menus.</summary>
public sealed class ShortcutsDialog : DialogWindow
{
    private static readonly (string Action, string How)[] MouseTips =
    {
        ("Draw", "Left mouse button or pen. With a pen, pressure can change the size and the opacity (see the tool options)."),
        ("Draw with the second colour", "Right mouse button"),
        ("Pan the canvas", "Hold Space and drag, drag with the middle mouse button, or use the Hand tool"),
        ("Zoom", "Mouse wheel (towards the pointer). Zoom tool: click, Alt+click or right-click to zoom out, drag a rectangle"),
        ("Scroll the canvas", "Shift+wheel sideways, Alt+wheel up and down"),
        ("Straight line, square, circle", "Hold Shift while dragging the Line, Rectangle or Ellipse tool"),
        ("Draw a shape from its centre", "Hold Alt while dragging the Rectangle or Ellipse tool"),
        ("Move a copy", "Hold Alt while dragging with the Move tool"),
        ("Nudge the selection", "Arrow keys (Shift = 10 pixels). With nothing selected, Left and Right change the frame"),
        ("Cancel", "Esc stops playback, cancels the stroke being drawn, or removes the selection"),
        ("Pick a colour", "Eyedropper tool. Hold Alt to pick from the active layer only, instead of from everything you see"),
        ("Open a file", "Drag an .animdraw project, or a picture to paste into the drawing, onto the window")
    };

    public ShortcutsDialog(Window owner, ShortcutMap shortcuts) : base(owner, "Keyboard Shortcuts", resizable: true)
    {
        var stack = new StackPanel { Margin = new Thickness(26, 18, 26, 12) };

        foreach (var group in ShortcutMap.Commands.GroupBy(c => c.Category))
        {
            stack.Children.Add(Heading(group.Key));
            var grid = Ui.MakeGrid("*,Auto");
            int row = 0;
            foreach (var command in group)
            {
                var keys = shortcuts.GesturesOf(command.Id);
                string text = keys.Count == 0 ? "" : string.Join("   or   ", keys.Select(k => k.ToDisplayString()));
                if (text.Length == 0) continue;
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                var name = Ui.Label(command.Name);
                name.Margin = new Thickness(0, 2, 24, 2);
                name.Place(grid, row, 0);
                var key = Ui.Label(text, dim: true);
                key.Margin = new Thickness(0, 2, 0, 2);
                key.FontFamily = new System.Windows.Media.FontFamily("Consolas");
                key.Place(grid, row, 1);
                row++;
            }
            if (row > 0) stack.Children.Add(grid);
        }

        stack.Children.Add(Heading("Mouse, pen and other actions"));
        foreach (var (action, how) in MouseTips)
        {
            var line = new StackPanel { Margin = new Thickness(0, 3, 0, 3) };
            line.Children.Add(Ui.Label(action));
            var detail = Ui.Wrapped(how, dim: true, maxWidth: 470);
            detail.FontSize = 11.5;
            line.Children.Add(detail);
            stack.Children.Add(line);
        }

        var scroll = new ScrollViewer
        {
            Content = stack,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            Width = 560,
            Height = 520
        };
        SetBody(scroll);
        AddButton("Close", isDefault: true, isCancel: true, primary: true);
    }

    private static TextBlock Heading(string text)
    {
        var heading = Ui.Label(text, size: 13, bold: true);
        heading.SetResourceReference(TextBlock.ForegroundProperty, ThemeKeys.Accent);
        heading.Margin = new Thickness(0, 14, 0, 4);
        return heading;
    }
}
