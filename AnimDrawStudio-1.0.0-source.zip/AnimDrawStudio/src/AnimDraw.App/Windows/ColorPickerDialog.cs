using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.Imaging;

namespace AnimDraw.App.Windows;

/// <summary>A small dialog for choosing one opaque colour: colour square, hue bar and a hex box.</summary>
public sealed class ColorPickerDialog : DialogWindow
{
    private readonly SaturationValueBox _square = new() { Height = 150, Width = 260 };
    private readonly HueSlider _hueBar = new() { Width = 260 };
    private readonly TextBox _hexBox = new() { Width = 90, MaxLength = 9, VerticalContentAlignment = VerticalAlignment.Center };
    private readonly Border _preview = new() { Width = 52, Height = 30, CornerRadius = new CornerRadius(4), BorderThickness = new Thickness(1) };

    private double _hue;
    private double _saturation;
    private double _brightness = 1;
    private bool _updating;

    public ColorPickerDialog(Window? owner, string title, ArgbColor initial) : base(owner, title)
    {
        Result = initial.WithAlpha(255);
        var (h, s, v) = Result.ToHsv();
        _hue = h;
        _saturation = s;
        _brightness = v;

        var body = new StackPanel { Margin = new Thickness(22, 18, 22, 8) };
        body.Children.Add(_square);
        _hueBar.Margin = new Thickness(0, 10, 0, 0);
        body.Children.Add(_hueBar);

        var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 12, 0, 0) };
        _preview.SetResourceReference(Border.BorderBrushProperty, ThemeKeys.BorderStrong);
        row.Children.Add(_preview);
        var hexLabel = Ui.Label("Hex", dim: true);
        hexLabel.Margin = new Thickness(14, 0, 6, 0);
        row.Children.Add(hexLabel);
        row.Children.Add(_hexBox);
        body.Children.Add(row);
        SetBody(body);

        AddButton("OK", () => Accept(), primary: true, isDefault: true);
        AddButton("Cancel", isCancel: true);

        _square.Picked += _ =>
        {
            _saturation = _square.Saturation;
            _brightness = _square.Brightness;
            Apply();
        };
        _hueBar.Picked += _ =>
        {
            _hue = _hueBar.Hue;
            _square.Hue = _hue;
            Apply();
        };
        _hexBox.LostKeyboardFocus += (_, _) => CommitHex();
        _hexBox.KeyDown += (_, e) =>
        {
            if (e.Key == Key.Enter)
            {
                CommitHex();
                e.Handled = true;
            }
        };

        Refresh();
    }

    /// <summary>The colour chosen (always opaque).</summary>
    public ArgbColor Result { get; private set; }

    private void Apply()
    {
        Result = ArgbColor.FromHsv(_hue, _saturation, _brightness);
        Refresh();
    }

    private void CommitHex()
    {
        if (_updating) return;
        if (ArgbColor.TryParse(_hexBox.Text, out ArgbColor parsed))
        {
            Result = parsed.WithAlpha(255);
            var (h, s, v) = Result.ToHsv();
            if (s > 1e-6 && v > 1e-6) _hue = h;
            _saturation = s;
            _brightness = v;
        }
        Refresh();
    }

    private void Refresh()
    {
        _updating = true;
        try
        {
            _square.Hue = _hue;
            _square.Saturation = _saturation;
            _square.Brightness = _brightness;
            _hueBar.Hue = _hue;
            _preview.Background = Ui.ToBrush(Result);
            _hexBox.Text = Result.ToHex();
        }
        finally
        {
            _updating = false;
        }
    }
}
