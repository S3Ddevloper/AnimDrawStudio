using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.Settings;

namespace AnimDraw.App.Windows;

/// <summary>Name, version and a few facts about the program.</summary>
public sealed class AboutDialog : DialogWindow
{
    public AboutDialog(Window owner) : base(owner, "About " + AppInfo.Name)
    {
        var body = new StackPanel { Margin = new Thickness(32, 26, 32, 10), MinWidth = 380 };

        var header = new StackPanel { Orientation = Orientation.Horizontal };
        header.Children.Add(CreateLogo());
        var titles = new StackPanel { Margin = new Thickness(16, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
        titles.Children.Add(Ui.Label(AppInfo.Name, size: 20, bold: true));
        titles.Children.Add(Ui.Label("Version " + AppInfo.Version, dim: true));
        header.Children.Add(titles);
        body.Children.Add(header);

        var tagline = Ui.Wrapped(AppInfo.Tagline + " for Windows 10 and 11.", maxWidth: 420);
        tagline.Margin = new Thickness(0, 16, 0, 0);
        body.Children.Add(tagline);

        var about = Ui.Wrapped(
            "Draw on layers, build animations frame by frame, play them back, and export them as GIF, MP4, PNG pictures, " +
            "PNG sequences or sprite sheets. Projects are saved as .animdraw files that keep every layer and frame editable.",
            dim: true, maxWidth: 420);
        about.Margin = new Thickness(0, 10, 0, 0);
        body.Children.Add(about);

        var notes = Ui.Wrapped(
            "The drawing and animation engine is written in C# and uses no third-party code libraries. MP4 export uses FFmpeg " +
            "when it is installed; FFmpeg is a separate program with its own licence and is not part of AnimDraw Studio.",
            dim: true, maxWidth: 420);
        notes.FontSize = 11.5;
        notes.Margin = new Thickness(0, 12, 0, 0);
        body.Children.Add(notes);

        var facts = Ui.Wrapped(
            "Settings: " + SettingsManager.DefaultDataFolder + "\nRuntime: " + System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
            dim: true, maxWidth: 420);
        facts.FontSize = 11;
        facts.Margin = new Thickness(0, 12, 0, 0);
        body.Children.Add(facts);

        SetBody(body);
        AddButton("OK", isDefault: true, isCancel: true, primary: true);
    }

    /// <summary>The program's picture, or a plain film icon when the picture cannot be read.</summary>
    private static UIElement CreateLogo()
    {
        try
        {
            var bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.UriSource = new Uri("pack://application:,,,/AnimDrawStudio;component/Assets/AnimDraw-256.png", UriKind.Absolute);
            bitmap.CacheOption = BitmapCacheOption.OnLoad;
            bitmap.EndInit();
            bitmap.Freeze();
            var image = new Image { Source = bitmap, Width = 56, Height = 56 };
            RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.HighQuality);
            return image;
        }
        catch (Exception ex) when (ex is IOException or FormatException or NotSupportedException or InvalidOperationException)
        {
            var icon = new IconView("film", 44);
            icon.SetResourceReference(IconView.ForegroundProperty, ThemeKeys.Accent);
            return icon;
        }
    }
}
