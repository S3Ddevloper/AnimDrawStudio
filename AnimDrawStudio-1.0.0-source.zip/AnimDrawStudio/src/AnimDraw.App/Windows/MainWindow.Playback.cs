using System.Windows.Media;

namespace AnimDraw.App.Windows;

public sealed partial class MainWindow
{
    private bool _playbackHooked;
    private PreviewWindow? _previewWindow;

    // ===================================================================== play, pause, stop

    private void TogglePlayback()
    {
        var doc = _editor.Document;
        if (_editor.IsPlaying)
        {
            _editor.PausePlayback();
            EndPlaybackUi();
            return;
        }
        if (doc.FrameCount < 2)
        {
            _editor.Say("There is only one frame, so there is nothing to play. Add frames first.");
            return;
        }
        _editor.StartPlayback();
        BeginPlaybackUi();
    }

    private void StopPlayback()
    {
        if (!_editor.IsPlaying) return;
        _editor.StopPlayback();
        EndPlaybackUi();
    }

    /// <summary>Stops playback where it is (a command that edits the project needs a still picture).</summary>
    private void InterruptPlayback()
    {
        if (_editor.IsPlaying)
        {
            _editor.PausePlayback();
            EndPlaybackUi();
        }
        else if (_playbackHooked)
        {
            EndPlaybackUi();
        }
    }

    // ===================================================================== the render loop

    private void BeginPlaybackUi()
    {
        if (!_playbackHooked)
        {
            _playbackHooked = true;
            CompositionTarget.Rendering += OnRendering;
        }
        _timelinePanel.UpdatePlayback(true, _editor.Playback.CurrentFrame);
    }

    private void EndPlaybackUi()
    {
        if (_playbackHooked)
        {
            CompositionTarget.Rendering -= OnRendering;
            _playbackHooked = false;
        }
        _canvas.ShowPlaybackFrame(null);
        _timelinePanel.UpdatePlayback(false, _editor.Document.CurrentFrame);
        UpdateFrameStatus();
    }

    /// <summary>
    /// Called once per screen refresh while playing. It only asks the engine which frame is due and shows the picture the
    /// background thread already prepared, so the window never waits for drawing work.
    /// </summary>
    private void OnRendering(object? sender, EventArgs e)
    {
        if (!_editor.IsPlaying)
        {
            // Something else paused playback (a click on the timeline, for example).
            EndPlaybackUi();
            return;
        }

        // Changing the frame rate or the loop switch while playing takes effect at once.
        var project = _editor.Document.Project;
        var engine = _editor.Playback;
        if (Math.Abs(engine.Fps - project.Fps) > 1e-9) engine.Fps = project.Fps;
        if (engine.Loop != project.Loop) engine.Loop = project.Loop;

        var tick = _editor.TickPlayback();
        if (!_editor.IsPlaying)
        {
            // A one-shot animation reached its last frame.
            EndPlaybackUi();
            _editor.Say("Finished playing");
            return;
        }
        if (!tick.FrameChanged) return;

        if (tick.Image != null) _canvas.ShowPlaybackFrame(tick.Image);
        _timelinePanel.UpdatePlayback(true, tick.Frame);
        _statusBar.SetFrame(tick.Frame + 1, _editor.Document.FrameCount);
    }

    // ===================================================================== preview window

    private void ShowPreview()
    {
        _editor.Document.CommitActiveEdit();
        if (_previewWindow != null)
        {
            if (_previewWindow.WindowState == System.Windows.WindowState.Minimized)
                _previewWindow.WindowState = System.Windows.WindowState.Normal;
            _previewWindow.Activate();
            return;
        }
        _previewWindow = new PreviewWindow(this, _editor);
        _previewWindow.Closed += (_, _) => _previewWindow = null;
        _previewWindow.Show();
    }
}
