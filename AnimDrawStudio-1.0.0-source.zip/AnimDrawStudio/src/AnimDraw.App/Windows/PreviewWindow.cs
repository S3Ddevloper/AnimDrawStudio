using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.Animation;
using AnimDraw.Core.App;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Rendering;

namespace AnimDraw.App.Windows;

/// <summary>
/// A separate window that plays the animation on its own: play, pause and stop, a speed from 0.1x to 8x, zoom levels, a frame
/// scrubber and the frame number. It has its own clock and its own frame cache, so it never disturbs the drawing window.
/// Frames are prepared on a background thread and the window only shows pictures that are ready, which keeps the interface
/// responsive even for large canvases. When the project is edited the preview refreshes itself a moment later.
/// </summary>
public sealed class PreviewWindow : AppWindow
{
    private static readonly double[] ZoomPresets = { 0.25, 0.5, 0.75, 1, 1.5, 2, 3, 4, 6, 8 };

    private readonly Editor _editor;
    private readonly PlaybackEngine _engine = new();
    private readonly PreviewSurface _surface = new();
    private readonly ScrollViewer _scroll;
    private readonly Border _stage;
    private readonly Slider _scrub;
    private readonly Button _play;
    private readonly IconView _playIcon;
    private readonly Button[] _navigation;
    private readonly ToggleButton _loop;
    private readonly TextBlock _frameText;
    private readonly TextBlock _timeText;
    private readonly TextBlock _status;
    private readonly SliderField _speed;
    private readonly ComboBox _zoomBox;
    private readonly DispatcherTimer _refreshTimer;
    private readonly Queue<long> _shownTimes = new();

    private Document _doc;
    private FrameCache? _cache;
    private int _frameCount = 1;
    private double _fps = 12;
    private bool _projectLoop = true;

    private int _shownFrame = -1;
    private int _wanted = -1;
    private int? _follow;
    private long _late;
    private long _lastStatusTicks;
    private bool _hooked;
    private bool _stale;
    private bool _updatingScrub;
    private bool _updatingZoom;
    private string? _message;

    private bool _panning;
    private Point _panFrom;
    private double _panX;
    private double _panY;
    private double _anchorX = 0.5;
    private double _anchorY = 0.5;

    public PreviewWindow(Window owner, Editor editor)
    {
        _editor = editor;
        _doc = editor.Document;

        Title = "Preview";
        ShowInTaskbar = false;
        ResizeMode = ResizeMode.CanResize;
        MinWidth = 480;
        MinHeight = 380;
        if (owner.IsLoaded && owner.IsVisible)
        {
            Owner = owner;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
        }
        else
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }
        ChooseStartSize(owner);

        // ---- the picture ----
        _scroll = new ScrollViewer
        {
            Content = _surface,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Disabled,
            Focusable = false
        };
        _stage = Ui.Box(ThemeKeys.Workspace);
        _stage.Child = _scroll;
        _stage.PreviewMouseWheel += OnStageWheel;
        _stage.MouseLeftButtonDown += OnStageDown;
        _stage.MouseMove += OnStageMove;
        _stage.MouseLeftButtonUp += OnStageUp;
        _stage.LostMouseCapture += (_, _) => _panning = false;
        _scroll.ScrollChanged += (_, _) => UpdateCursor();
        _surface.ZoomChanged += () => Ui.Later(UpdateZoomText, DispatcherPriority.Background);

        // ---- the controls under the picture ----
        var first = Ui.IconButton("first", "First frame (Home)", () => GoToManually(0));
        var previous = Ui.IconButton("prev", "Previous frame (Left arrow)", () => GoToManually(_shownFrame - 1));
        _play = Ui.IconButton("play", "Play (Space)", TogglePlay, 22);
        _playIcon = (IconView)_play.Content;
        var stop = Ui.IconButton("stop", "Stop and go back to the first frame (Esc)", Stop);
        var next = Ui.IconButton("next", "Next frame (Right arrow)", () => GoToManually(_shownFrame + 1));
        var last = Ui.IconButton("last", "Last frame (End)", () => GoToManually(_frameCount - 1));
        _navigation = new[] { first, previous, stop, next, last };

        _loop = Ui.IconToggle("loop", "Repeat when the end is reached (L)", _doc.Project.Loop, SetLoop);
        _frameText = Ui.Label("", bold: true, size: 13.5);
        _frameText.MinWidth = 130;
        _frameText.Margin = new Thickness(16, 0, 0, 0);
        _timeText = Ui.Label("", dim: true);
        _timeText.HorizontalAlignment = HorizontalAlignment.Right;
        _timeText.Margin = new Thickness(0, 0, 12, 0);

        var transport = Ui.MakeGrid("Auto,Auto,*,Auto");
        var buttons = new StackPanel { Orientation = Orientation.Horizontal };
        foreach (var button in new[] { first, previous, _play, stop, next, last }) buttons.Children.Add(button);
        buttons.Place(transport, 0, 0);
        _frameText.Place(transport, 0, 1);
        _timeText.Place(transport, 0, 2);
        _loop.Place(transport, 0, 3);

        _scrub = new Slider
        {
            Minimum = 1,
            Maximum = 2,
            Value = 1,
            SmallChange = 1,
            LargeChange = 5,
            TickFrequency = 1,
            IsSnapToTickEnabled = true,
            IsMoveToPointEnabled = true,
            Focusable = false,
            Margin = new Thickness(2, 8, 2, 4),
            ToolTip = "Drag to move through the frames"
        };
        _scrub.ValueChanged += (_, e) =>
        {
            if (!_updatingScrub) GoToManually((int)Math.Round(e.NewValue) - 1);
        };

        _speed = new SliderField("Speed", 0.1, PlaybackEngine.MaxSpeed, 1, 2, "×", logarithmic: true, sliderWidth: 130, step: 0.25, labelWidth: 0,
            tip: "How fast the animation plays compared with the project's frame rate");
        _speed.ValueChanged += value =>
        {
            _engine.Speed = value;
            UpdateStatus();
        };
        var normalSpeed = Ui.TextButton("1×", () =>
        {
            _speed.SetValue(1);
            _engine.Speed = 1;
            UpdateStatus();
        }, minWidth: 40);
        normalSpeed.ToolTip = "Normal speed";
        normalSpeed.Focusable = false;
        normalSpeed.Margin = new Thickness(8, 0, 0, 0);

        _zoomBox = new ComboBox { Width = 118, Focusable = false, VerticalAlignment = VerticalAlignment.Center, ToolTip = "Zoom (Ctrl+wheel, + and -)" };
        _zoomBox.Items.Add(new ComboBoxItem { Content = "Fit", Tag = 0.0 });
        foreach (double preset in ZoomPresets)
            _zoomBox.Items.Add(new ComboBoxItem { Content = Viewport.FormatZoom(preset), Tag = preset });
        _zoomBox.SelectedIndex = 0;
        _zoomBox.SelectionChanged += (_, _) =>
        {
            if (_updatingZoom || _zoomBox.SelectedItem is not ComboBoxItem { Tag: double tag }) return;
            SetZoomMode(tag <= 0 ? null : tag);
        };
        var zoomOut = Ui.IconButton("zoom-out", "Zoom out (-)", () => StepZoom(-1), 16);
        var zoomIn = Ui.IconButton("zoom-in", "Zoom in (+)", () => StepZoom(+1), 16);
        var zoomLabel = Ui.Label("Zoom", dim: true);
        zoomLabel.Margin = new Thickness(0, 0, 6, 0);

        var options = Ui.MakeGrid("Auto,Auto,*,Auto,Auto,Auto,Auto");
        _speed.Place(options, 0, 0);
        normalSpeed.Place(options, 0, 1);
        zoomLabel.Place(options, 0, 3);
        _zoomBox.Place(options, 0, 4);
        zoomOut.Place(options, 0, 5);
        zoomIn.Place(options, 0, 6);

        _status = Ui.Label("", dim: true, size: 11.5);
        _status.Margin = new Thickness(2, 8, 2, 0);
        _status.TextTrimming = TextTrimming.CharacterEllipsis;

        var controls = new StackPanel { Margin = new Thickness(14, 10, 14, 10) };
        controls.Children.Add(transport);
        controls.Children.Add(_scrub);
        controls.Children.Add(options);
        controls.Children.Add(_status);

        var bar = Ui.Box(ThemeKeys.Panel, ThemeKeys.Border, new Thickness(0, 1, 0, 0));
        bar.Child = controls;

        var layout = Ui.MakeGrid("*", "*,Auto");
        _stage.Place(layout, 0, 0);
        bar.Place(layout, 1, 0);
        Content = layout;

        // ---- connect ----
        _refreshTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(300) };
        _refreshTimer.Tick += (_, _) => RefreshNow();

        _projectLoop = _doc.Project.Loop;
        _engine.Loop = _projectLoop;
        _doc.Changed += OnDocumentChanged;
        _editor.DocumentReplaced += OnDocumentReplaced;
        _editor.FileStateChanged += UpdateTitle;

        UpdateTitle();
        RebuildCache(startFrame: _doc.CurrentFrame);
        UpdateZoomText();
    }

    // ===================================================================== start-up

    private void ChooseStartSize(Window owner)
    {
        double dpi = 1;
        try
        {
            dpi = Math.Max(0.5, VisualTreeHelper.GetDpi(owner).DpiScaleX);
        }
        catch (InvalidOperationException)
        {
            // an owner that is not shown yet: assume 100%
        }
        var work = SystemParameters.WorkArea;
        var project = _doc.Project;
        Width = Math.Clamp(project.Width / dpi + 60, 540, Math.Max(540, work.Width * 0.8));
        Height = Math.Clamp(project.Height / dpi + 220, 460, Math.Max(460, work.Height * 0.88));
    }

    private void UpdateTitle()
    {
        Title = "Preview - " + _editor.DisplayName;
    }

    // ===================================================================== the frame cache

    /// <summary>
    /// Takes a fresh copy of the project and prepares frames from it. Playback keeps running through a refresh: the clock stays
    /// where it is and only the pictures it asks for change.
    /// </summary>
    private void RebuildCache(int? startFrame = null)
    {
        var snapshot = _doc.CreateSnapshot();
        var old = _cache;
        _cache = new FrameCache(snapshot, withBackground: true, budgetBytes: 192L * 1024 * 1024);
        _frameCount = Math.Max(1, snapshot.FrameCount);
        _fps = snapshot.Fps;

        _engine.FrameCount = _frameCount;
        _engine.Fps = _fps;
        if (snapshot.Loop != _projectLoop)
        {
            _projectLoop = snapshot.Loop;
            SetLoop(_projectLoop);
            _loop.IsChecked = _projectLoop;
        }

        // The old frames are thrown away on another thread; stopping its worker can take a moment.
        if (old != null) Task.Run(old.Dispose);

        _surface.SetCanvas(snapshot.Width, snapshot.Height, snapshot.Background);
        ConfigureScrub();

        int frame = startFrame ?? (_shownFrame < 0 ? _doc.CurrentFrame : _shownFrame);
        if (_follow != null)
        {
            frame = _follow.Value;
            _follow = null;
        }
        frame = Math.Clamp(frame, 0, _frameCount - 1);

        if (_engine.State == PlaybackState.Playing)
        {
            frame = _engine.CurrentFrame;
        }
        else
        {
            _engine.Seek(frame);
        }

        _wanted = frame;
        _shownFrame = -1;
        ShowFrame(frame, compose: true);
        if (_engine.State == PlaybackState.Playing) _cache.StartPrefetch(_engine.CurrentFrame, _engine.Loop);

        _message = null;
        UpdateTransport();
        UpdateStatus();
    }

    private void ConfigureScrub()
    {
        _updatingScrub = true;
        _scrub.Minimum = 1;
        _scrub.Maximum = Math.Max(2, _frameCount);
        _scrub.TickFrequency = 1;
        _updatingScrub = false;
    }

    /// <summary>Puts a frame on the screen. While playing, only pictures that are ready are used, so the window never waits.</summary>
    private bool ShowFrame(int frame, bool compose)
    {
        var cache = _cache;
        if (cache == null) return false;
        frame = Math.Clamp(frame, 0, _frameCount - 1);

        if (!cache.TryGetCached(frame, out var image))
        {
            if (!compose) return false;
            image = cache.Get(frame);
        }
        _surface.ShowFrame(image);
        _shownFrame = frame;
        RecordShown();
        UpdateFrameReadout();
        return true;
    }

    private void RecordShown()
    {
        long now = Stopwatch.GetTimestamp();
        _shownTimes.Enqueue(now);
        while (_shownTimes.Count > 1 && now - _shownTimes.Peek() > Stopwatch.Frequency) _shownTimes.Dequeue();
    }

    private double MeasuredFps()
    {
        if (_shownTimes.Count < 2) return 0;
        long span = _shownTimes.Last() - _shownTimes.Peek();
        return span <= 0 ? 0 : (_shownTimes.Count - 1) * (double)Stopwatch.Frequency / span;
    }

    // ===================================================================== reacting to edits in the main window

    private void OnDocumentChanged(object? sender, DocumentChangedEventArgs e)
    {
        if ((e.Kind & (ChangeKind.Pixels | ChangeKind.Structure | ChangeKind.Settings)) != 0)
        {
            // Refresh a moment after the last change, so drawing a stroke does not rebuild the preview again and again.
            _stale = true;
            _refreshTimer.Stop();
            _refreshTimer.Start();
        }
        if ((e.Kind & ChangeKind.Frame) != 0 && _engine.State != PlaybackState.Playing)
        {
            // When the person moves to another frame in the main window, a stopped preview shows that frame too.
            _follow = _doc.CurrentFrame;
            if (!_stale) ApplyFollow();
        }
    }

    private void ApplyFollow()
    {
        if (_follow == null) return;
        int frame = Math.Clamp(_follow.Value, 0, _frameCount - 1);
        _follow = null;
        if (frame == _shownFrame) return;
        _engine.Seek(frame);
        ShowFrame(frame, compose: true);
        UpdateStatus();
    }

    private void RefreshNow()
    {
        _refreshTimer.Stop();
        if (!_stale) return;
        _stale = false;
        try
        {
            RebuildCache();
        }
        catch (Exception ex)
        {
            StopAfterError(ex);
        }
    }

    private void OnDocumentReplaced()
    {
        // A different project was opened or created: stop, follow the new document and start from its current frame.
        _doc.Changed -= OnDocumentChanged;
        _engine.Stop(returnToStart: false);
        Unhook();
        _doc = _editor.Document;
        _doc.Changed += OnDocumentChanged;
        _stale = false;
        _refreshTimer.Stop();
        _follow = null;
        _shownFrame = -1;
        _projectLoop = _doc.Project.Loop;
        _engine.Loop = _projectLoop;
        _loop.IsChecked = _projectLoop;
        UpdateTitle();
        RebuildCache(startFrame: _doc.CurrentFrame);
    }

    // ===================================================================== play, pause, stop, step

    private void TogglePlay()
    {
        if (_cache == null) return;
        if (_engine.State == PlaybackState.Playing)
        {
            _engine.Pause();
            Unhook();
            UpdateTransport();
            UpdateStatus();
            return;
        }
        if (_stale) RefreshNow();
        if (_frameCount < 2)
        {
            _message = "There is only one frame, so there is nothing to play. Add frames in the main window.";
            UpdateStatus();
            return;
        }

        _message = null;
        _shownTimes.Clear();
        if (_engine.State == PlaybackState.Paused)
        {
            _engine.Resume();
        }
        else
        {
            _late = 0;
            _engine.Play(Math.Max(0, _shownFrame));
        }
        _wanted = _engine.CurrentFrame;
        _cache!.StartPrefetch(_engine.CurrentFrame, _engine.Loop);
        Hook();
        UpdateTransport();
        UpdateStatus();
    }

    /// <summary>Stops and goes back to the first frame.</summary>
    private void Stop()
    {
        if (_cache == null) return;
        _engine.Stop(returnToStart: false);
        Unhook();
        _cache.StopPrefetch();
        _engine.Seek(0);
        ShowFrame(0, compose: true);
        UpdateTransport();
        UpdateStatus();
    }

    /// <summary>Moves to a frame because the person asked to. A playing preview pauses, like a video player does when stepping.</summary>
    private void GoToManually(int frame)
    {
        if (_cache == null) return;
        frame = Math.Clamp(frame, 0, _frameCount - 1);
        if (_engine.State == PlaybackState.Playing)
        {
            _engine.Pause();
            Unhook();
            UpdateTransport();
        }
        if (frame == _shownFrame)
        {
            UpdateFrameReadout();
            UpdateStatus();
            return;
        }
        _engine.Seek(frame);
        ShowFrame(frame, compose: true);
        UpdateStatus();
    }

    private void SetLoop(bool on)
    {
        _engine.Loop = on;
        if (_engine.State == PlaybackState.Playing) _cache?.StartPrefetch(_engine.CurrentFrame, on);
    }

    // ===================================================================== the render loop

    private void Hook()
    {
        if (_hooked) return;
        _hooked = true;
        CompositionTarget.Rendering += OnRendering;
    }

    private void Unhook()
    {
        if (!_hooked) return;
        _hooked = false;
        CompositionTarget.Rendering -= OnRendering;
    }

    /// <summary>
    /// Called once per screen refresh while playing. It asks the clock which frame is due and shows the picture the background
    /// thread has already prepared. A picture that is not ready yet is shown as soon as it is, and counted as late.
    /// </summary>
    private void OnRendering(object? sender, EventArgs e)
    {
        try
        {
            var cache = _cache;
            if (cache == null || _engine.State != PlaybackState.Playing)
            {
                Unhook();
                UpdateTransport();
                UpdateStatus();
                return;
            }

            _engine.Tick();
            int frame = _engine.CurrentFrame;
            bool finished = _engine.State != PlaybackState.Playing;   // a one-shot animation reached its last frame

            if (frame != _wanted)
            {
                if (_wanted != _shownFrame) _late++;   // the previous frame was never ready in time
                _wanted = frame;
                cache.UpdatePlayhead(frame);
            }
            if (frame != _shownFrame) ShowFrame(frame, compose: finished);

            if (finished)
            {
                Unhook();
                cache.StopPrefetch();
                UpdateTransport();
            }

            long now = Stopwatch.GetTimestamp();
            if (finished || now - _lastStatusTicks > Stopwatch.Frequency / 4)
            {
                _lastStatusTicks = now;
                UpdateStatus();
            }
        }
        catch (Exception ex)
        {
            StopAfterError(ex);
        }
    }

    private void StopAfterError(Exception ex)
    {
        _engine.Stop(returnToStart: false);
        Unhook();
        string? log = CrashLog.Write("The preview stopped because of an error", ex);
        _message = "The preview stopped: " + ex.Message + (log != null ? " (a report was saved in the error log folder)" : "");
        UpdateTransport();
        UpdateStatus();
    }

    // ===================================================================== what the window says

    private void UpdateTransport()
    {
        bool playing = _engine.State == PlaybackState.Playing;
        bool many = _frameCount > 1;
        _playIcon.Icon = playing ? "pause" : "play";
        _play.ToolTip = playing ? "Pause (Space)" : "Play (Space)";
        _play.IsEnabled = many;
        foreach (var button in _navigation) button.IsEnabled = many;
        _scrub.IsEnabled = many;
    }

    private void UpdateFrameReadout()
    {
        int frame = Math.Max(0, _shownFrame);
        _frameText.Text = string.Format(CultureInfo.CurrentCulture, "Frame {0} of {1}", frame + 1, _frameCount);
        double fps = Math.Max(1, _fps);
        _timeText.Text = string.Format(CultureInfo.CurrentCulture, "{0:0.00} s of {1:0.00} s", frame / fps, _frameCount / fps);
        if ((int)Math.Round(_scrub.Value) != frame + 1)
        {
            _updatingScrub = true;
            _scrub.Value = frame + 1;
            _updatingScrub = false;
        }
    }

    private void UpdateStatus()
    {
        if (_message != null)
        {
            _status.Text = _message;
            return;
        }
        if (_frameCount < 2)
        {
            _status.Text = "This project has one frame. Add frames in the main window to make an animation.";
            return;
        }

        double speed = _engine.Speed;
        double shown = _fps * speed;
        string rate = string.Format(CultureInfo.CurrentCulture, "{0:0.##} frames per second", shown);
        switch (_engine.State)
        {
            case PlaybackState.Playing:
                long skipped = _engine.DroppedFrames + _late;
                string measured = string.Format(CultureInfo.CurrentCulture, "showing {0:0.0}", MeasuredFps());
                string loss = skipped > 0 ? string.Format(CultureInfo.CurrentCulture, ", {0} {1} skipped", skipped, skipped == 1 ? "frame" : "frames") : "";
                _status.Text = $"Playing at {rate} ({measured}{loss})";
                break;
            case PlaybackState.Paused:
                _status.Text = $"Paused. {rate} when playing.";
                break;
            default:
                _status.Text = $"Ready. Press Space to play at {rate}.";
                break;
        }
    }

    // ===================================================================== zoom, pan and mouse

    private void SetZoomMode(double? zoom)
    {
        // Keep the middle of what is on screen in the middle while the picture grows or shrinks.
        double extentW = _scroll.ExtentWidth, extentH = _scroll.ExtentHeight;
        if (!_surface.IsFit && extentW > 0 && extentH > 0)
        {
            _anchorX = (_scroll.HorizontalOffset + _scroll.ViewportWidth / 2) / extentW;
            _anchorY = (_scroll.VerticalOffset + _scroll.ViewportHeight / 2) / extentH;
        }
        else
        {
            _anchorX = _anchorY = 0.5;
        }

        if (zoom == null)
        {
            _scroll.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
            _scroll.VerticalScrollBarVisibility = ScrollBarVisibility.Disabled;
            _surface.SetFit();
        }
        else
        {
            _scroll.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
            _scroll.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            _surface.SetZoom(zoom.Value);
            Ui.Later(RestoreScrollAnchor, DispatcherPriority.Loaded);
        }
        SyncZoomBox(zoom);
        UpdateZoomText();
        UpdateCursor();
    }

    private void RestoreScrollAnchor()
    {
        if (_surface.IsFit) return;
        _scroll.UpdateLayout();
        _scroll.ScrollToHorizontalOffset(_anchorX * _scroll.ExtentWidth - _scroll.ViewportWidth / 2);
        _scroll.ScrollToVerticalOffset(_anchorY * _scroll.ExtentHeight - _scroll.ViewportHeight / 2);
    }

    private void SyncZoomBox(double? zoom)
    {
        _updatingZoom = true;
        int index = -1;
        if (zoom == null) index = 0;
        else
        {
            for (int i = 0; i < ZoomPresets.Length; i++)
                if (Math.Abs(ZoomPresets[i] - zoom.Value) < 1e-6) index = i + 1;
        }
        _zoomBox.SelectedIndex = index;
        _updatingZoom = false;
    }

    /// <summary>Shows the zoom that "Fit" works out to, for example "Fit (133%)".</summary>
    private void UpdateZoomText()
    {
        if (_zoomBox.Items[0] is ComboBoxItem fit)
            fit.Content = _surface.IsFit ? "Fit (" + Viewport.FormatZoom(_surface.EffectiveZoom) + ")" : "Fit";
        if (_zoomBox.SelectedIndex < 0 && !_surface.IsFit)
            _zoomBox.ToolTip = "Zoom " + Viewport.FormatZoom(_surface.EffectiveZoom);
    }

    private void StepZoom(int direction)
    {
        double current = _surface.EffectiveZoom;
        double? target = null;
        if (direction > 0)
        {
            foreach (double preset in ZoomPresets)
            {
                if (preset > current * 1.001)
                {
                    target = preset;
                    break;
                }
            }
        }
        else
        {
            for (int i = ZoomPresets.Length - 1; i >= 0; i--)
            {
                if (ZoomPresets[i] < current / 1.001)
                {
                    target = ZoomPresets[i];
                    break;
                }
            }
        }
        if (target != null) SetZoomMode(target);
    }

    private void OnStageWheel(object sender, MouseWheelEventArgs e)
    {
        if (!Keyboard.Modifiers.HasFlag(ModifierKeys.Control)) return;
        StepZoom(e.Delta > 0 ? +1 : -1);
        e.Handled = true;
    }

    private static bool IsOnScrollBar(DependencyObject? source, DependencyObject stop)
    {
        for (var node = source; node != null && !ReferenceEquals(node, stop); node = VisualTreeHelper.GetParent(node))
        {
            if (node is ScrollBar) return true;
        }
        return false;
    }

    private void OnStageDown(object sender, MouseButtonEventArgs e)
    {
        if (IsOnScrollBar(e.OriginalSource as DependencyObject, _stage)) return;

        if (e.ClickCount == 2)
        {
            // Double-click switches between fitting the picture and showing it at 100%.
            SetZoomMode(_surface.IsFit ? 1.0 : null);
            e.Handled = true;
            return;
        }
        if (_surface.IsFit || (_scroll.ScrollableWidth <= 0 && _scroll.ScrollableHeight <= 0)) return;

        _panning = true;
        _panFrom = e.GetPosition(_stage);
        _panX = _scroll.HorizontalOffset;
        _panY = _scroll.VerticalOffset;
        _stage.CaptureMouse();
        _stage.Cursor = Cursors.SizeAll;
        e.Handled = true;
    }

    private void OnStageMove(object sender, MouseEventArgs e)
    {
        if (!_panning) return;
        var point = e.GetPosition(_stage);
        _scroll.ScrollToHorizontalOffset(_panX - (point.X - _panFrom.X));
        _scroll.ScrollToVerticalOffset(_panY - (point.Y - _panFrom.Y));
    }

    private void OnStageUp(object sender, MouseButtonEventArgs e)
    {
        if (!_panning) return;
        _panning = false;
        _stage.ReleaseMouseCapture();
        UpdateCursor();
    }

    private void UpdateCursor()
    {
        if (_panning) return;
        bool canPan = !_surface.IsFit && (_scroll.ScrollableWidth > 0 || _scroll.ScrollableHeight > 0);
        _stage.Cursor = canPan ? Cursors.Hand : Cursors.Arrow;
    }

    // ===================================================================== keyboard

    protected override void OnPreviewKeyDown(KeyEventArgs e)
    {
        base.OnPreviewKeyDown(e);
        if (e.Handled) return;

        // While a number is being typed, every key belongs to the text box.
        if (Keyboard.FocusedElement is TextBox) return;
        if (Keyboard.Modifiers != ModifierKeys.None && Keyboard.Modifiers != ModifierKeys.Shift) return;

        bool handled = true;
        switch (e.Key)
        {
            case Key.Space:
                TogglePlay();
                break;
            case Key.Left:
                GoToManually(_shownFrame - 1);
                break;
            case Key.Right:
                GoToManually(_shownFrame + 1);
                break;
            case Key.Home:
                GoToManually(0);
                break;
            case Key.End:
                GoToManually(_frameCount - 1);
                break;
            case Key.L:
                _loop.IsChecked = _loop.IsChecked != true;
                SetLoop(_loop.IsChecked == true);
                break;
            case Key.F:
                SetZoomMode(null);
                break;
            case Key.D1:
            case Key.NumPad1:
                SetZoomMode(1.0);
                break;
            case Key.OemPlus:
            case Key.Add:
                StepZoom(+1);
                break;
            case Key.OemMinus:
            case Key.Subtract:
                StepZoom(-1);
                break;
            case Key.Escape:
                // The first press stops a running preview, the next one closes the window.
                if (_engine.State == PlaybackState.Playing) Stop();
                else Close();
                break;
            default:
                handled = false;
                break;
        }
        if (handled) e.Handled = true;
    }

    // ===================================================================== closing

    protected override void OnClosed(EventArgs e)
    {
        base.OnClosed(e);
        Unhook();
        _refreshTimer.Stop();
        _doc.Changed -= OnDocumentChanged;
        _editor.DocumentReplaced -= OnDocumentReplaced;
        _editor.FileStateChanged -= UpdateTitle;
        _engine.Stop(returnToStart: false);

        var cache = _cache;
        _cache = null;
        if (cache != null) Task.Run(cache.Dispose);
    }
}
