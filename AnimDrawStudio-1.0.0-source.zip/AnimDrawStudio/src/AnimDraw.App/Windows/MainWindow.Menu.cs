using System.IO;
using System.Windows;
using System.Windows.Controls;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.App;

namespace AnimDraw.App.Windows;

public sealed partial class MainWindow
{
    private Menu _menu = null!;
    private readonly Dictionary<CommandId, MenuItem> _menuItems = new();
    private MenuItem _undoItem = null!;
    private MenuItem _redoItem = null!;
    private MenuItem _recentItem = null!;

    /// <summary>Commands whose menu entry shows a tick while they are switched on.</summary>
    private static readonly HashSet<CommandId> CheckableCommands = new()
    {
        CommandId.TogglePixelGrid, CommandId.ThemeDark, CommandId.ThemeLight,
        CommandId.ToolBrush, CommandId.ToolPencil, CommandId.ToolEraser, CommandId.ToolLine, CommandId.ToolRectangle,
        CommandId.ToolEllipse, CommandId.ToolFill, CommandId.ToolEyedropper, CommandId.ToolSelect, CommandId.ToolMove,
        CommandId.ToolHand, CommandId.ToolZoom,
        CommandId.ToggleLoop, CommandId.ToggleOnionSkin, CommandId.ToggleAutoKeyframe, CommandId.PlayPause
    };

    private void BuildMenu()
    {
        _menu = new Menu { IsMainMenu = true };
        _menu.Items.Add(BuildFileMenu());
        _menu.Items.Add(BuildEditMenu());
        _menu.Items.Add(BuildViewMenu());
        _menu.Items.Add(BuildDrawingMenu());
        _menu.Items.Add(BuildAnimationMenu());
        _menu.Items.Add(BuildLayerMenu());
        _menu.Items.Add(BuildExportMenu());
        _menu.Items.Add(BuildHelpMenu());

        // Whichever drop-down is about to open, bring the enabled and ticked states up to date first.
        _menu.AddHandler(MenuItem.SubmenuOpenedEvent, new RoutedEventHandler((_, _) => RefreshMenuStates()));
    }

    private MenuItem Add(ItemsControl parent, CommandId id, string? header = null, string? icon = null)
    {
        var item = new MenuItem { Header = header ?? ShortcutMap.Info(id).Name };
        string gesture = _shortcuts.DisplayTextOf(id);
        if (gesture.Length > 0) item.InputGestureText = gesture;
        if (icon != null) item.Icon = new IconView(icon, 16);
        item.Click += (_, _) => Run(id);
        parent.Items.Add(item);
        _menuItems[id] = item;
        return item;
    }

    private static MenuItem TopMenu(string header) => new() { Header = header };

    private MenuItem BuildFileMenu()
    {
        var file = TopMenu("_File");
        Add(file, CommandId.NewProject, "_New Project...", "new");
        Add(file, CommandId.OpenProject, "_Open Project...", "open");
        _recentItem = new MenuItem { Header = "Open _Recent" };
        file.Items.Add(_recentItem);
        file.Items.Add(new Separator());
        Add(file, CommandId.Save, "_Save", "save");
        Add(file, CommandId.SaveAs, "Save _As...");
        file.Items.Add(new Separator());
        Add(file, CommandId.ProjectSettings, "Project Se_ttings...", "settings");
        file.Items.Add(new Separator());
        Add(file, CommandId.Exit, "E_xit");
        return file;
    }

    private MenuItem BuildEditMenu()
    {
        var edit = TopMenu("_Edit");
        _undoItem = Add(edit, CommandId.Undo, "_Undo", "undo");
        _redoItem = Add(edit, CommandId.Redo, "_Redo", "redo");
        edit.Items.Add(new Separator());
        Add(edit, CommandId.Cut, "Cu_t", "cut");
        Add(edit, CommandId.Copy, "_Copy", "copy");
        Add(edit, CommandId.Paste, "_Paste", "paste");
        Add(edit, CommandId.PasteInPlace, "Paste in Pl_ace");
        Add(edit, CommandId.DuplicateSelection, "D_uplicate Selection", "duplicate");
        edit.Items.Add(new Separator());
        Add(edit, CommandId.SelectAll, "Select _All");
        Add(edit, CommandId.Deselect, "_Deselect");
        edit.Items.Add(new Separator());
        Add(edit, CommandId.ClearSelection, "Clear Selection / Layer _Drawing", "trash");
        Add(edit, CommandId.ClearFrame, "Clear Canvas (all layers, this frame)");
        edit.Items.Add(new Separator());
        Add(edit, CommandId.Preferences, "Pre_ferences...", "settings");
        return edit;
    }

    private MenuItem BuildViewMenu()
    {
        var view = TopMenu("_View");
        Add(view, CommandId.ZoomIn, "Zoom _In", "zoom-in");
        Add(view, CommandId.ZoomOut, "Zoom _Out", "zoom-out");
        Add(view, CommandId.ZoomFit, "_Fit Canvas to Window", "fit");
        Add(view, CommandId.Zoom100, "_Actual Size (100%)");
        Add(view, CommandId.Zoom200, "Zoom _200%");
        view.Items.Add(new Separator());
        Add(view, CommandId.TogglePixelGrid, "_Pixel Grid", null);
        Add(view, CommandId.ShowPreview, "_Preview Window...", "preview");
        view.Items.Add(new Separator());
        var theme = new MenuItem { Header = "_Theme" };
        Add(theme, CommandId.ThemeDark, "_Dark");
        Add(theme, CommandId.ThemeLight, "_Light");
        view.Items.Add(theme);
        return view;
    }

    private MenuItem BuildDrawingMenu()
    {
        var drawing = TopMenu("_Drawing");
        foreach (var group in ToolCatalog.Groups)
        {
            foreach (var tool in group)
                Add(drawing, tool.Command, tool.Name);
            drawing.Items.Add(new Separator());
        }
        Add(drawing, CommandId.SwapColors, "S_wap Colours", "swap");
        Add(drawing, CommandId.BrushSmaller, "S_maller Brush");
        Add(drawing, CommandId.BrushLarger, "_Larger Brush");
        return drawing;
    }

    private MenuItem BuildAnimationMenu()
    {
        var anim = TopMenu("_Animation");
        Add(anim, CommandId.PlayPause, "_Play / Pause", "play");
        Add(anim, CommandId.StopPlayback, "_Stop", "stop");
        Add(anim, CommandId.ToggleLoop, "_Loop", null);
        anim.Items.Add(new Separator());
        Add(anim, CommandId.FirstFrame, "_First Frame", "first");
        Add(anim, CommandId.PreviousFrame, "Pre_vious Frame", "prev");
        Add(anim, CommandId.NextFrame, "_Next Frame", "next");
        Add(anim, CommandId.LastFrame, "L_ast Frame", "last");
        Add(anim, CommandId.PreviousKeyframe, "Previous _Keyframe");
        Add(anim, CommandId.NextKeyframe, "Next K_eyframe");
        anim.Items.Add(new Separator());
        Add(anim, CommandId.InsertFrame, "_Add Frame", "frame-add");
        Add(anim, CommandId.DuplicateFrame, "D_uplicate Frame", "duplicate");
        Add(anim, CommandId.DeleteFrame, "_Delete Frame", "frame-del");
        anim.Items.Add(new Separator());
        Add(anim, CommandId.InsertKeyframe, "Add Key_frame", "keyframe");
        Add(anim, CommandId.InsertBlankKeyframe, "Add _Blank Keyframe", "keyframe-blank");
        Add(anim, CommandId.RemoveKeyframe, "_Remove Keyframe");
        anim.Items.Add(new Separator());
        Add(anim, CommandId.ToggleOnionSkin, "_Onion Skin", null);
        Add(anim, CommandId.OnionSkinSettings, "Onion Skin Se_ttings...", "onion");
        Add(anim, CommandId.ToggleAutoKeyframe, "Auto K_eyframe on Draw", null);
        return anim;
    }

    private MenuItem BuildLayerMenu()
    {
        var layer = TopMenu("_Layer");
        Add(layer, CommandId.NewLayer, "_New Layer", "plus");
        Add(layer, CommandId.DuplicateLayer, "D_uplicate Layer", "duplicate");
        Add(layer, CommandId.DeleteLayer, "_Delete Layer", "trash");
        Add(layer, CommandId.RenameLayer, "_Rename Layer", "rename");
        layer.Items.Add(new Separator());
        Add(layer, CommandId.LayerUp, "Move Layer _Up", "up");
        Add(layer, CommandId.LayerDown, "Move Layer D_own", "down");
        Add(layer, CommandId.MergeLayerDown, "_Merge Down", "merge");
        layer.Items.Add(new Separator());
        Add(layer, CommandId.ToggleLayerVisible, "_Show / Hide Layer", "eye");
        Add(layer, CommandId.ToggleLayerLock, "_Lock / Unlock Layer", "lock");
        return layer;
    }

    private MenuItem BuildExportMenu()
    {
        var export = TopMenu("E_xport");
        Add(export, CommandId.ExportDialog, "_Export...", "export");
        export.Items.Add(new Separator());
        Add(export, CommandId.ExportGif, "Animated _GIF...");
        Add(export, CommandId.ExportMp4, "_MP4 Video...");
        Add(export, CommandId.ExportPng, "_PNG Image (current frame)...");
        Add(export, CommandId.ExportPngSequence, "PNG _Sequence...");
        Add(export, CommandId.ExportSpriteSheet, "S_prite Sheet...");
        return export;
    }

    private MenuItem BuildHelpMenu()
    {
        var help = TopMenu("_Help");
        Add(help, CommandId.ShowShortcuts, "_Keyboard Shortcuts", "keyboard");
        Add(help, CommandId.OpenFfmpegPage, "Get _FFmpeg (for MP4 export)");
        help.Items.Add(new Separator());
        Add(help, CommandId.About, "_About AnimDraw Studio", "info");
        return help;
    }

    // ===================================================================== keeping the menus truthful

    private void RefreshMenuStates()
    {
        var doc = _editor.Document;
        foreach (var (id, item) in _menuItems)
        {
            item.IsEnabled = CanRun(id);
            if (CheckableCommands.Contains(id)) item.IsChecked = IsChecked(id);
        }

        string? undo = doc.History.UndoName;
        string? redo = doc.History.RedoName;
        _undoItem.Header = undo != null ? "_Undo " + undo : "_Undo";
        _redoItem.Header = redo != null ? "_Redo " + redo : "_Redo";
        RebuildRecentMenu();
    }

    private void RebuildRecentMenu()
    {
        _recentItem.Items.Clear();
        // No file-system check here: asking about a file on a disconnected network drive can take many seconds, and this
        // runs every time a menu opens. A file that has gone is reported (and dropped from the list) when it is chosen.
        var recent = _editor.SettingsManager.GetRecent();
        if (recent.Count == 0)
        {
            _recentItem.Items.Add(new MenuItem { Header = new TextBlock { Text = "(no recent projects)" }, IsEnabled = false });
            return;
        }

        int number = 1;
        foreach (string path in recent)
        {
            string captured = path;
            var item = new MenuItem
            {
                Header = new TextBlock { Text = number + "   " + Path.GetFileNameWithoutExtension(path) },
                ToolTip = path
            };
            item.Click += async (_, _) =>
            {
                try
                {
                    await OpenRecentAsync(captured);
                }
                catch (Exception ex)
                {
                    ReportUnexpected("opening a recent project", ex);
                }
            };
            _recentItem.Items.Add(item);
            number++;
        }

        _recentItem.Items.Add(new Separator());
        var clear = new MenuItem { Header = new TextBlock { Text = "Clear this list" } };
        clear.Click += (_, _) => _editor.SettingsManager.ClearRecent();
        _recentItem.Items.Add(clear);
    }
}
