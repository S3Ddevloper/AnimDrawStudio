using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using AnimDraw.App.Services;

namespace AnimDraw.App.Windows;

/// <summary>
/// The shell of every dialog: a body above a row of buttons, centred on the main window, closing with Escape.
/// Derived dialogs fill the body and add their buttons.
/// </summary>
public class DialogWindow : AppWindow
{
    private readonly Grid _layout;
    private readonly StackPanel _buttons;
    private readonly Border _bar;
    private StackPanel? _leftHost;

    public DialogWindow(Window? owner, string title, bool resizable = false)
    {
        Title = title;
        ShowInTaskbar = false;
        ResizeMode = resizable ? ResizeMode.CanResize : ResizeMode.NoResize;
        SizeToContent = SizeToContent.WidthAndHeight;
        UseLayoutRounding = true;

        // An owner that was never shown (a dialog at start-up) cannot be used as an owner.
        if (owner != null && owner.IsLoaded && owner.IsVisible && new WindowInteropHelper(owner).Handle != IntPtr.Zero)
        {
            Owner = owner;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
        }
        else
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }

        _layout = new Grid();
        _layout.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        _layout.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        _buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(20, 12, 20, 16) };
        _bar = Ui.Box(ThemeKeys.Panel);
        _bar.Child = _buttons;
        Grid.SetRow(_bar, 1);
        _layout.Children.Add(_bar);

        Content = _layout;
    }

    /// <summary>Sets the main content of the dialog.</summary>
    protected void SetBody(UIElement body)
    {
        Grid.SetRow(body, 0);
        _layout.Children.Insert(0, body);
    }

    /// <summary>Adds a button to the right-hand end of the button row.</summary>
    protected Button AddButton(string text, Action? click = null, bool primary = false, bool isDefault = false, bool isCancel = false, double minWidth = 88)
    {
        var button = new Button { Content = text, MinWidth = minWidth, Margin = new Thickness(_buttons.Children.Count == 0 ? 0 : 8, 0, 0, 0), IsDefault = isDefault, IsCancel = isCancel };
        if (primary) Ui.ApplyStyle(button, ThemeKeys.PrimaryButtonStyle);
        if (click != null) button.Click += (_, _) => click();
        _buttons.Children.Add(button);
        return button;
    }

    /// <summary>Adds an element at the left-hand end of the button row (for example a "Reset" link).</summary>
    protected void AddLeftButton(UIElement element)
    {
        if (_leftHost == null)
        {
            // The first time something goes on the left, the bar becomes a grid with a left and a right part.
            var grid = Ui.MakeGrid("Auto,*");
            _leftHost = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(20, 12, 0, 16), VerticalAlignment = VerticalAlignment.Center };
            _bar.Child = null;
            _leftHost.Place(grid, 0, 0);
            _buttons.Place(grid, 0, 1);
            _bar.Child = grid;
        }
        _leftHost.Children.Add(element);
    }

    protected void Accept()
    {
        DialogResult = true;
    }

    protected override void OnPreviewKeyDown(KeyEventArgs e)
    {
        base.OnPreviewKeyDown(e);
        if (!e.Handled && e.Key == Key.Escape && !HasCancelButton())
        {
            e.Handled = true;
            DialogResult = false;
        }
    }

    private bool HasCancelButton()
    {
        foreach (UIElement child in _buttons.Children)
            if (child is Button { IsCancel: true }) return true;
        return false;
    }
}
