using System.IO;
using System.Windows;
using System.Windows.Threading;
using AnimDraw.App.Services;
using AnimDraw.Core.IO;
using AnimDraw.Core.Tools;

namespace AnimDraw.App.Windows;

public sealed partial class MainWindow
{
    private int _busyCount;
    private CancellationTokenSource? _busyCts;

    // ===================================================================== busy work

    /// <summary>
    /// Runs slow work (opening, saving) while the rest of the window ignores clicks and keys. A message with a progress
    /// bar appears when the work takes longer than a moment; Cancel stops it if the work allows that.
    /// </summary>
    private async Task RunBusyAsync(string message, bool cancellable, Func<IProgress<double>, CancellationToken, Task> work)
    {
        _busyCount++;
        _content.IsHitTestVisible = false;
        using var cts = new CancellationTokenSource();
        _busyCts = cts;

        var progress = new Progress<double>(fraction =>
        {
            if (_busyCts != cts) return;
            _overlay.SetProgress(fraction);
            _statusBar.SetProgress(fraction);
        });

        var delay = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(350) };
        delay.Tick += (_, _) =>
        {
            delay.Stop();
            if (_busyCts == cts) _overlay.Show(message, null, cancellable ? () => cts.Cancel() : null);
        };
        delay.Start();
        _statusBar.SetMessage(message);

        try
        {
            await work(progress, cts.Token);
        }
        finally
        {
            delay.Stop();
            _overlay.Hide();
            _statusBar.SetProgress(null);
            _busyCts = null;
            _busyCount--;
            if (_busyCount == 0) _content.IsHitTestVisible = true;
        }
    }

    private void CancelBusy() => _busyCts?.Cancel();

    // ===================================================================== unsaved changes

    /// <summary>
    /// Makes sure unsaved work is not lost before something replaces or closes the project. Returns false when the person
    /// cancelled (or the save failed) and the action must not go ahead.
    /// </summary>
    private async Task<bool> ConfirmDiscardAsync(string action)
    {
        if (!_editor.IsDirty) return true;
        InterruptPlayback();
        switch (MessageDialog.AskSave(this, _editor.DisplayName, action))
        {
            case SaveChoice.Save: return await SaveAsync();
            case SaveChoice.DontSave: return true;
            default: return false;
        }
    }

    // ===================================================================== new

    private async Task NewProjectAsync()
    {
        var dialog = new NewProjectDialog(this, _editor.Settings);
        if (dialog.ShowDialog() != true) return;
        if (!await ConfirmDiscardAsync("creating a new project")) return;

        try
        {
            _editor.NewProject(dialog.CanvasWidth, dialog.CanvasHeight, dialog.Fps, dialog.ProjectBackground);
        }
        catch (ArgumentOutOfRangeException ex)
        {
            MessageDialog.Error(this, "New project", "A project with that size cannot be created.", ex.Message);
            return;
        }

        // The choices become the starting values of the next new project.
        var settings = _editor.Settings;
        settings.NewProjectWidth = dialog.CanvasWidth;
        settings.NewProjectHeight = dialog.CanvasHeight;
        settings.NewProjectFps = dialog.Fps;
        settings.NewProjectBackground = Core.App.Editor.BackgroundToText(dialog.ProjectBackground);
        _editor.SettingsManager.Save(out _);
    }

    // ===================================================================== open

    private async Task OpenProjectAsync()
    {
        string? path = FileDialogs.OpenProject(this, _editor.Settings.LastProjectFolder);
        if (path == null) return;
        await OpenWithConfirmAsync(path);
    }

    private Task OpenRecentAsync(string path) => OpenWithConfirmAsync(path);

    private async Task OpenWithConfirmAsync(string path)
    {
        if (!File.Exists(path))
        {
            MessageDialog.Warn(this, "Open project", $"The file \"{Path.GetFileName(path)}\" could not be found. It may have been moved or deleted.");
            _editor.SettingsManager.RemoveRecent(path);
            return;
        }
        if (!await ConfirmDiscardAsync("opening another project")) return;
        await OpenPathAsync(path);
    }

    private async Task OpenPathAsync(string path)
    {
        InterruptPlayback();
        try
        {
            await RunBusyAsync($"Opening {Path.GetFileName(path)}...", cancellable: true,
                (progress, ct) => _editor.OpenAsync(path, progress, ct));
            _editor.Settings.LastProjectFolder = Path.GetDirectoryName(Path.GetFullPath(path));
        }
        catch (ProjectFileException ex)
        {
            MessageDialog.Error(this, "The project could not be opened", ex.Message, ex.InnerException?.Message);
            if (!File.Exists(path)) _editor.SettingsManager.RemoveRecent(path);
        }
        catch (OperationCanceledException)
        {
            _editor.Say("Opening was cancelled.");
        }
    }

    // ===================================================================== save

    /// <summary>Saves to the project's file, asking for one first when there is none. Returns true when the project is saved.</summary>
    private async Task<bool> SaveAsync() =>
        _editor.FilePath == null ? await SaveAsAsync() : await SaveToAsync(_editor.FilePath);

    private async Task<bool> SaveAsAsync()
    {
        string? folder = _editor.FilePath != null ? Path.GetDirectoryName(_editor.FilePath) : _editor.Settings.LastProjectFolder;
        string? path = FileDialogs.SaveProject(this, _editor.DisplayName, folder, _editor.FilePath);
        if (path == null) return false;
        return await SaveToAsync(path);
    }

    private async Task<bool> SaveToAsync(string path)
    {
        InterruptPlayback();
        _editor.Document.CommitActiveEdit();
        try
        {
            await RunBusyAsync($"Saving {Path.GetFileName(path)}...", cancellable: true,
                (progress, ct) => _editor.SaveAsync(path, progress, ct));
            if (_editor.FilePath != null) _editor.Settings.LastProjectFolder = Path.GetDirectoryName(_editor.FilePath);
            return true;
        }
        catch (ProjectFileException ex)
        {
            MessageDialog.Error(this, "The project could not be saved", ex.Message + "\n\nYour project is still open. Try saving it to another place.", ex.InnerException?.Message);
            return false;
        }
        catch (OperationCanceledException)
        {
            _editor.Say("Saving was cancelled.");
            return false;
        }
    }

    // ===================================================================== recovery and start-up

    private async Task RunStartupAsync()
    {
        if (_settingsProblem != null)
        {
            MessageDialog.Warn(this, "Settings",
                "Your settings could not be read, so the standard settings are used. Your projects are not affected.", _settingsProblem);
        }

        if (_recoverable.Count > 0) await OfferRecoveryAsync(_recoverable);

        if (_startupFile != null) await OpenWithConfirmAsync(_startupFile);

        try
        {
            // Recovery copies nobody asked for in a month are not coming back.
            _editor.Recovery.PurgeOld(TimeSpan.FromDays(30));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            // The recovery folder is not essential; leave it alone.
        }
    }

    private async Task OfferRecoveryAsync(IReadOnlyList<RecoveryEntry> entries)
    {
        var dialog = new RecoveryDialog(this, entries);
        dialog.ShowDialog();
        if (dialog.Chosen is not RecoveryEntry entry) return;

        try
        {
            var loaded = RecoveryManager.Open(entry);
            _editor.AdoptRecovered(loaded, entry.OriginalPath);

            // Keep the old copy until this session has written a copy of its own, so a second crash loses nothing.
            if (await _editor.AutosaveIfNeededAsync()) RecoveryManager.Discard(entry);
        }
        catch (ProjectFileException ex)
        {
            MessageDialog.Error(this, "Recovery", "That recovery copy could not be opened. It may be damaged.", ex.Message);
        }
    }

    // ===================================================================== pictures

    private void ImportPicture(string path)
    {
        InterruptPlayback();
        var picture = BitmapBridge.LoadPicture(path);
        if (picture == null)
        {
            MessageDialog.Warn(this, "Picture", $"The picture \"{Path.GetFileName(path)}\" could not be read. It may not be a picture, or it is too large.");
            return;
        }
        var centre = _canvas.VisibleCenter();
        if (_editor.Paste(picture, (int)Math.Round(centre.X), (int)Math.Round(centre.Y)) &&
            _editor.Tools.CurrentKind is not (ToolKind.Move or ToolKind.Select))
        {
            _editor.Tools.Select(ToolKind.Move);
        }
    }
}
