using System.Windows;
using System.Windows.Controls;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Model;

namespace AnimDraw.App.Windows;

/// <summary>How many earlier and later frames are shown faintly behind the drawing, and how strongly.</summary>
public sealed class OnionSkinDialog : DialogWindow
{
    private readonly CheckBox _enabled = new() { Content = "Show onion skin" };
    private readonly CheckBox _colorize = new() { Content = "Tint earlier frames red and later frames blue" };
    private readonly SliderField _previous;
    private readonly SliderField _next;
    private readonly SliderField _opacity;

    public OnionSkinDialog(Window owner, Document document) : base(owner, "Onion Skin")
    {
        var current = document.Project.Onion;
        Result = current.Clone();

        _enabled.IsChecked = current.Enabled;
        _colorize.IsChecked = current.Colorize;
        _previous = new SliderField("Earlier frames", 0, ProjectLimits.MaxOnionFrames, current.PreviousFrames, 0, sliderWidth: 150, labelWidth: 110,
            tip: "How many frames before the current one are shown.");
        _next = new SliderField("Later frames", 0, ProjectLimits.MaxOnionFrames, current.NextFrames, 0, sliderWidth: 150, labelWidth: 110,
            tip: "How many frames after the current one are shown.");
        _opacity = new SliderField("Strength", 5, 90, current.Opacity * 100, 0, "%", sliderWidth: 150, labelWidth: 110,
            tip: "How visible the neighbouring frames are. They fade the further away they are.");

        var form = new FormGrid { Margin = new Thickness(26, 22, 26, 10) };
        form.AddFull(_enabled);
        form.AddFull(_previous, top: 8);
        form.AddFull(_next);
        form.AddFull(_opacity);
        form.AddFull(_colorize, top: 8);
        form.AddHint("Onion skin shows the drawings of neighbouring frames as faint ghosts so you can line up the next drawing with the last. It is only a help for drawing: it does not appear in exported files or in playback.", 400);
        SetBody(form);

        AddButton("OK", OnOk, primary: true, isDefault: true);
        AddButton("Cancel", isCancel: true);
    }

    /// <summary>The settings chosen. Valid after the dialog was accepted.</summary>
    public OnionSkinSettings Result { get; private set; }

    private void OnOk()
    {
        Result = new OnionSkinSettings
        {
            Enabled = _enabled.IsChecked == true,
            PreviousFrames = (int)Math.Round(_previous.Value),
            NextFrames = (int)Math.Round(_next.Value),
            Opacity = _opacity.Value / 100,
            Colorize = _colorize.IsChecked == true
        };
        Result.Normalize();
        Accept();
    }
}
