using System.IO;
using System.Windows;
using System.Windows.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.IO;

namespace AnimDraw.App.Windows;

/// <summary>
/// Offered at start-up when an earlier session ended without saving (a crash, a power cut). The person picks which
/// recovery copy to open, throws copies away, or leaves them for later.
/// </summary>
public sealed class RecoveryDialog : DialogWindow
{
    private readonly List<RecoveryEntry> _entries;
    private readonly ListBox _list = new() { Width = 480, Height = 190 };
    private readonly Button _recover;
    private readonly Button _discard;

    public RecoveryDialog(Window? owner, IReadOnlyList<RecoveryEntry> entries) : base(owner, "Recover unsaved work")
    {
        _entries = entries.ToList();

        var body = new StackPanel { Margin = new Thickness(26, 22, 26, 10) };
        body.Children.Add(Ui.Wrapped(
            _entries.Count == 1
                ? "AnimDraw Studio did not close properly last time, and a backup of unsaved work was kept."
                : "AnimDraw Studio did not close properly last time, and backups of unsaved work were kept.",
            maxWidth: 480));
        var hint = Ui.Wrapped("Choose one to open it. It opens as a new, unsaved project, so nothing you saved before is changed.", dim: true, maxWidth: 480);
        hint.Margin = new Thickness(0, 6, 0, 12);
        body.Children.Add(hint);
        body.Children.Add(_list);
        SetBody(body);

        _recover = AddButton("Recover", Recover, primary: true, isDefault: true);
        _discard = AddButton("Delete this backup", Discard);
        AddButton("Not now", isCancel: true);

        _list.SelectionChanged += (_, _) => UpdateButtons();
        _list.MouseDoubleClick += (_, _) =>
        {
            if (_list.SelectedIndex >= 0) Recover();
        };
        Fill();
    }

    /// <summary>The backup the person chose to open, or null.</summary>
    public RecoveryEntry? Chosen { get; private set; }

    private void Fill()
    {
        _list.Items.Clear();
        foreach (var entry in _entries)
        {
            var line = new StackPanel { Margin = new Thickness(6, 4, 6, 4) };
            line.Children.Add(Ui.Label(entry.ProjectName, bold: true));
            string when = entry.SavedUtc.ToLocalTime().ToString("dddd d MMMM yyyy, HH:mm", System.Globalization.CultureInfo.CurrentCulture);
            line.Children.Add(Ui.Label("Backed up " + when, dim: true));
            string where = entry.OriginalPath != null
                ? "From: " + entry.OriginalPath
                : "A project that was never saved";
            var origin = Ui.Label(where, dim: true);
            origin.FontSize = 11;
            origin.TextTrimming = TextTrimming.CharacterEllipsis;
            line.Children.Add(origin);
            _list.Items.Add(new ListBoxItem { Content = line, ToolTip = entry.OriginalPath ?? entry.DataPath });
        }
        if (_list.Items.Count > 0) _list.SelectedIndex = 0;
        UpdateButtons();
    }

    private void UpdateButtons()
    {
        bool any = _list.SelectedIndex >= 0 && _list.SelectedIndex < _entries.Count;
        _recover.IsEnabled = any;
        _discard.IsEnabled = any;
    }

    private void Recover()
    {
        int index = _list.SelectedIndex;
        if (index < 0 || index >= _entries.Count) return;
        Chosen = _entries[index];
        Accept();
    }

    private void Discard()
    {
        int index = _list.SelectedIndex;
        if (index < 0 || index >= _entries.Count) return;
        var entry = _entries[index];
        if (!MessageDialog.Confirm(this, "Delete backup",
                $"Delete the backup of \"{entry.ProjectName}\" for good? It cannot be brought back.", "Delete", "Keep", MessageKind.Warning))
            return;

        try
        {
            RecoveryManager.Discard(entry);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            MessageDialog.Warn(this, "Delete backup", "The backup could not be deleted.", ex.Message);
            return;
        }
        _entries.RemoveAt(index);
        Fill();
        if (_entries.Count == 0) DialogResult = false;
    }
}
