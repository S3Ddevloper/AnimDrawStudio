using System.Windows;
using System.Windows.Media;
using AnimDraw.App.Services;

namespace AnimDraw.App.Windows;

/// <summary>The base of every window: themed colours and font, a dark title bar when the theme is dark, crisp text.</summary>
public class AppWindow : Window
{
    public AppWindow()
    {
        SetResourceReference(BackgroundProperty, "Brush.Window");
        SetResourceReference(ForegroundProperty, "Brush.Text");
        FontFamily = new FontFamily("Segoe UI");
        FontSize = 12.5;
        UseLayoutRounding = true;
        TextOptions.SetTextFormattingMode(this, TextFormattingMode.Display);
        SourceInitialized += (_, _) => ThemeManager.ApplyWindowChrome(this);
        ThemeManager.ThemeChanged += OnThemeChanged;
        Closed += (_, _) => ThemeManager.ThemeChanged -= OnThemeChanged;
    }

    private void OnThemeChanged() => ThemeManager.ApplyWindowChrome(this);
}
