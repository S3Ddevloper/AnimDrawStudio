using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Model;

namespace AnimDraw.App.Windows;

/// <summary>Frame rate, looping, background and canvas size of the open project.</summary>
public sealed class ProjectSettingsDialog : DialogWindow
{
    private readonly Document _document;
    private readonly NumberField _fps;
    private readonly CheckBox _loop = new() { Content = "Repeat the animation when it reaches the end" };
    private readonly BackgroundPicker _background;
    private readonly NumberField _width;
    private readonly NumberField _height;
    private readonly RadioButton _crop = new() { Content = "Keep the drawings the same size (crop or add empty space)", GroupName = "resize" };
    private readonly RadioButton _scale = new() { Content = "Scale the drawings to the new size", GroupName = "resize" };
    private readonly RadioButton[,] _anchor = new RadioButton[3, 3];
    private readonly StackPanel _resizeOptions = new();
    private readonly TextBlock _info;
    private readonly Button _ok;

    public ProjectSettingsDialog(Window owner, Document document) : base(owner, "Project Settings")
    {
        _document = document;
        var project = document.Project;

        _fps = new NumberField(project.Fps, ProjectLimits.MinFps, ProjectLimits.MaxFps, decimals: 2, width: 76) { TrimZeros = true };
        _background = new BackgroundPicker(project.Background);
        _width = new NumberField(project.Width, ProjectLimits.MinDimension, ProjectLimits.MaxDimension, width: 76);
        _height = new NumberField(project.Height, ProjectLimits.MinDimension, ProjectLimits.MaxDimension, width: 76);
        _loop.IsChecked = project.Loop;
        _crop.IsChecked = true;

        var form = new FormGrid { Margin = new Thickness(26, 22, 26, 10) };

        form.AddSection("Animation");
        var fpsRow = new StackPanel { Orientation = Orientation.Horizontal };
        fpsRow.Children.Add(_fps.Box);
        var unit = Ui.Label("frames per second", dim: true);
        unit.Margin = new Thickness(8, 0, 0, 0);
        fpsRow.Children.Add(unit);
        form.AddRow("Frame rate", fpsRow);
        form.AddFull(_loop);

        form.AddSection("Background");
        form.AddRow("Behind the artwork", _background);

        form.AddSection("Canvas size");
        var sizeRow = new StackPanel { Orientation = Orientation.Horizontal };
        sizeRow.Children.Add(_width.Box);
        var by = Ui.Label("×", dim: true);
        by.Margin = new Thickness(8, 0, 8, 0);
        sizeRow.Children.Add(by);
        sizeRow.Children.Add(_height.Box);
        var px = Ui.Label("pixels", dim: true);
        px.Margin = new Thickness(8, 0, 0, 0);
        sizeRow.Children.Add(px);
        form.AddRow("Width × height", sizeRow, "Changing the size can be undone with Ctrl+Z.");

        _resizeOptions.Children.Add(_crop);
        _resizeOptions.Children.Add(_scale);
        var anchorLabel = Ui.Label("When the canvas is cropped or extended, the drawings stay at:", dim: true);
        anchorLabel.Margin = new Thickness(0, 8, 0, 4);
        _resizeOptions.Children.Add(anchorLabel);
        _resizeOptions.Children.Add(BuildAnchorGrid());
        form.AddFull(_resizeOptions);

        _info = Ui.Wrapped("", dim: true, maxWidth: 440);
        _info.FontSize = 11.5;
        form.AddFull(_info, top: 8);
        SetBody(form);

        _ok = AddButton("OK", () => Accept(), primary: true, isDefault: true);
        AddButton("Cancel", isCancel: true);

        _width.ValueChanged += _ => UpdateResizeState();
        _height.ValueChanged += _ => UpdateResizeState();
        _crop.Checked += (_, _) => UpdateResizeState();
        _scale.Checked += (_, _) => UpdateResizeState();
        UpdateResizeState();
    }

    public double Fps => ProjectLimits.ClampFps(_fps.Value);
    public bool Loop => _loop.IsChecked == true;
    public BackgroundSettings ProjectBackground => _background.Value;
    public int NewWidth => _width.IntValue;
    public int NewHeight => _height.IntValue;
    public CanvasResizeMode CanvasResize => _scale.IsChecked == true ? CanvasResizeMode.ScaleContent : CanvasResizeMode.CropOrExtend;

    /// <summary>0, 1, 2 = left, middle, right.</summary>
    public int AnchorX
    {
        get
        {
            for (int y = 0; y < 3; y++)
                for (int x = 0; x < 3; x++)
                    if (_anchor[x, y].IsChecked == true) return x;
            return 1;
        }
    }

    /// <summary>0, 1, 2 = top, middle, bottom.</summary>
    public int AnchorY
    {
        get
        {
            for (int y = 0; y < 3; y++)
                for (int x = 0; x < 3; x++)
                    if (_anchor[x, y].IsChecked == true) return y;
            return 1;
        }
    }

    private UIElement BuildAnchorGrid()
    {
        var grid = new Grid { HorizontalAlignment = HorizontalAlignment.Left };
        for (int i = 0; i < 3; i++)
        {
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(26) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(24) });
        }
        string[] names = { "top left", "top", "top right", "left", "centre", "right", "bottom left", "bottom", "bottom right" };
        for (int y = 0; y < 3; y++)
        {
            for (int x = 0; x < 3; x++)
            {
                var radio = new RadioButton
                {
                    GroupName = "anchor",
                    IsChecked = x == 1 && y == 1,
                    ToolTip = "Keep the drawings at the " + names[y * 3 + x],
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                };
                _anchor[x, y] = radio;
                Grid.SetColumn(radio, x);
                Grid.SetRow(radio, y);
                grid.Children.Add(radio);
            }
        }
        return grid;
    }

    private void UpdateResizeState()
    {
        int w = _width.IntValue;
        int h = _height.IntValue;
        bool changed = w != _document.CanvasWidth || h != _document.CanvasHeight;
        _resizeOptions.IsEnabled = changed;
        foreach (var radio in _anchor) radio.IsEnabled = changed && _crop.IsChecked == true;

        string key = ThemeKeys.TextDim;
        string text = "";
        bool valid = ProjectLimits.IsValidSize(w, h, out string? problem);
        if (!valid)
        {
            text = problem ?? "That size is not possible.";
            key = ThemeKeys.Danger;
        }
        else if (changed)
        {
            bool shrinks = w < _document.CanvasWidth || h < _document.CanvasHeight;
            if (_crop.IsChecked == true && shrinks)
            {
                text = "Parts of the drawings outside the new, smaller canvas are removed. You can undo this.";
                key = ThemeKeys.Warning;
            }
            else
            {
                text = string.Format(CultureInfo.CurrentCulture, "The canvas becomes {0} × {1} pixels on every layer and frame.", w, h);
            }
            if ((long)w * h > ProjectLimits.WarnPixels)
            {
                text += " This is a very large canvas and will need a lot of memory.";
                key = ThemeKeys.Warning;
            }
        }
        _info.Text = text;
        _info.SetResourceReference(TextBlock.ForegroundProperty, key);
        _ok.IsEnabled = valid;
    }
}
