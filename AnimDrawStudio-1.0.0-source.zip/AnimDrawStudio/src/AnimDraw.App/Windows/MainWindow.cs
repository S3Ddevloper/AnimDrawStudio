using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Threading;
using AnimDraw.App.Controls;
using AnimDraw.App.Panels;
using AnimDraw.App.Services;
using AnimDraw.Core.App;
using AnimDraw.Core.Editing;
using AnimDraw.Core.IO;
using AnimDraw.Core.Tools;

namespace AnimDraw.App.Windows;

/// <summary>
/// The program's main window: menu bar, tool palette, tool options, canvas, timeline, colour and layer panels and the
/// status bar. It builds them, forwards keyboard shortcuts and menu choices to <see cref="Run"/>, and keeps the title,
/// status bar and autosave in step with the project. The drawing and animation logic lives in the engine.
/// </summary>
public sealed partial class MainWindow : AppWindow
{
    private const ModifierKeys CommandModifiers = ModifierKeys.Control | ModifierKeys.Shift | ModifierKeys.Alt;

    private readonly Editor _editor;
    private readonly ShortcutMap _shortcuts = ShortcutMap.CreateDefault();
    private readonly Dictionary<(Key Key, ModifierKeys Modifiers), CommandId> _gestures = new();
    private readonly IReadOnlyList<RecoveryEntry> _recoverable;
    private readonly string? _startupFile;
    private readonly string? _settingsProblem;

    private readonly CanvasView _canvas = new();
    private readonly ToolPalette _toolPalette;
    private readonly ToolOptionsBar _optionsBar;
    private readonly ColorPanel _colorPanel;
    private readonly LayersPanel _layersPanel;
    private readonly TimelinePanel _timelinePanel;
    private readonly StatusBarPanel _statusBar;
    private readonly BusyOverlay _overlay = new();
    private readonly DispatcherTimer _autosaveTimer = new();

    private Grid _content = null!;
    private ColumnDefinition _rightColumn = null!;
    private RowDefinition _timelineRow = null!;
    private RowDefinition _colorRow = null!;

    private Document? _watched;
    private bool _closeApproved;
    private bool _closeCheckRunning;
    private bool _startupDone;
    private bool _autosaveRunning;

    public MainWindow(Editor editor, string? startupFile, IReadOnlyList<RecoveryEntry> recoverable, string? settingsProblem)
    {
        _editor = editor;
        _startupFile = startupFile;
        _recoverable = recoverable;
        _settingsProblem = settingsProblem;

        Title = AppInfo.Name;
        MinWidth = 960;
        MinHeight = 620;
        AllowDrop = true;

        BuildGestureTable();

        _toolPalette = new ToolPalette(editor, _shortcuts);
        _optionsBar = new ToolOptionsBar(editor, Run);
        _colorPanel = new ColorPanel(editor);
        _layersPanel = new LayersPanel(editor, _shortcuts, Run);
        _timelinePanel = new TimelinePanel(editor, _shortcuts, Run);
        _statusBar = new StatusBarPanel(() => _canvas.ZoomOut(), () => _canvas.ZoomIn(), ZoomPreset);
        _canvas.Attach(editor);
        _canvas.ShowPixelGrid = editor.Settings.ShowPixelGrid;

        BuildMenu();
        Content = BuildLayout();
        ApplyWindowPlacement();
        ConnectEvents();

        WatchDocument();
        RefreshAllStatus();
    }

    // ===================================================================== layout

    private UIElement BuildLayout()
    {
        var settings = _editor.Settings;

        _content = Ui.MakeGrid("*", "Auto,*,Auto");

        var menuBar = Ui.Box(ThemeKeys.Panel, ThemeKeys.Border, new Thickness(0, 0, 0, 1));
        menuBar.Child = _menu;
        menuBar.Place(_content, 0, 0);

        // tools | centre | splitter | right-hand panels
        var workspace = Ui.MakeGrid("Auto,*,5,Auto", "*");
        _rightColumn = workspace.ColumnDefinitions[3];
        _rightColumn.Width = new GridLength(Math.Clamp(settings.RightPanelWidth, 220, 560));
        _rightColumn.MinWidth = 220;
        _rightColumn.MaxWidth = 560;
        workspace.Place(_content, 1, 0);

        _toolPalette.Place(workspace, 0, 0);

        // options bar / canvas / splitter / timeline
        var centre = Ui.MakeGrid("*", "Auto,*,5,Auto");
        _timelineRow = centre.RowDefinitions[3];
        _timelineRow.Height = new GridLength(Math.Clamp(settings.TimelineHeight, 150, 600));
        _timelineRow.MinHeight = 150;
        centre.RowDefinitions[1].MinHeight = 140;
        _optionsBar.Place(centre, 0, 0);

        var canvasHost = Ui.Box(ThemeKeys.Workspace);
        canvasHost.ClipToBounds = true;
        canvasHost.Child = _canvas;
        canvasHost.Place(centre, 1, 0);

        new GridSplitter
        {
            Height = 5,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Stretch,
            ResizeDirection = GridResizeDirection.Rows,
            ResizeBehavior = GridResizeBehavior.PreviousAndNext,
            Focusable = false,
            ToolTip = "Drag to make the timeline taller or shorter"
        }.Place(centre, 2, 0);
        _timelinePanel.Place(centre, 3, 0);
        centre.Place(workspace, 0, 1);

        new GridSplitter
        {
            Width = 5,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Stretch,
            ResizeDirection = GridResizeDirection.Columns,
            ResizeBehavior = GridResizeBehavior.PreviousAndNext,
            Focusable = false,
            ToolTip = "Drag to make the side panels wider or narrower"
        }.Place(workspace, 0, 2);

        // colour panel above the layers
        var right = Ui.MakeGrid("*", "340,5,*");
        _colorRow = right.RowDefinitions[0];
        _colorRow.MinHeight = 140;
        right.RowDefinitions[2].MinHeight = 140;
        _colorPanel.Place(right, 0, 0);
        new GridSplitter
        {
            Height = 5,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Stretch,
            ResizeDirection = GridResizeDirection.Rows,
            ResizeBehavior = GridResizeBehavior.PreviousAndNext,
            Focusable = false,
            ToolTip = "Drag to give the colour panel or the layers more room"
        }.Place(right, 1, 0);
        _layersPanel.Place(right, 2, 0);
        right.Place(workspace, 0, 3);

        _statusBar.Place(_content, 2, 0);

        var outer = new Grid();
        outer.Children.Add(_content);
        outer.Children.Add(_overlay);
        return outer;
    }

    private void ApplyWindowPlacement()
    {
        var saved = _editor.Settings.Window;
        double left = SystemParameters.VirtualScreenLeft;
        double top = SystemParameters.VirtualScreenTop;
        double width = SystemParameters.VirtualScreenWidth;
        double height = SystemParameters.VirtualScreenHeight;

        Width = Math.Min(saved.Width, width);
        Height = Math.Min(saved.Height, height);

        // Only restore the old position when enough of the window would still be on a screen.
        bool onScreen = !double.IsNaN(saved.Left) && !double.IsNaN(saved.Top) &&
                        saved.Left + 120 < left + width && saved.Left + Width - 120 > left &&
                        saved.Top >= top - 4 && saved.Top + 80 < top + height;
        if (onScreen)
        {
            WindowStartupLocation = WindowStartupLocation.Manual;
            Left = saved.Left;
            Top = saved.Top;
        }
        else
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }
        if (saved.Maximized) WindowState = WindowState.Maximized;
    }

    private void SaveWindowState()
    {
        var settings = _editor.Settings;
        Rect bounds = WindowState == WindowState.Normal ? new Rect(Left, Top, Width, Height) : RestoreBounds;
        if (!bounds.IsEmpty && bounds.Width > 0 && bounds.Height > 0)
        {
            settings.Window.Left = bounds.Left;
            settings.Window.Top = bounds.Top;
            settings.Window.Width = bounds.Width;
            settings.Window.Height = bounds.Height;
        }
        settings.Window.Maximized = WindowState == WindowState.Maximized;
        if (_rightColumn.ActualWidth > 0) settings.RightPanelWidth = _rightColumn.ActualWidth;
        if (_timelineRow.ActualHeight > 0) settings.TimelineHeight = _timelineRow.ActualHeight;
        settings.ShowPixelGrid = _canvas.ShowPixelGrid;
    }

    // ===================================================================== wiring

    private void ConnectEvents()
    {
        _editor.DocumentReplaced += OnDocumentReplaced;
        _editor.FileStateChanged += OnFileStateChanged;
        _editor.Status += OnEditorStatus;
        _editor.SettingsManager.Changed += OnSettingsChanged;

        _canvas.ViewChanged += () => _statusBar.SetZoom(_canvas.ZoomText);
        _canvas.PointerCanvasMoved += p => _statusBar.SetCursor(p);
        _canvas.PlaybackInterrupted += EndPlaybackUi;

        _autosaveTimer.Tick += OnAutosaveTick;

        SourceInitialized += (_, _) => ConfigureAutosave();
        Loaded += OnWindowLoaded;
        ContentRendered += OnContentRendered;
    }

    private void OnWindowLoaded(object sender, RoutedEventArgs e)
    {
        // Give the colour panel the height it needs, as far as the window allows.
        _colorPanel.Measure(new Size(Math.Max(220, _rightColumn.ActualWidth), double.PositiveInfinity));
        double wanted = _colorPanel.DesiredSize.Height + 2;
        double available = Math.Max(300, _content.ActualHeight - 120);
        _colorRow.Height = new GridLength(Math.Clamp(Math.Min(wanted, available * 0.6), 160, 520));
        _statusBar.SetZoom(_canvas.ZoomText);
    }

    private async void OnContentRendered(object? sender, EventArgs e)
    {
        if (_startupDone) return;
        _startupDone = true;
        try
        {
            await RunStartupAsync();
        }
        catch (Exception ex)
        {
            ReportUnexpected("starting up", ex);
        }
    }

    private void OnEditorStatus(string message) => _statusBar.SetMessage(message);

    private void OnSettingsChanged()
    {
        // Recent projects changed: the File menu is rebuilt when it opens, nothing to do here.
    }

    private void OnFileStateChanged()
    {
        UpdateTitle();
        _statusBar.SetSaved(_editor.IsDirty);
    }

    private void OnDocumentReplaced()
    {
        WatchDocument();
        EndPlaybackUi();
        RefreshAllStatus();
    }

    private void WatchDocument()
    {
        if (_watched != null) _watched.Changed -= OnDocumentChanged;
        _watched = _editor.Document;
        _watched.Changed += OnDocumentChanged;
    }

    private void OnDocumentChanged(object? sender, DocumentChangedEventArgs e)
    {
        // While playing, the frame readouts belong to playback, but the title and the saved state still have to follow
        // edits made meanwhile (switching Loop on, or changing the speed of the animation).
        const ChangeKind frameInfo = ChangeKind.Frame | ChangeKind.Structure | ChangeKind.Settings;
        if (!_editor.IsPlaying && (e.Kind & frameInfo) != 0) UpdateFrameStatus();
        UpdateTitle();
        _statusBar.SetSaved(_editor.IsDirty);
    }

    private void RefreshAllStatus()
    {
        var doc = _editor.Document;
        _statusBar.SetCanvasSize(doc.CanvasWidth, doc.CanvasHeight);
        _statusBar.SetZoom(_canvas.ZoomText);
        UpdateFrameStatus();
        UpdateTitle();
        _statusBar.SetSaved(_editor.IsDirty);
    }

    private void UpdateFrameStatus()
    {
        var doc = _editor.Document;
        _statusBar.SetFrame(doc.CurrentFrame + 1, doc.FrameCount);
        _statusBar.SetFps(doc.Project.Fps);
        _statusBar.SetCanvasSize(doc.CanvasWidth, doc.CanvasHeight);
    }

    private void UpdateTitle()
    {
        string title = (_editor.IsDirty ? "*" : "") + _editor.DisplayName + " - " + AppInfo.Name;
        if (Title != title) Title = title;
    }

    private void ZoomPreset(double? zoom)
    {
        if (zoom is double z) _canvas.ZoomCenter(z);
        else _canvas.ZoomFit();
    }

    // ===================================================================== autosave

    private void ConfigureAutosave()
    {
        _autosaveTimer.Stop();
        int minutes = _editor.Settings.AutosaveMinutes;
        if (minutes <= 0) return;
        _autosaveTimer.Interval = TimeSpan.FromMinutes(minutes);
        _autosaveTimer.Start();
    }

    private async void OnAutosaveTick(object? sender, EventArgs e)
    {
        if (_autosaveRunning || _busyCount > 0) return;
        _autosaveRunning = true;
        try
        {
            await _editor.AutosaveIfNeededAsync();
        }
        catch (Exception ex)
        {
            // A failed autosave must never interrupt the person's work; the details go to the log.
            CrashLog.Write("Autosave failed", ex);
        }
        finally
        {
            _autosaveRunning = false;
        }
    }

    // ===================================================================== keyboard

    private void BuildGestureTable()
    {
        foreach (var (id, gesture) in _shortcuts.AllBindings())
        {
            // Alt+F4 is left to Windows, which closes the window and so reaches OnClosing like every other way out.
            if (id == CommandId.Exit) continue;
            if (!Enum.TryParse(gesture.Key, out Key key)) continue;
            ModifierKeys modifiers = ModifierKeys.None;
            if (gesture.Ctrl) modifiers |= ModifierKeys.Control;
            if (gesture.Shift) modifiers |= ModifierKeys.Shift;
            if (gesture.Alt) modifiers |= ModifierKeys.Alt;
            _gestures[(key, modifiers)] = id;
        }
    }

    private static bool IsTextInputFocused() =>
        Keyboard.FocusedElement is TextBoxBase or PasswordBox or ComboBox { IsEditable: true };

    /// <summary>True when the keyboard focus is on a menu or one of its items (the menu bar, a drop-down or a context menu).</summary>
    private static bool IsKeyboardInMenu()
    {
        DependencyObject? element = Keyboard.FocusedElement as DependencyObject;
        for (int depth = 0; element != null && depth < 64; depth++)
        {
            if (element is MenuBase or MenuItem) return true;
            element = LogicalTreeHelper.GetParent(element) ??
                      (element is System.Windows.Media.Visual ? System.Windows.Media.VisualTreeHelper.GetParent(element) : null);
        }
        return false;
    }

    /// <summary>While someone types in a number box, only shortcuts that cannot be text editing keys still work.</summary>
    private static bool AllowedWhileTyping(Key key, ModifierKeys modifiers)
    {
        if (key is >= Key.F1 and <= Key.F12) return true;
        if ((modifiers & ModifierKeys.Control) == 0) return false;
        return key is not (Key.A or Key.C or Key.V or Key.X or Key.Y or Key.Z or Key.Delete or Key.Back);
    }

    protected override void OnPreviewKeyDown(KeyEventArgs e)
    {
        base.OnPreviewKeyDown(e);
        if (e.Handled) return;

        Key key = e.Key switch
        {
            Key.System => e.SystemKey,
            Key.ImeProcessed => e.ImeProcessedKey,
            Key.DeadCharProcessed => e.DeadCharProcessedKey,
            _ => e.Key
        };
        if (key is Key.None or Key.LeftCtrl or Key.RightCtrl or Key.LeftShift or Key.RightShift
            or Key.LeftAlt or Key.RightAlt or Key.LWin or Key.RWin) return;

        // While a menu has the keyboard (an open drop-down, or the menu bar after pressing Alt) its own keys come first:
        // Enter runs the highlighted item, letters are access keys, Escape closes it. Shortcuts would take those keys away.
        if (IsKeyboardInMenu()) return;

        if (_busyCount > 0)
        {
            if (key == Key.Escape) CancelBusy();
            if (e.Key != Key.System) e.Handled = true;
            return;
        }

        ModifierKeys modifiers = Keyboard.Modifiers & CommandModifiers;
        bool typing = IsTextInputFocused();

        if (key == Key.Space && modifiers == ModifierKeys.None && !typing)
        {
            _canvas.SpaceHeld = true;
            e.Handled = true;
            return;
        }

        if (_gestures.TryGetValue((key, modifiers), out CommandId id))
        {
            if (typing && !AllowedWhileTyping(key, modifiers)) return;
            e.Handled = true;
            Run(id);
            return;
        }

        if (typing) return;

        if (key == Key.Escape && modifiers == ModifierKeys.None)
        {
            e.Handled = HandleEscape();
            return;
        }

        if (key is Key.Left or Key.Right or Key.Up or Key.Down &&
            (modifiers == ModifierKeys.None || modifiers == ModifierKeys.Shift) && _canvas.IsKeyboardFocused)
        {
            e.Handled = HandleArrow(key, big: modifiers == ModifierKeys.Shift);
        }
    }

    protected override void OnPreviewKeyUp(KeyEventArgs e)
    {
        base.OnPreviewKeyUp(e);
        if (e.Key == Key.Space) _canvas.SpaceHeld = false;

        // Pressing and releasing Alt on its own would move the focus into the menu bar. Over the canvas Alt is a drawing
        // modifier (zoom out, copy while moving), so it must not do that.
        if (e.Key == Key.System && e.SystemKey is Key.LeftAlt or Key.RightAlt && _canvas.IsMouseOver) e.Handled = true;
    }

    protected override void OnDeactivated(EventArgs e)
    {
        base.OnDeactivated(e);
        _canvas.SpaceHeld = false;
    }

    private bool HandleEscape()
    {
        if (_editor.IsPlaying)
        {
            Run(CommandId.StopPlayback);
            return true;
        }
        if (_editor.Tools.IsDrawing)
        {
            _editor.Tools.Cancel();
            return true;
        }
        if (_editor.Document.Selection != null)
        {
            _editor.Document.Deselect();
            return true;
        }
        return false;
    }

    private bool HandleArrow(Key key, bool big)
    {
        var doc = _editor.Document;
        int step = big ? 10 : 1;
        int dx = key == Key.Left ? -step : key == Key.Right ? step : 0;
        int dy = key == Key.Up ? -step : key == Key.Down ? step : 0;

        if (doc.Selection != null || _editor.Tools.CurrentKind == ToolKind.Move)
        {
            InterruptPlayback();
            if (_editor.Tools.IsDrawing) return true;
            if (!LayerEditable()) return true;
            if (!doc.NudgeSelection(dx, dy)) _editor.Say("There is nothing to move here.");
            return true;
        }

        if (dy == 0)
        {
            Run(dx < 0 ? CommandId.PreviousFrame : CommandId.NextFrame);
            return true;
        }

        // Up and Down do nothing on the canvas. They are still consumed here: left alone, Windows would use them to move the
        // keyboard focus to a neighbouring control, and the canvas would stop receiving the frame and tool shortcuts.
        return true;
    }

    // ===================================================================== drag and drop

    private static readonly string[] PictureExtensions = { ".png", ".jpg", ".jpeg", ".bmp", ".gif" };

    private static IReadOnlyList<string> DroppedFiles(DragEventArgs e)
    {
        if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return Array.Empty<string>();
        if (e.Data.GetData(DataFormats.FileDrop) is not string[] files) return Array.Empty<string>();
        return files
            .Where(f =>
            {
                string ext = Path.GetExtension(f);
                return ext.Equals(ProjectFileFormat.Extension, StringComparison.OrdinalIgnoreCase) ||
                       PictureExtensions.Contains(ext, StringComparer.OrdinalIgnoreCase);
            })
            .ToList();
    }

    protected override void OnDragOver(DragEventArgs e)
    {
        base.OnDragOver(e);
        e.Effects = _busyCount == 0 && DroppedFiles(e).Count > 0 ? DragDropEffects.Copy : DragDropEffects.None;
        e.Handled = true;
    }

    protected override async void OnDrop(DragEventArgs e)
    {
        base.OnDrop(e);
        e.Handled = true;
        if (_busyCount > 0) return;
        var files = DroppedFiles(e);
        if (files.Count == 0) return;
        string file = files[0];
        try
        {
            if (Path.GetExtension(file).Equals(ProjectFileFormat.Extension, StringComparison.OrdinalIgnoreCase))
                await OpenWithConfirmAsync(file);
            else
                ImportPicture(file);
        }
        catch (Exception ex)
        {
            ReportUnexpected("opening the dropped file", ex);
        }
    }

    // ===================================================================== closing

    protected override void OnClosing(CancelEventArgs e)
    {
        base.OnClosing(e);
        if (_closeApproved) return;

        // Every way of closing (the X button, Alt+F4, File > Exit) lands here first. The window stays open until the
        // question about unsaved work has been answered, and that happens after this event has finished: a window cannot
        // be closed from inside its own Closing event (Close() throws while it is still closing).
        e.Cancel = true;
        if (_busyCount > 0)
        {
            _statusBar.SetMessage("Please wait until the current operation has finished.");
            return;
        }
        if (_closeCheckRunning) return;
        _closeCheckRunning = true;
        _ = CloseAfterCheckAsync();
    }

    private async Task CloseAfterCheckAsync()
    {
        try
        {
            // Without this, a project with no unsaved changes would reach Close() before this method ever gave control back,
            // that is, while the window is still inside its Closing event.
            await Task.Yield();
            InterruptPlayback();
            if (!await ConfirmDiscardAsync("closing")) return;
            FinishClosing();
        }
        catch (Exception ex)
        {
            ReportUnexpected("closing the program", ex);
        }
        finally
        {
            _closeCheckRunning = false;
        }
    }

    private void FinishClosing()
    {
        _autosaveTimer.Stop();
        EndPlaybackUi();
        _previewWindow?.Close();
        SaveWindowState();
        _editor.PersistSettings(out _);

        // The person has agreed to leave, so nothing has to stay behind in the recovery folder.
        _editor.ExitApproved = true;
        _closeApproved = true;
        try
        {
            Close();
        }
        catch (InvalidOperationException)
        {
            // Windows would not let this window close right now. Stay open and keep protecting the work.
            _closeApproved = false;
            _editor.ExitApproved = false;
            ConfigureAutosave();
            throw;
        }
    }

    protected override void OnClosed(EventArgs e)
    {
        _editor.DocumentReplaced -= OnDocumentReplaced;
        _editor.FileStateChanged -= OnFileStateChanged;
        _editor.Status -= OnEditorStatus;
        _editor.SettingsManager.Changed -= OnSettingsChanged;
        if (_watched != null) _watched.Changed -= OnDocumentChanged;
        base.OnClosed(e);
    }

    // ===================================================================== errors

    private void ReportUnexpected(string what, Exception ex)
    {
        string? logged = CrashLog.Write("Unexpected problem while " + what, ex);
        string text = "Something unexpected went wrong while " + what + ". Your project is still open; saving it is a good idea.";
        if (logged != null) text += "\n\nA report was written to:\n" + logged;
        MessageDialog.Error(this, "Something went wrong", text, ex.GetType().Name + ": " + ex.Message);
    }
}
