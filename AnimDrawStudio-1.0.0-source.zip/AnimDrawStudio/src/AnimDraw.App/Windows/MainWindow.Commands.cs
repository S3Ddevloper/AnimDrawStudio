using System.Windows;
using AnimDraw.App.Services;
using AnimDraw.Core.App;
using AnimDraw.Core.Drawing;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Export;
using AnimDraw.Core.Model;
using AnimDraw.Core.Settings;
using AnimDraw.Core.Tools;

namespace AnimDraw.App.Windows;

public sealed partial class MainWindow
{
    /// <summary>Commands that leave playback running; every other command stops it where it is first.</summary>
    private static readonly HashSet<CommandId> KeepsPlaying = new()
    {
        CommandId.ZoomIn, CommandId.ZoomOut, CommandId.ZoomFit, CommandId.Zoom100, CommandId.Zoom200,
        CommandId.TogglePixelGrid, CommandId.ShowPreview, CommandId.ThemeDark, CommandId.ThemeLight,
        CommandId.ToolBrush, CommandId.ToolPencil, CommandId.ToolEraser, CommandId.ToolLine, CommandId.ToolRectangle,
        CommandId.ToolEllipse, CommandId.ToolFill, CommandId.ToolEyedropper, CommandId.ToolSelect, CommandId.ToolMove,
        CommandId.ToolHand, CommandId.ToolZoom, CommandId.SwapColors, CommandId.BrushSmaller, CommandId.BrushLarger,
        CommandId.PlayPause, CommandId.StopPlayback, CommandId.ToggleLoop,
        CommandId.ShowShortcuts, CommandId.About, CommandId.OpenFfmpegPage, CommandId.Exit
    };

    /// <summary>Starts a command. Anything unexpected is reported in a message instead of ending the program.</summary>
    private async void Run(CommandId id)
    {
        try
        {
            await RunAsync(id);
        }
        catch (Exception ex)
        {
            ReportUnexpected("running \"" + ShortcutMap.Info(id).Name + "\"", ex);
        }
    }

    private async Task RunAsync(CommandId id)
    {
        if (_busyCount > 0) return;
        if (!KeepsPlaying.Contains(id)) InterruptPlayback();

        switch (id)
        {
            // ----- file -----
            case CommandId.NewProject: await NewProjectAsync(); break;
            case CommandId.OpenProject: await OpenProjectAsync(); break;
            case CommandId.Save: await SaveAsync(); break;
            case CommandId.SaveAs: await SaveAsAsync(); break;
            case CommandId.ProjectSettings: ShowProjectSettings(); break;
            case CommandId.Exit: Close(); break;

            // ----- edit -----
            case CommandId.Undo: UndoRedo(undo: true); break;
            case CommandId.Redo: UndoRedo(undo: false); break;
            case CommandId.Cut: CopyOrCut(cut: true); break;
            case CommandId.Copy: CopyOrCut(cut: false); break;
            case CommandId.Paste: Paste(inPlace: false); break;
            case CommandId.PasteInPlace: Paste(inPlace: true); break;
            case CommandId.DuplicateSelection: DuplicateSelection(); break;
            case CommandId.SelectAll: _editor.Document.SelectAll(); break;
            case CommandId.Deselect: _editor.Document.Deselect(); break;
            case CommandId.ClearSelection: ClearSelectionOrLayer(); break;
            case CommandId.ClearFrame: ClearCanvas(); break;
            case CommandId.Preferences: ShowPreferences(); break;

            // ----- view -----
            case CommandId.ZoomIn: _canvas.ZoomIn(); break;
            case CommandId.ZoomOut: _canvas.ZoomOut(); break;
            case CommandId.ZoomFit: _canvas.ZoomFit(); break;
            case CommandId.Zoom100: _canvas.ZoomExact(1); break;
            case CommandId.Zoom200: _canvas.ZoomExact(2); break;
            case CommandId.TogglePixelGrid: _canvas.ShowPixelGrid = !_canvas.ShowPixelGrid; break;
            case CommandId.ShowPreview: ShowPreview(); break;
            case CommandId.ThemeDark: SwitchTheme(AppTheme.Dark); break;
            case CommandId.ThemeLight: SwitchTheme(AppTheme.Light); break;

            // ----- tools -----
            case CommandId.SwapColors: _editor.ToolSettings.SwapColors(); break;
            case CommandId.BrushSmaller: StepBrushSize(-1); break;
            case CommandId.BrushLarger: StepBrushSize(+1); break;

            // ----- animation -----
            case CommandId.PlayPause: TogglePlayback(); break;
            case CommandId.StopPlayback: StopPlayback(); break;
            case CommandId.ToggleLoop: _editor.Document.SetLoop(!_editor.Document.Project.Loop); break;
            case CommandId.FirstFrame: _editor.Document.GoToFrame(0); break;
            case CommandId.PreviousFrame: _editor.Document.GoToFrame(_editor.Document.CurrentFrame - 1); break;
            case CommandId.NextFrame: _editor.Document.GoToFrame(_editor.Document.CurrentFrame + 1); break;
            case CommandId.LastFrame: _editor.Document.GoToFrame(_editor.Document.FrameCount - 1); break;
            case CommandId.PreviousKeyframe: GoToKeyframe(forward: false); break;
            case CommandId.NextKeyframe: GoToKeyframe(forward: true); break;
            case CommandId.InsertFrame: AddFrame(duplicate: false); break;
            case CommandId.DuplicateFrame: AddFrame(duplicate: true); break;
            case CommandId.DeleteFrame: DeleteFrame(); break;
            case CommandId.InsertKeyframe: AddKeyframe(blank: false); break;
            case CommandId.InsertBlankKeyframe: AddKeyframe(blank: true); break;
            case CommandId.RemoveKeyframe: RemoveKeyframe(); break;
            case CommandId.ToggleOnionSkin: _editor.Document.UpdateOnionSkin(o => o.Enabled = !o.Enabled); break;
            case CommandId.OnionSkinSettings: ShowOnionSettings(); break;
            case CommandId.ToggleAutoKeyframe: ToggleAutoKeyframe(); break;

            // ----- layers -----
            case CommandId.NewLayer: NewLayer(); break;
            case CommandId.DeleteLayer: DeleteLayer(); break;
            case CommandId.DuplicateLayer: DuplicateLayer(); break;
            case CommandId.RenameLayer: _layersPanel.BeginRename(); break;
            case CommandId.LayerUp: MoveLayer(up: true); break;
            case CommandId.LayerDown: MoveLayer(up: false); break;
            case CommandId.MergeLayerDown: MergeLayerDown(); break;
            case CommandId.ToggleLayerVisible: ToggleActiveLayerVisible(); break;
            case CommandId.ToggleLayerLock: ToggleActiveLayerLock(); break;

            // ----- export -----
            case CommandId.ExportDialog: ShowExport(null); break;
            case CommandId.ExportGif: ShowExport(ExportFormat.Gif); break;
            case CommandId.ExportMp4: ShowExport(ExportFormat.Mp4); break;
            case CommandId.ExportPng: ShowExport(ExportFormat.Png); break;
            case CommandId.ExportPngSequence: ShowExport(ExportFormat.PngSequence); break;
            case CommandId.ExportSpriteSheet: ShowExport(ExportFormat.SpriteSheet); break;

            // ----- help -----
            case CommandId.ShowShortcuts: new ShortcutsDialog(this, _shortcuts).ShowDialog(); break;
            case CommandId.About: new AboutDialog(this).ShowDialog(); break;
            case CommandId.OpenFfmpegPage:
                if (!Native.OpenUrl(FfmpegLocator.DownloadPage))
                    MessageDialog.Info(this, "FFmpeg", "Your web browser could not be opened. FFmpeg can be downloaded from:\n" + FfmpegLocator.DownloadPage);
                break;

            default:
                SelectToolFor(id);
                break;
        }
    }

    // ===================================================================== command state

    private bool CanRun(CommandId id)
    {
        var doc = _editor.Document;
        var layer = doc.ActiveLayer;
        int frame = doc.CurrentFrame;
        int layerIndex = doc.Project.IndexOfLayer(layer);
        int layerCount = doc.Project.Layers.Count;

        return id switch
        {
            CommandId.Undo => doc.History.CanUndo || doc.HasActiveEdit,
            CommandId.Redo => doc.History.CanRedo,
            CommandId.Deselect => doc.Selection != null,
            CommandId.DuplicateSelection => doc.Selection != null,
            CommandId.StopPlayback => _editor.IsPlaying,
            CommandId.FirstFrame or CommandId.PreviousFrame => frame > 0,
            CommandId.LastFrame or CommandId.NextFrame => frame < doc.FrameCount - 1,
            CommandId.PreviousKeyframe => PreviousKeyframeOf(layer, frame) >= 0,
            CommandId.NextKeyframe => layer.Track.NextKeyFrameAfter(frame) >= 0,
            CommandId.InsertFrame or CommandId.DuplicateFrame => doc.CanAddFrame,
            CommandId.DeleteFrame => doc.CanDeleteFrame,
            CommandId.InsertKeyframe => !layer.Track.IsKeyframe(frame),
            CommandId.RemoveKeyframe => layer.Track.IsKeyframe(frame),
            CommandId.NewLayer or CommandId.DuplicateLayer => doc.CanAddLayer,
            CommandId.DeleteLayer => doc.CanDeleteLayer,
            CommandId.LayerUp => layerIndex < layerCount - 1,
            CommandId.LayerDown or CommandId.MergeLayerDown => layerIndex > 0,
            _ => true
        };
    }

    private bool IsChecked(CommandId id)
    {
        var doc = _editor.Document;
        return id switch
        {
            CommandId.TogglePixelGrid => _canvas.ShowPixelGrid,
            CommandId.ThemeDark => ThemeManager.Current == AppTheme.Dark,
            CommandId.ThemeLight => ThemeManager.Current == AppTheme.Light,
            CommandId.ToggleLoop => doc.Project.Loop,
            CommandId.ToggleOnionSkin => doc.Project.Onion.Enabled,
            CommandId.ToggleAutoKeyframe => doc.AutoKeyframe,
            CommandId.PlayPause => _editor.IsPlaying,
            _ => ToolCatalog.All.Any(t => t.Command == id && t.Kind == _editor.Tools.CurrentKind)
        };
    }

    private static int PreviousKeyframeOf(Layer layer, int frame)
    {
        int probe = layer.Track.IsKeyframe(frame) ? frame - 1 : frame;
        return probe < 0 ? -1 : layer.Track.GoverningKeyFrame(probe);
    }

    /// <summary>Says why the active layer cannot be drawn on, or returns true when it can.</summary>
    private bool LayerEditable()
    {
        var layer = _editor.Document.ActiveLayer;
        if (layer.Locked)
        {
            _editor.Say($"Layer \"{layer.Name}\" is locked. Unlock it to change it.");
            return false;
        }
        if (!layer.Visible)
        {
            _editor.Say($"Layer \"{layer.Name}\" is hidden. Show it to change it.");
            return false;
        }
        return true;
    }

    /// <summary>
    /// Asks before something is deleted, unless the person switched the question off. The answer "don't ask again" is
    /// remembered in the settings (and can be turned back on in Preferences).
    /// </summary>
    private bool ConfirmDestructive(string title, string text, string yes)
    {
        if (!_editor.Settings.ConfirmDestructive) return true;
        bool ok = MessageDialog.ConfirmWithOptOut(this, title, text + "\n\nYou can undo this with Ctrl+Z.", yes, "Cancel",
            "Don't ask me again (this can be switched back on in Preferences)", out bool dontAsk);
        if (ok && dontAsk)
        {
            _editor.Settings.ConfirmDestructive = false;
            _editor.SettingsManager.Save(out _);
        }
        return ok;
    }

    // ===================================================================== edit

    private void UndoRedo(bool undo)
    {
        var doc = _editor.Document;
        if (_editor.Tools.IsDrawing)
        {
            // Mid-stroke, undo means "never mind this stroke".
            _editor.Tools.Cancel();
            _editor.Say("Stroke cancelled");
            return;
        }
        string? name = undo ? doc.History.UndoName : doc.History.RedoName;
        bool done = undo ? doc.Undo() : doc.Redo();
        if (done) _editor.Say((undo ? "Undid " : "Redid ") + (name ?? "the last step"));
        else _editor.Say(undo ? "There is nothing to undo." : "There is nothing to redo.");
    }

    private void CopyOrCut(bool cut)
    {
        bool done = cut ? _editor.Cut() : _editor.Copy();
        if (done && !ClipboardService.Publish(_editor.Clipboard))
            _editor.Say((cut ? "Cut" : "Copied") + ", but other programs cannot paste it because the Windows clipboard is busy.");
    }

    private void Paste(bool inPlace)
    {
        var clip = _editor.Clipboard;
        var source = ClipboardService.Inspect(clip);
        var doc = _editor.Document;

        Point centre = _canvas.VisibleCenter();
        int cx = (int)Math.Round(centre.X);
        int cy = (int)Math.Round(centre.Y);
        bool pasted;

        if (source == ClipboardService.Source.Foreign)
        {
            var picture = ClipboardService.ReadForeignPicture();
            if (picture == null)
            {
                _editor.Say("The picture on the clipboard could not be read.");
                return;
            }
            if (inPlace)
            {
                cx = doc.CanvasWidth / 2;
                cy = doc.CanvasHeight / 2;
            }
            pasted = _editor.Paste(picture, cx, cy);
        }
        else if (clip.HasImage)
        {
            pasted = inPlace ? PasteOwnInPlace() : _editor.Paste(clip.Image!, cx, cy);
        }
        else
        {
            _editor.Say("There is nothing to paste. Copy something first, or copy a picture in another program.");
            return;
        }

        // A pasted picture is selected; with the Move tool it can be dragged straight away.
        if (pasted && _editor.Tools.CurrentKind is not (ToolKind.Move or ToolKind.Select))
            _editor.Tools.Select(ToolKind.Move);
    }

    private bool PasteOwnInPlace()
    {
        if (_editor.PasteInternalInPlace())
        {
            _editor.Say("Pasted in place");
            return true;
        }
        _editor.Say(_editor.Document.ActiveLayer.Locked || !_editor.Document.ActiveLayer.Visible
            ? $"Layer \"{_editor.Document.ActiveLayer.Name}\" cannot be drawn on. Unlock or show it first."
            : "Nothing was pasted.");
        return false;
    }

    private void DuplicateSelection()
    {
        // The menu entry is greyed out without a selection; the keyboard shortcut must not do more than the menu does.
        if (_editor.Document.Selection == null)
        {
            _editor.Say("Select something first, then duplicate it.");
            return;
        }
        if (!LayerEditable()) return;
        if (_editor.Document.DuplicateSelection()) _editor.Say("Duplicated the selection");
        else _editor.Say("There is nothing to duplicate in the selection.");
    }

    private void ClearSelectionOrLayer()
    {
        var doc = _editor.Document;
        if (!LayerEditable()) return;
        if (doc.Selection == null &&
            !ConfirmDestructive("Clear layer",
                $"Erase everything drawn on layer \"{doc.ActiveLayer.Name}\" in frame {doc.CurrentFrame + 1}?", "Erase"))
            return;
        if (doc.ClearActiveLayerFrame()) _editor.Say(doc.Selection != null ? "Cleared the selection" : "Cleared the layer");
        else _editor.Say("There is nothing to clear here.");
    }

    private void ClearCanvas()
    {
        var doc = _editor.Document;
        if (!ConfirmDestructive("Clear canvas",
                $"Erase the drawings on all visible, unlocked layers in frame {doc.CurrentFrame + 1}?", "Clear canvas"))
            return;
        if (doc.ClearFrame()) _editor.Say("Cleared frame " + (doc.CurrentFrame + 1));
        else _editor.Say("There is nothing to clear: the visible layers are empty here, or locked.");
    }

    // ===================================================================== view and tools

    private void SwitchTheme(AppTheme theme)
    {
        if (ThemeManager.Current == theme) return;
        if (!ThemeManager.Apply(theme, out string? problem))
        {
            MessageDialog.Warn(this, "Theme", "The theme could not be changed.", problem);
            return;
        }
        _editor.Settings.Theme = theme;
        _editor.SettingsManager.Save(out _);
    }

    private void SelectToolFor(CommandId id)
    {
        foreach (var tool in ToolCatalog.All)
        {
            if (tool.Command != id) continue;
            _editor.Tools.Select(tool.Kind);
            return;
        }
    }

    /// <summary>Makes the brush (or the line width of shapes) a little larger or smaller, in steps that suit the current size.</summary>
    private void StepBrushSize(int direction)
    {
        var settings = _editor.ToolSettings;
        BrushSettings? brush = _editor.Tools.CurrentKind switch
        {
            ToolKind.Brush => settings.Brush,
            ToolKind.Pencil => settings.Pencil,
            ToolKind.Eraser => settings.Eraser,
            _ => null
        };

        double current = brush?.Size ?? settings.ShapeLineWidth;
        double next = direction > 0
            ? (current < 10 ? current + 1 : Math.Ceiling(current * 1.12))
            : (current <= 10 ? current - 1 : Math.Floor(current / 1.12));

        if (brush != null)
        {
            brush.Size = Math.Clamp(next, BrushSettings.MinSize, BrushSettings.MaxSize);
            _editor.Say("Brush size " + brush.Size.ToString("0") + " px");
        }
        else if (_editor.Tools.CurrentKind is ToolKind.Line or ToolKind.Rectangle or ToolKind.Ellipse)
        {
            settings.ShapeLineWidth = Math.Clamp(next, 1, 200);
            _editor.Say("Line width " + settings.ShapeLineWidth.ToString("0") + " px");
        }
        else
        {
            return;
        }
        settings.RaiseChanged();
    }

    // ===================================================================== animation

    private void GoToKeyframe(bool forward)
    {
        var doc = _editor.Document;
        var track = doc.ActiveLayer.Track;
        int target = forward ? track.NextKeyFrameAfter(doc.CurrentFrame) : PreviousKeyframeOf(doc.ActiveLayer, doc.CurrentFrame);
        if (target < 0 || target >= doc.FrameCount)
        {
            _editor.Say(forward ? "There is no later keyframe on this layer." : "There is no earlier keyframe on this layer.");
            return;
        }
        doc.GoToFrame(target);
    }

    private void AddFrame(bool duplicate)
    {
        var doc = _editor.Document;
        bool done = duplicate ? doc.DuplicateFrame(doc.CurrentFrame) : doc.InsertBlankFrameAfter(doc.CurrentFrame);
        if (!done)
        {
            _editor.Say($"A project can have at most {ProjectLimits.MaxFrames:N0} frames.");
            return;
        }
        _editor.Say((duplicate ? "Duplicated to frame " : "Added frame ") + (doc.CurrentFrame + 1));
    }

    private void DeleteFrame()
    {
        var doc = _editor.Document;
        if (!doc.CanDeleteFrame)
        {
            _editor.Say("The last frame cannot be deleted.");
            return;
        }
        if (!ConfirmDestructive("Delete frame", $"Delete frame {doc.CurrentFrame + 1} on every layer?", "Delete frame")) return;
        if (doc.DeleteFrame(doc.CurrentFrame)) _editor.Say("Deleted a frame");
    }

    private void AddKeyframe(bool blank)
    {
        var doc = _editor.Document;
        var layer = doc.ActiveLayer;
        if (layer.Locked)
        {
            _editor.Say($"Layer \"{layer.Name}\" is locked.");
            return;
        }
        bool done = blank ? doc.InsertBlankKeyframe(layer, doc.CurrentFrame) : doc.InsertKeyframe(layer, doc.CurrentFrame);
        if (done) _editor.Say(blank ? "Added a blank keyframe" : "Added a keyframe");
        else _editor.Say("This frame already is a keyframe on this layer.");
    }

    private void RemoveKeyframe()
    {
        var doc = _editor.Document;
        var layer = doc.ActiveLayer;
        if (layer.Locked)
        {
            _editor.Say($"Layer \"{layer.Name}\" is locked.");
            return;
        }
        if (doc.RemoveKeyframe(layer, doc.CurrentFrame)) _editor.Say("Removed the keyframe; the earlier drawing is held here now");
        else _editor.Say("This frame is not a keyframe on this layer.");
    }

    private void ToggleAutoKeyframe()
    {
        var doc = _editor.Document;
        doc.AutoKeyframe = !doc.AutoKeyframe;
        _editor.Settings.AutoKeyframe = doc.AutoKeyframe;
        _editor.Say(doc.AutoKeyframe
            ? "Auto keyframe is on: drawing on a held frame makes a keyframe for you."
            : "Auto keyframe is off: drawing changes the held drawing on every frame it spans.");
    }

    private void ShowOnionSettings()
    {
        var dialog = new OnionSkinDialog(this, _editor.Document);
        if (dialog.ShowDialog() != true) return;
        var chosen = dialog.Result;
        _editor.Document.UpdateOnionSkin(o =>
        {
            o.Enabled = chosen.Enabled;
            o.PreviousFrames = chosen.PreviousFrames;
            o.NextFrames = chosen.NextFrames;
            o.Opacity = chosen.Opacity;
            o.Colorize = chosen.Colorize;
        });
    }

    // ===================================================================== layers

    private void NewLayer()
    {
        var doc = _editor.Document;
        var layer = doc.AddLayer();
        _editor.Say(layer != null ? $"Added layer \"{layer.Name}\"" : $"A project can have at most {ProjectLimits.MaxLayers} layers.");
    }

    private void DuplicateLayer()
    {
        var doc = _editor.Document;
        var copy = doc.DuplicateLayer(doc.ActiveLayer);
        _editor.Say(copy != null ? $"Duplicated the layer as \"{copy.Name}\"" : $"A project can have at most {ProjectLimits.MaxLayers} layers.");
    }

    private void DeleteLayer()
    {
        var doc = _editor.Document;
        if (!doc.CanDeleteLayer)
        {
            _editor.Say("The last layer cannot be deleted.");
            return;
        }
        var layer = doc.ActiveLayer;
        if (!ConfirmDestructive("Delete layer", $"Delete layer \"{layer.Name}\" with all of its drawings on every frame?", "Delete layer")) return;
        if (doc.DeleteLayer(layer)) _editor.Say($"Deleted layer \"{layer.Name}\"");
    }

    private void MoveLayer(bool up)
    {
        var doc = _editor.Document;
        bool moved = up ? doc.MoveLayerUp(doc.ActiveLayer) : doc.MoveLayerDown(doc.ActiveLayer);
        if (!moved) _editor.Say(up ? "The layer is already on top." : "The layer is already at the bottom.");
    }

    private void MergeLayerDown()
    {
        var doc = _editor.Document;
        var layer = doc.ActiveLayer;
        int index = doc.Project.IndexOfLayer(layer);
        if (index <= 0)
        {
            _editor.Say("There is no layer below to merge into.");
            return;
        }
        var lower = doc.Project.Layers[index - 1];
        if (lower.Locked)
        {
            _editor.Say($"The layer below (\"{lower.Name}\") is locked. Unlock it first.");
            return;
        }
        if (!ConfirmDestructive("Merge layer", $"Merge \"{layer.Name}\" into \"{lower.Name}\" on every frame?", "Merge")) return;
        if (doc.MergeDown(layer)) _editor.Say($"Merged into \"{lower.Name}\"");
    }

    private void ToggleActiveLayerVisible()
    {
        var doc = _editor.Document;
        doc.SetLayerVisible(doc.ActiveLayer, !doc.ActiveLayer.Visible);
    }

    private void ToggleActiveLayerLock()
    {
        var doc = _editor.Document;
        doc.SetLayerLocked(doc.ActiveLayer, !doc.ActiveLayer.Locked);
    }

    // ===================================================================== dialogs

    private void ShowProjectSettings()
    {
        var doc = _editor.Document;
        var dialog = new ProjectSettingsDialog(this, doc);
        if (dialog.ShowDialog() != true) return;

        bool changed = false;
        doc.History.BeginGroup("Project Settings");
        try
        {
            changed |= doc.SetFps(dialog.Fps);
            changed |= doc.SetLoop(dialog.Loop);
            changed |= doc.SetBackground(dialog.ProjectBackground);
            if (dialog.NewWidth != doc.CanvasWidth || dialog.NewHeight != doc.CanvasHeight)
                changed |= doc.ResizeCanvas(dialog.NewWidth, dialog.NewHeight, dialog.CanvasResize, dialog.AnchorX, dialog.AnchorY);
        }
        finally
        {
            doc.History.EndGroup();
        }
        _editor.Say(changed ? "Project settings changed" : "Nothing was changed");
    }

    private void ShowPreferences()
    {
        var dialog = new PreferencesDialog(this, _editor);
        if (dialog.ShowDialog() != true) return;
        ConfigureAutosave();
        _editor.Document.AutoKeyframe = _editor.Settings.AutoKeyframe;
        if (ThemeManager.Current != _editor.Settings.Theme) SwitchTheme(_editor.Settings.Theme);
        _editor.Say("Preferences saved");
    }

    private void ShowExport(ExportFormat? format)
    {
        var doc = _editor.Document;
        doc.CommitActiveEdit();
        var dialog = new ExportDialog(this, _editor, format);
        dialog.ShowDialog();
    }
}
