using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.App;
using AnimDraw.Core.Model;
using AnimDraw.Core.Settings;

namespace AnimDraw.App.Windows;

/// <summary>Asks for the size, frame rate and background of a new project. The starting values are the ones used last time.</summary>
public sealed class NewProjectDialog : DialogWindow
{
    private sealed record Preset(string Name, int Width, int Height);

    private static readonly Preset[] Presets =
    {
        new("HD  (1280 × 720)", 1280, 720),
        new("Full HD  (1920 × 1080)", 1920, 1080),
        new("4K UHD  (3840 × 2160)", 3840, 2160),
        new("Square  (1080 × 1080)", 1080, 1080),
        new("Portrait  (1080 × 1920)", 1080, 1920),
        new("Small square  (512 × 512)", 512, 512),
        new("Pixel art wide  (320 × 180)", 320, 180),
        new("Pixel art square  (64 × 64)", 64, 64)
    };

    private const string CustomName = "Custom size";

    private readonly ComboBox _preset = new() { Width = 260 };
    private readonly NumberField _width;
    private readonly NumberField _height;
    private readonly NumberField _fps;
    private readonly BackgroundPicker _background;
    private readonly TextBlock _info;
    private readonly Button _create;
    private bool _syncing;

    public NewProjectDialog(Window owner, AppSettings settings) : base(owner, "New Project")
    {
        _width = new NumberField(settings.NewProjectWidth, ProjectLimits.MinDimension, ProjectLimits.MaxDimension, width: 76);
        _height = new NumberField(settings.NewProjectHeight, ProjectLimits.MinDimension, ProjectLimits.MaxDimension, width: 76);
        _fps = new NumberField(settings.NewProjectFps, ProjectLimits.MinFps, ProjectLimits.MaxFps, decimals: 2, width: 76) { TrimZeros = true };
        _background = new BackgroundPicker(Editor.ParseBackground(settings.NewProjectBackground));

        var form = new FormGrid { Margin = new Thickness(26, 22, 26, 10) };

        foreach (var preset in Presets) _preset.Items.Add(preset.Name);
        _preset.Items.Add(CustomName);
        form.AddRow("Preset", _preset, "Ready-made sizes. Pick \"Custom size\" or type the numbers yourself.");

        var sizeRow = new StackPanel { Orientation = Orientation.Horizontal };
        sizeRow.Children.Add(_width.Box);
        var by = Ui.Label("×", dim: true);
        by.Margin = new Thickness(8, 0, 8, 0);
        sizeRow.Children.Add(by);
        sizeRow.Children.Add(_height.Box);
        sizeRow.Children.Add(Ui.Label("pixels", dim: true));
        ((TextBlock)sizeRow.Children[^1]).Margin = new Thickness(8, 0, 0, 0);
        form.AddRow("Canvas size", sizeRow, "Width × height in pixels, up to 8192 each.");

        var fpsRow = new StackPanel { Orientation = Orientation.Horizontal };
        fpsRow.Children.Add(_fps.Box);
        var fpsUnit = Ui.Label("frames per second", dim: true);
        fpsUnit.Margin = new Thickness(8, 0, 0, 0);
        fpsRow.Children.Add(fpsUnit);
        form.AddRow("Frame rate", fpsRow, "How many frames are shown each second when the animation plays. 12 is typical for hand-drawn work.");

        form.AddRow("Background", _background);

        _info = Ui.Wrapped("", dim: true, maxWidth: 420);
        _info.FontSize = 11.5;
        _info.Margin = new Thickness(0, 10, 0, 0);
        form.AddFull(_info, top: 10);
        SetBody(form);

        _create = AddButton("Create", () => Accept(), primary: true, isDefault: true);
        AddButton("Cancel", isCancel: true);

        _preset.SelectionChanged += (_, _) => OnPresetChosen();
        _width.ValueChanged += _ => OnSizeEdited();
        _height.ValueChanged += _ => OnSizeEdited();
        _fps.ValueChanged += _ => UpdateInfo();
        _background.Changed += UpdateInfo;

        OnSizeEdited();
    }

    public int CanvasWidth => _width.IntValue;
    public int CanvasHeight => _height.IntValue;
    public double Fps => ProjectLimits.ClampFps(_fps.Value);
    public BackgroundSettings ProjectBackground => _background.Value;

    private void OnPresetChosen()
    {
        if (_syncing) return;
        int index = _preset.SelectedIndex;
        if (index < 0 || index >= Presets.Length) return;
        _width.SetValue(Presets[index].Width);
        _height.SetValue(Presets[index].Height);
        UpdateInfo();
    }

    private void OnSizeEdited()
    {
        // Show the matching preset, or "Custom size" when the numbers fit none.
        _syncing = true;
        int match = Array.FindIndex(Presets, p => p.Width == _width.IntValue && p.Height == _height.IntValue);
        _preset.SelectedIndex = match >= 0 ? match : Presets.Length;
        _syncing = false;
        UpdateInfo();
    }

    private void UpdateInfo()
    {
        int w = _width.IntValue;
        int h = _height.IntValue;
        long pixels = (long)w * h;

        string key = ThemeKeys.TextDim;
        string text;
        if (!ProjectLimits.IsValidSize(w, h, out string? problem))
        {
            text = problem ?? "That size is not possible.";
            key = ThemeKeys.Danger;
            _create.IsEnabled = false;
        }
        else
        {
            _create.IsEnabled = true;
            double megapixels = pixels / 1_000_000.0;
            double megabytes = pixels * 4.0 / (1024 * 1024);
            text = string.Format(CultureInfo.CurrentCulture,
                "{0} × {1} pixels ({2:0.0} megapixels). A layer that is completely painted on one frame needs about {3:0.#} MB of memory; empty areas need none.",
                w, h, megapixels, megabytes);
            if (pixels > ProjectLimits.WarnPixels)
            {
                text += " This is a very large canvas. Drawing, playback and exporting will be slower, and the program needs a lot of memory.";
                key = ThemeKeys.Warning;
            }
        }
        _info.Text = text;
        _info.SetResourceReference(TextBlock.ForegroundProperty, key);
    }
}
