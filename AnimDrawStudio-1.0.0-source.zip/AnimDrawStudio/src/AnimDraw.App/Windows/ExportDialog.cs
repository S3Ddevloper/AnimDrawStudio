using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.App;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Export;
using AnimDraw.Core.IO;
using AnimDraw.Core.Model;

namespace AnimDraw.App.Windows;

/// <summary>
/// The export window. The person picks a format and its options; a summary under the options says what will be written and
/// what is wrong with the settings, and the Export button stays off until they are usable. The export runs in the
/// background with a progress bar and a Cancel button, so the window never freezes.
/// </summary>
public sealed class ExportDialog : DialogWindow
{
    private static ExportFormat? _lastFormat;

    private readonly Editor _editor;
    private readonly Document _doc;
    private readonly Project _project;

    private readonly ComboBox _format = new() { Width = 320 };
    private readonly TextBox _path = new() { Width = 330, VerticalContentAlignment = VerticalAlignment.Center };
    private readonly TextBox _prefix = new() { Width = 160, MaxLength = 40, Text = "frame", VerticalContentAlignment = VerticalAlignment.Center };
    private readonly NumberField _width;
    private readonly NumberField _height;
    private readonly CheckBox _keepRatio = new() { Content = "Keep proportions", IsChecked = true };
    private readonly CheckBox _smooth = new() { Content = "Smooth scaling (turn off for crisp pixel art)", IsChecked = true };
    private readonly CheckBox _transparent = new() { Content = "Transparent background" };
    private readonly NumberField _from;
    private readonly NumberField _to;
    private readonly NumberField _fps;
    private readonly CheckBox _loop = new() { Content = "Repeat forever", IsChecked = true };
    private readonly SliderField _quality;
    private readonly ComboBox _compression = new() { Width = 200 };
    private readonly NumberField _columns;
    private readonly NumberField _padding;
    private readonly CheckBox _json = new() { Content = "Also write a .json file with the position of every frame", IsChecked = true };
    private readonly FfmpegSelector _ffmpeg;

    private readonly TextBlock _pathLabel;
    private readonly TextBlock _sizeLabel;
    private readonly TextBlock _framesLabel;
    private readonly TextBlock _toLabel;
    private readonly TextBlock _ofLabel;
    private readonly StackPanel _summary = new();
    private readonly StackPanel _progressPanel = new() { Visibility = Visibility.Collapsed };
    private readonly ProgressBar _bar = new();
    private readonly TextBlock _progressText;
    private readonly StackPanel _resultPanel = new() { Visibility = Visibility.Collapsed };
    private readonly Button _exportButton;
    private readonly Button _closeButton;
    private readonly FormGrid _form;

    private readonly FormRow _rowPrefix;
    private readonly FormRow _rowSize;
    private readonly FormRow _rowSmooth;
    private readonly FormRow _rowTransparent;
    private readonly FormRow _rowFrames;
    private readonly FormRow _rowFps;
    private readonly FormRow _rowLoop;
    private readonly FormRow _rowQuality;
    private readonly FormRow _rowCompression;
    private readonly FormRow _rowColumns;
    private readonly FormRow _rowPadding;
    private readonly FormRow _rowJson;
    private readonly FormRow _secQuality;
    private readonly FormRow _secSheet;
    private readonly FormRow _secFfmpeg;
    private readonly FormRow _rowFfmpeg;

    private ExportFormat _current;
    private bool _building = true;
    private bool _running;
    private bool _closeWhenDone;
    private bool _transparentWasOn;
    private CancellationTokenSource? _cts;
    private ExportResult? _result;

    public ExportDialog(Window owner, Editor editor, ExportFormat? initialFormat) : base(owner, "Export", resizable: false)
    {
        _editor = editor;
        _doc = editor.Document;
        _project = _doc.Project;
        _current = initialFormat ?? _lastFormat ?? ExportFormat.Gif;

        var defaults = ExportOptions.CreateDefault(_project, _current, _doc.CurrentFrame);
        int frames = _project.FrameCount;

        _width = new NumberField(defaults.Width, 1, ExportOptions.MaxOutputDimension, width: 74);
        _height = new NumberField(defaults.Height, 1, ExportOptions.MaxOutputDimension, width: 74);
        _from = new NumberField(defaults.StartFrame + 1, 1, frames, width: 70);
        _to = new NumberField(defaults.EndFrame + 1, 1, frames, width: 70);
        _fps = new NumberField(defaults.Fps, ProjectLimits.MinFps, ProjectLimits.MaxFps, 2, width: 70) { TrimZeros = true };
        _quality = new SliderField("", 1, 100, defaults.Quality, 0, sliderWidth: 200,
            tip: "Higher is a better picture and a bigger file. 85 is a good start.");
        _columns = new NumberField(0, 0, 1024, width: 70);
        _padding = new NumberField(0, 0, 512, width: 70);
        _ffmpeg = new FfmpegSelector(this, editor.Settings.FfmpegPath);
        _transparent.IsChecked = defaults.Transparent;
        _transparentWasOn = defaults.Transparent;

        foreach (var format in Enum.GetValues<ExportFormat>())
            _format.Items.Add(new ComboBoxItem { Content = ExportOptions.DisplayName(format), Tag = format });
        _format.SelectedIndex = (int)_current;

        _compression.Items.Add(new ComboBoxItem { Content = "Fast (larger files)", Tag = PngCompression.Fast });
        _compression.Items.Add(new ComboBoxItem { Content = "Balanced", Tag = PngCompression.Normal });
        _compression.Items.Add(new ComboBoxItem { Content = "Smallest files (slower)", Tag = PngCompression.Best });
        _compression.SelectedIndex = 1;

        _form = new FormGrid(128) { Margin = new Thickness(26, 18, 26, 8) };

        _form.AddSection("What to export");
        _form.AddRow("Format", _format);

        var pathRow = new StackPanel { Orientation = Orientation.Horizontal };
        pathRow.Children.Add(_path);
        var browse = new Button { Content = "Browse...", MinWidth = 78, Margin = new Thickness(8, 0, 0, 0) };
        browse.Click += (_, _) => Browse();
        pathRow.Children.Add(browse);
        _pathLabel = _form.AddRow("Save as", pathRow).Label!;

        _rowPrefix = _form.AddRow("File name prefix", _prefix, "The pictures are named prefix_0001.png, prefix_0002.png and so on.");

        _form.AddSection("Picture");
        var sizeRow = new StackPanel { Orientation = Orientation.Horizontal };
        sizeRow.Children.Add(_width.Box);
        var by = Ui.Label("×", dim: true);
        by.Margin = new Thickness(8, 0, 8, 0);
        sizeRow.Children.Add(by);
        sizeRow.Children.Add(_height.Box);
        var px = Ui.Label("pixels", dim: true);
        px.Margin = new Thickness(8, 0, 12, 0);
        sizeRow.Children.Add(px);
        sizeRow.Children.Add(_keepRatio);
        _keepRatio.VerticalAlignment = VerticalAlignment.Center;
        _rowSize = _form.AddRow("Picture size", sizeRow, "Frames are scaled to this size. The canvas of the project is " + _project.Width + " × " + _project.Height + ".");
        _sizeLabel = _rowSize.Label!;
        _rowSmooth = _form.AddFull(_smooth);
        _rowTransparent = _form.AddFull(_transparent);

        _secQuality = _form.AddSection("Frames and quality");
        var framesRow = new StackPanel { Orientation = Orientation.Horizontal };
        framesRow.Children.Add(_from.Box);
        _toLabel = Ui.Label("to", dim: true);
        _toLabel.Margin = new Thickness(8, 0, 8, 0);
        framesRow.Children.Add(_toLabel);
        framesRow.Children.Add(_to.Box);
        _ofLabel = Ui.Label("of " + frames, dim: true);
        _ofLabel.Margin = new Thickness(8, 0, 0, 0);
        framesRow.Children.Add(_ofLabel);
        _rowFrames = _form.AddRow("Frames", framesRow, "Frame numbers as shown in the timeline.");
        _framesLabel = _rowFrames.Label!;

        _rowFps = _form.AddRow("Frame rate", FpsRow(), "How many frames are shown each second in the result.");
        _rowLoop = _form.AddFull(_loop);
        _rowQuality = _form.AddRow("Quality", _quality);
        _rowCompression = _form.AddRow("PNG file size", _compression, "Only changes how big the files are, never how the pictures look.");

        _secSheet = _form.AddSection("Sprite sheet");
        _rowColumns = _form.AddRow("Columns", _columns.Box, "0 chooses a roughly square grid.");
        _rowPadding = _form.AddRow("Space between frames", PaddingRow());
        _rowJson = _form.AddFull(_json);

        _secFfmpeg = _form.AddSection("MP4 needs FFmpeg");
        _rowFfmpeg = _form.AddFull(_ffmpeg);

        _form.AddSection("Summary");
        _summary.Margin = new Thickness(0, 0, 0, 4);
        _form.AddFull(_summary);

        _bar.Height = 8;
        _progressText = Ui.Wrapped("", dim: true, maxWidth: 480);
        _progressText.Margin = new Thickness(0, 6, 0, 0);
        _progressPanel.Children.Add(_bar);
        _progressPanel.Children.Add(_progressText);
        _form.AddFull(_progressPanel, top: 8);
        _form.AddFull(_resultPanel, top: 8);

        var scroll = new ScrollViewer
        {
            Content = _form,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            MaxHeight = Math.Max(320, SystemParameters.WorkArea.Height - 190)
        };
        SetBody(scroll);

        _exportButton = AddButton("Export", () => _ = StartExportAsync(), primary: true, isDefault: true);
        _closeButton = AddButton("Close", isCancel: true);

        HookEvents();
        _building = false;
        ApplyFormat(initial: true);
    }

    private UIElement FpsRow()
    {
        var row = new StackPanel { Orientation = Orientation.Horizontal };
        row.Children.Add(_fps.Box);
        var unit = Ui.Label("frames per second", dim: true);
        unit.Margin = new Thickness(8, 0, 0, 0);
        row.Children.Add(unit);
        return row;
    }

    private UIElement PaddingRow()
    {
        var row = new StackPanel { Orientation = Orientation.Horizontal };
        row.Children.Add(_padding.Box);
        var unit = Ui.Label("pixels", dim: true);
        unit.Margin = new Thickness(8, 0, 0, 0);
        row.Children.Add(unit);
        return row;
    }

    // ===================================================================== reading the controls

    private ExportFormat SelectedFormat =>
        _format.SelectedItem is ComboBoxItem { Tag: ExportFormat format } ? format : ExportFormat.Gif;

    private PngCompression SelectedCompression =>
        _compression.SelectedItem is ComboBoxItem { Tag: PngCompression c } ? c : PngCompression.Normal;

    private ExportOptions BuildOptions()
    {
        var format = SelectedFormat;
        int start = _from.IntValue - 1;
        int end = format == ExportFormat.Png ? start : _to.IntValue - 1;
        return new ExportOptions
        {
            Format = format,
            OutputPath = _path.Text.Trim().Trim('"'),
            Width = _width.IntValue,
            Height = _height.IntValue,
            Fps = _fps.Value,
            StartFrame = start,
            EndFrame = end,
            Transparent = _transparent.IsChecked == true && format != ExportFormat.Mp4,
            Quality = (int)Math.Round(_quality.Value),
            PngCompression = SelectedCompression,
            Loop = _loop.IsChecked == true,
            SmoothScaling = _smooth.IsChecked == true,
            FileNamePrefix = _prefix.Text,
            Columns = _columns.IntValue,
            Padding = _padding.IntValue,
            WriteSpriteSheetJson = _json.IsChecked == true,
            FfmpegPath = _ffmpeg.Path
        };
    }

    // ===================================================================== reacting to changes

    private void HookEvents()
    {
        _format.SelectionChanged += (_, _) =>
        {
            if (!_building) ApplyFormat(initial: false);
        };
        _path.TextChanged += (_, _) => UpdateSummary();
        _prefix.TextChanged += (_, _) => UpdateSummary();
        _width.ValueChanged += v =>
        {
            if (_keepRatio.IsChecked == true) _height.SetValue(Math.Max(1, Math.Round(v * _project.Height / _project.Width)));
            UpdateSummary();
        };
        _height.ValueChanged += v =>
        {
            if (_keepRatio.IsChecked == true) _width.SetValue(Math.Max(1, Math.Round(v * _project.Width / _project.Height)));
            UpdateSummary();
        };
        _keepRatio.Click += (_, _) =>
        {
            if (_keepRatio.IsChecked != true) return;
            _height.SetValue(Math.Max(1, Math.Round(_width.Value * _project.Height / _project.Width)));
            UpdateSummary();
        };
        _from.ValueChanged += v =>
        {
            if (v > _to.Value) _to.SetValue(v);
            UpdateSummary();
        };
        _to.ValueChanged += v =>
        {
            if (v < _from.Value) _from.SetValue(v);
            UpdateSummary();
        };
        _fps.ValueChanged += _ => UpdateSummary();
        _columns.ValueChanged += _ => UpdateSummary();
        _padding.ValueChanged += _ => UpdateSummary();
        _quality.ValueChanged += _ => UpdateSummary();
        foreach (var box in new[] { _smooth, _transparent, _loop, _json })
            box.Click += (_, _) => UpdateSummary();
        _transparent.Click += (_, _) => _transparentWasOn = _transparent.IsChecked == true;
        _compression.SelectionChanged += (_, _) => UpdateSummary();
        _ffmpeg.StatusChanged += UpdateSummary;
    }

    /// <summary>Shows the options that belong to the chosen format and hides the rest.</summary>
    private void ApplyFormat(bool initial)
    {
        var format = SelectedFormat;
        var previous = _current;
        _current = format;
        _lastFormat = format;

        bool timed = format is ExportFormat.Gif or ExportFormat.Mp4;
        bool single = format == ExportFormat.Png;
        bool pngKind = format is ExportFormat.Png or ExportFormat.PngSequence or ExportFormat.SpriteSheet;

        _rowPrefix.Visible = format == ExportFormat.PngSequence;
        _rowFps.Visible = timed;
        _rowLoop.Visible = format == ExportFormat.Gif;
        _rowQuality.Visible = timed;
        _secQuality.Visible = true;
        _rowCompression.Visible = pngKind;
        _secSheet.Visible = format == ExportFormat.SpriteSheet;
        _rowColumns.Visible = format == ExportFormat.SpriteSheet;
        _rowPadding.Visible = format == ExportFormat.SpriteSheet;
        _rowJson.Visible = format == ExportFormat.SpriteSheet;
        _secFfmpeg.Visible = format == ExportFormat.Mp4;
        _rowFfmpeg.Visible = format == ExportFormat.Mp4;

        _framesLabel.Text = single ? "Frame" : "Frames";
        _toLabel.Visibility = _to.Box.Visibility = single ? Visibility.Collapsed : Visibility.Visible;
        _ofLabel.Text = single ? "(the frame shown in the timeline)" : "of " + _project.FrameCount;
        _sizeLabel.Text = format == ExportFormat.SpriteSheet ? "Size of each frame" : "Picture size";
        _pathLabel.Text = format == ExportFormat.PngSequence ? "Save in folder" : "Save as";

        // MP4 cannot hold transparency; for the other formats the choice comes back when the person returns to them.
        if (format == ExportFormat.Mp4)
        {
            _transparent.IsChecked = false;
            _transparent.IsEnabled = false;
            _transparent.ToolTip = "MP4 video cannot be transparent.";
        }
        else
        {
            _transparent.IsEnabled = true;
            _transparent.ToolTip = null;
            if (previous == ExportFormat.Mp4 || initial) _transparent.IsChecked = _transparentWasOn;
        }

        if (single && !initial)
        {
            _from.SetValue(_doc.CurrentFrame + 1);
            _to.SetValue(_doc.CurrentFrame + 1);
        }
        else if (previous == ExportFormat.Png && !initial)
        {
            _from.SetValue(1);
            _to.SetValue(_project.FrameCount);
        }

        // New format, new kind of path: keep the folder, change the name.
        _building = true;
        _path.Text = Suggest(format, FolderOfCurrentPath());
        _building = false;
        UpdateSummary();
    }

    private string FolderOfCurrentPath()
    {
        string text = _path.Text.Trim().Trim('"');
        try
        {
            if (text.Length > 0)
            {
                if (_current != ExportFormat.PngSequence || !Directory.Exists(text)) return Path.GetDirectoryName(Path.GetFullPath(text)) ?? DefaultFolder();
                return text;
            }
        }
        catch (Exception ex) when (ex is ArgumentException or NotSupportedException or PathTooLongException)
        {
            // fall through to the default folder
        }
        return DefaultFolder();
    }

    private string DefaultFolder()
    {
        string? last = _editor.Settings.LastExportFolder;
        if (!string.IsNullOrWhiteSpace(last) && Directory.Exists(last)) return last;
        if (_editor.FilePath != null)
        {
            string? own = Path.GetDirectoryName(_editor.FilePath);
            if (!string.IsNullOrEmpty(own) && Directory.Exists(own)) return own;
        }
        return Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
    }

    private string Suggest(ExportFormat format, string folder)
    {
        string name = _editor.DisplayName;
        return format switch
        {
            ExportFormat.PngSequence => Path.Combine(folder, name + "_frames"),
            ExportFormat.SpriteSheet => Path.Combine(folder, name + "_sheet.png"),
            _ => Path.Combine(folder, name + ExportOptions.DefaultExtension(format))
        };
    }

    private void Browse()
    {
        var format = SelectedFormat;
        string initial = FolderOfCurrentPath();
        if (format == ExportFormat.PngSequence)
        {
            string? folder = FileDialogs.PickFolder(this, "Choose a folder for the pictures", initial);
            if (folder != null) _path.Text = folder;
            return;
        }
        string extension = ExportOptions.DefaultExtension(format);
        string suggested = Path.GetFileName(Suggest(format, initial));
        string? file = FileDialogs.SaveExport(this, "Export " + ExportOptions.DisplayName(format), ExportOptions.DisplayName(format), extension, suggested, initial);
        if (file != null) _path.Text = file;
    }

    // ===================================================================== the summary under the options

    private void UpdateSummary()
    {
        if (_building || _running) return;
        var options = BuildOptions();
        var plan = ExportManager.Plan(_project, options);
        var lines = new List<(string Text, string Key)>();
        bool ready = plan.IsValid;

        foreach (string problem in plan.Problems) lines.Add((problem, ThemeKeys.Danger));

        if (plan.IsValid)
        {
            var o = plan.Options;
            string what = options.Format switch
            {
                ExportFormat.Gif or ExportFormat.Mp4 => string.Format(CultureInfo.CurrentCulture,
                    "{0} frames, {1:0.0#} seconds at {2:0.##} frames per second, {3} × {4} pixels.",
                    plan.OutputFrames, plan.Duration.TotalSeconds, o.Fps, o.Width, o.Height),
                ExportFormat.Png => string.Format(CultureInfo.CurrentCulture, "One picture of frame {0}, {1} × {2} pixels.", o.StartFrame + 1, o.Width, o.Height),
                ExportFormat.PngSequence => string.Format(CultureInfo.CurrentCulture, "{0} pictures of {1} × {2} pixels each.", plan.OutputFrames, o.Width, o.Height),
                _ => SheetSummary(plan)
            };
            lines.Add((what, ThemeKeys.Text));
            if (options.Format == ExportFormat.PngSequence && plan.OutputFiles.Count > 0)
                lines.Add(("Files: " + Path.GetFileName(plan.OutputFiles[0]) + " ... " + Path.GetFileName(plan.OutputFiles[^1]), ThemeKeys.TextDim));
            else if (plan.OutputFiles.Count > 0)
                lines.Add(("File: " + plan.OutputFiles[0], ThemeKeys.TextDim));
        }
        foreach (string warning in plan.Warnings) lines.Add((warning, ThemeKeys.Warning));

        if (options.Format == ExportFormat.Mp4 && !(_ffmpeg.Info?.CanWriteMp4 ?? false))
        {
            ready = false;
            lines.Add((_ffmpeg.Info == null
                ? "MP4 needs FFmpeg. It is not found yet: choose where it is below, or use another format."
                : "This FFmpeg cannot write MP4 files. Choose another one below, or use another format.", ThemeKeys.Danger));
        }

        _summary.Children.Clear();
        foreach (var (text, key) in lines)
        {
            var block = Ui.Wrapped(text, maxWidth: 480);
            block.Margin = new Thickness(0, 1, 0, 1);
            block.SetResourceReference(TextBlock.ForegroundProperty, key);
            _summary.Children.Add(block);
        }
        _exportButton.IsEnabled = ready;
    }

    private static string SheetSummary(ExportPlan plan)
    {
        var o = plan.Options;
        var layout = SpriteSheetLayout.Compute(plan.OutputFrames, o.Width, o.Height, o.Columns, o.Padding);
        return string.Format(CultureInfo.CurrentCulture,
            "{0} frames in {1} columns and {2} rows. The sheet is {3} × {4} pixels.",
            plan.OutputFrames, layout.Columns, layout.Rows, layout.Width, layout.Height);
    }

    // ===================================================================== running the export

    private async Task StartExportAsync()
    {
        if (_running) return;
        try
        {
            await RunExportAsync();
        }
        catch (Exception ex)
        {
            SetRunning(false);
            string? log = CrashLog.Write("Export failed unexpectedly", ex);
            ShowResult(new ExportResult
            {
                Status = ExportStatus.Failed,
                Problem = ExportProblem.Unexpected,
                Message = "The export failed unexpectedly: " + ex.Message + (log != null ? "\nA report was written to " + log : "")
            });
        }
    }

    private async Task RunExportAsync()
    {
        foreach (var field in new[] { _width, _height, _from, _to, _fps, _columns, _padding }) field.Commit();
        var options = BuildOptions();
        var plan = ExportManager.Plan(_project, options);
        if (!plan.IsValid) return;

        var existing = ExportManager.FindExistingOutputs(_project, options);
        if (existing.Count > 0)
        {
            string text = existing.Count == 1
                ? $"\"{Path.GetFileName(existing[0])}\" already exists. Replace it?"
                : $"{existing.Count} files with the same names already exist in that folder. Replace them?";
            if (!MessageDialog.Confirm(this, "Replace files", text, "Replace", "Cancel", MessageKind.Warning)) return;
        }

        _result = null;
        _resultPanel.Visibility = Visibility.Collapsed;
        _resultPanel.Children.Clear();
        _bar.Value = 0;
        _progressText.Text = "Starting...";
        SetRunning(true);

        using var cts = new CancellationTokenSource();
        _cts = cts;
        var progress = new Progress<ExportProgress>(p =>
        {
            _bar.Value = Math.Clamp(p.Fraction, 0, 1) * 100;
            _progressText.Text = p.FramesTotal > 0
                ? string.Format(CultureInfo.CurrentCulture, "{0} ({1} of {2})", p.Message, p.FramesDone, p.FramesTotal)
                : p.Message;
        });

        ExportResult result = await ExportManager.ExportAsync(_doc, options, progress, cts.Token);
        _cts = null;

        SetRunning(false);
        if (result.Succeeded) RememberChoices(plan.Options);
        ShowResult(result);

        if (_closeWhenDone) Close();
    }

    private void RememberChoices(ExportOptions used)
    {
        var settings = _editor.Settings;
        try
        {
            string? folder = used.Format == ExportFormat.PngSequence ? used.OutputPath : Path.GetDirectoryName(used.OutputPath);
            if (!string.IsNullOrEmpty(folder)) settings.LastExportFolder = folder;
        }
        catch (ArgumentException)
        {
            // an odd path: nothing to remember
        }
        if (used.Format == ExportFormat.Mp4) settings.FfmpegPath = _ffmpeg.Path;
        _editor.SettingsManager.Save(out _);
        _editor.Say(used.Format == ExportFormat.PngSequence ? "Exported the pictures to " + used.OutputPath : "Exported to " + used.OutputPath);
    }

    private void SetRunning(bool running)
    {
        _running = running;
        _form.IsHitTestVisible = !running;
        _progressPanel.Visibility = running ? Visibility.Visible : Visibility.Collapsed;
        _exportButton.IsEnabled = !running;
        _closeButton.Content = running ? "Cancel export" : "Close";
        if (!running) UpdateSummary();
    }

    private void ShowResult(ExportResult result)
    {
        _result = result;
        _resultPanel.Children.Clear();

        string headline = result.Status switch
        {
            ExportStatus.Success => "Export finished",
            ExportStatus.Cancelled => "Export cancelled",
            _ => "The export did not work"
        };
        string colour = result.Status switch
        {
            ExportStatus.Success => ThemeKeys.Success,
            ExportStatus.Cancelled => ThemeKeys.Warning,
            _ => ThemeKeys.Danger
        };

        var title = Ui.Label(headline, size: 13.5, bold: true);
        title.SetResourceReference(TextBlock.ForegroundProperty, colour);
        _resultPanel.Children.Add(title);

        var message = Ui.Wrapped(result.Message, maxWidth: 480);
        message.Margin = new Thickness(0, 3, 0, 0);
        _resultPanel.Children.Add(message);

        if (result.Succeeded && result.Elapsed.TotalSeconds >= 0.1)
        {
            var time = Ui.Label(string.Format(CultureInfo.CurrentCulture, "Took {0:0.0} seconds.", result.Elapsed.TotalSeconds), dim: true);
            time.Margin = new Thickness(0, 2, 0, 0);
            _resultPanel.Children.Add(time);
        }
        foreach (string warning in result.Warnings)
        {
            var note = Ui.Wrapped(warning, maxWidth: 480);
            note.SetResourceReference(TextBlock.ForegroundProperty, ThemeKeys.Warning);
            note.Margin = new Thickness(0, 3, 0, 0);
            _resultPanel.Children.Add(note);
        }

        if (result.Problem == ExportProblem.FfmpegMissing || result.Problem == ExportProblem.FfmpegFailed)
        {
            var help = Ui.Wrapped("Choose the location of ffmpeg.exe in the box above, or download FFmpeg from its web page.", dim: true, maxWidth: 480);
            help.Margin = new Thickness(0, 4, 0, 0);
            _resultPanel.Children.Add(help);
            var download = Ui.TextButton("Open the FFmpeg download page", () => Native.OpenUrl(FfmpegLocator.DownloadPage), minWidth: 120);
            download.HorizontalAlignment = HorizontalAlignment.Left;
            download.Margin = new Thickness(0, 6, 0, 0);
            _resultPanel.Children.Add(download);
        }

        if (result.Succeeded && result.Files.Count > 0)
        {
            string first = result.Files[0];
            var show = Ui.TextButton("Show in folder", () => Native.RevealInExplorer(first), minWidth: 120);
            show.HorizontalAlignment = HorizontalAlignment.Left;
            show.Margin = new Thickness(0, 8, 0, 0);
            _resultPanel.Children.Add(show);
        }

        _resultPanel.Visibility = Visibility.Visible;
    }

    // ===================================================================== closing

    protected override void OnClosing(CancelEventArgs e)
    {
        base.OnClosing(e);
        if (!_running) return;

        // An export is under way: closing means "stop it", and the window closes when it has stopped.
        e.Cancel = true;
        _closeWhenDone = true;
        _cts?.Cancel();
        _progressText.Text = "Cancelling...";
    }
}
