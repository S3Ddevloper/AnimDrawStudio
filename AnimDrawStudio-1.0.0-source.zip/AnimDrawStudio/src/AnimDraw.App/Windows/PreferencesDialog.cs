using System.Windows;
using System.Windows.Controls;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.App;
using AnimDraw.Core.Settings;

namespace AnimDraw.App.Windows;

/// <summary>Settings that are kept between runs: look, autosave, confirmations and where FFmpeg is.</summary>
public sealed class PreferencesDialog : DialogWindow
{
    private readonly Editor _editor;
    private readonly RadioButton _dark = new() { Content = "Dark", GroupName = "theme" };
    private readonly RadioButton _light = new() { Content = "Light", GroupName = "theme" };
    private readonly NumberField _autosave = new(2, 0, 60, width: 60);
    private readonly CheckBox _autoKeyframe = new() { Content = "Drawing on a held frame makes a keyframe automatically" };
    private readonly CheckBox _confirm = new() { Content = "Ask before deleting layers or frames and before clearing the canvas" };
    private readonly FfmpegSelector _ffmpeg;

    public PreferencesDialog(Window owner, Editor editor) : base(owner, "Preferences")
    {
        _editor = editor;
        var settings = editor.Settings;

        _dark.IsChecked = settings.Theme == AppTheme.Dark;
        _light.IsChecked = settings.Theme == AppTheme.Light;
        _autosave.SetValue(settings.AutosaveMinutes);
        _autoKeyframe.IsChecked = settings.AutoKeyframe;
        _confirm.IsChecked = settings.ConfirmDestructive;
        _ffmpeg = new FfmpegSelector(this, settings.FfmpegPath);

        var form = new FormGrid(150) { Margin = new Thickness(26, 22, 26, 10) };

        form.AddSection("Appearance");
        var theme = new StackPanel { Orientation = Orientation.Horizontal };
        _dark.Margin = new Thickness(0, 0, 18, 0);
        theme.Children.Add(_dark);
        theme.Children.Add(_light);
        form.AddRow("Theme", theme);

        form.AddSection("Saving");
        var autosaveRow = new StackPanel { Orientation = Orientation.Horizontal };
        autosaveRow.Children.Add(_autosave.Box);
        var minutes = Ui.Label("minutes  (0 turns it off)", dim: true);
        minutes.Margin = new Thickness(8, 0, 0, 0);
        autosaveRow.Children.Add(minutes);
        form.AddRow("Automatic backup every", autosaveRow,
            "While you work, a recovery copy of unsaved changes is written to a separate folder. After a crash or power cut the program offers it back.");

        form.AddSection("Drawing");
        form.AddFull(_autoKeyframe);
        form.AddFull(_confirm);

        form.AddSection("MP4 export (FFmpeg)");
        form.AddFull(_ffmpeg);

        form.AddSection("Where things are kept");
        var folders = new StackPanel { Orientation = Orientation.Horizontal };
        var settingsFolder = new Button { Content = "Settings folder", MinWidth = 110, Margin = new Thickness(0, 0, 8, 0) };
        settingsFolder.Click += (_, _) => Native.RevealInExplorer(editor.SettingsManager.Folder);
        var recoveryFolder = new Button { Content = "Backup folder", MinWidth = 110, Margin = new Thickness(0, 0, 8, 0) };
        recoveryFolder.Click += (_, _) => Native.RevealInExplorer(editor.Recovery.Folder);
        var logFolder = new Button { Content = "Error reports", MinWidth = 110 };
        logFolder.Click += (_, _) => Native.RevealInExplorer(CrashLog.Folder);
        folders.Children.Add(settingsFolder);
        folders.Children.Add(recoveryFolder);
        folders.Children.Add(logFolder);
        form.AddFull(folders, top: 4);
        form.AddHint("Keyboard shortcuts can be looked up under Help → Keyboard Shortcuts.", 440);
        SetBody(form);

        AddButton("OK", OnOk, primary: true, isDefault: true);
        AddButton("Cancel", isCancel: true);
    }

    private void OnOk()
    {
        _autosave.Commit();
        var settings = _editor.Settings;
        settings.Theme = _light.IsChecked == true ? AppTheme.Light : AppTheme.Dark;
        settings.AutosaveMinutes = _autosave.IntValue;
        settings.AutoKeyframe = _autoKeyframe.IsChecked == true;
        settings.ConfirmDestructive = _confirm.IsChecked == true;
        settings.FfmpegPath = _ffmpeg.Path;

        if (!_editor.SettingsManager.Save(out string? error))
        {
            MessageDialog.Warn(this, "Preferences",
                "The preferences are used now, but they could not be written to disk, so they will be forgotten when the program closes.", error);
        }
        Accept();
    }
}
