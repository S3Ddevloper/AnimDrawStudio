using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.App;
using AnimDraw.Core.Editing;

namespace AnimDraw.App.Panels;

/// <summary>
/// The bottom panel: transport buttons (first, previous, play, stop, next, last), the current frame and the frame rate,
/// loop and onion-skin switches, the frame and keyframe commands, and the frame grid with its scroll bars.
/// </summary>
public sealed class TimelinePanel : Border
{
    private readonly Editor _editor;
    private readonly ShortcutMap _shortcuts;
    private readonly Action<CommandId> _run;

    private readonly TimelineView _view;
    private readonly ScrollBar _horizontal = new() { Orientation = Orientation.Horizontal };
    private readonly ScrollBar _vertical = new() { Orientation = Orientation.Vertical };
    private readonly Slider _zoom = new() { Minimum = TimelineView.MinCellWidth, Maximum = TimelineView.MaxCellWidth, Width = 90, Focusable = false, VerticalAlignment = VerticalAlignment.Center };

    private readonly Button _playButton;
    private readonly IconView _playIcon = new("play", 18);
    private readonly NumberField _frameField = new(1, 1, 1, width: 52);
    private readonly TextBlock _frameTotal;
    private readonly NumberField _fpsField = new(12, 1, 120, 0, width: 52);
    private readonly ToggleButton _loopToggle;
    private readonly ToggleButton _onionToggle;
    private readonly Button _deleteFrameButton;

    private Document _document;
    private bool _syncing;
    private bool _playing;

    public TimelinePanel(Editor editor, ShortcutMap shortcuts, Action<CommandId> runCommand)
    {
        _editor = editor;
        _shortcuts = shortcuts;
        _run = runCommand;
        _document = editor.Document;
        this.Themed(BackgroundProperty, ThemeKeys.Panel);
        this.Themed(BorderBrushProperty, ThemeKeys.Border);
        BorderThickness = new Thickness(0, 1, 0, 0);

        _view = new TimelineView(editor, shortcuts, runCommand);

        // ---- transport row ----
        var bar = new WrapPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(6, 4, 6, 2) };

        void AddButton(Button b) { b.Margin = new Thickness(0, 0, 2, 0); bar.Children.Add(b); }
        void Gap() { bar.Children.Add(Ui.VerticalLine(6)); }

        AddButton(Command("first", "First frame", CommandId.FirstFrame));
        AddButton(Command("prev", "Previous frame", CommandId.PreviousFrame));
        _playButton = new Button { Content = _playIcon, Focusable = false, MinWidth = 34 };
        Ui.ApplyStyle(_playButton, ThemeKeys.PrimaryButtonStyle);
        _playButton.Padding = new Thickness(6, 3, 6, 3);
        Ui.Tip(_playButton, "Play / pause", _shortcuts.DisplayTextOf(CommandId.PlayPause));
        _playButton.Click += (_, _) => _run(CommandId.PlayPause);
        AddButton(_playButton);
        AddButton(Command("stop", "Stop (back to where playing began)", CommandId.StopPlayback));
        AddButton(Command("next", "Next frame", CommandId.NextFrame));
        AddButton(Command("last", "Last frame", CommandId.LastFrame));
        Gap();

        var frameLabel = Ui.Label("Frame", dim: true);
        frameLabel.Margin = new Thickness(2, 0, 6, 0);
        bar.Children.Add(frameLabel);
        _frameField.Box.ToolTip = "Current frame. Type a number to jump to it.";
        bar.Children.Add(_frameField.Box);
        _frameTotal = Ui.Label("/ 1", dim: true);
        _frameTotal.Margin = new Thickness(6, 0, 4, 0);
        bar.Children.Add(_frameTotal);
        Gap();

        var fpsLabel = Ui.Label("FPS", dim: true);
        fpsLabel.Margin = new Thickness(2, 0, 6, 0);
        bar.Children.Add(fpsLabel);
        _fpsField.Box.ToolTip = "Frames per second of the animation (1 to 120).";
        bar.Children.Add(_fpsField.Box);
        Gap();

        _loopToggle = Ui.IconToggle("loop", "Loop playback  (" + _shortcuts.DisplayTextOf(CommandId.ToggleLoop) + ")", _document.Project.Loop, _ => _run(CommandId.ToggleLoop));
        _loopToggle.Margin = new Thickness(0, 0, 2, 0);
        bar.Children.Add(_loopToggle);
        _onionToggle = Ui.IconToggle("onion", "Onion skin: show the previous and next frames as ghosts  (" + _shortcuts.DisplayTextOf(CommandId.ToggleOnionSkin) + ")",
            _document.Project.Onion.Enabled, _ => _run(CommandId.ToggleOnionSkin));
        bar.Children.Add(_onionToggle);
        var onionOptions = Ui.IconButton("chevron-down", "Onion skin settings", () => _run(CommandId.OnionSkinSettings), 12);
        onionOptions.MinWidth = 18;
        onionOptions.Padding = new Thickness(1, 5, 1, 5);
        onionOptions.Margin = new Thickness(0, 0, 0, 0);
        bar.Children.Add(onionOptions);
        Gap();

        AddButton(Command("frame-add", "Add a frame after this one", CommandId.InsertFrame));
        AddButton(Command("duplicate", "Duplicate this frame", CommandId.DuplicateFrame));
        _deleteFrameButton = Command("frame-del", "Delete this frame", CommandId.DeleteFrame);
        AddButton(_deleteFrameButton);
        Gap();
        AddButton(Command("keyframe", "Make a keyframe here (copies the drawing that is held)", CommandId.InsertKeyframe));
        AddButton(Command("keyframe-blank", "Make a blank keyframe here", CommandId.InsertBlankKeyframe));
        AddButton(Command("minus", "Remove the keyframe here (the previous drawing is held again)", CommandId.RemoveKeyframe));

        // ---- grid with scroll bars ----
        var grid = Ui.MakeGrid("*,Auto", "Auto,*,Auto");
        bar.Place(grid, 0, 0, columnSpan: 2);
        _view.Place(grid, 1, 0);
        _vertical.Place(grid, 1, 1);

        var bottom = Ui.MakeGrid("*,Auto");
        _horizontal.Place(bottom, 0, 0);
        var zoomBox = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(8, 0, 8, 0), VerticalAlignment = VerticalAlignment.Center };
        var zoomLabel = Ui.Label("Zoom", dim: true);
        zoomLabel.Margin = new Thickness(0, 0, 6, 0);
        zoomBox.Children.Add(zoomLabel);
        zoomBox.Children.Add(_zoom);
        zoomBox.ToolTip = "Width of the frame cells (Ctrl + mouse wheel over the grid)";
        zoomBox.Place(bottom, 0, 1);
        bottom.Place(grid, 2, 0, columnSpan: 2);

        Child = grid;

        // ---- wiring ----
        _zoom.Value = _view.CellWidth;
        _zoom.ValueChanged += (_, e) =>
        {
            if (_syncing) return;
            _view.CellWidth = e.NewValue;
        };
        _horizontal.ValueChanged += (_, e) =>
        {
            if (_syncing) return;
            _view.HorizontalOffset = e.NewValue;
        };
        _vertical.ValueChanged += (_, e) =>
        {
            if (_syncing) return;
            _view.VerticalOffset = e.NewValue;
        };
        _view.ScrollMetricsChanged += SyncScrollBars;

        _frameField.ValueChanged += v =>
        {
            if (_editor.IsPlaying) _editor.PausePlayback();
            _editor.Document.GoToFrame((int)v - 1);
        };
        _fpsField.ValueChanged += v => _editor.Document.SetFps(v);

        editor.DocumentReplaced += () =>
        {
            _document.Changed -= OnDocumentChanged;
            _document = _editor.Document;
            _document.Changed += OnDocumentChanged;
            RefreshState();
        };
        _document.Changed += OnDocumentChanged;
        RefreshState();
        SyncScrollBars();
    }

    /// <summary>The frame grid, so that the window can show the playback position in it.</summary>
    public TimelineView View => _view;

    private Button Command(string icon, string tip, CommandId id)
    {
        var button = Ui.IconButton(icon, tip + ShortcutText(id), () => _run(id));
        return button;
    }

    private string ShortcutText(CommandId id)
    {
        string text = _shortcuts.DisplayTextOf(id);
        return text.Length == 0 ? "" : "  (" + text + ")";
    }

    private void OnDocumentChanged(object? sender, DocumentChangedEventArgs e)
    {
        const ChangeKind relevant = ChangeKind.Frame | ChangeKind.Structure | ChangeKind.Settings;
        if ((e.Kind & relevant) != 0) RefreshState();
    }

    /// <summary>Shows whether the animation is playing and which frame it is on (while playing, the document's frame does not move).</summary>
    public void UpdatePlayback(bool playing, int frame)
    {
        _playing = playing;
        _playIcon.Icon = playing ? "pause" : "play";
        _view.PlaybackFrame = playing ? frame : null;
        _syncing = true;
        _frameField.SetValue(frame + 1);
        _syncing = false;
    }

    /// <summary>Brings the frame number, frame rate and switches in line with the project.</summary>
    public void RefreshState()
    {
        _syncing = true;
        try
        {
            var project = _document.Project;
            _frameField.Maximum = project.FrameCount;
            _frameField.SetValue(_playing ? _frameField.Value : _document.CurrentFrame + 1);
            _frameTotal.Text = "/ " + project.FrameCount.ToString(CultureInfo.CurrentCulture);

            _fpsField.Decimals = Math.Abs(project.Fps - Math.Round(project.Fps)) < 0.005 ? 0 : 2;
            _fpsField.SetValue(project.Fps);
            _loopToggle.IsChecked = project.Loop;
            _onionToggle.IsChecked = project.Onion.Enabled;
            _deleteFrameButton.IsEnabled = _document.CanDeleteFrame;
        }
        finally
        {
            _syncing = false;
        }
        SyncScrollBars();
    }

    private void SyncScrollBars()
    {
        _syncing = true;
        try
        {
            double hMax = Math.Max(0, _view.ExtentWidth - _view.ViewportWidth);
            _horizontal.Minimum = 0;
            _horizontal.Maximum = hMax;
            _horizontal.ViewportSize = Math.Max(1, _view.ViewportWidth);
            _horizontal.SmallChange = _view.CellWidth * 3;
            _horizontal.LargeChange = Math.Max(_view.CellWidth, _view.ViewportWidth * 0.9);
            _horizontal.Value = Math.Min(_view.HorizontalOffset, hMax);
            _horizontal.IsEnabled = hMax > 0.5;

            double vMax = Math.Max(0, _view.ExtentHeight - _view.ViewportHeight);
            _vertical.Minimum = 0;
            _vertical.Maximum = vMax;
            _vertical.ViewportSize = Math.Max(1, _view.ViewportHeight);
            _vertical.SmallChange = TimelineView.RowHeight;
            _vertical.LargeChange = Math.Max(TimelineView.RowHeight, _view.ViewportHeight * 0.9);
            _vertical.Value = Math.Min(_view.VerticalOffset, vMax);
            _vertical.Visibility = vMax > 0.5 ? Visibility.Visible : Visibility.Collapsed;

            if (Math.Abs(_zoom.Value - _view.CellWidth) > 0.01) _zoom.Value = _view.CellWidth;
        }
        finally
        {
            _syncing = false;
        }
    }
}
