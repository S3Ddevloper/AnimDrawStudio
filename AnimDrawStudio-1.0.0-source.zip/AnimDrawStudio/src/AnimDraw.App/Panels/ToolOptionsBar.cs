using System.Windows;
using System.Windows.Controls;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.App;
using AnimDraw.Core.Drawing;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Tools;

namespace AnimDraw.App.Panels;

/// <summary>The strip above the canvas that shows the options of the active tool: size, opacity, hardness, fill tolerance and so on.</summary>
public sealed class ToolOptionsBar : Border
{
    private readonly Editor _editor;
    private readonly WrapPanel _panel = new() { Orientation = Orientation.Horizontal };
    private readonly Action<CommandId> _run;
    private Action? _refresh;
    private bool _rebuilding;

    public ToolOptionsBar(Editor editor, Action<CommandId> runCommand)
    {
        _editor = editor;
        _run = runCommand;
        this.Themed(BackgroundProperty, ThemeKeys.Panel);
        this.Themed(BorderBrushProperty, ThemeKeys.Border);
        BorderThickness = new Thickness(0, 0, 0, 1);
        MinHeight = 40;
        Padding = new Thickness(8, 3, 8, 3);
        Child = _panel;

        editor.Tools.ToolChanged += _ => Rebuild();
        editor.ToolSettings.Changed += () => _refresh?.Invoke();
        editor.DocumentReplaced += () =>
        {
            AttachDocument();
            Rebuild();
        };
        AttachDocument();
        Rebuild();
    }

    private Document? _attached;

    private void AttachDocument()
    {
        if (_attached != null) _attached.Changed -= OnDocumentChanged;
        _attached = _editor.Document;
        _attached.Changed += OnDocumentChanged;
    }

    private void OnDocumentChanged(object? sender, DocumentChangedEventArgs e)
    {
        if ((e.Kind & ChangeKind.Selection) != 0) _refresh?.Invoke();
    }

    private ToolSettings Settings => _editor.ToolSettings;

    // ----- building the bar for a tool -----

    private void Rebuild()
    {
        if (_rebuilding) return;
        _rebuilding = true;
        try
        {
            _panel.Children.Clear();
            _refresh = null;
            switch (_editor.Tools.CurrentKind)
            {
                case ToolKind.Brush: BuildBrush(Settings.Brush, hardness: true, smoothing: true, opacityLabel: "Opacity", pencil: false); break;
                case ToolKind.Pencil: BuildBrush(Settings.Pencil, hardness: false, smoothing: true, opacityLabel: "Opacity", pencil: true); break;
                case ToolKind.Eraser: BuildBrush(Settings.Eraser, hardness: true, smoothing: true, opacityLabel: "Strength", pencil: false); break;
                case ToolKind.Line: BuildShape(withStyle: false, "Hold Shift to snap to 15° steps."); break;
                case ToolKind.Rectangle: BuildShape(withStyle: true, "Hold Shift for a square."); break;
                case ToolKind.Ellipse: BuildShape(withStyle: true, "Hold Shift for a circle."); break;
                case ToolKind.Fill: BuildFill(); break;
                case ToolKind.Eyedropper: BuildEyedropper(); break;
                case ToolKind.Select: BuildSelect(); break;
                case ToolKind.Move: BuildHint("Drag to move the selection, or the whole drawing of this layer when nothing is selected. Alt drags a copy, Shift keeps to one direction, arrow keys nudge."); break;
                case ToolKind.Hand: BuildView("Drag to pan. You can also hold the Space bar or use the middle mouse button with any tool."); break;
                case ToolKind.Zoom: BuildView("Click to zoom in, Alt or right-click to zoom out, drag a rectangle to zoom to it."); break;
            }
            _refresh?.Invoke();
        }
        finally
        {
            _rebuilding = false;
        }
    }

    private void Add(UIElement element, double right = 18)
    {
        if (element is FrameworkElement fe) fe.Margin = new Thickness(0, 3, right, 3);
        _panel.Children.Add(element);
    }

    private void BuildBrush(BrushSettings brush, bool hardness, bool smoothing, string opacityLabel, bool pencil)
    {
        var size = new SliderField("Size", BrushSettings.MinSize, BrushSettings.MaxSize, brush.Size, 0, "px", logarithmic: true, sliderWidth: 90, labelWidth: 34,
            tip: "Brush size in canvas pixels. Shortcut: [ and ]");
        size.ValueChanged += v => { brush.Size = v; Settings.RaiseChanged(); };
        Add(size);

        var opacity = new SliderField(opacityLabel, 1, 100, brush.Opacity * 100, 0, "%", sliderWidth: 80, labelWidth: 50,
            tip: "How solid the whole stroke is. Overlapping parts of one stroke do not get darker.");
        opacity.ValueChanged += v => { brush.Opacity = v / 100; Settings.RaiseChanged(); };
        Add(opacity);

        SliderField? hard = null;
        if (hardness)
        {
            hard = new SliderField("Hardness", 0, 100, brush.Hardness * 100, 0, "%", sliderWidth: 70, labelWidth: 56, tip: "0% gives a soft, feathered edge; 100% a crisp edge.");
            hard.ValueChanged += v => { brush.Hardness = v / 100; Settings.RaiseChanged(); };
            Add(hard);
        }

        SliderField? smooth = null;
        if (smoothing)
        {
            smooth = new SliderField("Smoothing", 0, 95, brush.Smoothing * 100, 0, "%", sliderWidth: 70, labelWidth: 62,
                tip: "Steadies shaky lines. Higher values lag behind the pointer more.");
            smooth.ValueChanged += v => { brush.Smoothing = v / 100; Settings.RaiseChanged(); };
            Add(smooth);
        }

        var penSize = CheckBox("Pen pressure: size", brush.PressureAffectsSize, "A pen tablet changes the size with pressure.");
        penSize.Click += (_, _) => { brush.PressureAffectsSize = penSize.IsChecked == true; Settings.RaiseChanged(); };
        Add(penSize, 12);
        var penOpacity = CheckBox("opacity", brush.PressureAffectsOpacity, "A pen tablet changes the opacity with pressure.");
        penOpacity.Click += (_, _) => { brush.PressureAffectsOpacity = penOpacity.IsChecked == true; Settings.RaiseChanged(); };
        Add(penOpacity);

        CheckBox? snap = null;
        if (pencil)
        {
            snap = CheckBox("Snap to pixels", brush.SnapToPixels, "Keeps pencil lines on whole pixels, for pixel art.");
            snap.Click += (_, _) => { brush.SnapToPixels = snap.IsChecked == true; brush.Antialias = snap.IsChecked != true; Settings.RaiseChanged(); };
            Add(snap);
        }

        _refresh = () =>
        {
            size.SetValue(brush.Size);
            opacity.SetValue(brush.Opacity * 100);
            hard?.SetValue(brush.Hardness * 100);
            smooth?.SetValue(brush.Smoothing * 100);
            penSize.IsChecked = brush.PressureAffectsSize;
            penOpacity.IsChecked = brush.PressureAffectsOpacity;
            if (snap != null) snap.IsChecked = brush.SnapToPixels;
        };
    }

    private void BuildShape(bool withStyle, string hint)
    {
        var width = new SliderField("Line width", 1, 200, Settings.ShapeLineWidth, 0, "px", logarithmic: true, sliderWidth: 90, labelWidth: 62);
        width.ValueChanged += v => { Settings.ShapeLineWidth = v; Settings.RaiseChanged(); };
        Add(width);

        ComboBox? style = null;
        if (withStyle)
        {
            style = new ComboBox { Width = 140, Focusable = false, VerticalAlignment = VerticalAlignment.Center };
            style.Items.Add("Outline");
            style.Items.Add("Filled");
            style.Items.Add("Outline and fill");
            style.SelectionChanged += (_, _) =>
            {
                if (_rebuilding || style.SelectedIndex < 0) return;
                Settings.ShapeStyle = (ShapeStyle)style.SelectedIndex;
                Settings.RaiseChanged();
            };
            style.ToolTip = "Filled shapes use the primary colour; with an outline, the fill uses the secondary colour.";
            Add(style);
        }
        var text = Ui.Label(hint, dim: true);
        Add(text, 0);

        _refresh = () =>
        {
            width.SetValue(Settings.ShapeLineWidth);
            if (style != null)
            {
                bool was = _rebuilding;
                _rebuilding = true;
                style.SelectedIndex = (int)Settings.ShapeStyle;
                _rebuilding = was;
            }
        };
    }

    private void BuildFill()
    {
        var fill = Settings.Fill;
        var tolerance = new SliderField("Tolerance", 0, 255, fill.Tolerance, 0, "", sliderWidth: 90, labelWidth: 58,
            tip: "How different a colour may be from the clicked one and still be filled.");
        tolerance.ValueChanged += v => { fill.Tolerance = (int)v; Settings.RaiseChanged(); };
        Add(tolerance);

        var grow = new SliderField("Grow", 0, 4, fill.Grow, 0, "px", sliderWidth: 60, labelWidth: 32,
            tip: "Spreads the fill under line art so no light fringe is left along the lines.");
        grow.ValueChanged += v => { fill.Grow = (int)v; Settings.RaiseChanged(); };
        Add(grow);

        var contiguous = CheckBox("Contiguous", fill.Contiguous, "Fill only the connected area. Off: fill every matching pixel.");
        contiguous.Click += (_, _) => { fill.Contiguous = contiguous.IsChecked == true; Settings.RaiseChanged(); };
        Add(contiguous, 12);
        var allLayers = CheckBox("All layers", fill.SampleAllLayers, "Decide the area from every visible layer instead of only the active one.");
        allLayers.Click += (_, _) => { fill.SampleAllLayers = allLayers.IsChecked == true; Settings.RaiseChanged(); };
        Add(allLayers);

        _refresh = () =>
        {
            tolerance.SetValue(fill.Tolerance);
            grow.SetValue(fill.Grow);
            contiguous.IsChecked = fill.Contiguous;
            allLayers.IsChecked = fill.SampleAllLayers;
        };
    }

    private void BuildEyedropper()
    {
        var all = CheckBox("Sample all layers", Settings.EyedropperSampleAllLayers, "Pick the visible colour (all layers) instead of the colour on the active layer only.");
        all.Click += (_, _) => { Settings.EyedropperSampleAllLayers = all.IsChecked == true; Settings.RaiseChanged(); };
        Add(all, 18);
        Add(Ui.Label("Left click sets the primary colour, right click the secondary colour.", dim: true), 0);
        _refresh = () => all.IsChecked = Settings.EyedropperSampleAllLayers;
    }

    private void BuildSelect()
    {
        var info = Ui.Label("", dim: false);
        Add(Ui.IconTextButton("select", "Select all", () => _run(CommandId.SelectAll)), 8);
        Add(Ui.TextButton("Deselect", () => _run(CommandId.Deselect), minWidth: 70), 18);
        Add(info, 18);
        Add(Ui.Label("Drag a rectangle. Ctrl+C, Ctrl+X and Ctrl+V copy, cut and paste; Delete clears.", dim: true), 0);
        _refresh = () =>
        {
            var selection = _editor.Document.Selection;
            info.Text = selection is { IsEmpty: false } r ? $"Selection  {r.X}, {r.Y}   {r.Width} × {r.Height} px" : "No selection";
        };
    }

    private void BuildHint(string text) => Add(Ui.Label(text, dim: true), 0);

    private void BuildView(string text)
    {
        Add(Ui.TextButton("Fit", () => _run(CommandId.ZoomFit), minWidth: 50), 6);
        Add(Ui.TextButton("100%", () => _run(CommandId.Zoom100), minWidth: 54), 6);
        Add(Ui.TextButton("200%", () => _run(CommandId.Zoom200), minWidth: 54), 18);
        Add(Ui.Label(text, dim: true), 0);
    }

    private static CheckBox CheckBox(string text, bool isChecked, string tip) => new()
    {
        Content = text,
        IsChecked = isChecked,
        Focusable = false,
        ToolTip = tip,
        VerticalAlignment = VerticalAlignment.Center
    };
}
