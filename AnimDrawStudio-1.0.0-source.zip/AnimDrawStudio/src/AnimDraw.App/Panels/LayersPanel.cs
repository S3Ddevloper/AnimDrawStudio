using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.App;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Model;

namespace AnimDraw.App.Panels;

/// <summary>
/// The list of layers, top layer first. Each row has an eye (show or hide), a lock, a small picture of the layer's drawing on
/// the current frame and the layer's name. Click selects, double-click renames, dragging a row reorders, right-click opens a menu.
/// </summary>
public sealed class LayersPanel : Border
{
    private const int ThumbBoxWidth = 44;
    private const int ThumbBoxHeight = 30;

    private sealed class LayerRow : Border
    {
        public LayerRow(Layer layer) => Layer = layer;
        public Layer Layer { get; }
        public Grid Content { get; init; } = null!;
        public TextBlock NameText { get; init; } = null!;
        public Image Thumbnail { get; init; } = null!;
        public WriteableBitmap? Bitmap { get; set; }
        public bool Renaming { get; set; }
    }

    private readonly Editor _editor;
    private readonly Action<CommandId> _run;
    private readonly ShortcutMap _shortcuts;
    private readonly StackPanel _rows = new();
    private readonly ScrollViewer _scroll;
    private readonly SliderField _opacity;
    private readonly DispatcherTimer _thumbnailTimer;
    private readonly HashSet<Guid> _staleThumbnails = new();
    private readonly List<LayerRow> _rowList = new();
    private readonly List<Button> _headerButtons = new();

    private Document _document;
    private string _signature = "";
    private bool _allThumbnailsStale;

    private LayerRow? _pressedRow;
    private double _pressY;
    private bool _dragging;
    private LayerRow? _dropRow;
    private bool _dropBelow;

    public LayersPanel(Editor editor, ShortcutMap shortcuts, Action<CommandId> runCommand)
    {
        _editor = editor;
        _shortcuts = shortcuts;
        _run = runCommand;
        _document = editor.Document;
        this.Themed(BackgroundProperty, ThemeKeys.Panel);

        var root = Ui.MakeGrid("*", "Auto,*,Auto");

        Button Header(string icon, string tip, CommandId command)
        {
            var b = Ui.IconButton(icon, tip + ShortcutSuffix(command), () => _run(command), 16);
            b.MinWidth = 26;
            b.MinHeight = 26;
            _headerButtons.Add(b);
            return b;
        }

        var header = Ui.PanelHeader("Layers",
            Header("plus", "New layer", CommandId.NewLayer),
            Header("duplicate", "Duplicate layer", CommandId.DuplicateLayer),
            Header("up", "Move layer up", CommandId.LayerUp),
            Header("down", "Move layer down", CommandId.LayerDown),
            Header("merge", "Merge layer into the one below", CommandId.MergeLayerDown),
            Header("trash", "Delete layer", CommandId.DeleteLayer));
        header.Place(root, 0, 0);

        _scroll = new ScrollViewer
        {
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            Content = _rows,
            Focusable = false
        };
        _scroll.Place(root, 1, 0);

        var footer = Ui.Box(ThemeKeys.PanelHeader, ThemeKeys.Border, new Thickness(0, 1, 0, 0));
        footer.Padding = new Thickness(10, 7, 10, 7);
        _opacity = new SliderField("Layer opacity", 0, 100, 100, 0, "%", sliderWidth: 90, labelWidth: 0, tip: "How see-through the selected layer is.");
        _opacity.ValueChanged += v => _document.SetLayerOpacity(_document.ActiveLayer, v / 100.0, coalesce: true);
        footer.Child = _opacity;
        footer.Place(root, 2, 0);

        Child = root;

        _thumbnailTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(280) };
        _thumbnailTimer.Tick += (_, _) => RefreshStaleThumbnails();

        editor.DocumentReplaced += () =>
        {
            Attach(_editor.Document);
            RebuildRows();
        };
        ThemeManager.ThemeChanged += () => RebuildRows();
        Attach(_document);
        RebuildRows();
    }

    private string ShortcutSuffix(CommandId id)
    {
        string text = _shortcuts.DisplayTextOf(id);
        return text.Length == 0 ? "" : "  (" + text + ")";
    }

    private void Attach(Document document)
    {
        _document.Changed -= OnDocumentChanged;
        _document = document;
        _document.Changed += OnDocumentChanged;
    }

    // ----- following the document -----

    private string Signature() =>
        string.Join("|", _document.Project.Layers.Select(l => $"{l.Id:N}:{l.Name}:{(l.Visible ? 1 : 0)}{(l.Locked ? 1 : 0)}"));

    private void OnDocumentChanged(object? sender, DocumentChangedEventArgs e)
    {
        if (_pressedRow != null && _dragging) return; // never rebuild under the user's finger

        if ((e.Kind & (ChangeKind.Structure | ChangeKind.Settings)) != 0)
        {
            if (Signature() != _signature) RebuildRows();
            else
            {
                UpdateActiveHighlight();
                MarkAllThumbnailsStale();
            }
        }
        else
        {
            if ((e.Kind & ChangeKind.ActiveLayer) != 0) UpdateActiveHighlight();
            if ((e.Kind & ChangeKind.Frame) != 0) MarkAllThumbnailsStale();
            else if ((e.Kind & ChangeKind.Pixels) != 0) MarkThumbnailStale(_document.ActiveLayer.Id);
        }
        UpdateOpacity();
    }

    private void UpdateOpacity()
    {
        _opacity.SetValue(_document.ActiveLayer.Opacity * 100);
    }

    // ----- rows -----

    private void RebuildRows()
    {
        _signature = Signature();
        _rows.Children.Clear();
        _rowList.Clear();

        var layers = _document.Project.Layers;
        for (int i = layers.Count - 1; i >= 0; i--)
        {
            LayerRow row = BuildRow(layers[i]);
            _rowList.Add(row);
            _rows.Children.Add(row);
        }
        _rows.Margin = new Thickness(0, 2, 0, 6);
        UpdateActiveHighlight();
        MarkAllThumbnailsStale();
        UpdateOpacity();
    }

    private LayerRow BuildRow(Layer layer)
    {
        var grid = Ui.MakeGrid("Auto,Auto,Auto,*");

        var eye = Ui.IconButton(layer.Visible ? "eye" : "eye-off", layer.Visible ? "Hide layer" : "Show layer",
            () => { _document.SetLayerVisible(layer, !layer.Visible); }, 16);
        eye.MinWidth = 26;
        eye.MinHeight = 26;
        eye.Themed(Control.ForegroundProperty, layer.Visible ? ThemeKeys.Text : ThemeKeys.TextDisabled);
        eye.Place(grid, 0, 0);

        var padlock = Ui.IconButton(layer.Locked ? "lock" : "unlock", layer.Locked ? "Unlock layer" : "Lock layer (protects it from drawing)",
            () => { _document.SetLayerLocked(layer, !layer.Locked); }, 16);
        padlock.MinWidth = 26;
        padlock.MinHeight = 26;
        padlock.Themed(Control.ForegroundProperty, layer.Locked ? ThemeKeys.Warning : ThemeKeys.TextDisabled);
        padlock.Place(grid, 0, 1);

        var image = new Image { Stretch = Stretch.None, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.NearestNeighbor);
        var frame = new Border
        {
            Width = ThumbBoxWidth,
            Height = ThumbBoxHeight,
            Margin = new Thickness(6, 0, 8, 0),
            Background = CheckerBrushes.Small,
            BorderThickness = new Thickness(1),
            Child = image,
            Opacity = layer.Visible ? 1 : 0.45,
            SnapsToDevicePixels = true
        };
        frame.Themed(Border.BorderBrushProperty, ThemeKeys.BorderStrong);
        frame.Place(grid, 0, 2);

        var name = new TextBlock { Text = layer.Name, VerticalAlignment = VerticalAlignment.Center, TextTrimming = TextTrimming.CharacterEllipsis, ToolTip = layer.Name };
        name.Themed(TextBlock.ForegroundProperty, layer.Visible ? ThemeKeys.Text : ThemeKeys.TextDisabled);
        name.Place(grid, 0, 3);

        var row = new LayerRow(layer)
        {
            Content = grid,
            NameText = name,
            Thumbnail = image,
            Child = grid,
            Margin = new Thickness(4, 1, 4, 1),
            Padding = new Thickness(3, 3, 6, 3),
            CornerRadius = new CornerRadius(5),
            BorderThickness = new Thickness(0, 2, 0, 2),
            BorderBrush = Brushes.Transparent,
            Background = Brushes.Transparent,
            Cursor = Cursors.Arrow
        };

        row.MouseLeftButtonDown += (_, e) => OnRowPressed(row, e);
        row.MouseMove += (_, e) => OnRowMoved(row, e);
        row.MouseLeftButtonUp += (_, e) => OnRowReleased(row, e);
        row.LostMouseCapture += (_, _) => OnRowCaptureLost(row);
        row.MouseRightButtonDown += (_, _) => _document.SetActiveLayer(layer);
        row.MouseRightButtonUp += (_, e) =>
        {
            ShowMenu(row);
            e.Handled = true;
        };
        row.MouseEnter += (_, _) => { if (!IsActive(row)) row.Themed(BackgroundProperty, ThemeKeys.ControlHover); };
        row.MouseLeave += (_, _) => { if (!IsActive(row)) row.Background = Brushes.Transparent; };
        return row;
    }

    private bool IsActive(LayerRow row) => ReferenceEquals(row.Layer, _document.ActiveLayer);

    private void UpdateActiveHighlight()
    {
        Layer active = _document.ActiveLayer;
        foreach (LayerRow row in _rowList)
        {
            if (ReferenceEquals(row.Layer, active)) row.Themed(BackgroundProperty, ThemeKeys.AccentSoft);
            else row.Background = Brushes.Transparent;
        }
        LayerRow? activeRow = _rowList.FirstOrDefault(r => ReferenceEquals(r.Layer, active));
        activeRow?.BringIntoView();
    }

    // ----- thumbnails -----

    private void MarkAllThumbnailsStale()
    {
        _allThumbnailsStale = true;
        _thumbnailTimer.Start();
    }

    private void MarkThumbnailStale(Guid layerId)
    {
        _staleThumbnails.Add(layerId);
        _thumbnailTimer.Start();
    }

    private void RefreshStaleThumbnails()
    {
        _thumbnailTimer.Stop();
        var (width, height) = LayerThumbnail.SizeFor(_document.CanvasWidth, _document.CanvasHeight, ThumbBoxWidth - 2, ThumbBoxHeight - 2);
        int frame = _document.CurrentFrame;
        foreach (LayerRow row in _rowList)
        {
            if (!_allThumbnailsStale && !_staleThumbnails.Contains(row.Layer.Id)) continue;
            RefreshThumbnail(row, width, height, frame);
        }
        _allThumbnailsStale = false;
        _staleThumbnails.Clear();
    }

    private static void RefreshThumbnail(LayerRow row, int width, int height, int frame)
    {
        if (row.Bitmap == null || row.Bitmap.PixelWidth != width || row.Bitmap.PixelHeight != height)
        {
            row.Bitmap = new WriteableBitmap(width, height, 96, 96, PixelFormats.Pbgra32, null);
            row.Thumbnail.Source = row.Bitmap;
        }
        Cel? cel = row.Layer.GetCelAt(frame);
        uint[] pixels = cel == null ? new uint[width * height] : LayerThumbnail.Render(cel.Surface, width, height);
        row.Bitmap.WritePixels(new Int32Rect(0, 0, width, height), pixels, width * 4, 0);
    }

    // ----- select, drag to reorder -----

    private void OnRowPressed(LayerRow row, MouseButtonEventArgs e)
    {
        if (row.Renaming) return;
        _document.SetActiveLayer(row.Layer);
        if (e.ClickCount == 2)
        {
            BeginRename(row.Layer);
            e.Handled = true;
            return;
        }
        _pressedRow = row;
        _pressY = e.GetPosition(_rows).Y;
        _dragging = false;
        row.CaptureMouse();
    }

    private void OnRowMoved(LayerRow row, MouseEventArgs e)
    {
        if (_pressedRow != row || e.LeftButton != MouseButtonState.Pressed) return;
        double y = e.GetPosition(_rows).Y;
        if (!_dragging && Math.Abs(y - _pressY) > 6) _dragging = true;
        if (!_dragging) return;

        // The row whose middle is nearest to the pointer is the drop target; the pointer's side of its middle picks above or below.
        LayerRow? target = null;
        bool below = false;
        double best = double.MaxValue;
        foreach (LayerRow candidate in _rowList)
        {
            double middle = candidate.TranslatePoint(new Point(0, candidate.ActualHeight / 2), _rows).Y;
            double distance = Math.Abs(y - middle);
            if (distance < best)
            {
                best = distance;
                target = candidate;
                below = y > middle;
            }
        }
        ShowDropMarker(target, below);
    }

    private void OnRowReleased(LayerRow row, MouseButtonEventArgs e)
    {
        if (_pressedRow != row) return;
        bool wasDragging = _dragging;
        LayerRow? target = _dropRow;
        bool below = _dropBelow;
        _pressedRow = null;
        _dragging = false;
        row.ReleaseMouseCapture();
        ShowDropMarker(null, false);

        if (!wasDragging || target == null || ReferenceEquals(target, row)) return;

        // Rows are listed top first, the layers bottom first, so the list index and the layer index run in opposite directions.
        int count = _rowList.Count;
        int fromDisplay = _rowList.IndexOf(row);
        int targetDisplay = _rowList.IndexOf(target);
        int slot = below ? targetDisplay + 1 : targetDisplay; // insertion point in the current display order
        int finalDisplay = slot > fromDisplay ? slot - 1 : slot;
        int newLayerIndex = count - 1 - finalDisplay;
        if (newLayerIndex == _document.Project.IndexOfLayer(row.Layer)) return;
        _document.MoveLayer(row.Layer, newLayerIndex);
        e.Handled = true;
    }

    /// <summary>
    /// The mouse capture was taken away in the middle of a press (another window was activated, a dialog opened). Without
    /// this the panel would think a drag is still going on and stop following the project.
    /// </summary>
    private void OnRowCaptureLost(LayerRow row)
    {
        if (_pressedRow != row) return; // the normal end of a press has already cleared this
        _pressedRow = null;
        _dragging = false;
        ShowDropMarker(null, false);
        if (Signature() != _signature) RebuildRows();
    }

    private void ShowDropMarker(LayerRow? target, bool below)
    {
        if (_dropRow != null)
        {
            _dropRow.BorderBrush = Brushes.Transparent;
            _dropRow.BorderThickness = new Thickness(0, 2, 0, 2);
        }
        _dropRow = target;
        _dropBelow = below;
        if (target == null) return;
        target.Themed(Border.BorderBrushProperty, ThemeKeys.Accent);
        target.BorderThickness = below ? new Thickness(0, 0, 0, 2) : new Thickness(0, 2, 0, 0);
    }

    // ----- rename -----

    /// <summary>Lets the user type a new name for a layer (the active layer when none is given).</summary>
    public void BeginRename(Layer? layer = null)
    {
        layer ??= _document.ActiveLayer;
        LayerRow? row = _rowList.FirstOrDefault(r => ReferenceEquals(r.Layer, layer));
        if (row == null) return;

        row.Renaming = true;
        var box = new TextBox
        {
            Text = layer.Name,
            MaxLength = Document.MaxLayerNameLength,
            VerticalAlignment = VerticalAlignment.Center,
            VerticalContentAlignment = VerticalAlignment.Center,
            MinHeight = 24
        };
        Grid.SetColumn(box, 3);
        row.Content.Children.Remove(row.NameText);
        row.Content.Children.Add(box);

        bool finished = false;
        void Finish(bool apply)
        {
            if (finished) return;
            finished = true;
            row.Renaming = false;
            string text = box.Text;
            if (apply) _document.RenameLayer(layer!, text);
            RebuildRows(); // also restores the label when the name did not change
            _editor.Say(apply ? "Layer renamed." : "Rename cancelled.");
        }

        box.KeyDown += (_, e) =>
        {
            if (e.Key == Key.Enter) { Finish(true); e.Handled = true; }
            else if (e.Key == Key.Escape) { Finish(false); e.Handled = true; }
        };
        box.LostKeyboardFocus += (_, _) => Finish(true);
        box.Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() =>
        {
            box.Focus();
            box.SelectAll();
        }));
    }

    // ----- context menu -----

    private void ShowMenu(LayerRow row)
    {
        Layer layer = row.Layer;
        var menu = new ContextMenu();

        MenuItem Item(string header, Action action, string? gesture = null)
        {
            var item = new MenuItem { Header = header, InputGestureText = gesture ?? "" };
            item.Click += (_, _) => action();
            return item;
        }

        menu.Items.Add(Item("Rename", () => BeginRename(layer), _shortcuts.DisplayTextOf(CommandId.RenameLayer)));
        menu.Items.Add(Item("Duplicate", () => _run(CommandId.DuplicateLayer), _shortcuts.DisplayTextOf(CommandId.DuplicateLayer)));
        menu.Items.Add(Item("Delete", () => _run(CommandId.DeleteLayer), _shortcuts.DisplayTextOf(CommandId.DeleteLayer)));
        menu.Items.Add(new Separator());
        menu.Items.Add(Item(layer.Visible ? "Hide" : "Show", () => _document.SetLayerVisible(layer, !layer.Visible)));
        menu.Items.Add(Item(layer.Locked ? "Unlock" : "Lock", () => _document.SetLayerLocked(layer, !layer.Locked)));
        menu.Items.Add(new Separator());
        menu.Items.Add(Item("Move up", () => _run(CommandId.LayerUp), _shortcuts.DisplayTextOf(CommandId.LayerUp)));
        menu.Items.Add(Item("Move down", () => _run(CommandId.LayerDown), _shortcuts.DisplayTextOf(CommandId.LayerDown)));
        menu.Items.Add(Item("Merge down", () => _run(CommandId.MergeLayerDown), _shortcuts.DisplayTextOf(CommandId.MergeLayerDown)));
        menu.PlacementTarget = row;
        menu.IsOpen = true;
    }
}
