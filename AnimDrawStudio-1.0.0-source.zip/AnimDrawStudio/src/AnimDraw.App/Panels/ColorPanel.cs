using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.App;
using AnimDraw.Core.Imaging;

namespace AnimDraw.App.Panels;

/// <summary>
/// Chooses the two paint colours: a colour square with a hue bar, hex and RGB boxes, a ready-made palette, the colours
/// used recently, and colours saved on purpose. The colour being edited is the one whose swatch has the blue frame.
/// </summary>
public sealed class ColorPanel : Border
{
    private static readonly string[] Palette =
    {
        "#000000", "#3D3D3D", "#7A7A7A", "#B8B8B8", "#FFFFFF", "#7B3F00", "#C68642", "#F1C27D", "#FFE0BD", "#FF0000", "#FF7F00", "#FFD400",
        "#A6E22E", "#00A651", "#00B7C3", "#0078D7", "#1C2BFF", "#7F00FF", "#C71585", "#FF69B4", "#8B0000", "#006400", "#00008B", "#FFDAB9"
    };

    private readonly Editor _editor;
    private readonly SaturationValueBox _square = new() { Height = 128 };
    private readonly HueSlider _hueBar = new();
    private readonly TextBox _hexBox = new() { Width = 78, MaxLength = 9, VerticalContentAlignment = VerticalAlignment.Center };
    private readonly NumberField _red = new(0, 0, 255, width: 42);
    private readonly NumberField _green = new(0, 0, 255, width: 42);
    private readonly NumberField _blue = new(0, 0, 255, width: 42);
    private readonly Border _primarySwatch = new();
    private readonly Border _secondarySwatch = new();
    private readonly WrapPanel _recentHost = new();
    private readonly WrapPanel _customHost = new();
    private readonly TextBlock _recentEmpty;
    private readonly TextBlock _customEmpty;

    private bool _editingSecondary;
    private bool _updating;
    private double _hue;
    private double _saturation;
    private double _brightness = 1;

    public ColorPanel(Editor editor)
    {
        _editor = editor;
        this.Themed(BackgroundProperty, ThemeKeys.Panel);

        var stack = new StackPanel { Margin = new Thickness(10, 10, 10, 10) };

        // --- current colours ---
        var top = Ui.MakeGrid("Auto,Auto,*");
        top.Margin = new Thickness(0, 0, 0, 10);
        top.Height = 54;
        var swatches = new Grid { Width = 62, Height = 52 };
        ConfigureSwatch(_secondarySwatch, 34, "Secondary colour (right mouse button). Click to edit it.");
        _secondarySwatch.HorizontalAlignment = HorizontalAlignment.Right;
        _secondarySwatch.VerticalAlignment = VerticalAlignment.Bottom;
        ConfigureSwatch(_primarySwatch, 34, "Primary colour (left mouse button). Click to edit it.");
        _primarySwatch.HorizontalAlignment = HorizontalAlignment.Left;
        _primarySwatch.VerticalAlignment = VerticalAlignment.Top;
        swatches.Children.Add(_secondarySwatch);
        swatches.Children.Add(_primarySwatch);
        _primarySwatch.MouseLeftButtonDown += (_, _) => { _editingSecondary = false; Refresh(); };
        _secondarySwatch.MouseLeftButtonDown += (_, _) => { _editingSecondary = true; Refresh(); };
        swatches.Place(top, 0, 0);

        var swapBox = new StackPanel { Margin = new Thickness(6, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
        var swap = Ui.IconButton("swap", "Swap the two colours (X)", () => { _editor.ToolSettings.SwapColors(); }, 16);
        swap.MinWidth = 26;
        swap.MinHeight = 26;
        var reset = Ui.TextButton("B/W", ResetColors, minWidth: 26);
        reset.Padding = new Thickness(4, 1, 4, 1);
        reset.MinHeight = 22;
        reset.FontSize = 10.5;
        reset.Focusable = false;
        reset.ToolTip = "Reset to black and white";
        reset.Margin = new Thickness(0, 2, 0, 0);
        swapBox.Children.Add(swap);
        swapBox.Children.Add(reset);
        swapBox.Place(top, 0, 1);

        var hexRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center };
        hexRow.Children.Add(Ui.Label("Hex", dim: true));
        _hexBox.Margin = new Thickness(6, 0, 0, 0);
        hexRow.Children.Add(_hexBox);
        hexRow.Place(top, 0, 2);
        stack.Children.Add(top);

        // --- colour square and hue ---
        stack.Children.Add(_square);
        _hueBar.Margin = new Thickness(0, 8, 0, 0);
        stack.Children.Add(_hueBar);

        // --- RGB ---
        var rgb = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 10, 0, 0), HorizontalAlignment = HorizontalAlignment.Left };
        AddChannel(rgb, "R", _red);
        AddChannel(rgb, "G", _green);
        AddChannel(rgb, "B", _blue);
        stack.Children.Add(rgb);

        // --- swatches ---
        stack.Children.Add(SectionTitle("Palette"));
        var paletteHost = new WrapPanel();
        foreach (string hex in Palette) paletteHost.Children.Add(MakeSwatch(hex, custom: false));
        stack.Children.Add(paletteHost);

        stack.Children.Add(SectionTitle("Recent"));
        stack.Children.Add(_recentHost);
        _recentEmpty = Ui.Label("Colours you use appear here.", dim: true);
        _recentEmpty.FontSize = 11;
        stack.Children.Add(_recentEmpty);

        var customTitle = new Grid { Margin = new Thickness(0, 10, 0, 4) };
        customTitle.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        customTitle.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var customLabel = Ui.Label("My colours", dim: true, size: 11, bold: true);
        customLabel.Place(customTitle, 0, 0);
        var add = Ui.IconButton("plus", "Save the current colour in My colours", AddCustom, 14);
        add.MinWidth = 22;
        add.MinHeight = 22;
        add.Padding = new Thickness(2);
        add.Place(customTitle, 0, 1);
        stack.Children.Add(customTitle);
        stack.Children.Add(_customHost);
        _customEmpty = Ui.Label("Press + to keep the current colour.", dim: true);
        _customEmpty.FontSize = 11;
        stack.Children.Add(_customEmpty);

        Child = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, Content = stack, Focusable = false };

        // --- events ---
        _square.Picked += finished =>
        {
            _saturation = _square.Saturation;
            _brightness = _square.Brightness;
            ApplyHsv(finished);
        };
        _hueBar.Picked += finished =>
        {
            _hue = _hueBar.Hue;
            _square.Hue = _hue;
            ApplyHsv(finished);
        };
        _red.ValueChanged += _ => ApplyRgb();
        _green.ValueChanged += _ => ApplyRgb();
        _blue.ValueChanged += _ => ApplyRgb();
        _hexBox.LostKeyboardFocus += (_, _) => CommitHex();
        _hexBox.KeyDown += (_, e) =>
        {
            if (e.Key == Key.Enter) { CommitHex(); _hexBox.SelectAll(); e.Handled = true; }
            else if (e.Key == Key.Escape) { Refresh(); e.Handled = true; }
        };
        _hexBox.GotKeyboardFocus += (_, _) => _hexBox.SelectAll();

        editor.ToolSettings.Changed += Refresh;
        editor.SettingsManager.Changed += RebuildLists;
        ThemeManager.ThemeChanged += RebuildLists;

        RebuildLists();
        Refresh();
    }

    private ArgbColor ActiveColor => _editingSecondary ? _editor.ToolSettings.SecondaryColor : _editor.ToolSettings.PrimaryColor;

    // ----- updating the colour -----

    private void SetActive(ArgbColor color, bool remember)
    {
        var ts = _editor.ToolSettings;
        ArgbColor opaque = color.WithAlpha(255);
        if (_editingSecondary) ts.SecondaryColor = opaque; else ts.PrimaryColor = opaque;
        ts.RaiseChanged();
        if (remember) _editor.RememberColor(opaque); // the settings change event refreshes the list of recent colours
    }

    private void ApplyHsv(bool finished) => SetActive(ArgbColor.FromHsv(_hue, _saturation, _brightness), finished);

    private void ApplyRgb()
    {
        if (_updating) return;
        SetActive(ArgbColor.FromRgb((byte)_red.IntValue, (byte)_green.IntValue, (byte)_blue.IntValue), true);
    }

    private void CommitHex()
    {
        if (_updating) return;
        if (ArgbColor.TryParse(_hexBox.Text, out ArgbColor color)) SetActive(color, true);
        else Refresh();
    }

    private void ResetColors()
    {
        var ts = _editor.ToolSettings;
        ts.PrimaryColor = ArgbColor.Black;
        ts.SecondaryColor = ArgbColor.White;
        ts.RaiseChanged();
    }

    /// <summary>Shows the current tool colours in every part of the panel.</summary>
    private void Refresh()
    {
        if (_updating) return;
        _updating = true;
        try
        {
            var ts = _editor.ToolSettings;
            _primarySwatch.Background = Ui.ToBrush(ts.PrimaryColor);
            _secondarySwatch.Background = Ui.ToBrush(ts.SecondaryColor);
            MarkActive(_primarySwatch, !_editingSecondary);
            MarkActive(_secondarySwatch, _editingSecondary);

            ArgbColor active = ActiveColor;
            // Keep the hue the user picked when the colour is grey; only follow other colours that arrive from outside.
            if (ArgbColor.FromHsv(_hue, _saturation, _brightness) != active)
            {
                var (h, s, v) = active.ToHsv();
                if (s > 1e-6 && v > 1e-6) _hue = h;
                _saturation = s;
                _brightness = v;
            }
            _square.Hue = _hue;
            _square.Saturation = _saturation;
            _square.Brightness = _brightness;
            _hueBar.Hue = _hue;
            _red.SetValue(active.R);
            _green.SetValue(active.G);
            _blue.SetValue(active.B);
            if (!_hexBox.IsKeyboardFocused) _hexBox.Text = active.WithAlpha(255).ToHex();
        }
        finally
        {
            _updating = false;
        }
    }

    // ----- swatches -----

    private void ConfigureSwatch(Border swatch, double size, string tip)
    {
        swatch.Width = size;
        swatch.Height = size;
        swatch.CornerRadius = new CornerRadius(4);
        swatch.BorderThickness = new Thickness(2);
        swatch.Cursor = Cursors.Hand;
        swatch.ToolTip = tip;
        swatch.SetResourceReference(Border.BorderBrushProperty, ThemeKeys.BorderStrong);
    }

    private void MarkActive(Border swatch, bool active)
    {
        swatch.SetResourceReference(Border.BorderBrushProperty, active ? ThemeKeys.Accent : ThemeKeys.BorderStrong);
        Panel.SetZIndex(swatch, active ? 2 : 1);
    }

    private UIElement SectionTitle(string text)
    {
        var label = Ui.Label(text, dim: true, size: 11, bold: true);
        label.Margin = new Thickness(0, 10, 0, 4);
        return label;
    }

    private static void AddChannel(StackPanel row, string name, NumberField field)
    {
        var label = Ui.Label(name, dim: true);
        label.Margin = new Thickness(row.Children.Count == 0 ? 0 : 10, 0, 4, 0);
        row.Children.Add(label);
        row.Children.Add(field.Box);
    }

    private Border MakeSwatch(string hex, bool custom)
    {
        ArgbColor color = ArgbColor.ParseOrDefault(hex, ArgbColor.Black);
        var swatch = new Border
        {
            Width = 18,
            Height = 18,
            Margin = new Thickness(0, 0, 4, 4),
            CornerRadius = new CornerRadius(3),
            BorderThickness = new Thickness(1),
            Cursor = Cursors.Hand,
            Background = Ui.ToBrush(color),
            ToolTip = hex
        };
        swatch.SetResourceReference(Border.BorderBrushProperty, ThemeKeys.BorderStrong);
        swatch.MouseLeftButtonDown += (_, e) =>
        {
            SetActive(color, remember: true);
            e.Handled = true;
        };
        swatch.MouseRightButtonUp += (_, e) =>
        {
            ShowSwatchMenu(swatch, color, custom);
            e.Handled = true;
        };
        return swatch;
    }

    private void ShowSwatchMenu(Border swatch, ArgbColor color, bool custom)
    {
        var menu = new ContextMenu();
        var primary = new MenuItem { Header = "Use as primary colour" };
        primary.Click += (_, _) =>
        {
            _editor.ToolSettings.PrimaryColor = color.WithAlpha(255);
            _editor.ToolSettings.RaiseChanged();
        };
        var secondary = new MenuItem { Header = "Use as secondary colour" };
        secondary.Click += (_, _) =>
        {
            _editor.ToolSettings.SecondaryColor = color.WithAlpha(255);
            _editor.ToolSettings.RaiseChanged();
        };
        menu.Items.Add(primary);
        menu.Items.Add(secondary);
        menu.Items.Add(new Separator());
        if (custom)
        {
            var remove = new MenuItem { Header = "Remove from My colours" };
            remove.Click += (_, _) => _editor.SettingsManager.RemoveCustomColor(color.WithAlpha(255).ToHex());
            menu.Items.Add(remove);
        }
        else
        {
            var save = new MenuItem { Header = "Add to My colours" };
            save.Click += (_, _) => _editor.SettingsManager.AddCustomColor(color.WithAlpha(255).ToHex());
            menu.Items.Add(save);
        }
        menu.PlacementTarget = swatch;
        menu.IsOpen = true;
    }

    private void AddCustom()
    {
        string hex = ActiveColor.WithAlpha(255).ToHex();
        if (!_editor.SettingsManager.AddCustomColor(hex))
            _editor.Say(_editor.Settings.CustomColors.Count >= Core.Settings.AppSettings.MaxCustomColors
                ? "My colours is full. Right-click a colour to remove it."
                : "That colour is already in My colours.");
    }

    private void RebuildLists()
    {
        RebuildRecent();
        RebuildCustom();
        Refresh();
    }

    private void RebuildRecent()
    {
        _recentHost.Children.Clear();
        foreach (string hex in _editor.Settings.RecentColors) _recentHost.Children.Add(MakeSwatch(hex, custom: false));
        _recentEmpty.Visibility = _recentHost.Children.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    private void RebuildCustom()
    {
        _customHost.Children.Clear();
        foreach (string hex in _editor.Settings.CustomColors) _customHost.Children.Add(MakeSwatch(hex, custom: true));
        _customEmpty.Visibility = _customHost.Children.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
    }
}
