using System.Windows;
using System.Windows.Controls;
using AnimDraw.App.Controls;
using AnimDraw.App.Services;
using AnimDraw.Core.App;
using AnimDraw.Core.Tools;

namespace AnimDraw.App.Panels;

/// <summary>The column of tool buttons at the left edge of the window.</summary>
public sealed class ToolPalette : Border
{
    private readonly Editor _editor;
    private readonly Dictionary<ToolKind, RadioButton> _buttons = new();

    public ToolPalette(Editor editor, ShortcutMap shortcuts)
    {
        _editor = editor;
        this.Themed(BackgroundProperty, ThemeKeys.Panel);
        this.Themed(BorderBrushProperty, ThemeKeys.Border);
        BorderThickness = new Thickness(0, 0, 1, 0);
        Padding = new Thickness(5, 6, 5, 6);

        var stack = new StackPanel { Orientation = Orientation.Vertical };
        bool first = true;
        foreach (var group in ToolCatalog.Groups)
        {
            if (!first) stack.Children.Add(Ui.HorizontalLine(5));
            first = false;
            foreach (var tool in group)
            {
                var button = new RadioButton
                {
                    GroupName = "AnimDrawTools",
                    Content = new IconView(tool.Icon, 22),
                    IsChecked = editor.Tools.CurrentKind == tool.Kind
                };
                Ui.ApplyStyle(button, ThemeKeys.ToolRadioStyle);
                Ui.Tip(button, tool.Name, shortcuts.DisplayTextOf(tool.Command));
                ToolKind kind = tool.Kind;
                button.Checked += (_, _) => _editor.Tools.Select(kind);
                _buttons[tool.Kind] = button;
                stack.Children.Add(button);
            }
        }
        Child = stack;
        editor.Tools.ToolChanged += OnToolChanged;
    }

    private void OnToolChanged(ToolKind kind)
    {
        if (_buttons.TryGetValue(kind, out var button) && button.IsChecked != true) button.IsChecked = true;
    }
}
