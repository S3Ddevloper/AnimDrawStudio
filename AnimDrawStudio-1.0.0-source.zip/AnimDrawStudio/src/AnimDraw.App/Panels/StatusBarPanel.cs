using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Threading;
using AnimDraw.App.Services;

namespace AnimDraw.App.Panels;

/// <summary>
/// The strip at the bottom of the window: a message area on the left, then the canvas size, the pointer position, the zoom
/// controls, the current frame, the frame rate and whether the project is saved.
/// </summary>
public sealed class StatusBarPanel : Border
{
    private const string ReadyText = "Ready";

    private readonly TextBlock _message;
    private readonly TextBlock _canvasSize;
    private readonly TextBlock _cursor;
    private readonly TextBlock _frame;
    private readonly TextBlock _fps;
    private readonly TextBlock _saved;
    private readonly Border _savedDot;
    private readonly Button _zoomButton;
    private readonly ProgressBar _progress;
    private readonly DispatcherTimer _clearTimer;

    public StatusBarPanel(Action zoomOut, Action zoomIn, Action<double?> zoomPreset)
    {
        this.Themed(BackgroundProperty, ThemeKeys.Panel);
        this.Themed(BorderBrushProperty, ThemeKeys.Border);
        BorderThickness = new Thickness(0, 1, 0, 0);
        Height = 28;

        // message | progress | canvas size | pointer | zoom | frame | fps | saved state
        var grid = Ui.MakeGrid("*,Auto,Auto,Auto,Auto,Auto,Auto,Auto");

        _message = Ui.Label(ReadyText);
        _message.TextTrimming = TextTrimming.CharacterEllipsis;
        _message.Margin = new Thickness(10, 0, 10, 0);
        _message.Place(grid, 0, 0);

        _progress = new ProgressBar
        {
            Width = 140,
            Height = 8,
            Minimum = 0,
            Maximum = 100,
            Visibility = Visibility.Collapsed,
            Margin = new Thickness(0, 0, 12, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        _progress.Place(grid, 0, 1);

        _canvasSize = Cell(grid, 2, "Canvas size in pixels", 90);
        _cursor = Cell(grid, 3, "Pointer position on the canvas (pixels)", 96);

        // zoom: [-] 100% [+]
        var zoom = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 6, 0) };
        var zoomOutButton = Ui.IconButton("zoom-out", "Zoom out", zoomOut, 14);
        zoomOutButton.MinWidth = 24;
        zoomOutButton.MinHeight = 22;
        zoomOutButton.Padding = new Thickness(3);
        _zoomButton = new Button
        {
            Content = "100%",
            MinWidth = 58,
            MinHeight = 22,
            Padding = new Thickness(4, 0, 4, 0),
            Focusable = false,
            ToolTip = "Zoom level. Click for presets."
        };
        _zoomButton.Click += (_, _) => ShowZoomMenu(zoomPreset);
        var zoomInButton = Ui.IconButton("zoom-in", "Zoom in", zoomIn, 14);
        zoomInButton.MinWidth = 24;
        zoomInButton.MinHeight = 22;
        zoomInButton.Padding = new Thickness(3);
        zoom.Children.Add(zoomOutButton);
        zoom.Children.Add(_zoomButton);
        zoom.Children.Add(zoomInButton);
        zoom.Place(grid, 0, 4);

        _frame = Cell(grid, 5, "Current frame / number of frames", 96);
        _fps = Cell(grid, 6, "Frames per second", 56);

        var state = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 12, 0) };
        _savedDot = new Border { Width = 9, Height = 9, CornerRadius = new CornerRadius(5), Margin = new Thickness(0, 0, 6, 0), VerticalAlignment = VerticalAlignment.Center };
        _saved = Ui.Label("", dim: true);
        state.Children.Add(_savedDot);
        state.Children.Add(_saved);
        state.MinWidth = 116;
        state.Place(grid, 0, 7);
        SetSaved(false);

        Child = grid;

        _clearTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(8) };
        _clearTimer.Tick += (_, _) =>
        {
            _clearTimer.Stop();
            _message.Text = ReadyText;
        };
    }

    private static TextBlock Cell(Grid grid, int column, string tip, double minWidth)
    {
        var text = Ui.Label("", dim: true);
        text.Margin = new Thickness(10, 0, 10, 0);
        text.ToolTip = tip;
        text.MinWidth = minWidth;
        text.Place(grid, 0, column);
        return text;
    }

    /// <summary>Shows a short message for a few seconds.</summary>
    public void SetMessage(string message)
    {
        bool blank = string.IsNullOrWhiteSpace(message);
        _message.Text = blank ? ReadyText : message;
        _clearTimer.Stop();
        if (!blank) _clearTimer.Start();
    }

    public void SetCanvasSize(int width, int height) =>
        _canvasSize.Text = string.Create(CultureInfo.CurrentCulture, $"{width} × {height} px");

    /// <summary>Shows where the pointer is in canvas pixels, or clears the field when it is outside the canvas view.</summary>
    public void SetCursor(Point? canvasPoint)
    {
        _cursor.Text = canvasPoint is Point p
            ? "X " + Math.Floor(p.X).ToString("0", CultureInfo.InvariantCulture) + "   Y " + Math.Floor(p.Y).ToString("0", CultureInfo.InvariantCulture)
            : "";
    }

    public void SetZoom(string text) => _zoomButton.Content = text;

    public void SetFrame(int frameNumber, int frameCount) =>
        _frame.Text = string.Create(CultureInfo.CurrentCulture, $"Frame {frameNumber} / {frameCount}");

    public void SetFps(double fps)
    {
        string format = Math.Abs(fps - Math.Round(fps)) < 0.005 ? "0" : "0.##";
        _fps.Text = fps.ToString(format, CultureInfo.CurrentCulture) + " fps";
    }

    private bool? _shownUnsaved;

    /// <summary>Shows whether there are unsaved changes. Cheap to call after every edit: nothing happens when the state is unchanged.</summary>
    public void SetSaved(bool unsavedChanges)
    {
        if (_shownUnsaved == unsavedChanges) return;
        _shownUnsaved = unsavedChanges;
        _saved.Text = unsavedChanges ? "Unsaved changes" : "All changes saved";
        _savedDot.SetResourceReference(Border.BackgroundProperty, unsavedChanges ? ThemeKeys.Warning : ThemeKeys.Success);
    }

    /// <summary>Shows a progress bar (0 to 1), or hides it when the value is null.</summary>
    public void SetProgress(double? fraction)
    {
        if (fraction is double f)
        {
            _progress.Visibility = Visibility.Visible;
            _progress.Value = Math.Clamp(f, 0, 1) * 100;
        }
        else
        {
            _progress.Visibility = Visibility.Collapsed;
        }
    }

    private void ShowZoomMenu(Action<double?> zoomPreset)
    {
        var menu = new ContextMenu { PlacementTarget = _zoomButton, Placement = PlacementMode.Top };

        void AddItem(string header, double? zoom)
        {
            var item = new MenuItem { Header = header };
            item.Click += (_, _) => zoomPreset(zoom);
            menu.Items.Add(item);
        }

        AddItem("Fit to window", null);
        menu.Items.Add(new Separator());
        foreach (double z in new[] { 0.125, 0.25, 0.5, 1, 2, 4, 8, 16, 32 })
            AddItem((z * 100).ToString("0.##", CultureInfo.CurrentCulture) + "%", z);
        menu.IsOpen = true;
    }
}
