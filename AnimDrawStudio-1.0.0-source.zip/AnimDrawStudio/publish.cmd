@echo off
rem Runs publish.ps1 without having to change the PowerShell execution policy.
rem Extra options are passed on, for example:   publish.cmd -Zip -Installer
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0publish.ps1" %*
set EXITCODE=%ERRORLEVEL%
if not "%EXITCODE%"=="0" echo.& echo The build did not finish. Read the messages above.
exit /b %EXITCODE%
