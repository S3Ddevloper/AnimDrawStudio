using System.Diagnostics;
using System.Text.Json;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Export;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.IO;
using AnimDraw.Core.Model;
using AnimDraw.Core.Rendering;
using static AnimDraw.Core.Tests.Helpers;

namespace AnimDraw.Core.Tests;

public static class ExportTests
{
    // ------------------------------------------------------------------ an independent GIF reader for the tests

    private sealed class GifFrameInfo
    {
        public PixelBuffer Picture = null!;   // what a viewer shows after this frame has been drawn
        public int DelayCs;
        public int Disposal;
        public bool HasTransparency;
        public IntRect Rect;
    }

    private sealed class GifInfo
    {
        public int Width, Height;
        public bool LoopsForever;
        public bool SawNetscape;
        public List<GifFrameInfo> Frames = new();
        public int TotalDelayCs => Frames.Sum(f => f.DelayCs);
    }

    /// <summary>Decodes LZW data (starting at the minimum-code-size byte) the way the GIF specification describes.</summary>
    private static byte[] LzwDecode(byte[] data, ref int pos, int expected)
    {
        int minCode = data[pos++];
        var bytes = new List<byte>();
        while (true)
        {
            int len = data[pos++];
            if (len == 0) break;
            for (int i = 0; i < len; i++) bytes.Add(data[pos++]);
        }

        int clear = 1 << minCode, eoi = clear + 1;
        var prefix = new int[4096];
        var suffix = new byte[4096];
        var output = new List<byte>(expected);
        var stack = new byte[4097];

        int codeSize = minCode + 1, next = eoi + 1, prev = -1;
        int bitPos = 0;
        int totalBits = bytes.Count * 8;

        int ReadCode()
        {
            if (bitPos + codeSize > totalBits) return -1;
            int code = 0;
            for (int b = 0; b < codeSize; b++)
            {
                int bit = (bytes[(bitPos + b) >> 3] >> ((bitPos + b) & 7)) & 1;
                code |= bit << b;
            }
            bitPos += codeSize;
            return code;
        }

        byte First(int code)
        {
            while (code >= clear) code = prefix[code];
            return (byte)code;
        }

        void Emit(int code)
        {
            int sp = 0;
            while (code >= clear)
            {
                stack[sp++] = suffix[code];
                code = prefix[code];
            }
            stack[sp++] = (byte)code;
            while (sp > 0) output.Add(stack[--sp]);
        }

        while (true)
        {
            int code = ReadCode();
            if (code < 0) throw new Exception("LZW data ended without an end code");
            if (code == clear)
            {
                codeSize = minCode + 1; next = eoi + 1; prev = -1;
                continue;
            }
            if (code == eoi) break;
            if (prev == -1)
            {
                if (code >= clear) throw new Exception("first code after clear must be a literal");
                output.Add((byte)code);
                prev = code;
                continue;
            }
            if (code < next)
            {
                Emit(code);
                if (next < 4096) { prefix[next] = prev; suffix[next] = First(code); next++; }
            }
            else if (code == next)
            {
                byte f = First(prev);
                if (next < 4096) { prefix[next] = prev; suffix[next] = f; next++; }
                Emit(code);
            }
            else throw new Exception($"invalid LZW code {code} (next is {next})");
            prev = code;
            if (next == (1 << codeSize) && codeSize < 12) codeSize++;
        }
        return output.ToArray();
    }

    private static GifInfo DecodeGif(byte[] d)
    {
        T.True(d.Length > 20, "GIF is too short");
        T.Equal("GIF89a", System.Text.Encoding.ASCII.GetString(d, 0, 6), "signature");
        var gif = new GifInfo { Width = d[6] | (d[7] << 8), Height = d[8] | (d[9] << 8) };
        int packed = d[10];
        int pos = 13;
        byte[] globalTable = Array.Empty<byte>();
        if ((packed & 0x80) != 0)
        {
            int size = 3 * (1 << ((packed & 7) + 1));
            globalTable = d[pos..(pos + size)];
            pos += size;
        }

        var canvas = new PixelBuffer(gif.Width, gif.Height);
        int gceDelay = 0, gceDisposal = 0, gceTransparent = -1;
        GifFrameInfo? previous = null;

        while (true)
        {
            int block = d[pos++];
            if (block == 0x3B) break;
            if (block == 0x21)
            {
                int label = d[pos++];
                if (label == 0xF9)
                {
                    pos++; // block size 4
                    int flags = d[pos++];
                    gceDisposal = (flags >> 2) & 7;
                    gceDelay = d[pos] | (d[pos + 1] << 8);
                    pos += 2;
                    int t = d[pos++];
                    gceTransparent = (flags & 1) != 0 ? t : -1;
                    pos++; // terminator
                }
                else
                {
                    int len = d[pos++];
                    string id = System.Text.Encoding.ASCII.GetString(d, pos, len);
                    bool netscape = label == 0xFF && id == "NETSCAPE2.0";
                    pos += len;
                    while (true)
                    {
                        int sub = d[pos++];
                        if (sub == 0) break;
                        if (netscape && sub == 3 && d[pos] == 1)
                        {
                            gif.SawNetscape = true;
                            gif.LoopsForever = (d[pos + 1] | (d[pos + 2] << 8)) == 0;
                        }
                        pos += sub;
                    }
                }
                continue;
            }
            if (block != 0x2C) throw new Exception($"unexpected block 0x{block:X2} at {pos - 1}");

            int x = d[pos] | (d[pos + 1] << 8), y = d[pos + 2] | (d[pos + 3] << 8);
            int w = d[pos + 4] | (d[pos + 5] << 8), h = d[pos + 6] | (d[pos + 7] << 8);
            int lp = d[pos + 8];
            pos += 9;
            byte[] table = globalTable;
            if ((lp & 0x80) != 0)
            {
                int size = 3 * (1 << ((lp & 7) + 1));
                table = d[pos..(pos + size)];
                pos += size;
            }
            T.False((lp & 0x40) != 0, "interlaced frames are not expected");
            byte[] indices = LzwDecode(d, ref pos, w * h);
            T.Equal(w * h, indices.Length, "decoded pixel count of a frame");

            // Apply the previous frame's disposal before drawing this one.
            if (previous != null && previous.Disposal == 2) canvas.Clear(previous.Rect);
            for (int yy = 0; yy < h; yy++)
            for (int xx = 0; xx < w; xx++)
            {
                int idx = indices[yy * w + xx];
                if (idx == gceTransparent) continue;
                canvas.SetPixel(x + xx, y + yy, Px.FromStraight(255, table[idx * 3], table[idx * 3 + 1], table[idx * 3 + 2]));
            }

            var info = new GifFrameInfo
            {
                Picture = canvas.Clone(),
                DelayCs = gceDelay,
                Disposal = gceDisposal,
                HasTransparency = gceTransparent >= 0,
                Rect = new IntRect(x, y, w, h)
            };
            gif.Frames.Add(info);
            previous = info;
            gceTransparent = -1;
        }
        T.Equal(d.Length, pos, "nothing follows the trailer");
        return gif;
    }

    // ------------------------------------------------------------------ helpers

    private static readonly uint Yellow = Px.FromStraight(255, 255, 220, 0);

    /// <summary>
    /// Four frames on a 64 x 48 canvas: a coloured square in a different place and colour each frame, with frame 3 holding
    /// frame 2's drawing (so exporting it exercises repeated frames).
    /// </summary>
    private static Document SquareAnim(bool transparentBackground, int w = 64, int h = 48)
    {
        var p = Project.CreateNew(w, h, 12, transparentBackground ? BackgroundSettings.Transparent : BackgroundSettings.White);
        p.FrameCount = 4;
        var d = new Document(p);
        var layer = d.ActiveLayer;
        uint[] colors = { Red, Green, Blue };
        for (int f = 0; f < 3; f++)
        {
            d.GoToFrame(f);
            d.InsertBlankKeyframe(layer, f);
            Paint(d, new IntRect(4 + f * 18, 6 + f * 4, 12, 12), colors[f]);
        }
        d.GoToFrame(0);
        return d;
    }

    private static ExportResult RunExport(Document d, ExportOptions o) => ExportManager.Export(d.CreateSnapshot(), o);

    private static ExportOptions Options(Document d, ExportFormat format, string path)
    {
        var o = ExportOptions.CreateDefault(d.Project, format);
        o.OutputPath = path;
        return o;
    }

    private sealed class TempDir : IDisposable
    {
        public string Root { get; } = Path.Combine(Path.GetTempPath(), "animdraw-tests", "export-" + Guid.NewGuid().ToString("N"));
        public TempDir() => Directory.CreateDirectory(Root);
        public string P(string name) => Path.Combine(Root, name);
        public void Dispose()
        {
            try { Directory.Delete(Root, recursive: true); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
    }

    private static string KeepDir(string subfolder)
    {
        string dir = Path.Combine(DrawingTests.OutDir, subfolder);
        Directory.CreateDirectory(dir);
        return dir;
    }

    private static double MeanAbsError(PixelBuffer a, PixelBuffer b)
    {
        T.Equal(a.Width, b.Width); T.Equal(a.Height, b.Height);
        double sum = 0;
        for (int i = 0; i < a.Pixels.Length; i++)
        {
            Px.ToStraight(a.Pixels[i], out int aa, out int ar, out int ag, out int ab);
            Px.ToStraight(b.Pixels[i], out int ba, out int br, out int bg, out int bb);
            sum += Math.Abs(ar - br) + Math.Abs(ag - bg) + Math.Abs(ab - bb);
        }
        return sum / (a.Pixels.Length * 3.0);
    }

    // ------------------------------------------------------------------ the tests

    public static void RunAll()
    {
        TimelineTests();
        LzwTests();
        GifTests();
        PngTests();
        SheetTests();
        PlanTests();
        BehaviourTests();
        Mp4Tests();
    }

    private static void TimelineTests()
    {
        T.Suite("Export timing");

        T.Run("same frame rate maps frame for frame, inside the chosen range", () =>
        {
            T.Equal("2,3,4,5", string.Join(",", ExportTimeline.MapFrames(2, 5, 12, 12)));
            T.Equal(0, ExportTimeline.MapFrames(5, 2, 12, 12).Count);
        });

        T.Run("a higher output rate repeats frames and a lower one skips them, keeping the running time", () =>
        {
            T.Equal("0,0,1,1,2,2", string.Join(",", ExportTimeline.MapFrames(0, 2, 12, 24)));
            T.Equal("0,2,4", string.Join(",", ExportTimeline.MapFrames(0, 5, 12, 6)));
            T.Equal(10, ExportTimeline.MapFrames(0, 23, 24, 10).Count, "24 frames at 24 fps last 1 s, so 10 frames at 10 fps");
            T.Equal(1, ExportTimeline.MapFrames(3, 3, 12, 1).Count, "never fewer than one frame");
        });

        T.Run("GIF delays add up exactly even when one frame is 8.33 hundredths of a second", () =>
        {
            int[] d = ExportTimeline.GifDelays(24, 12);
            T.Equal(200, d.Sum(), "24 frames at 12 fps = 2.00 s");
            T.True(d.All(v => v == 8 || v == 9), string.Join(",", d));
            T.Equal(300, ExportTimeline.GifDelays(30, 10).Sum());
            T.Equal(100, ExportTimeline.GifDelays(30, 30).Sum(), "30 frames at 30 fps");
            T.True(ExportTimeline.GifDelays(10, 120).All(v => v >= 2), "browsers treat anything below 2 as 10");
        });
    }

    private static void LzwTests()
    {
        T.Suite("GIF compression");

        void RoundTrip(string label, byte[] pixels, int minCode)
        {
            using var ms = new MemoryStream();
            new GifLzwEncoder().Encode(pixels, ms, minCode);
            byte[] data = ms.ToArray();
            int pos = 0;
            byte[] back = LzwDecode(data, ref pos, pixels.Length);
            T.Equal(data.Length, pos, label + ": all bytes consumed");
            if (!back.AsSpan().SequenceEqual(pixels)) throw new Exception($"{label}: decoded data differs ({back.Length} vs {pixels.Length} bytes)");
        }

        T.Run("data survives compression and decompression: runs, noise, patterns, tiny inputs", () =>
        {
            var rng = new Random(7);
            RoundTrip("single pixel", new byte[] { 5 }, 8);
            RoundTrip("two pixels", new byte[] { 5, 5 }, 8);
            RoundTrip("empty", Array.Empty<byte>(), 8);
            RoundTrip("long run of one colour", new byte[200_000], 8);
            RoundTrip("alternating", Enumerable.Range(0, 50_000).Select(i => (byte)(i % 2 * 200)).ToArray(), 8);
            RoundTrip("repeating ramp", Enumerable.Range(0, 100_000).Select(i => (byte)(i % 256)).ToArray(), 8);

            var noise = new byte[300_000];
            rng.NextBytes(noise);
            RoundTrip("white noise fills the table many times", noise, 8);

            var lowNoise = new byte[100_000];
            for (int i = 0; i < lowNoise.Length; i++) lowNoise[i] = (byte)rng.Next(4);
            RoundTrip("2-bit symbols", lowNoise, 2);
            for (int i = 0; i < lowNoise.Length; i++) lowNoise[i] = (byte)rng.Next(16);
            RoundTrip("4-bit symbols", lowNoise, 4);

            var blocks = new byte[120_000];
            for (int i = 0; i < blocks.Length; i++) blocks[i] = (byte)((i / 37 + (i % 5 == 0 ? 1 : 0)) & 0xFF);
            RoundTrip("structured", blocks, 8);
        });

        T.Run("every input length around the code-size boundaries round-trips", () =>
        {
            var rng = new Random(11);
            for (int n = 1; n <= 700; n++)
            {
                var px = new byte[n];
                for (int i = 0; i < n; i++) px[i] = (byte)rng.Next(256);
                RoundTrip("length " + n, px, 8);
            }
        });
    }

    private static void GifTests()
    {
        T.Suite("GIF export");

        T.Run("every frame decodes to exactly what was drawn, with the right timing and looping", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(transparentBackground: false);
            var o = Options(d, ExportFormat.Gif, tmp.P("anim"));
            var result = RunExport(d, o);
            T.True(result.Succeeded, result.Message);
            T.True(result.Files.Count == 1 && result.Files[0].EndsWith("anim.gif"), "extension added");
            T.Equal(4, result.FramesWritten);

            var gif = DecodeGif(File.ReadAllBytes(result.Files[0]));
            T.Equal(64, gif.Width); T.Equal(48, gif.Height);
            T.True(gif.SawNetscape && gif.LoopsForever, "loops forever");
            T.Equal(33, gif.TotalDelayCs, "4 frames at 12 fps = 0.33 s (8+9+8+8)");
            for (int f = 0; f < 4; f++)
            {
                var expected = Compositor.ComposeFrame(d.Project, f, withBackground: true);
                T.Equal(0.0, MeanAbsError(expected, GifPictureAt(gif, f, 4)), $"frame {f} matches exactly");
            }
        });

        T.Run("a frame that repeats the previous one only lengthens it", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            var result = RunExport(d, Options(d, ExportFormat.Gif, tmp.P("a.gif")));
            var gif = DecodeGif(File.ReadAllBytes(result.Files[0]));
            T.Equal(3, gif.Frames.Count, "frames 2 and 3 are identical, so three images are stored");
            T.True(gif.Frames[2].DelayCs >= 16, "the last image is shown for two frame times: " + gif.Frames[2].DelayCs);
        });

        T.Run("only the changed part of each frame is stored on an opaque background", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false, 200, 150);
            var result = RunExport(d, Options(d, ExportFormat.Gif, tmp.P("a.gif")));
            var gif = DecodeGif(File.ReadAllBytes(result.Files[0]));
            T.Equal(200 * 150, gif.Frames[0].Rect.Width * gif.Frames[0].Rect.Height, "first frame is complete");
            for (int f = 1; f < gif.Frames.Count; f++)
                T.True(gif.Frames[f].Rect.Width * gif.Frames[f].Rect.Height < 200 * 150 / 2, $"frame {f} stores {gif.Frames[f].Rect}");
            for (int f = 0; f < 4; f++)
                T.Equal(0.0, MeanAbsError(Compositor.ComposeFrame(d.Project, f, true), GifPictureAt(gif, f, 4)), $"frame {f} still looks right");
        });

        T.Run("a transparent export keeps the background out", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(transparentBackground: true);
            var o = Options(d, ExportFormat.Gif, tmp.P("t.gif"));
            T.True(o.Transparent, "defaults to transparent for a transparent project");
            var result = RunExport(d, o);
            T.True(result.Succeeded, result.Message);
            var gif = DecodeGif(File.ReadAllBytes(result.Files[0]));
            T.True(gif.Frames.All(f => f.HasTransparency), "transparency flag set");
            T.True(gif.Frames.All(f => f.Disposal == 2), "each frame is cleared before the next");
            T.PixelIs(Red, gif.Frames[0].Picture.GetPixel(8, 10), "frame 0 square");
            T.PixelIs(0u, gif.Frames[0].Picture.GetPixel(40, 30), "outside the square is see-through");
            T.PixelIs(Green, gif.Frames[1].Picture.GetPixel(26, 14), "frame 1 square");
            T.PixelIs(0u, gif.Frames[1].Picture.GetPixel(8, 10), "frame 0's square is gone in frame 1");
        });

        T.Run("a white project can still be exported with the background removed", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            var o = Options(d, ExportFormat.Gif, tmp.P("t.gif"));
            o.Transparent = true;
            var gif = DecodeGif(File.ReadAllBytes(RunExport(d, o).Files[0]));
            T.PixelIs(0u, gif.Frames[0].Picture.GetPixel(40, 30), "white background removed");
            T.PixelIs(Red, gif.Frames[0].Picture.GetPixel(8, 10));
        });

        T.Run("a transparent project exported opaque is put on white", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(true);
            var o = Options(d, ExportFormat.Gif, tmp.P("w.gif"));
            o.Transparent = false;
            var gif = DecodeGif(File.ReadAllBytes(RunExport(d, o).Files[0]));
            T.PixelIs(White, gif.Frames[0].Picture.GetPixel(40, 30));
        });

        T.Run("an animation with nothing visible on some frames still exports", () =>
        {
            using var tmp = new TempDir();
            var p = Project.CreateNew(32, 32, 10, BackgroundSettings.Transparent);
            p.FrameCount = 3;
            var d = new Document(p);
            d.InsertBlankKeyframe(d.ActiveLayer, 0);
            d.GoToFrame(1); d.InsertBlankKeyframe(d.ActiveLayer, 1); Paint(d, new IntRect(4, 4, 8, 8), Red);
            var result = RunExport(d, Options(d, ExportFormat.Gif, tmp.P("e.gif")));
            T.True(result.Succeeded, result.Message);
            var gif = DecodeGif(File.ReadAllBytes(result.Files[0]));
            T.Equal(30, gif.TotalDelayCs, "3 frames at 10 fps");
            T.PixelIs(0u, gif.Frames[0].Picture.GetPixel(5, 5), "empty first frame");
        });

        T.Run("a completely empty transparent animation exports", () =>
        {
            using var tmp = new TempDir();
            var d = NewDoc(16, 16, 2);
            var result = RunExport(d, Options(d, ExportFormat.Gif, tmp.P("empty.gif")));
            T.True(result.Succeeded, result.Message);
            T.True(DecodeGif(File.ReadAllBytes(result.Files[0])).Frames.Count >= 1);
        });

        T.Run("playing once instead of looping leaves out the loop block", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            var o = Options(d, ExportFormat.Gif, tmp.P("once.gif"));
            o.Loop = false;
            T.False(DecodeGif(File.ReadAllBytes(RunExport(d, o).Files[0])).SawNetscape);
        });

        T.Run("a different output frame rate changes the timing but keeps the running time", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            var o = Options(d, ExportFormat.Gif, tmp.P("fast.gif"));
            o.Fps = 24;
            var result = RunExport(d, o);
            T.Equal(8, result.FramesWritten, "4 frames at 12 fps become 8 at 24 fps");
            T.Equal(33, DecodeGif(File.ReadAllBytes(result.Files[0])).TotalDelayCs, "still a third of a second");
        });

        T.Run("a frame range and a smaller size are honoured", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false, 128, 96);
            var o = Options(d, ExportFormat.Gif, tmp.P("part.gif"));
            o.StartFrame = 1; o.EndFrame = 2; o.Width = 64; o.Height = 48;
            var result = RunExport(d, o);
            T.Equal(2, result.FramesWritten);
            var gif = DecodeGif(File.ReadAllBytes(result.Files[0]));
            T.Equal(64, gif.Width); T.Equal(48, gif.Height);
            // frame 1's square is at (22,10) 12x12 on the 128x96 canvas, so (11,5) 6x6 at half size
            T.PixelIs(Green, gif.Frames[0].Picture.GetPixel(13, 7), "scaled square", tolerance: 12);
        });

        T.Run("gradients stay close to the original and dithering helps at high quality", () =>
        {
            using var tmp = new TempDir();
            var p = Project.CreateNew(160, 100, 12, BackgroundSettings.White);
            var d = new Document(p);
            d.InsertBlankKeyframe(d.ActiveLayer, 0);
            var session = d.BeginEdit(out _)!;
            for (int y = 0; y < 100; y++)
            for (int x = 0; x < 160; x++)
                session.Surface.BlendBuffer(PixelOfColor(Px.FromStraight(255, x * 255 / 159, y * 255 / 99, 128 + (x + y) % 100)), x, y, session.Recorder);
            session.AddDirty(d.CanvasBounds); session.TakeDirty(); session.Commit("gradient");

            var expected = Compositor.ComposeFrame(d.Project, 0, true);
            double[] errors = new double[2];
            int[] qualities = { 100, 30 };
            for (int i = 0; i < 2; i++)
            {
                var o = Options(d, ExportFormat.Gif, tmp.P($"g{i}.gif"));
                o.Quality = qualities[i];
                var gif = DecodeGif(File.ReadAllBytes(RunExport(d, o).Files[0]));
                errors[i] = MeanAbsError(expected, gif.Frames[0].Picture);
            }
            Console.WriteLine($"        gradient error: quality 100 = {errors[0]:0.00}, quality 30 = {errors[1]:0.00} (per channel, out of 255)");
            T.True(errors[0] < 10, $"high quality error {errors[0]}");
            T.True(errors[1] < 25, $"low quality error {errors[1]}");
            T.True(errors[0] <= errors[1] + 0.5, "higher quality is not worse");
        });

        T.Run("a long animation with a big frame size encodes in reasonable time", () =>
        {
            using var tmp = new TempDir();
            var p = Project.CreateNew(1280, 720, 24, BackgroundSettings.White);
            p.FrameCount = 48;
            var d = new Document(p);
            var layer = d.ActiveLayer;
            for (int f = 0; f < 48; f++)
            {
                d.GoToFrame(f);
                d.InsertBlankKeyframe(layer, f);
                Paint(d, new IntRect(20 + f * 20, 200 + (f % 7) * 30, 160, 160), f % 2 == 0 ? Red : Blue);
            }
            var sw = Stopwatch.StartNew();
            var result = RunExport(d, Options(d, ExportFormat.Gif, tmp.P("big.gif")));
            long ms = sw.ElapsedMilliseconds;
            Console.WriteLine($"        1280x720, 48 frames: {ms} ms, {result.TotalBytes / 1024} KB");
            T.True(result.Succeeded, result.Message);
            T.True(ms < 20000, $"took {ms} ms");
            var gif = DecodeGif(File.ReadAllBytes(result.Files[0]));
            T.Equal(1280, gif.Width);
            T.Equal(0.0, MeanAbsError(Compositor.ComposeFrame(d.Project, 47, true), gif.Frames[^1].Picture), "last frame is right");
        });

        T.Run("a detailed animation (gradient, noise, soft edges) is written for checking with other programs", () =>
        {
            string dir = KeepDir("export");
            var p = Project.CreateNew(480, 270, 12, BackgroundSettings.White);
            p.FrameCount = 8;
            var d = new Document(p);
            var sky = d.ActiveLayer;
            d.InsertBlankKeyframe(sky, 0);
            var s = d.BeginEdit(out _)!;
            for (int y = 0; y < 270; y++)
            {
                var row = new PixelBuffer(480, 1);
                for (int x = 0; x < 480; x++)
                    row.SetPixel(x, 0, Px.FromStraight(255, 40 + y * 150 / 269, 90 + (x * 60 / 479), 200 - y * 120 / 269));
                s.Surface.BlendBuffer(row, 0, y, s.Recorder);
            }
            s.AddDirty(d.CanvasBounds); s.TakeDirty(); s.Commit("sky");

            var noiseLayer = d.AddLayer("noise")!;
            d.InsertBlankKeyframe(noiseLayer, 0);
            var rng = new Random(5);
            var ns = d.BeginEdit(out _)!;
            var noise = new PixelBuffer(160, 90);
            for (int i = 0; i < noise.Pixels.Length; i++) noise.Pixels[i] = Px.FromStraight(255, rng.Next(256), rng.Next(256), rng.Next(256));
            ns.Surface.BlendBuffer(noise, 20, 150, ns.Recorder);
            ns.AddDirty(d.CanvasBounds); ns.TakeDirty(); ns.Commit("noise");

            var disc = d.AddLayer("disc")!;
            for (int f = 0; f < 8; f++)
            {
                d.GoToFrame(f);
                d.InsertBlankKeyframe(disc, f);
                var ds = d.BeginEdit(out _)!;
                double cx = 60 + f * 50, cy = 100 + Math.Sin(f * 0.8) * 40, r = 36;
                var tile = new PixelBuffer(90, 90);
                for (int y = 0; y < 90; y++)
                for (int x = 0; x < 90; x++)
                {
                    double dist = Math.Sqrt((x - 45 + 0.5) * (x - 45 + 0.5) + (y - 45 + 0.5) * (y - 45 + 0.5));
                    int a = (int)Math.Round(Math.Clamp(r - dist + 0.5, 0, 1) * 255);
                    if (a > 0) tile.SetPixel(x, y, Px.FromStraight(a, 250, 240 - f * 20, 40 + f * 25));
                }
                ds.Surface.BlendBuffer(tile, (int)cx - 45, (int)cy - 45, ds.Recorder);
                ds.AddDirty(d.CanvasBounds); ds.TakeDirty(); ds.Commit("disc");
            }
            d.GoToFrame(0);

            var gif = Options(d, ExportFormat.Gif, Path.Combine(dir, "detail.gif"));
            T.True(RunExport(d, gif).Succeeded);
            var seq = Options(d, ExportFormat.PngSequence, Path.Combine(dir, "detail-frames"));
            seq.FileNamePrefix = "detail";
            T.True(RunExport(d, seq).Succeeded);
            var lowGif = Options(d, ExportFormat.Gif, Path.Combine(dir, "detail-q20.gif"));
            lowGif.Quality = 20;
            T.True(RunExport(d, lowGif).Succeeded);
            var mp4 = ExportManager.Plan(d.Project, Options(d, ExportFormat.Mp4, Path.Combine(dir, "detail.mp4")));
            if (FfmpegLocator.Find(null) != null) T.True(RunExport(d, Options(d, ExportFormat.Mp4, Path.Combine(dir, "detail.mp4"))).Succeeded);
            var sheet = Options(d, ExportFormat.SpriteSheet, Path.Combine(dir, "detail-sheet.png"));
            sheet.Width = 240; sheet.Height = 135; sheet.Columns = 4;
            T.True(RunExport(d, sheet).Succeeded);
        });

        T.Run("sample files are written for visual inspection", () =>
        {
            var d = SquareAnim(false, 96, 72);
            string dir = KeepDir("export");
            T.True(RunExport(d, Options(d, ExportFormat.Gif, Path.Combine(dir, "squares.gif"))).Succeeded);
            var dt = SquareAnim(true, 96, 72);
            T.True(RunExport(dt, Options(dt, ExportFormat.Gif, Path.Combine(dir, "squares-transparent.gif"))).Succeeded);
        });
    }

    private static PixelBuffer PixelOfColor(uint color)
    {
        var b = new PixelBuffer(1, 1);
        b.Fill(color);
        return b;
    }

    /// <summary>The picture a viewer shows at output frame <paramref name="outputFrame"/>, given merged repeated frames.</summary>
    private static PixelBuffer GifPictureAt(GifInfo gif, int outputFrame, int outputFrameCount)
    {
        // Frames that repeated were merged into one image with a longer delay: find the image shown at that moment.
        int[] expectedDelays = ExportTimeline.GifDelays(outputFrameCount, 12);
        int startCs = expectedDelays.Take(outputFrame).Sum() + 1;
        int t = 0;
        foreach (var f in gif.Frames)
        {
            if (startCs <= t + f.DelayCs) return f.Picture;
            t += f.DelayCs;
        }
        return gif.Frames[^1].Picture;
    }

    private static void PngTests()
    {
        T.Suite("PNG and PNG sequence export");

        T.Run("a single frame becomes a PNG that matches the frame exactly", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            d.GoToFrame(1);
            var o = ExportOptions.CreateDefault(d.Project, ExportFormat.Png, d.CurrentFrame);
            o.OutputPath = tmp.P("frame");
            T.Equal(1, o.StartFrame);
            var result = RunExport(d, o);
            T.True(result.Succeeded, result.Message);
            var png = PngCodec.Decode(File.ReadAllBytes(result.Files[0]));
            AssertSame(Compositor.ComposeFrame(d.Project, 1, true), png);
        });

        T.Run("transparent PNG keeps alpha; opaque PNG is flattened onto the background", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(true);
            var o = Options(d, ExportFormat.Png, tmp.P("t.png"));
            var withAlpha = PngCodec.Decode(File.ReadAllBytes(RunExport(d, o).Files[0]));
            T.PixelIs(0u, withAlpha.GetPixel(40, 30));
            T.PixelIs(Red, withAlpha.GetPixel(8, 10));
            o.Transparent = false;
            o.OutputPath = tmp.P("o.png");
            var flat = PngCodec.Decode(File.ReadAllBytes(RunExport(d, o).Files[0]));
            T.PixelIs(White, flat.GetPixel(40, 30));
        });

        T.Run("a custom background colour is used when the picture is opaque", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            d.SetBackground(BackgroundSettings.Custom(new ArgbColor(255, 10, 20, 30)));
            var png = PngCodec.Decode(File.ReadAllBytes(RunExport(d, Options(d, ExportFormat.Png, tmp.P("c.png"))).Files[0]));
            T.PixelIs(Px.FromStraight(255, 10, 20, 30), png.GetPixel(40, 30));
        });

        T.Run("scaling to a larger or smaller size gives the requested dimensions", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            foreach (var (w, h) in new[] { (128, 96), (32, 24), (200, 50) })
            {
                var o = Options(d, ExportFormat.Png, tmp.P($"s{w}.png"));
                o.Width = w; o.Height = h;
                var png = PngCodec.Decode(File.ReadAllBytes(RunExport(d, o).Files[0]));
                T.Equal(w, png.Width); T.Equal(h, png.Height);
            }
        });

        T.Run("nearest-neighbour scaling keeps pixel art crisp", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            var o = Options(d, ExportFormat.Png, tmp.P("n.png"));
            o.Width = 128; o.Height = 96; o.SmoothScaling = false;
            var png = PngCodec.Decode(File.ReadAllBytes(RunExport(d, o).Files[0]));
            var colours = new HashSet<uint>();
            foreach (uint p in png.Pixels) colours.Add(p);
            T.Equal(2, colours.Count, "only white and red: no blended edge pixels");
        });

        T.Run("a PNG sequence writes one numbered file per frame and nothing else", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            var o = Options(d, ExportFormat.PngSequence, tmp.P("frames"));
            o.FileNamePrefix = "walk";
            var result = RunExport(d, o);
            T.True(result.Succeeded, result.Message);
            string[] files = Directory.GetFileSystemEntries(tmp.P("frames")).Select(Path.GetFileName).OrderBy(x => x).ToArray()!;
            T.Equal("walk_0001.png,walk_0002.png,walk_0003.png,walk_0004.png", string.Join(",", files));
            T.Equal(4, result.Files.Count);
            for (int f = 0; f < 4; f++)
                AssertSame(Compositor.ComposeFrame(d.Project, f, true), PngCodec.Decode(File.ReadAllBytes(tmp.P($"frames/walk_000{f + 1}.png"))));
        });

        T.Run("sequence file names are cleaned and numbering widens for long animations", () =>
        {
            T.Equal("a_0001.png", ExportManager.SequenceFileNames("a", 3)[0]);
            T.Equal("x_00001.png", ExportManager.SequenceFileNames("x", 12000)[0]);
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            var o = Options(d, ExportFormat.PngSequence, tmp.P("f"));
            o.FileNamePrefix = "bad/na:me*?";
            var plan = ExportManager.Plan(d.Project, o);
            T.True(plan.IsValid, string.Join(" ", plan.Problems));
            T.True(Path.GetFileName(plan.OutputFiles[0]).StartsWith("bad_na_me__"), Path.GetFileName(plan.OutputFiles[0]));
        });

        T.Run("a frame range for a sequence only writes those frames, numbered from 1", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            var o = Options(d, ExportFormat.PngSequence, tmp.P("r"));
            o.StartFrame = 1; o.EndFrame = 2;
            var result = RunExport(d, o);
            T.True(result.Succeeded, result.Message);
            string[] files = Directory.GetFiles(tmp.P("r")).Select(Path.GetFileName).OrderBy(x => x).ToArray()!;
            T.Equal("frame_0001.png,frame_0002.png", string.Join(",", files));
            AssertSame(Compositor.ComposeFrame(d.Project, 1, true), PngCodec.Decode(File.ReadAllBytes(tmp.P("r/frame_0001.png"))));
            AssertSame(Compositor.ComposeFrame(d.Project, 2, true), PngCodec.Decode(File.ReadAllBytes(tmp.P("r/frame_0002.png"))));
        });

        T.Run("an existing file is replaced and reported beforehand", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            var o = Options(d, ExportFormat.Png, tmp.P("same.png"));
            T.Equal(0, ExportManager.FindExistingOutputs(d.Project, o).Count);
            T.True(RunExport(d, o).Succeeded);
            T.Equal(1, ExportManager.FindExistingOutputs(d.Project, o).Count, "second time the file would be overwritten");
            File.WriteAllText(tmp.P("same.png"), "old");
            T.True(RunExport(d, o).Succeeded);
            T.True(new FileInfo(tmp.P("same.png")).Length > 20, "replaced with a real PNG");
            T.Equal(1, Directory.GetFileSystemEntries(tmp.Root).Length, "no temporary files");
        });
    }

    private static void AssertSame(PixelBuffer a, PixelBuffer b, int tolerance = 0)
    {
        T.Equal(a.Width, b.Width, "width");
        T.Equal(a.Height, b.Height, "height");
        for (int i = 0; i < a.Pixels.Length; i++)
            if (Px.MaxChannelDiff(a.Pixels[i], b.Pixels[i]) > tolerance)
                throw new Exception($"pixel {i % a.Width},{i / a.Width}: {a.Pixels[i]:X8} vs {b.Pixels[i]:X8}");
    }

    private static void SheetTests()
    {
        T.Suite("Sprite sheet export");

        T.Run("layout: roughly square grid, explicit columns, padding", () =>
        {
            var l = SpriteSheetLayout.Compute(10, 32, 16, 0, 0);
            T.Equal(4, l.Columns); T.Equal(3, l.Rows); T.Equal(128, l.Width); T.Equal(48, l.Height);
            var l2 = SpriteSheetLayout.Compute(10, 32, 16, 5, 2);
            T.Equal(5, l2.Columns); T.Equal(2, l2.Rows); T.Equal(5 * 32 + 4 * 2, l2.Width); T.Equal(2 * 16 + 2, l2.Height);
            T.Equal(10, SpriteSheetLayout.Compute(10, 8, 8, 99, 0).Columns, "never more columns than frames");
            var (x, y) = l2.CellOrigin(7);
            T.Equal(2 * 34, x); T.Equal(1 * 18, y);
            T.False(SpriteSheetLayout.Compute(500, 1000, 1000, 0, 0).IsWithinLimits(out _), "huge sheets are refused");
        });

        T.Run("frames land in their cells and a JSON file describes them", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            var o = Options(d, ExportFormat.SpriteSheet, tmp.P("sheet"));
            o.Columns = 2; o.Padding = 4;
            var result = RunExport(d, o);
            T.True(result.Succeeded, result.Message);
            T.Equal(2, result.Files.Count);
            var sheet = PngCodec.Decode(File.ReadAllBytes(tmp.P("sheet.png")));
            T.Equal(2 * 64 + 4, sheet.Width); T.Equal(2 * 48 + 4, sheet.Height);
            T.PixelIs(Red, sheet.GetPixel(8, 10), "frame 0 in cell 0");
            T.PixelIs(Green, sheet.GetPixel(68 + 26, 14), "frame 1 in cell 1");
            T.PixelIs(Blue, sheet.GetPixel(0 + 44, 52 + 18), "frame 2 in cell 2 (second row)");
            T.PixelIs(White, sheet.GetPixel(66, 5), "the gap between cells is filled on an opaque sheet");

            using var json = JsonDocument.Parse(File.ReadAllText(tmp.P("sheet.json")));
            var frames = json.RootElement.GetProperty("frames");
            T.Equal(4, frames.GetArrayLength());
            T.Equal(68, frames[1].GetProperty("frame").GetProperty("x").GetInt32());
            T.Equal(52, frames[2].GetProperty("frame").GetProperty("y").GetInt32());
            T.Equal(83, frames[0].GetProperty("duration").GetInt32());
            var meta = json.RootElement.GetProperty("meta");
            T.Equal("sheet.png", meta.GetProperty("image").GetString());
            T.Equal(132, meta.GetProperty("size").GetProperty("w").GetInt32());
            T.Equal(2, meta.GetProperty("columns").GetInt32());
        });

        T.Run("a transparent sheet keeps its gaps transparent; the JSON can be left out", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(true);
            var o = Options(d, ExportFormat.SpriteSheet, tmp.P("t.png"));
            o.Padding = 4; o.WriteSpriteSheetJson = false; o.Columns = 2;
            var result = RunExport(d, o);
            T.Equal(1, result.Files.Count);
            T.False(File.Exists(tmp.P("t.json")));
            var sheet = PngCodec.Decode(File.ReadAllBytes(tmp.P("t.png")));
            T.PixelIs(0u, sheet.GetPixel(66, 5));
            T.PixelIs(Red, sheet.GetPixel(8, 10));
        });

        T.Run("a sheet that would be too large is refused with an explanation", () =>
        {
            var p = Project.CreateNew(4000, 4000, 12);
            p.FrameCount = 40;
            var d = new Document(p);
            var o = Options(d, ExportFormat.SpriteSheet, Path.Combine(Path.GetTempPath(), "never.png"));
            var result = RunExport(d, o);
            T.Equal(ExportStatus.Failed, result.Status);
            T.Equal(ExportProblem.InvalidOptions, result.Problem);
            T.True(result.Message.Contains("too large"), result.Message);
        });
    }

    private static void PlanTests()
    {
        T.Suite("Export settings checks");

        T.Run("bad settings are explained and nothing is written", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            ExportOptions Fresh(ExportFormat f = ExportFormat.Gif) => Options(d, f, tmp.P("x"));

            var o = Fresh(); o.StartFrame = 3; o.EndFrame = 1;
            T.True(ExportManager.Plan(d.Project, o).Problems.Any(p => p.Contains("last frame")));
            o = Fresh(); o.OutputPath = "  ";
            T.True(ExportManager.Plan(d.Project, o).Problems.Any(p => p.Contains("Choose where")));
            o = Fresh(ExportFormat.PngSequence); o.OutputPath = "";
            T.True(ExportManager.Plan(d.Project, o).Problems.Any(p => p.Contains("folder")));
            o = Fresh(); o.Width = 20000;
            T.True(ExportManager.Plan(d.Project, o).Problems.Any(p => p.Contains("8192")));
            o = Fresh(); o.Width = 8000; o.Height = 8000;
            T.True(ExportManager.Plan(d.Project, o).Problems.Any(p => p.Contains("million")));
            o = Fresh(); o.Fps = 0;
            T.True(ExportManager.Plan(d.Project, o).Problems.Any(p => p.Contains("frame rate")));
            o = Fresh(); o.Fps = double.NaN;
            T.True(ExportManager.Plan(d.Project, o).Problems.Any(p => p.Contains("frame rate")));
            o = Fresh(); o.OutputPath = "bad\0name";
            T.True(ExportManager.Plan(d.Project, o).Problems.Any(p => p.Contains("not valid")));

            File.WriteAllText(tmp.P("afile"), "x");
            o = Fresh(ExportFormat.PngSequence); o.OutputPath = tmp.P("afile");
            T.True(ExportManager.Plan(d.Project, o).Problems.Any(p => p.Contains("folder")));
            Directory.CreateDirectory(tmp.P("adir.gif"));
            o = Fresh(); o.OutputPath = tmp.P("adir.gif");
            T.True(ExportManager.Plan(d.Project, o).Problems.Any(p => p.Contains("folder with that name")));

            var badOptions = Fresh();
            badOptions.StartFrame = 3;
            badOptions.EndFrame = 1;
            var bad = RunExport(d, badOptions);
            T.Equal(ExportStatus.Failed, bad.Status);
            T.Equal(ExportProblem.InvalidOptions, bad.Problem);
            T.Equal(0, Directory.GetFileSystemEntries(tmp.Root).Count(e => Path.GetFileName(e) == "x.gif"), "nothing written");
        });

        T.Run("adjustments are reported as warnings, not errors", () =>
        {
            var d = SquareAnim(false, 65, 47);
            var o = Options(d, ExportFormat.Mp4, Path.Combine(Path.GetTempPath(), "w.mp4"));
            o.Transparent = true;
            var plan = ExportManager.Plan(d.Project, o);
            T.True(plan.IsValid, string.Join(" ", plan.Problems));
            T.Equal(66, plan.Options.Width); T.Equal(48, plan.Options.Height);
            T.False(plan.Options.Transparent);
            T.Equal(2, plan.Warnings.Count);

            var g = Options(d, ExportFormat.Gif, Path.Combine(Path.GetTempPath(), "w.gif"));
            g.Fps = 100;
            var gp = ExportManager.Plan(d.Project, g);
            T.Near(50, gp.Options.Fps, 1e-9);
            T.True(gp.Warnings.Any(w => w.Contains("50")));
        });

        T.Run("the plan reports frame count and running time", () =>
        {
            var d = SquareAnim(false);
            var o = Options(d, ExportFormat.Gif, Path.Combine(Path.GetTempPath(), "p.gif"));
            o.Fps = 24;
            var plan = ExportManager.Plan(d.Project, o);
            T.Equal(8, plan.OutputFrames);
            T.Near(1.0 / 3, plan.Duration.TotalSeconds, 0.001);
        });
    }

    private static void BehaviourTests()
    {
        T.Suite("Export behaviour");

        T.Run("exporting in the background reports rising progress and leaves the document free to edit", () =>
        {
            using var tmp = new TempDir();
            var p = Project.CreateNew(640, 360, 12, BackgroundSettings.White);
            p.FrameCount = 30;
            var d = new Document(p);
            var layer = d.ActiveLayer;
            for (int f = 0; f < 30; f++)
            {
                d.GoToFrame(f); d.InsertBlankKeyframe(layer, f);
                Paint(d, new IntRect(10 + f * 10, 50, 80, 80), Red);
            }
            d.GoToFrame(0);

            var reports = new List<ExportProgress>();
            var progress = new InlineProgress<ExportProgress>(r => { lock (reports) reports.Add(r); });
            var o = Options(d, ExportFormat.PngSequence, tmp.P("bg"));
            var task = ExportManager.ExportAsync(d, o, progress);
            // The caller gets control back immediately and may keep drawing; the export works from a snapshot.
            Paint(d, new IntRect(0, 0, 20, 20), Blue);
            var result = task.GetAwaiter().GetResult();

            T.True(result.Succeeded, result.Message);
            T.True(reports.Count >= 10, $"{reports.Count} progress reports");
            for (int i = 1; i < reports.Count; i++) T.True(reports[i].Fraction >= reports[i - 1].Fraction - 1e-9, "progress never goes backwards");
            T.True(reports[^1].Fraction >= 0.99, "ends at the end");
            var first = PngCodec.Decode(File.ReadAllBytes(tmp.P("bg/frame_0001.png")));
            T.PixelIs(Red, first.GetPixel(30, 80), "exported content");
        });

        T.Run("an export of the document is a snapshot: edits made during the export are not in it", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false, 320, 240);
            var o = Options(d, ExportFormat.Png, tmp.P("snap.png"));
            var task = ExportManager.ExportAsync(d, o);
            Paint(d, new IntRect(100, 100, 50, 50), Blue); // after the snapshot was taken
            T.True(task.GetAwaiter().GetResult().Succeeded);
            var png = PngCodec.Decode(File.ReadAllBytes(tmp.P("snap.png")));
            T.PixelIs(White, png.GetPixel(120, 120), "the later stroke is not in the file");
        });

        T.Run("cancelling stops the export and leaves no half-written files", () =>
        {
            using var tmp = new TempDir();
            var p = Project.CreateNew(640, 360, 12, BackgroundSettings.White);
            p.FrameCount = 60;
            var d = new Document(p);
            var layer = d.ActiveLayer;
            for (int f = 0; f < 60; f++)
            {
                d.GoToFrame(f); d.InsertBlankKeyframe(layer, f);
                Paint(d, new IntRect(10 + f * 5, 50, 80, 80), f % 2 == 0 ? Red : Green);
            }
            foreach (var format in new[] { ExportFormat.Gif, ExportFormat.PngSequence, ExportFormat.SpriteSheet })
            {
                using var cts = new CancellationTokenSource();
                var progress = new InlineProgress<ExportProgress>(r => { if (r.FramesDone >= 5) cts.Cancel(); });
                string path = format == ExportFormat.PngSequence ? tmp.P("cancel-folder") : tmp.P("cancel" + ExportOptions.DefaultExtension(format));
                var o = Options(d, format, path);
                o.Width = 320; o.Height = 180;
                var result = ExportManager.ExportAsync(d, o, progress, cts.Token).GetAwaiter().GetResult();
                T.Equal(ExportStatus.Cancelled, result.Status, format + " status: " + result.Message);
            }
            T.Equal(0, Directory.GetFileSystemEntries(tmp.Root).Count(e => !Path.GetFileName(e).StartsWith("cancel-folder")),
                "no files left: " + string.Join(", ", Directory.GetFileSystemEntries(tmp.Root)));
            if (Directory.Exists(tmp.P("cancel-folder")))
                T.Equal(0, Directory.GetFileSystemEntries(tmp.P("cancel-folder")).Length, "the sequence folder is empty");
        });

        T.Run("a cancelled export does not damage the file it would have replaced", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            var o = Options(d, ExportFormat.Gif, tmp.P("keep.gif"));
            T.True(RunExport(d, o).Succeeded);
            byte[] before = File.ReadAllBytes(tmp.P("keep.gif"));
            using var cts = new CancellationTokenSource();
            cts.Cancel();
            var result = ExportManager.Export(d.CreateSnapshot(), o, null, cts.Token);
            T.Equal(ExportStatus.Cancelled, result.Status);
            T.True(before.AsSpan().SequenceEqual(File.ReadAllBytes(tmp.P("keep.gif"))), "unchanged");
        });

        T.Run("an unwritable destination is reported in plain words, not thrown", () =>
        {
            using var tmp = new TempDir();
            File.WriteAllText(tmp.P("blocker"), "x");
            var d = SquareAnim(false);
            foreach (var format in new[] { ExportFormat.Gif, ExportFormat.Png, ExportFormat.SpriteSheet })
            {
                var o = Options(d, format, Path.Combine(tmp.P("blocker"), "inside", "out"));
                var result = RunExport(d, o);
                T.Equal(ExportStatus.Failed, result.Status, format.ToString());
                T.True(result.Message.Length > 10, result.Message);
            }
            var seq = Options(d, ExportFormat.PngSequence, Path.Combine(tmp.P("blocker"), "inside"));
            T.Equal(ExportStatus.Failed, RunExport(d, seq).Status);
        });

        T.Run("exporting a project with several layers, opacity and hidden layers matches the composite", () =>
        {
            using var tmp = new TempDir();
            var p = Project.CreateNew(64, 48, 12, BackgroundSettings.White);
            var d = new Document(p);
            Paint(d, new IntRect(0, 0, 40, 40), Blue);
            var top = d.AddLayer("top")!;
            Paint(d, new IntRect(20, 20, 40, 20), Red);
            d.SetLayerOpacity(top, 0.5);
            var hidden = d.AddLayer("hidden")!;
            Paint(d, new IntRect(0, 40, 64, 8), Green);
            d.SetLayerVisible(hidden, false);
            var png = PngCodec.Decode(File.ReadAllBytes(RunExport(d, Options(d, ExportFormat.Png, tmp.P("l.png"))).Files[0]));
            AssertSame(Compositor.ComposeFrame(d.Project, 0, true), png);
            T.PixelIs(White, png.GetPixel(30, 44), "hidden layer is not exported");
        });
    }

    private sealed class InlineProgress<T2> : IProgress<T2>
    {
        private readonly Action<T2> _onReport;
        public InlineProgress(Action<T2> onReport) => _onReport = onReport;
        public void Report(T2 value) => _onReport(value);
    }

    // ------------------------------------------------------------------ MP4 (needs ffmpeg)

    private static void Mp4Tests()
    {
        T.Suite("MP4 export");
        var ffmpeg = FfmpegLocator.Find(null);

        T.Run("without ffmpeg the user gets an explanation and nothing is written", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false);
            var o = Options(d, ExportFormat.Mp4, tmp.P("v.mp4"));
            o.FfmpegPath = tmp.P("no-such-ffmpeg.exe");
            // Hide any ffmpeg on the PATH for this check.
            string? oldPath = Environment.GetEnvironmentVariable("PATH");
            Environment.SetEnvironmentVariable("PATH", tmp.Root);
            try
            {
                var result = RunExport(d, o);
                T.Equal(ExportStatus.Failed, result.Status);
                T.Equal(ExportProblem.FfmpegMissing, result.Problem);
                T.True(result.Message.Contains("FFmpeg") && result.Message.Contains("ffmpeg.org"), result.Message);
                T.True(result.Message.Contains("GIF"), "points out what still works");
                T.False(File.Exists(tmp.P("v.mp4")));
            }
            finally { Environment.SetEnvironmentVariable("PATH", oldPath); }
        });

        T.Run("a program that is not ffmpeg is not accepted", () =>
        {
            using var tmp = new TempDir();
            string fake = tmp.P(FfmpegLocator.ExecutableName);
            File.WriteAllText(fake, "#!/bin/sh\necho hello\n");
            T.True(FfmpegLocator.Probe(fake) == null);
        });

        if (ffmpeg == null)
        {
            T.Skip("MP4 encoding checks", "ffmpeg is not installed on this machine");
            return;
        }
        Console.WriteLine($"        using {ffmpeg.Version} (x264: {ffmpeg.HasLibx264})");

        T.Run("ffmpeg is found and its encoders are detected", () =>
        {
            T.True(ffmpeg.CanWriteMp4, "can write MP4");
            T.True(FfmpegLocator.Candidates(null).Any());
        });

        T.Run("the video has the right size, frame count, rate and colours", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false, 128, 96);
            var o = Options(d, ExportFormat.Mp4, tmp.P("v.mp4"));
            o.Fps = 12;
            var result = RunExport(d, o);
            T.True(result.Succeeded, result.Message);
            var (w, h, frames) = DecodeVideo(tmp.P("v.mp4"));
            T.Equal(128, w); T.Equal(96, h);
            T.Equal(4, frames.Count, "four frames");
            // frame 0's red square is at (4,6) 12x12 -> centre (10,12); frame 1 green at (22,10) -> centre (28,16)
            AssertNear(frames[0], w, 10, 12, 255, 0, 0, 40);
            AssertNear(frames[1], w, 28, 16, 0, 255, 0, 60);
            AssertNear(frames[0], w, 100, 80, 255, 255, 255, 10);
            AssertNear(frames[2], w, 46, 20, 0, 0, 255, 40);
        });

        T.Run("colours are not shifted by the video conversion", () =>
        {
            using var tmp = new TempDir();
            var p = Project.CreateNew(64, 64, 12, BackgroundSettings.Custom(new ArgbColor(255, 200, 80, 30)));
            var d = new Document(p);
            var o = Options(d, ExportFormat.Mp4, tmp.P("c.mp4"));
            T.True(RunExport(d, o).Succeeded);
            var (w, _, frames) = DecodeVideo(tmp.P("c.mp4"));
            AssertNear(frames[0], w, 32, 32, 200, 80, 30, 8);
        });

        T.Run("odd sizes are rounded up to even ones and the user is told", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false, 65, 47);
            var result = RunExport(d, Options(d, ExportFormat.Mp4, tmp.P("odd.mp4")));
            T.True(result.Succeeded, result.Message);
            T.True(result.Warnings.Any(w => w.Contains("even")), "warning present");
            var (w, h, _) = DecodeVideo(tmp.P("odd.mp4"));
            T.Equal(66, w); T.Equal(48, h);
        });

        T.Run("a different output rate and a frame range are honoured", () =>
        {
            using var tmp = new TempDir();
            var d = SquareAnim(false, 64, 48);
            var o = Options(d, ExportFormat.Mp4, tmp.P("r.mp4"));
            o.Fps = 24; o.StartFrame = 0; o.EndFrame = 1;
            var result = RunExport(d, o);
            T.True(result.Succeeded, result.Message);
            T.Equal(4, DecodeVideo(tmp.P("r.mp4")).Frames.Count, "2 frames at 12 fps -> 4 at 24 fps");
        });

        T.Run("higher quality makes a bigger file", () =>
        {
            using var tmp = new TempDir();
            var p = Project.CreateNew(320, 240, 12, BackgroundSettings.White);
            p.FrameCount = 6;
            var d = new Document(p);
            var layer = d.ActiveLayer;
            var rng = new Random(3);
            for (int f = 0; f < 6; f++)
            {
                d.GoToFrame(f); d.InsertBlankKeyframe(layer, f);
                for (int i = 0; i < 40; i++) Paint(d, new IntRect(rng.Next(300), rng.Next(220), 20, 20), Px.FromStraight(255, rng.Next(256), rng.Next(256), rng.Next(256)));
            }
            long[] sizes = new long[2];
            int[] qualities = { 100, 10 };
            for (int i = 0; i < 2; i++)
            {
                var o = Options(d, ExportFormat.Mp4, tmp.P($"q{i}.mp4"));
                o.Quality = qualities[i];
                T.True(RunExport(d, o).Succeeded);
                sizes[i] = new FileInfo(tmp.P($"q{i}.mp4")).Length;
            }
            Console.WriteLine($"        quality 100 = {sizes[0] / 1024} KB, quality 10 = {sizes[1] / 1024} KB");
            T.True(sizes[0] > sizes[1] * 1.3, $"{sizes[0]} vs {sizes[1]}");
        });

        T.Run("cancelling stops ffmpeg and removes the partial file", () =>
        {
            using var tmp = new TempDir();
            var p = Project.CreateNew(640, 360, 12, BackgroundSettings.White);
            p.FrameCount = 120;
            var d = new Document(p);
            var layer = d.ActiveLayer;
            for (int f = 0; f < 120; f += 10)
            {
                d.GoToFrame(f); d.InsertBlankKeyframe(layer, f);
                Paint(d, new IntRect(10 + f, 50, 80, 80), Red);
            }
            using var cts = new CancellationTokenSource();
            var progress = new InlineProgress<ExportProgress>(r => { if (r.FramesDone >= 10) cts.Cancel(); });
            var result = ExportManager.ExportAsync(d, Options(d, ExportFormat.Mp4, tmp.P("cancel.mp4")), progress, cts.Token).GetAwaiter().GetResult();
            T.Equal(ExportStatus.Cancelled, result.Status, result.Message);
            T.Equal(0, Directory.GetFileSystemEntries(tmp.Root).Length, "nothing left: " + string.Join(", ", Directory.GetFileSystemEntries(tmp.Root)));
        });

        T.Run("a 1920 x 1080 video of 48 frames is made in reasonable time", () =>
        {
            using var tmp = new TempDir();
            var p = Project.CreateNew(1920, 1080, 24, BackgroundSettings.White);
            p.FrameCount = 48;
            var d = new Document(p);
            var layer = d.ActiveLayer;
            for (int f = 0; f < 48; f++)
            {
                d.GoToFrame(f); d.InsertBlankKeyframe(layer, f);
                Paint(d, new IntRect(20 + f * 30, 300, 200, 200), f % 2 == 0 ? Red : Blue);
            }
            var sw = Stopwatch.StartNew();
            var result = RunExport(d, Options(d, ExportFormat.Mp4, tmp.P("hd.mp4")));
            Console.WriteLine($"        1920x1080, 48 frames: {sw.ElapsedMilliseconds} ms, {result.TotalBytes / 1024} KB");
            T.True(result.Succeeded, result.Message);
            T.True(sw.ElapsedMilliseconds < 60000, $"{sw.ElapsedMilliseconds} ms");
        });

        T.Run("sample video is written for inspection", () =>
        {
            var d = SquareAnim(false, 128, 96);
            T.True(RunExport(d, Options(d, ExportFormat.Mp4, Path.Combine(KeepDir("export"), "squares.mp4"))).Succeeded);
        });
    }

    private static void AssertNear(byte[] rgbFrame, int width, int x, int y, int r, int g, int b, int tolerance)
    {
        int o = (y * width + x) * 3;
        int dr = Math.Abs(rgbFrame[o] - r), dg = Math.Abs(rgbFrame[o + 1] - g), db = Math.Abs(rgbFrame[o + 2] - b);
        if (Math.Max(dr, Math.Max(dg, db)) > tolerance)
            throw new Exception($"video pixel ({x},{y}) is {rgbFrame[o]},{rgbFrame[o + 1]},{rgbFrame[o + 2]} but should be about {r},{g},{b}");
    }

    /// <summary>Decodes a video with ffmpeg itself (the reference implementation) into raw RGB frames.</summary>
    private static (int Width, int Height, List<byte[]> Frames) DecodeVideo(string path)
    {
        var ffmpeg = FfmpegLocator.Find(null)!;
        var probe = new ProcessStartInfo(ffmpeg.Path) { RedirectStandardError = true, RedirectStandardOutput = true, UseShellExecute = false };
        foreach (string a in new[] { "-hide_banner", "-i", path }) probe.ArgumentList.Add(a);
        string info;
        using (var p = Process.Start(probe)!)
        {
            string err = p.StandardError.ReadToEnd();
            p.StandardOutput.ReadToEnd();
            p.WaitForExit();
            info = err;
        }
        var m = System.Text.RegularExpressions.Regex.Match(info, @"Video:.*?, (\d{2,5})x(\d{2,5})");
        T.True(m.Success, "could not read the video size from: " + info);
        int w = int.Parse(m.Groups[1].Value), h = int.Parse(m.Groups[2].Value);

        var psi = new ProcessStartInfo(ffmpeg.Path) { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
        foreach (string a in new[] { "-hide_banner", "-loglevel", "error", "-i", path, "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1" }) psi.ArgumentList.Add(a);
        using var proc = Process.Start(psi)!;
        var stderr = proc.StandardError.ReadToEndAsync();
        using var ms = new MemoryStream();
        proc.StandardOutput.BaseStream.CopyTo(ms);
        proc.WaitForExit();
        stderr.Wait();
        byte[] all = ms.ToArray();
        int frameBytes = w * h * 3;
        var frames = new List<byte[]>();
        for (int o = 0; o + frameBytes <= all.Length; o += frameBytes) frames.Add(all[o..(o + frameBytes)]);
        return (w, h, frames);
    }
}
