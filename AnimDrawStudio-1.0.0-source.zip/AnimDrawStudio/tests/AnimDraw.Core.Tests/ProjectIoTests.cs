using System.Diagnostics;
using System.IO.Compression;
using System.Text;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.IO;
using AnimDraw.Core.Model;
using AnimDraw.Core.Rendering;
using AnimDraw.Core.Settings;
using static AnimDraw.Core.Tests.Helpers;

namespace AnimDraw.Core.Tests;

public static class ProjectIoTests
{
    // ------------------------------------------------------------------ helpers

    private sealed class TempDir : IDisposable
    {
        public string Root { get; } = Path.Combine(Path.GetTempPath(), "animdraw-tests", Guid.NewGuid().ToString("N"));

        public TempDir() => Directory.CreateDirectory(Root);

        public string P(string name) => Path.Combine(Root, name);

        public void Dispose()
        {
            try { Directory.Delete(Root, recursive: true); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
    }

    private static readonly uint HalfYellow = Px.FromStraight(128, 255, 255, 0);

    /// <summary>
    /// Three layers (bottom to top: "Background art", "Ink", "FX"), six frames, a custom background, non-default
    /// onion skin, a hidden layer, a locked layer, a half-transparent layer, a held drawing and a blank keyframe.
    /// </summary>
    private static Document RichDoc(out Layer art, out Layer ink, out Layer fx)
    {
        var bg = BackgroundSettings.Custom(new ArgbColor(255, 20, 40, 60));
        var p = Project.CreateNew(96, 64, 24, bg);
        p.FrameCount = 6;
        p.Loop = false;
        p.Onion = new OnionSkinSettings { Enabled = false, PreviousFrames = 2, NextFrames = 3, Opacity = 0.6, Colorize = false };
        var d = new Document(p);

        art = d.ActiveLayer;
        d.RenameLayer(art, "Background art");
        ink = d.AddLayer("Ink")!;
        fx = d.AddLayer("FX")!;

        void Key(Layer layer, int frame, IntRect rect, uint color)
        {
            d.SetActiveLayer(layer);
            d.GoToFrame(frame);
            d.InsertBlankKeyframe(layer, frame);
            Paint(d, rect, color);
        }

        Key(art, 0, new IntRect(0, 40, 96, 24), Blue);                 // held across all six frames
        Key(ink, 0, new IntRect(4, 4, 10, 10), Red);                    // frames 0-1
        Key(ink, 2, new IntRect(30, 10, 12, 12), Green);                // frames 2-3
        d.SetActiveLayer(ink); d.GoToFrame(4); d.InsertBlankKeyframe(ink, 4); // frames 4-5: nothing
        Key(fx, 1, new IntRect(50, 20, 8, 8), HalfYellow);              // frames 1-5

        d.SetLayerOpacity(ink, 0.5);
        d.SetLayerVisible(fx, false);
        d.SetLayerLocked(art, true);
        d.SetActiveLayer(ink);
        d.GoToFrame(3);
        return d;
    }

    private static byte[] Serialize(Document d, SaveOptions? options = null)
    {
        using var ms = new MemoryStream();
        ProjectSerializer.Save(d.CreateSnapshot(), ms, d.CurrentFrame, d.ActiveLayer.Id, options);
        return ms.ToArray();
    }

    private static LoadedProject Deserialize(byte[] bytes)
    {
        using var ms = new MemoryStream(bytes);
        return ProjectSerializer.Load(ms);
    }

    private static void AssertSamePixels(PixelBuffer a, PixelBuffer b, int tolerance, string what)
    {
        T.Equal(a.Width, b.Width, what + " width");
        T.Equal(a.Height, b.Height, what + " height");
        for (int i = 0; i < a.Pixels.Length; i++)
        {
            if (Px.MaxChannelDiff(a.Pixels[i], b.Pixels[i]) > tolerance)
                throw new Exception($"{what}: pixel {i % a.Width},{i / a.Width} differs: {a.Pixels[i]:X8} vs {b.Pixels[i]:X8}");
        }
    }

    private static void AssertSameProject(Project a, Project b, int tolerance = 2)
    {
        T.Equal(a.Width, b.Width, "width");
        T.Equal(a.Height, b.Height, "height");
        T.Near(a.Fps, b.Fps, 1e-9, "fps");
        T.Equal(a.FrameCount, b.FrameCount, "frame count");
        T.Equal(a.Loop, b.Loop, "loop");
        T.Equal(a.Background.Mode, b.Background.Mode, "background mode");
        T.Equal(a.Background.EffectiveColor, b.Background.EffectiveColor, "background colour");
        T.Equal(a.Onion.Enabled, b.Onion.Enabled, "onion enabled");
        T.Equal(a.Onion.PreviousFrames, b.Onion.PreviousFrames, "onion previous frames");
        T.Equal(a.Onion.NextFrames, b.Onion.NextFrames, "onion next frames");
        T.Near(a.Onion.Opacity, b.Onion.Opacity, 1e-9, "onion opacity");
        T.Equal(a.Onion.Colorize, b.Onion.Colorize, "onion colorize");
        T.Equal(a.Layers.Count, b.Layers.Count, "layer count");
        for (int i = 0; i < a.Layers.Count; i++)
        {
            var la = a.Layers[i];
            var lb = b.Layers[i];
            T.Equal(la.Id, lb.Id, $"layer {i} id");
            T.Equal(la.Name, lb.Name, $"layer {i} name");
            T.Equal(la.Visible, lb.Visible, $"layer {i} visible");
            T.Equal(la.Locked, lb.Locked, $"layer {i} locked");
            T.Near(la.Opacity, lb.Opacity, 1e-9, $"layer {i} opacity");
            var ka = la.Track.Keyframes.ToList();
            var kb = lb.Track.Keyframes.ToList();
            T.Equal(ka.Count, kb.Count, $"layer {i} keyframe count");
            for (int k = 0; k < ka.Count; k++)
            {
                T.Equal(ka[k].Frame, kb[k].Frame, $"layer {i} keyframe {k} frame number");
                AssertSamePixels(ka[k].Cel.Surface.ToBuffer(), kb[k].Cel.Surface.ToBuffer(), tolerance,
                    $"layer \"{la.Name}\" keyframe at frame {ka[k].Frame}");
            }
        }
    }

    private static byte[] Utf8(string s) => Encoding.UTF8.GetBytes(s);

    private static byte[] Zip(params (string Name, byte[] Data)[] entries)
    {
        using var ms = new MemoryStream();
        using (var z = new ZipArchive(ms, ZipArchiveMode.Create, leaveOpen: true))
        {
            foreach (var (name, data) in entries)
            {
                var e = z.CreateEntry(name, CompressionLevel.NoCompression);
                using var s = e.Open();
                s.Write(data, 0, data.Length);
            }
        }
        return ms.ToArray();
    }

    private static List<string> EntryNames(byte[] zipBytes)
    {
        using var ms = new MemoryStream(zipBytes);
        using var z = new ZipArchive(ms, ZipArchiveMode.Read);
        return z.Entries.Select(e => e.FullName).ToList();
    }

    private const string GoodManifest = "{\"format\":\"AnimDraw\",\"version\":1}";
    private const string LayerId = "11111111111111111111111111111111";

    private static string ProjectJson(int w = 8, int h = 8, int frames = 1, string? layers = null)
    {
        layers ??= $"[{{\"id\":\"{LayerId}\",\"name\":\"L\",\"cels\":[]}}]";
        return $"{{\"width\":{w},\"height\":{h},\"fps\":12,\"frameCount\":{frames},\"layers\":{layers}}}";
    }

    private static string LayerWithCel(string image, int x = 0, int y = 0) =>
        $"[{{\"id\":\"{LayerId}\",\"name\":\"L\",\"cels\":[{{\"frame\":0,\"image\":\"{image.Replace("\\", "\\\\")}\",\"x\":{x},\"y\":{y},\"width\":4,\"height\":4}}]}}]";

    private static byte[] HandBuilt(string projectJson, string manifest = GoodManifest, params (string Name, byte[] Data)[] extra)
    {
        var entries = new List<(string Name, byte[] Data)>
        {
            ("manifest.json", Utf8(manifest)),
            ("project.json", Utf8(projectJson))
        };
        entries.AddRange(extra);
        return Zip(entries.ToArray());
    }

    private static byte[] RedSquarePng(int size = 4)
    {
        var buf = new PixelBuffer(size, size);
        buf.Fill(Red);
        return PngCodec.Encode(buf);
    }

    /// <summary>Loading must fail with a <see cref="ProjectFileException"/> that has a readable message.</summary>
    private static void Rejects(string label, byte[] file, string? mustMention = null)
    {
        try
        {
            using var ms = new MemoryStream(file);
            ProjectSerializer.Load(ms);
        }
        catch (ProjectFileException ex)
        {
            if (string.IsNullOrWhiteSpace(ex.Message)) throw new Exception($"{label}: the error message is empty");
            if (mustMention != null && !ex.Message.Contains(mustMention, StringComparison.OrdinalIgnoreCase))
                throw new Exception($"{label}: message \"{ex.Message}\" does not mention \"{mustMention}\"");
            return;
        }
        catch (Exception ex)
        {
            throw new Exception($"{label}: expected a ProjectFileException but got {ex.GetType().Name}: {ex.Message}");
        }
        throw new Exception($"{label}: the file was accepted but should have been rejected");
    }

    private static uint Crc32(ReadOnlySpan<byte> data)
    {
        uint c = 0xFFFFFFFF;
        foreach (byte b in data)
        {
            c ^= b;
            for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
        }
        return c ^ 0xFFFFFFFF;
    }

    private static byte[] PngChunk(string type, byte[] data, uint? lengthOverride = null)
    {
        using var ms = new MemoryStream();
        void Be(uint v) { ms.WriteByte((byte)(v >> 24)); ms.WriteByte((byte)(v >> 16)); ms.WriteByte((byte)(v >> 8)); ms.WriteByte((byte)v); }
        Be(lengthOverride ?? (uint)data.Length);
        byte[] td = Encoding.ASCII.GetBytes(type).Concat(data).ToArray();
        ms.Write(td, 0, td.Length);
        Be(Crc32(td));
        return ms.ToArray();
    }

    private static readonly byte[] PngSignature = { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A };

    /// <summary>A PNG with a valid header that claims a given size but holds no picture data.</summary>
    private static byte[] PngClaiming(int w, int h)
    {
        var ihdr = new byte[13];
        ihdr[0] = (byte)(w >> 24); ihdr[1] = (byte)(w >> 16); ihdr[2] = (byte)(w >> 8); ihdr[3] = (byte)w;
        ihdr[4] = (byte)(h >> 24); ihdr[5] = (byte)(h >> 16); ihdr[6] = (byte)(h >> 8); ihdr[7] = (byte)h;
        ihdr[8] = 8; ihdr[9] = 6;
        return PngSignature.Concat(PngChunk("IHDR", ihdr)).Concat(PngChunk("IEND", Array.Empty<byte>())).ToArray();
    }

    // ------------------------------------------------------------------ the tests

    public static void RunAll()
    {
        FormatTests();
        HostileFileTests();
        PngHardeningTests();
        DiskTests();
        DirtyFlagTests();
        RecoveryTests();
        SettingsTests();
    }

    // ------------------------------------------------------------------ project format

    private static void FormatTests()
    {
        T.Suite("Project file format (.animdraw)");

        T.Run("round trip keeps layers, order, flags, opacity, keyframes, drawings and settings", () =>
        {
            var d = RichDoc(out _, out var ink, out _);
            var loaded = Deserialize(Serialize(d));
            AssertSameProject(d.Project, loaded.Project);
            T.Equal(3, loaded.CurrentFrame, "current frame");
            T.True(loaded.ActiveLayerId == ink.Id, "active layer");
            T.Equal(3, loaded.Project.Layers.Count, "three layers");
            T.Equal("Background art", loaded.Project.Layers[0].Name);
            T.Equal("FX", loaded.Project.Layers[2].Name);
            T.True(loaded.Project.Layers[0].Locked && !loaded.Project.Layers[2].Visible, "flags");
            T.Near(0.5, loaded.Project.Layers[1].Opacity, 1e-9, "layer opacity");
            T.Equal(BackgroundMode.Custom, loaded.Project.Background.Mode);
            T.False(loaded.Project.Loop);
        });

        T.Run("every frame looks the same after reloading", () =>
        {
            var d = RichDoc(out _, out _, out _);
            var loaded = Deserialize(Serialize(d));
            for (int f = 0; f < 6; f++)
            {
                var before = Compositor.ComposeFrame(d.Project, f, withBackground: true);
                var after = Compositor.ComposeFrame(loaded.Project, f, withBackground: true);
                AssertSamePixels(before, after, 2, $"composited frame {f}");
            }
        });

        T.Run("drawings land where they were: opaque pixels are exact, held frames repeat", () =>
        {
            var d = RichDoc(out _, out _, out _);
            var loaded = Deserialize(Serialize(d));
            var ink = loaded.Project.Layers[1];
            T.PixelIs(Red, PixelOf(ink, 0, 5, 5), "frame 0 red");
            T.PixelIs(Red, PixelOf(ink, 1, 5, 5), "frame 1 holds frame 0");
            T.PixelIs(Green, PixelOf(ink, 2, 31, 11), "frame 2 green");
            T.PixelIs(0u, PixelOf(ink, 2, 5, 5), "frame 2 no longer has the red square");
            T.PixelIs(Blue, PixelOf(loaded.Project.Layers[0], 5, 10, 50), "background art is held to the last frame");
            T.PixelIs(HalfYellow, PixelOf(loaded.Project.Layers[2], 3, 52, 22), "semi-transparent pixel", tolerance: 2);
            T.True(loaded.Project.Layers[2].GetCelAt(0) == null, "FX has nothing before its first keyframe");
        });

        T.Run("a blank keyframe is still a keyframe after reloading", () =>
        {
            var d = RichDoc(out _, out _, out _);
            var ink = Deserialize(Serialize(d)).Project.Layers[1];
            T.True(ink.Track.IsKeyframe(4), "keyframe at 4");
            var cel = ink.GetCelAt(5);
            T.True(cel != null && cel.Surface.IsBlank(), "frames 4-5 are empty, not a repeat of frame 2");
        });

        T.Run("saving, loading and saving again changes nothing", () =>
        {
            var d = RichDoc(out _, out _, out _);
            var first = Deserialize(Serialize(d));
            var second = Deserialize(Serialize(new Document(first.Project)));
            AssertSameProject(first.Project, second.Project, tolerance: 0);
        });

        T.Run("identical drawings are stored once", () =>
        {
            var d = RichDoc(out _, out var ink, out _);
            int Images(byte[] b) => EntryNames(b).Count(n => n.StartsWith("cels/", StringComparison.Ordinal));
            T.Equal(4, Images(Serialize(d)), "four distinct non-blank drawings");
            d.SetActiveLayer(ink);
            d.DuplicateFrame(0);
            d.DuplicateFrame(0);
            T.Equal(4, Images(Serialize(d)), "duplicated frames add no images");
        });

        T.Run("reloaded copies of one stored drawing can still be edited independently", () =>
        {
            var d = RichDoc(out _, out var ink, out _);
            d.SetActiveLayer(ink);
            d.DuplicateFrame(0); // frame 1 is now an identical copy of frame 0 on the ink layer
            var doc = ProjectFileManager.DocumentFrom(Deserialize(Serialize(d)));
            var loadedInk = doc.Project.Layers[1];
            doc.SetActiveLayer(loadedInk);
            doc.GoToFrame(1);
            T.True(Paint(doc, new IntRect(60, 30, 6, 6), Blue), "paint on frame 1");
            T.PixelIs(Blue, PixelOf(loadedInk, 1, 62, 32), "frame 1 changed");
            T.PixelIs(0u, PixelOf(loadedInk, 0, 62, 32), "frame 0 did not");
        });

        T.Run("the file contains the editable structure, not just a flattened picture", () =>
        {
            var names = EntryNames(Serialize(RichDoc(out _, out _, out _)));
            T.True(names.Contains("manifest.json") && names.Contains("project.json") && names.Contains("preview.png"), string.Join(",", names));
            T.True(names.Count(n => n.StartsWith("cels/")) >= 4, "separate image per drawing");
        });

        T.Run("a small preview picture is stored and readable without loading the project", () =>
        {
            var d = NewDoc(1024, 512);
            Paint(d, new IntRect(10, 10, 200, 200), Red);
            using var ms = new MemoryStream(Serialize(d));
            var preview = ProjectSerializer.TryReadPreview(ms);
            T.True(preview != null, "preview present");
            T.Equal(256, preview!.Width, "scaled to 256 wide");
            T.Equal(128, preview.Height, "keeps the aspect ratio");
            using var none = new MemoryStream(Serialize(d, new SaveOptions { IncludePreview = false }));
            T.True(ProjectSerializer.TryReadPreview(none) == null, "no preview when switched off");
        });

        T.Run("transparent and white backgrounds survive", () =>
        {
            var d = NewDoc(16, 16);
            T.Equal(BackgroundMode.Transparent, Deserialize(Serialize(d)).Project.Background.Mode);
            d.SetBackground(BackgroundSettings.White);
            T.Equal(BackgroundMode.White, Deserialize(Serialize(d)).Project.Background.Mode);
        });

        T.Run("a 4096 x 2304 project with art on 8 frames saves and reloads quickly and exactly", () =>
        {
            var p = Project.CreateNew(4096, 2304, 24, BackgroundSettings.Transparent);
            p.FrameCount = 8;
            var d = new Document(p);
            var layer = d.ActiveLayer;
            for (int f = 0; f < 8; f++)
            {
                d.GoToFrame(f);
                d.InsertBlankKeyframe(layer, f);
                Paint(d, new IntRect(200 + f * 300, 300, 600, 600), f % 2 == 0 ? Red : Blue);
            }
            var sw = Stopwatch.StartNew();
            byte[] bytes = Serialize(d);
            long saveMs = sw.ElapsedMilliseconds;
            sw.Restart();
            var loaded = Deserialize(bytes);
            long loadMs = sw.ElapsedMilliseconds;
            Console.WriteLine($"        4096x2304, 8 frames: save {saveMs} ms, load {loadMs} ms, file {bytes.Length / 1024} KB");
            AssertSameProject(d.Project, loaded.Project, tolerance: 0);
            T.True(saveMs < 20000 && loadMs < 20000, $"save {saveMs} ms / load {loadMs} ms is too slow");
        });
    }

    // ------------------------------------------------------------------ hostile and damaged files

    private static void HostileFileTests()
    {
        T.Suite("Damaged and hostile files");

        T.Run("a hand-built minimal project loads (control for the tests below)", () =>
        {
            byte[] file = HandBuilt(ProjectJson(layers: LayerWithCel("cels/00001.png")), GoodManifest, ("cels/00001.png", RedSquarePng()));
            var loaded = Deserialize(file);
            T.PixelIs(Red, PixelOf(loaded.Project.Layers[0], 0, 1, 1));
            T.PixelIs(0u, PixelOf(loaded.Project.Layers[0], 0, 6, 6));
        });

        T.Run("things that are not projects are refused with a message", () =>
        {
            Rejects("random bytes", new byte[2000].Select((_, i) => (byte)(i * 31 + 7)).ToArray());
            Rejects("empty file", Array.Empty<byte>());
            Rejects("plain text", Utf8("hello, this is not a project"));
            Rejects("a zip with no manifest", Zip(("project.json", Utf8(ProjectJson()))), "manifest");
            Rejects("a zip of something else", Zip(("manifest.json", Utf8("{\"format\":\"Other\",\"version\":1}")), ("project.json", Utf8(ProjectJson()))), "not an AnimDraw");
            Rejects("manifest that is not JSON", Zip(("manifest.json", Utf8("{{{")), ("project.json", Utf8(ProjectJson()))));
            Rejects("missing project data", Zip(("manifest.json", Utf8(GoodManifest))), "missing");
            Rejects("project data that is not JSON", HandBuilt("{not json"));
            Rejects("project data that is null", HandBuilt("null"));
        });

        T.Run("a truncated copy of a real project is refused", () =>
        {
            byte[] good = Serialize(RichDoc(out _, out _, out _));
            foreach (double fraction in new[] { 0.9, 0.5, 0.1 })
            {
                byte[] cut = good.Take((int)(good.Length * fraction)).ToArray();
                Rejects($"truncated to {fraction:P0}", cut);
            }
        });

        T.Run("a project from a newer program version says so", () =>
        {
            Rejects("version 99", HandBuilt(ProjectJson(), "{\"format\":\"AnimDraw\",\"version\":99}"), "newer version");
        });

        T.Run("unsupported sizes, frame counts and layer counts are refused", () =>
        {
            Rejects("huge canvas", HandBuilt(ProjectJson(w: 100000, h: 100000)), "canvas");
            Rejects("canvas over the pixel limit", HandBuilt(ProjectJson(w: 8000, h: 8000)), "million");
            Rejects("zero width", HandBuilt(ProjectJson(w: 0, h: 10)), "canvas");
            Rejects("negative height", HandBuilt(ProjectJson(w: 10, h: -5)), "canvas");
            Rejects("no frames", HandBuilt(ProjectJson(frames: 0)), "frames");
            Rejects("millions of frames", HandBuilt(ProjectJson(frames: 50_000_000)), "frames");
            Rejects("no layers", HandBuilt(ProjectJson(layers: "[]")), "layers");
            Rejects("layers is null", HandBuilt(ProjectJson(layers: "null")), "layers");
            string many = "[" + string.Join(",", Enumerable.Range(0, 129).Select(i => $"{{\"id\":\"{i:D32}\",\"name\":\"L{i}\",\"cels\":[]}}")) + "]";
            Rejects("129 layers", HandBuilt(ProjectJson(layers: many)), "layers");
        });

        T.Run("image paths that try to escape the project are refused", () =>
        {
            byte[] png = RedSquarePng();
            foreach (string bad in new[]
            {
                "../evil.png", "cels/../evil.png", "cels/../../evil.png", "/etc/passwd", "C:\\Windows\\evil.png",
                "cels/..\\evil.png", "cels/sub/dir.png", "manifest.json", "project.json", "cels/", "cels/a b.png", "CELS/00001.png"
            })
            {
                Rejects($"image path \"{bad}\"", HandBuilt(ProjectJson(layers: LayerWithCel(bad)), GoodManifest, ("cels/00001.png", png)), "image path");
            }
        });

        T.Run("a drawing that is listed but missing is refused", () =>
        {
            Rejects("missing image", HandBuilt(ProjectJson(layers: LayerWithCel("cels/00007.png"))), "missing");
        });

        T.Run("damaged pictures inside the project are refused", () =>
        {
            byte[] png = RedSquarePng();
            string layers = LayerWithCel("cels/00001.png");

            Rejects("garbage instead of a PNG", HandBuilt(ProjectJson(layers: layers), GoodManifest, ("cels/00001.png", Utf8("not a png at all"))), "damaged");
            Rejects("empty picture", HandBuilt(ProjectJson(layers: layers), GoodManifest, ("cels/00001.png", Array.Empty<byte>())));
            Rejects("picture cut short", HandBuilt(ProjectJson(layers: layers), GoodManifest, ("cels/00001.png", png.Take(png.Length - 20).ToArray())));

            byte[] flipped = (byte[])png.Clone();
            flipped[flipped.Length / 2] ^= 0x55; // inside the compressed picture data
            Rejects("one wrong byte in the picture data", HandBuilt(ProjectJson(layers: layers), GoodManifest, ("cels/00001.png", flipped)), "damaged");
        });

        T.Run("a picture bigger than the canvas is refused", () =>
        {
            Rejects("20x20 picture on an 8x8 canvas",
                HandBuilt(ProjectJson(layers: LayerWithCel("cels/00001.png")), GoodManifest, ("cels/00001.png", RedSquarePng(20))), "canvas");
        });

        T.Run("a picture that claims to be gigantic is refused without allocating it", () =>
        {
            long before = GC.GetTotalMemory(forceFullCollection: true);
            Rejects("100000 x 100000 PNG header",
                HandBuilt(ProjectJson(layers: LayerWithCel("cels/00001.png")), GoodManifest, ("cels/00001.png", PngClaiming(100000, 100000))), "canvas");
            long grown = GC.GetTotalMemory(forceFullCollection: false) - before;
            T.True(grown < 50_000_000, $"memory grew by {grown / 1_000_000} MB while refusing the file");
        });

        T.Run("drawings positioned outside the canvas do not crash and are clipped", () =>
        {
            foreach (var (x, y) in new[] { (-50, -50), (1000, 1000), (6, 6), (int.MinValue, 0), (0, int.MaxValue) })
            {
                var loaded = Deserialize(HandBuilt(ProjectJson(layers: LayerWithCel("cels/00001.png", x, y)), GoodManifest, ("cels/00001.png", RedSquarePng())));
                T.True(loaded.Project.Layers[0].GetCelAt(0) != null, $"cel at {x},{y} exists");
            }
            var edge = Deserialize(HandBuilt(ProjectJson(layers: LayerWithCel("cels/00001.png", 6, 6)), GoodManifest, ("cels/00001.png", RedSquarePng())));
            T.PixelIs(Red, PixelOf(edge.Project.Layers[0], 0, 7, 7), "the part inside the canvas is kept");
        });

        T.Run("explicit nulls and odd values in the JSON never crash the loader", () =>
        {
            string[] variants =
            {
                $"[{{\"id\":null,\"name\":null,\"cels\":null,\"opacity\":5}}]",
                $"[{{\"id\":\"not-a-guid\",\"name\":\"   \",\"cels\":[null,{{\"frame\":-3}},{{\"frame\":999}}]}}]",
                $"[{{\"id\":\"{LayerId}\",\"name\":\"A\",\"cels\":[]}},{{\"id\":\"{LayerId}\",\"name\":\"B\",\"cels\":[]}}]", // duplicate ids
                $"[null,{{\"id\":\"{LayerId}\",\"name\":\"A\"}}]"
            };
            foreach (string layers in variants)
            {
                var loaded = Deserialize(HandBuilt(ProjectJson(layers: layers)));
                T.True(loaded.Project.Layers.Count >= 1, "at least one layer");
                T.Equal(loaded.Project.Layers.Count, loaded.Project.Layers.Select(l => l.Id).Distinct().Count(), "layer ids are unique");
                foreach (var l in loaded.Project.Layers) T.True(l.Opacity >= 0 && l.Opacity <= 1 && l.Name.Trim().Length > 0, "sane layer values");
            }
            string nullBackground = "{\"width\":8,\"height\":8,\"fps\":9999,\"frameCount\":2,\"background\":null,\"onion\":null,\"currentFrame\":77,\"activeLayerId\":\"zzz\","
                                    + $"\"layers\":[{{\"id\":\"{LayerId}\",\"name\":\"L\",\"cels\":[]}}]}}";
            var p = Deserialize(HandBuilt(nullBackground));
            T.True(p.Project.Fps <= ProjectLimits.MaxFps, "fps is clamped");
            T.Equal(1, p.CurrentFrame, "current frame is clamped into range");
            T.True(p.ActiveLayerId == null, "an unreadable active layer is ignored");
        });

        T.Run("flipping random bytes in a real project never causes anything but a clear refusal", () =>
        {
            byte[] good = Serialize(RichDoc(out _, out _, out _));
            var rng = new Random(20240601);
            int accepted = 0, refused = 0;
            for (int i = 0; i < 500; i++)
            {
                byte[] bad = (byte[])good.Clone();
                int flips = 1 + rng.Next(4);
                for (int f = 0; f < flips; f++) bad[rng.Next(bad.Length)] ^= (byte)(1 << rng.Next(8));
                if (i % 9 == 0) Array.Resize(ref bad, rng.Next(bad.Length));
                try
                {
                    using var ms = new MemoryStream(bad);
                    ProjectSerializer.Load(ms);
                    accepted++;
                }
                catch (ProjectFileException ex)
                {
                    if (string.IsNullOrWhiteSpace(ex.Message)) throw new Exception($"variant {i}: empty message");
                    refused++;
                }
                catch (Exception ex)
                {
                    throw new Exception($"variant {i}: unexpected {ex.GetType().Name}: {ex.Message}");
                }
            }
            Console.WriteLine($"        {accepted} damaged variants still loaded, {refused} were refused");
            T.True(refused > 50, "most corruptions are detected");
        });
    }

    // ------------------------------------------------------------------ PNG hardening

    private static void PngHardeningTests()
    {
        T.Suite("PNG reader limits");

        T.Run("a checksum mismatch is detected", () =>
        {
            byte[] png = RedSquarePng(8);
            T.Equal(Red, PngCodec.Decode(png).GetPixel(0, 0), "intact picture decodes");
            byte[] bad = (byte[])png.Clone();
            bad[^20] ^= 0x01;
            T.Throws<InvalidDataException>(() => PngCodec.Decode(bad));
        });

        T.Run("the size limit is enforced before any memory is reserved", () =>
        {
            byte[] big = PngClaiming(30000, 30000);
            T.Throws<InvalidDataException>(() => PngCodec.Decode(big, maxPixels: 1000));
            T.Throws<InvalidDataException>(() => PngCodec.Decode(PngClaiming(20000, 20000))); // over the 200M default
        });

        T.Run("a chunk that claims to be larger than the file is refused", () =>
        {
            byte[] bomb = PngSignature.Concat(PngChunk("IDAT", new byte[10], lengthOverride: 0x3FFFFFFF)).ToArray();
            T.Throws<InvalidDataException>(() => PngCodec.Decode(bomb));
        });

        T.Run("truncated data and a wrong signature are reported", () =>
        {
            byte[] png = RedSquarePng(8);
            T.Throws<InvalidDataException>(() => PngCodec.Decode(png.Take(30).ToArray()));
            T.Throws<InvalidDataException>(() => PngCodec.Decode(Utf8("GIF89a not a png")));
        });
    }

    // ------------------------------------------------------------------ saving to disk

    private static void DiskTests()
    {
        T.Suite("Saving and opening files");

        T.Run("the .animdraw extension is added only when missing", () =>
        {
            T.Equal("art.animdraw", ProjectFileManager.NormalizePath("art"));
            T.Equal("art.animdraw", ProjectFileManager.NormalizePath("  art  "));
            T.Equal("art.AnimDraw", ProjectFileManager.NormalizePath("art.AnimDraw"));
            T.Equal("art.png.animdraw", ProjectFileManager.NormalizePath("art.png"));
            T.Throws<ProjectFileException>(() => ProjectFileManager.NormalizePath("   "));
        });

        T.Run("save then open gives back the same project", () =>
        {
            using var tmp = new TempDir();
            var d = RichDoc(out _, out _, out _);
            string path = tmp.P("scene");
            ProjectFileManager.Save(d.CreateSnapshot(), path, d.CurrentFrame, d.ActiveLayer.Id);
            T.True(File.Exists(path + ".animdraw"), "file written with extension");
            var loaded = ProjectFileManager.Open(path + ".animdraw");
            AssertSameProject(d.Project, loaded.Project);
        });

        T.Run("saving over an existing file replaces it and leaves no temporary files", () =>
        {
            using var tmp = new TempDir();
            string path = tmp.P("scene.animdraw");
            var d = NewDoc(32, 32);
            Paint(d, new IntRect(1, 1, 5, 5), Red);
            ProjectFileManager.Save(d.CreateSnapshot(), path, 0, d.ActiveLayer.Id);
            Paint(d, new IntRect(10, 10, 5, 5), Green);
            ProjectFileManager.Save(d.CreateSnapshot(), path, 0, d.ActiveLayer.Id);
            var back = ProjectFileManager.Open(path);
            T.PixelIs(Green, PixelOf(back.Project.Layers[0], 0, 11, 11), "second save is what is on disk");
            T.Equal(1, Directory.GetFileSystemEntries(tmp.Root).Length, "only the project file remains: " + string.Join(", ", Directory.GetFileSystemEntries(tmp.Root)));
        });

        T.Run("a save that is cancelled halfway leaves the previous file untouched", () =>
        {
            using var tmp = new TempDir();
            string path = tmp.P("scene.animdraw");
            var d = RichDoc(out _, out _, out _);
            ProjectFileManager.Save(d.CreateSnapshot(), path, 0, d.ActiveLayer.Id);
            byte[] before = File.ReadAllBytes(path);

            Paint(d, new IntRect(70, 5, 5, 5), Red);
            using var cts = new CancellationTokenSource();
            cts.Cancel();
            T.Throws<OperationCanceledException>(() => ProjectFileManager.Save(d.CreateSnapshot(), path, 0, d.ActiveLayer.Id, ct: cts.Token));

            T.True(before.AsSpan().SequenceEqual(File.ReadAllBytes(path)), "the old file is byte-for-byte unchanged");
            T.Equal(1, Directory.GetFileSystemEntries(tmp.Root).Length, "no temporary file left behind");
            T.True(ProjectFileManager.Open(path).Project.Layers.Count == 3, "and it still opens");
        });

        T.Run("saving into a folder that does not exist explains the problem", () =>
        {
            using var tmp = new TempDir();
            var d = NewDoc(16, 16);
            try
            {
                ProjectFileManager.Save(d.CreateSnapshot(), tmp.P("nope/deeper/scene.animdraw"), 0, d.ActiveLayer.Id);
                throw new Exception("expected a ProjectFileException");
            }
            catch (ProjectFileException ex)
            {
                T.True(ex.Message.Contains("folder", StringComparison.OrdinalIgnoreCase), ex.Message);
            }
        });

        T.Run("an invalid file name is explained, not thrown as a raw exception", () =>
        {
            var d = NewDoc(16, 16);
            T.Throws<ProjectFileException>(() => ProjectFileManager.Save(d.CreateSnapshot(), "bad\0name", 0, d.ActiveLayer.Id));
        });

        T.Run("opening a file that is not there or not a project explains the problem", () =>
        {
            using var tmp = new TempDir();
            try { ProjectFileManager.Open(tmp.P("gone.animdraw")); throw new Exception("expected a ProjectFileException"); }
            catch (ProjectFileException ex) { T.True(ex.Message.Contains("could not be found"), ex.Message); }

            try { ProjectFileManager.Open(tmp.Root); throw new Exception("expected a ProjectFileException"); }
            catch (ProjectFileException) { }

            File.WriteAllText(tmp.P("fake.animdraw"), "this is just text");
            T.Throws<ProjectFileException>(() => ProjectFileManager.Open(tmp.P("fake.animdraw")));
        });

        T.Run("SaveAsync writes the file, reports progress and marks the document saved", () =>
        {
            using var tmp = new TempDir();
            var d = RichDoc(out _, out _, out _);
            T.True(d.IsDirty);
            double last = 0;
            var progress = new SyncProgress(v => last = Math.Max(last, v));
            ProjectFileManager.SaveAsync(d, tmp.P("a.animdraw"), progress: progress).GetAwaiter().GetResult();
            T.False(d.IsDirty, "clean after saving");
            T.True(last > 0.9, $"progress reached {last}");
            T.True(File.Exists(tmp.P("a.animdraw")));
        });

        T.Run("a failed SaveAsync leaves the document marked as unsaved", () =>
        {
            using var tmp = new TempDir();
            var d = RichDoc(out _, out _, out _);
            try
            {
                ProjectFileManager.SaveAsync(d, tmp.P("missing-folder/a.animdraw")).GetAwaiter().GetResult();
                throw new Exception("expected a ProjectFileException");
            }
            catch (ProjectFileException) { }
            T.True(d.IsDirty, "still dirty");
        });

        T.Run("OpenAsync restores the current frame and active layer and the document starts clean", () =>
        {
            using var tmp = new TempDir();
            var d = RichDoc(out _, out var ink, out _);
            ProjectFileManager.SaveAsync(d, tmp.P("a.animdraw")).GetAwaiter().GetResult();
            var reopened = ProjectFileManager.OpenAsync(tmp.P("a.animdraw")).GetAwaiter().GetResult();
            T.Equal(3, reopened.CurrentFrame);
            T.True(reopened.ActiveLayer.Id == ink.Id, "active layer");
            T.False(reopened.IsDirty, "freshly opened document is clean");
            T.False(reopened.History.CanUndo, "no history yet");
        });
    }

    /// <summary>Progress reporter that runs inline, so tests need no synchronisation context.</summary>
    private sealed class SyncProgress : IProgress<double>
    {
        private readonly Action<double> _onReport;
        public SyncProgress(Action<double> onReport) => _onReport = onReport;
        public void Report(double value) => _onReport(value);
    }

    // ------------------------------------------------------------------ unsaved-changes tracking

    private static void DirtyFlagTests()
    {
        T.Suite("Unsaved changes tracking");

        T.Run("a new document is clean, editing makes it dirty, undo back to the saved state makes it clean", () =>
        {
            var d = NewDoc();
            T.False(d.IsDirty, "new document");
            Paint(d, new IntRect(1, 1, 4, 4), Red);
            T.True(d.IsDirty, "after a stroke");
            d.MarkSaved();
            T.False(d.IsDirty, "after saving");
            Paint(d, new IntRect(10, 10, 4, 4), Green);
            T.True(d.IsDirty, "after another stroke");
            d.Undo();
            T.False(d.IsDirty, "undo returns to the saved state");
            d.Redo();
            T.True(d.IsDirty, "redo moves away from it again");
        });

        T.Run("layer, frame and setting changes count as unsaved changes", () =>
        {
            var d = NewDoc(32, 32, 2);
            d.MarkSaved();
            d.AddLayer(); T.True(d.IsDirty, "add layer"); d.MarkSaved();
            d.SetFps(24); T.True(d.IsDirty, "fps"); d.MarkSaved();
            d.InsertBlankFrameAfter(0); T.True(d.IsDirty, "frame"); d.MarkSaved();
            d.SetBackground(BackgroundSettings.White); T.True(d.IsDirty, "background"); d.MarkSaved();
            d.UpdateOnionSkin(o => o.NextFrames = 3); T.True(d.IsDirty, "onion skin options (not undoable, but saved with the project)");
            d.MarkSaved(); T.False(d.IsDirty);
        });

        T.Run("edits made while a save is still running stay unsaved", () =>
        {
            var d = NewDoc();
            Paint(d, new IntRect(1, 1, 4, 4), Red);
            var token = d.BeginSave();
            Paint(d, new IntRect(10, 10, 4, 4), Green);   // the user keeps drawing during the save
            d.CompleteSave(token);
            T.True(d.IsDirty, "the second stroke was not part of the saved file");
            d.MarkSaved();
            T.False(d.IsDirty);

            d.UpdateOnionSkin(o => o.Opacity = 0.5);
            token = d.BeginSave();
            d.UpdateOnionSkin(o => o.Opacity = 0.6);
            d.CompleteSave(token);
            T.True(d.IsDirty, "a setting changed during the save is still unsaved");
        });
    }

    // ------------------------------------------------------------------ crash recovery

    private static void RecoveryTests()
    {
        T.Suite("Crash recovery");

        static void CopyAs(RecoveryManager from, string folder, string newSession)
        {
            File.Copy(from.DataFilePath, Path.Combine(folder, newSession + ".animdraw"));
            File.Copy(Path.ChangeExtension(from.DataFilePath, ".json"), Path.Combine(folder, newSession + ".json"));
        }

        T.Run("an autosaved copy of an unsaved project can be recovered after a crash", () =>
        {
            using var tmp = new TempDir();
            string folder = tmp.P("recovery");
            var d = RichDoc(out _, out _, out _);

            using var running = new RecoveryManager(folder, "sessionA");
            T.True(running.Start(), "recovery folder is usable");
            T.True(running.NeedsAutosave(d), "unsaved work needs an autosave");
            T.True(running.AutosaveAsync(d, originalPath: null, projectName: "Untitled").GetAwaiter().GetResult(), "autosave written");
            T.False(running.NeedsAutosave(d), "nothing new to save");
            T.False(running.AutosaveAsync(d, null, "Untitled").GetAwaiter().GetResult(), "no pointless second write");

            // Another copy of the program starts: the running session's copy must not be offered as "crashed".
            var other = new RecoveryManager(folder, "sessionB");
            T.Equal(0, other.FindRecoverable().Count, "a live session is not offered for recovery");

            // The first program dies without cleaning up: its files remain but its lock is gone.
            CopyAs(running, folder, "crashed");
            var found = other.FindRecoverable();
            T.Equal(1, found.Count, "the dead session's copy is offered");
            T.Equal("crashed", found[0].SessionId);
            T.Equal("Untitled", found[0].ProjectName);

            var recovered = RecoveryManager.Open(found[0]);
            AssertSameProject(d.Project, recovered.Project);
            T.Equal(3, recovered.CurrentFrame);

            RecoveryManager.Discard(found[0]);
            T.Equal(0, other.FindRecoverable().Count, "discarded copies are gone");
        });

        T.Run("the autosave is a snapshot: drawing during the write does not leak into it", () =>
        {
            using var tmp = new TempDir();
            var d = NewDoc(64, 48);
            Paint(d, new IntRect(0, 0, 10, 10), Red);
            using var rm = new RecoveryManager(tmp.P("rec"), "s1");
            rm.Start();
            var running = rm.AutosaveAsync(d, "C:\\art\\scene.animdraw", "scene");
            Paint(d, new IntRect(20, 20, 10, 10), Green); // keep drawing immediately
            T.True(running.GetAwaiter().GetResult());

            var saved = ProjectFileManager.Open(rm.DataFilePath);
            T.PixelIs(Red, PixelOf(saved.Project.Layers[0], 0, 5, 5), "earlier stroke is in the copy");
            T.PixelIs(0u, PixelOf(saved.Project.Layers[0], 0, 25, 25), "later stroke is not");
            T.True(rm.NeedsAutosave(d), "but the document has moved on, so another autosave is due");
        });

        T.Run("a clean document is never autosaved", () =>
        {
            using var tmp = new TempDir();
            var d = NewDoc();
            Paint(d, new IntRect(0, 0, 4, 4), Red);
            d.MarkSaved();
            using var rm = new RecoveryManager(tmp.P("rec"), "s1");
            rm.Start();
            T.False(rm.NeedsAutosave(d));
            T.False(rm.AutosaveAsync(d, null, "x").GetAwaiter().GetResult());
            T.False(File.Exists(rm.DataFilePath));
        });

        T.Run("closing normally removes the session's recovery copy", () =>
        {
            using var tmp = new TempDir();
            string folder = tmp.P("rec");
            var d = NewDoc();
            Paint(d, new IntRect(0, 0, 4, 4), Red);
            var rm = new RecoveryManager(folder, "s1");
            rm.Start();
            rm.AutosaveAsync(d, null, "x").GetAwaiter().GetResult();
            T.True(File.Exists(rm.DataFilePath));
            rm.Dispose();
            T.Equal(0, Directory.GetFiles(folder).Length, "nothing left: " + string.Join(", ", Directory.GetFiles(folder)));
            T.Equal(0, new RecoveryManager(folder, "s2").FindRecoverable().Count);
        });

        T.Run("saving the project clears its recovery copy, and later edits write a new one", () =>
        {
            using var tmp = new TempDir();
            var d = NewDoc();
            Paint(d, new IntRect(0, 0, 4, 4), Red);
            using var rm = new RecoveryManager(tmp.P("rec"), "s1");
            rm.Start();
            rm.AutosaveAsync(d, null, "x").GetAwaiter().GetResult();
            d.MarkSaved();
            rm.ClearCurrent();
            T.False(File.Exists(rm.DataFilePath), "copy removed after a save");
            Paint(d, new IntRect(8, 8, 4, 4), Green);
            T.True(rm.NeedsAutosave(d), "edits after the save need a new copy");
            T.True(rm.AutosaveAsync(d, null, "x").GetAwaiter().GetResult());
            T.True(File.Exists(rm.DataFilePath));
        });

        T.Run("a session whose lock file is still held is not treated as crashed", () =>
        {
            using var tmp = new TempDir();
            string folder = tmp.P("rec");
            Directory.CreateDirectory(folder);
            var d = NewDoc();
            Paint(d, new IntRect(0, 0, 4, 4), Red);
            File.WriteAllBytes(Path.Combine(folder, "live.animdraw"), Serialize(d));
            File.WriteAllText(Path.Combine(folder, "live.json"), "{\"projectName\":\"Live\",\"savedUtc\":\"" + DateTime.UtcNow.ToString("O") + "\"}");

            var finder = new RecoveryManager(folder, "finder");
            using (new FileStream(Path.Combine(folder, "live.lock"), FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                T.Equal(0, finder.FindRecoverable().Count, "lock held: still running");
            var after = finder.FindRecoverable();
            T.Equal(1, after.Count, "lock released (leftover lock file): crashed");
            T.Equal("Live", after[0].ProjectName);
        });

        T.Run("damaged metadata still offers the data; metadata without data is ignored", () =>
        {
            using var tmp = new TempDir();
            string folder = tmp.P("rec");
            Directory.CreateDirectory(folder);
            var d = NewDoc();
            Paint(d, new IntRect(0, 0, 4, 4), Red);
            File.WriteAllBytes(Path.Combine(folder, "x.animdraw"), Serialize(d));
            File.WriteAllText(Path.Combine(folder, "x.json"), "}{ definitely not json");
            File.WriteAllText(Path.Combine(folder, "orphan.json"), "{\"projectName\":\"Orphan\"}");

            var found = new RecoveryManager(folder, "me").FindRecoverable();
            T.Equal(1, found.Count);
            T.Equal("x", found[0].SessionId);
            T.True(RecoveryManager.Open(found[0]).Project.Layers.Count == 1);
        });

        T.Run("old recovery copies are purged and recent ones are kept", () =>
        {
            using var tmp = new TempDir();
            string folder = tmp.P("rec");
            Directory.CreateDirectory(folder);
            var d = NewDoc();
            Paint(d, new IntRect(0, 0, 4, 4), Red);
            byte[] data = Serialize(d);
            foreach (var (name, when) in new[] { ("old", DateTime.UtcNow.AddDays(-40)), ("recent", DateTime.UtcNow.AddHours(-2)) })
            {
                File.WriteAllBytes(Path.Combine(folder, name + ".animdraw"), data);
                File.WriteAllText(Path.Combine(folder, name + ".json"), $"{{\"projectName\":\"{name}\",\"savedUtc\":\"{when:O}\"}}");
            }
            var rm = new RecoveryManager(folder, "me");
            T.Equal(2, rm.FindRecoverable().Count);
            rm.PurgeOld(TimeSpan.FromDays(14));
            var left = rm.FindRecoverable();
            T.Equal(1, left.Count);
            T.Equal("recent", left[0].SessionId);
            T.Equal("recent", left[0].ProjectName);
        });

        T.Run("an unusable recovery folder is reported, not thrown", () =>
        {
            using var tmp = new TempDir();
            File.WriteAllText(tmp.P("a-file"), "x");
            using var rm = new RecoveryManager(Path.Combine(tmp.P("a-file"), "sub"), "s1"); // a folder cannot be created inside a file
            T.False(rm.Start());
            var d = NewDoc();
            Paint(d, new IntRect(0, 0, 4, 4), Red);
            T.False(rm.AutosaveAsync(d, null, "x").GetAwaiter().GetResult(), "autosave quietly does nothing");
            T.Equal(0, rm.FindRecoverable().Count);
        });
    }

    // ------------------------------------------------------------------ settings

    private static void SettingsTests()
    {
        T.Suite("Settings and recent projects");

        T.Run("defaults are used when there is no settings file, and values survive a save and load", () =>
        {
            using var tmp = new TempDir();
            var m = new SettingsManager(tmp.P("cfg"));
            var s = m.Load();
            T.Equal(AppTheme.Dark, s.Theme);
            T.Equal(1280, s.NewProjectWidth);
            T.True(m.LoadProblem == null, "a missing file is not a problem");

            s.Theme = AppTheme.Light;
            s.FfmpegPath = "C:\\tools\\ffmpeg.exe";
            s.NewProjectFps = 24;
            s.AutosaveMinutes = 5;
            s.Window.Maximized = true;
            s.PrimaryColor = "#FF8800";
            T.True(m.Save(out string? error), error ?? "");

            var again = new SettingsManager(tmp.P("cfg")).Load();
            T.Equal(AppTheme.Light, again.Theme);
            T.Equal("C:\\tools\\ffmpeg.exe", again.FfmpegPath);
            T.Near(24, again.NewProjectFps, 1e-9);
            T.Equal(5, again.AutosaveMinutes);
            T.True(again.Window.Maximized, "window state");
            T.Equal("#FF8800", again.PrimaryColor);
        });

        T.Run("a damaged settings file falls back to defaults, keeps a copy and can be overwritten", () =>
        {
            using var tmp = new TempDir();
            Directory.CreateDirectory(tmp.P("cfg"));
            File.WriteAllText(tmp.P("cfg/settings.json"), "{ this is : not json ");
            var m = new SettingsManager(tmp.P("cfg"));
            var s = m.Load();
            T.Equal(AppTheme.Dark, s.Theme);
            T.True(m.LoadProblem != null, "the problem is reported");
            T.True(File.Exists(tmp.P("cfg/settings.json.broken")), "the damaged file is kept for inspection");
            T.True(m.Save(out _));
            T.True(m.LoadProblem == null || new SettingsManager(tmp.P("cfg")).Load() != null);
            T.True(new SettingsManager(tmp.P("cfg")).Load().NewProjectWidth == 1280);
        });

        T.Run("hand-edited files: comments, trailing commas, unknown keys, text numbers and out-of-range values", () =>
        {
            using var tmp = new TempDir();
            Directory.CreateDirectory(tmp.P("cfg"));
            File.WriteAllText(tmp.P("cfg/settings.json"), """
                {
                  // my settings
                  "theme": "Light",
                  "someOptionFromTheFuture": { "x": [1, 2, 3] },
                  "newProjectWidth": 999999,
                  "newProjectHeight": -4,
                  "newProjectFps": "30",
                  "brushSize": "NaN",
                  "brushOpacity": 7,
                  "autosaveMinutes": -9,
                  "rightPanelWidth": 5,
                  "recentProjects": ["a.animdraw", "A.ANIMDRAW", "", "  ", "b.animdraw"],
                }
                """);
            var m = new SettingsManager(tmp.P("cfg"));
            var s = m.Load();
            T.True(m.LoadProblem == null, m.LoadProblem ?? "");
            T.Equal(AppTheme.Light, s.Theme);
            T.Equal(ProjectLimits.MaxDimension, s.NewProjectWidth, "width clamped");
            T.Equal(1, s.NewProjectHeight, "height clamped");
            T.Near(30, s.NewProjectFps, 1e-9, "number written as text");
            T.Near(12, s.BrushSize, 1e-9, "NaN replaced");
            T.Near(1, s.BrushOpacity, 1e-9, "opacity clamped");
            T.Equal(0, s.AutosaveMinutes, "negative interval means off");
            T.Near(200, s.RightPanelWidth, 1e-9, "panel width clamped");
            T.Equal(2, s.RecentProjects.Count, "blank and duplicate (case-insensitive) recents removed");
        });

        T.Run("recent projects: newest first, no duplicates, capped, missing files filtered", () =>
        {
            using var tmp = new TempDir();
            var m = new SettingsManager(tmp.P("cfg"));
            m.Load();
            int changes = 0;
            m.Changed += () => changes++;

            var files = Enumerable.Range(0, 20).Select(i => tmp.P($"p{i}.animdraw")).ToList();
            foreach (var f in files) File.WriteAllText(f, "x");
            foreach (var f in files) m.AddRecent(f);
            T.Equal(AppSettings.MaxRecentProjects, m.Settings.RecentProjects.Count, "capped");
            T.Equal(Path.GetFullPath(files[19]), m.Settings.RecentProjects[0], "newest first");

            m.AddRecent(files[15].ToUpperInvariant() == files[15] ? files[15] : files[15]);
            T.Equal(Path.GetFullPath(files[15]), m.Settings.RecentProjects[0], "reopening moves it to the top");
            T.Equal(AppSettings.MaxRecentProjects, m.Settings.RecentProjects.Count, "still no duplicates");
            T.Equal(m.Settings.RecentProjects.Count, m.Settings.RecentProjects.Distinct(StringComparer.OrdinalIgnoreCase).Count());
            T.Equal(Path.GetDirectoryName(Path.GetFullPath(files[15])), m.Settings.LastProjectFolder, "remembers the folder");

            File.Delete(files[19]);
            T.False(m.GetRecentExisting().Contains(Path.GetFullPath(files[19])), "deleted file is not offered");
            T.True(m.GetRecentExisting().Count == AppSettings.MaxRecentProjects - 1);

            m.RemoveRecent(Path.GetFullPath(files[15]));
            T.False(m.Settings.RecentProjects.Contains(Path.GetFullPath(files[15])));
            m.ClearRecent();
            T.Equal(0, m.Settings.RecentProjects.Count);
            T.True(changes >= 23, $"listeners were told ({changes})");
            m.AddRecent("   ");
            T.Equal(0, m.Settings.RecentProjects.Count, "blank path ignored");
        });

        T.Run("recent colours: newest first, no duplicates, capped", () =>
        {
            using var tmp = new TempDir();
            var m = new SettingsManager(tmp.P("cfg"));
            m.Load();
            for (int i = 0; i < 30; i++) m.AddRecentColor($"#{i:X2}0000");
            m.AddRecentColor("#050000");
            T.Equal(AppSettings.MaxRecentColors, m.Settings.RecentColors.Count);
            T.Equal("#050000", m.Settings.RecentColors[0]);
            T.Equal(m.Settings.RecentColors.Count, m.Settings.RecentColors.Distinct(StringComparer.OrdinalIgnoreCase).Count());
        });

        T.Run("saving settings is atomic and failure is reported, not thrown", () =>
        {
            using var tmp = new TempDir();
            var m = new SettingsManager(tmp.P("cfg"));
            m.Load();
            T.True(m.Save(out _));
            T.True(m.Save(out _));
            T.Equal(1, Directory.GetFiles(tmp.P("cfg")).Length, "no temporary files: " + string.Join(", ", Directory.GetFiles(tmp.P("cfg"))));

            File.WriteAllText(tmp.P("blocker"), "x");
            var bad = new SettingsManager(Path.Combine(tmp.P("blocker"), "inside"));
            bad.Load();
            T.False(bad.Save(out string? error), "cannot create a folder inside a file");
            T.True(!string.IsNullOrWhiteSpace(error), "and says why");
        });
    }
}
