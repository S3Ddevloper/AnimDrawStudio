using System.Diagnostics;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.IO;
using AnimDraw.Core.Model;
using AnimDraw.Core.Rendering;
using AnimDraw.Core.Tools;
using static AnimDraw.Core.Tests.Helpers;

namespace AnimDraw.Core.Tests;

public static class DrawingTests
{
    /// <summary>Where sample images are written for visual inspection.</summary>
    public static string OutDir = Path.Combine(Path.GetTempPath(), "animdraw-test-output");

    private sealed class Rig
    {
        public Document Doc;
        public ToolManager Tools;
        public ToolSettings Settings;
        public List<string> Messages = new();
        public ArgbColor? Picked;

        public Rig(int w = 120, int h = 90, int frames = 1)
        {
            Doc = NewDoc(w, h, frames);
            Settings = new ToolSettings();
            var ctx = new ToolContext(Doc, Settings) { Notify = Messages.Add };
            ctx.ColorPicked = (c, _) => Picked = c;
            Tools = new ToolManager(ctx);
            Settings.PrimaryColor = ArgbColor.FromRgb(255, 0, 0);
        }

        public uint At(int x, int y) => PixelOf(Doc.ActiveLayer, Doc.CurrentFrame, x, y);

        public void Drag(ToolKind tool, params (float X, float Y)[] pts) => DragWith(tool, 1f, false, false, false, pts);

        public void DragWith(ToolKind tool, float pressure, bool shift, bool alt, bool secondary, params (float X, float Y)[] pts)
        {
            Tools.Select(tool);
            Tools.PointerDown(new PointerInput(pts[0].X, pts[0].Y, pressure, shift, false, alt, secondary));
            for (int i = 1; i < pts.Length; i++)
                Tools.PointerMove(new PointerInput(pts[i].X, pts[i].Y, pressure, shift, false, alt, secondary));
            var last = pts[^1];
            Tools.PointerUp(new PointerInput(last.X, last.Y, pressure, shift, false, alt, secondary));
        }

        public int CountOpaque(IntRect r)
        {
            int n = 0;
            for (int y = r.Y; y < r.Bottom; y++)
            for (int x = r.X; x < r.Right; x++)
                if (Px.A(At(x, y)) == 255) n++;
            return n;
        }

        public void Dump(string name)
        {
            Directory.CreateDirectory(OutDir);
            var buf = Compositor.ComposeFrame(Doc.Project, Doc.CurrentFrame, withBackground: true);
            File.WriteAllBytes(Path.Combine(OutDir, name + ".png"), PngCodec.Encode(buf));
        }
    }

    public static void RunAll()
    {
        T.Suite("Brush, pencil, eraser");
        T.Run("brush paints a smooth stroke with anti-aliased edges", () =>
        {
            var r = new Rig();
            r.Settings.Brush.Size = 10;
            r.Settings.Brush.Smoothing = 0;
            r.Drag(ToolKind.Brush, (10, 45), (60, 45), (110, 45));
            T.PixelIs(Red, r.At(60, 45), "centre of the stroke is solid");
            uint edge = r.At(60, 40);
            T.True(Px.A(edge) > 0 && Px.A(edge) < 255, "edge pixel is partially transparent");
            T.PixelIs(0, r.At(60, 30), "far from the stroke is empty");
            T.True(Px.A(r.At(12, 45)) > 200, "stroke starts where the pointer went down");
            T.True(Px.A(r.At(108, 45)) > 200, "and reaches where it was released");
            T.Equal(1, r.Doc.History.UndoCount);
        });
        T.Run("one click makes a round dot", () =>
        {
            var r = new Rig();
            r.Settings.Brush.Size = 20;
            r.Drag(ToolKind.Brush, (60, 45));
            T.PixelIs(Red, r.At(60, 45));
            T.PixelIs(0, r.At(60, 45 + 14));
            T.True(Px.A(r.At(60 + 8, 45)) > 200);
        });
        T.Run("stroke opacity does not build up where the stroke overlaps itself", () =>
        {
            var r = new Rig();
            r.Settings.Brush.Size = 14;
            r.Settings.Brush.Opacity = 0.5;
            r.Settings.Brush.Smoothing = 0;
            r.Drag(ToolKind.Brush, (20, 45), (80, 45), (80, 60), (20, 60), (20, 45), (80, 45));
            int a = Px.A(r.At(50, 45));
            T.True(Math.Abs(a - 128) <= 2, $"alpha should stay near 128 but is {a}");
            int a2 = Px.A(r.At(80, 45));
            T.True(Math.Abs(a2 - 128) <= 2, $"alpha at an overlap should stay near 128 but is {a2}");
        });
        T.Run("pen pressure changes brush size", () =>
        {
            var light = new Rig();
            light.Settings.Brush.Size = 30;
            light.DragWith(ToolKind.Brush, 0.2f, false, false, false, (20, 45), (100, 45));
            var firm = new Rig();
            firm.Settings.Brush.Size = 30;
            firm.DragWith(ToolKind.Brush, 1.0f, false, false, false, (20, 45), (100, 45));
            int thin = 0, thick = 0;
            for (int y = 0; y < 90; y++) { if (Px.A(light.At(60, y)) > 128) thin++; if (Px.A(firm.At(60, y)) > 128) thick++; }
            T.True(thick > thin * 2, $"firm pressure ({thick}px) should be much thicker than light ({thin}px)");
        });
        T.Run("pen pressure can change opacity", () =>
        {
            var r = new Rig();
            r.Settings.Brush.Size = 20;
            r.Settings.Brush.PressureAffectsSize = false;
            r.Settings.Brush.PressureAffectsOpacity = true;
            r.DragWith(ToolKind.Brush, 0.3f, false, false, false, (20, 45), (100, 45));
            int a = Px.A(r.At(60, 45));
            T.True(a > 40 && a < 160, $"light pressure should be translucent, alpha {a}");
        });
        T.Run("pencil draws hard pixels with no anti-aliasing", () =>
        {
            var r = new Rig();
            r.Settings.Pencil.Size = 1;
            r.Drag(ToolKind.Pencil, (10.4f, 10.4f), (50.6f, 30.2f));
            bool soft = false; int solid = 0;
            for (int y = 0; y < 90; y++)
            for (int x = 0; x < 120; x++)
            {
                int a = Px.A(r.At(x, y));
                if (a == 255) solid++; else if (a != 0) soft = true;
            }
            T.False(soft, "no partially transparent pixels");
            T.True(solid >= 40 && solid <= 60, $"about one pixel per column, got {solid}");
        });
        T.Run("pencil lines are connected", () =>
        {
            var r = new Rig();
            r.Settings.Pencil.Size = 1;
            r.Drag(ToolKind.Pencil, (5, 5), (100, 70));
            for (int x = 5; x < 100; x++)
            {
                bool any = false;
                for (int y = 0; y < 90; y++) if (Px.A(r.At(x, y)) == 255) any = true;
                T.True(any, $"column {x} has no pixel");
            }
        });
        T.Run("eraser removes paint, and erasing nothing leaves no trace", () =>
        {
            var r = new Rig();
            Paint(r.Doc, new IntRect(10, 10, 60, 40), Red);
            r.Settings.Eraser.Size = 20;
            r.Drag(ToolKind.Eraser, (20, 30), (60, 30));
            T.PixelIs(0, r.At(40, 30));
            T.PixelIs(Red, r.At(40, 12 + 0 * 1), tolerance: 0);
            int undo = r.Doc.History.UndoCount;
            r.Drag(ToolKind.Eraser, (100, 80), (110, 80));
            T.Equal(undo, r.Doc.History.UndoCount);
            r.Doc.Undo();
            T.PixelIs(Red, r.At(40, 30));
        });
        T.Run("the flipped pen end erases", () =>
        {
            var r = new Rig();
            Paint(r.Doc, new IntRect(10, 10, 60, 40), Red);
            r.Tools.Select(ToolKind.Brush);
            r.Settings.Eraser.Size = 10;
            r.Tools.PointerDown(new PointerInput(30, 30, 1f, Inverted: true));
            r.Tools.PointerUp(new PointerInput(30, 30, 1f, Inverted: true));
            T.PixelIs(0, r.At(30, 30));
        });
        T.Run("drawing on a locked layer is refused with a message", () =>
        {
            var r = new Rig();
            r.Doc.SetLayerLocked(r.Doc.ActiveLayer, true);
            r.Drag(ToolKind.Brush, (10, 10), (30, 30));
            T.PixelIs(0, r.At(20, 20));
            T.True(r.Messages.Count > 0 && r.Messages[0].Contains("locked"));
        });
        T.Run("painting is limited to the selection", () =>
        {
            var r = new Rig();
            r.Settings.Brush.Size = 20;
            r.Doc.SelectRect(new IntRect(40, 0, 20, 90));
            r.Drag(ToolKind.Brush, (10, 45), (110, 45));
            T.PixelIs(0, r.At(20, 45));
            T.PixelIs(Red, r.At(50, 45));
            T.PixelIs(0, r.At(80, 45));
        });
        T.Run("right button paints with the secondary colour", () =>
        {
            var r = new Rig();
            r.Settings.SecondaryColor = ArgbColor.FromRgb(0, 0, 255);
            r.Settings.Brush.Size = 12;
            r.DragWith(ToolKind.Brush, 1f, false, false, true, (20, 45), (60, 45));
            T.PixelIs(Blue, r.At(40, 45));
        });
        T.Run("shift-click draws a straight line from the last stroke end", () =>
        {
            var r = new Rig();
            r.Settings.Brush.Size = 6;
            r.Settings.Brush.Smoothing = 0;
            r.Drag(ToolKind.Brush, (10, 10));
            r.Tools.PointerDown(new PointerInput(100, 10, 1f, Shift: true));
            r.Tools.PointerUp(new PointerInput(100, 10, 1f, Shift: true));
            T.PixelIs(Red, r.At(55, 10));
        });

        T.Suite("Shapes");
        T.Run("line tool draws a crisp 1px horizontal line", () =>
        {
            var r = new Rig();
            r.Settings.ShapeLineWidth = 1;
            r.Drag(ToolKind.Line, (10.3f, 20.7f), (80.9f, 20.2f));
            T.PixelIs(Red, r.At(40, 20));
            T.PixelIs(0, r.At(40, 19));
            T.PixelIs(0, r.At(40, 21));
        });
        T.Run("shift snaps lines to 45 degrees", () =>
        {
            var r = new Rig();
            r.Settings.ShapeLineWidth = 1;
            r.DragWith(ToolKind.Line, 1f, true, false, false, (10, 10), (70, 52));
            T.PixelIs(Red, r.At(40, 40), tolerance: 20);
        });
        T.Run("rectangle outline leaves the inside empty", () =>
        {
            var r = new Rig();
            r.Settings.ShapeLineWidth = 3;
            r.Settings.ShapeStyle = ShapeStyle.Outline;
            r.Drag(ToolKind.Rectangle, (20, 20), (80, 60));
            T.PixelIs(Red, r.At(50, 20));
            T.PixelIs(Red, r.At(20, 40));
            T.PixelIs(0, r.At(50, 40), "inside");
            T.PixelIs(0, r.At(10, 10), "outside");
        });
        T.Run("filled rectangle fills exactly the dragged box", () =>
        {
            var r = new Rig();
            r.Settings.ShapeStyle = ShapeStyle.Filled;
            r.Drag(ToolKind.Rectangle, (20, 20), (80, 60));
            T.PixelIs(Red, r.At(20, 20));
            T.PixelIs(Red, r.At(79, 59));
            T.PixelIs(0, r.At(80, 60));
            T.PixelIs(0, r.At(19, 30));
            T.Equal(60 * 40, r.CountOpaque(new IntRect(0, 0, 120, 90)));
        });
        T.Run("outline and fill use the two colours", () =>
        {
            var r = new Rig();
            r.Settings.SecondaryColor = ArgbColor.FromRgb(0, 255, 0);
            r.Settings.ShapeStyle = ShapeStyle.OutlineAndFill;
            r.Settings.ShapeLineWidth = 5;
            r.Drag(ToolKind.Rectangle, (20, 20), (80, 60));
            T.PixelIs(Green, r.At(50, 40), "fill is the secondary colour");
            T.PixelIs(Red, r.At(50, 21), "outline is the primary colour");
        });
        T.Run("shift makes a square, alt grows from the centre", () =>
        {
            var r = new Rig();
            r.Settings.ShapeStyle = ShapeStyle.Filled;
            r.DragWith(ToolKind.Rectangle, 1f, true, false, false, (20, 20), (60, 35));
            T.PixelIs(Red, r.At(25, 55), "square: height follows the longer side");
            var c = new Rig();
            c.Settings.ShapeStyle = ShapeStyle.Filled;
            c.DragWith(ToolKind.Rectangle, 1f, false, true, false, (60, 45), (80, 55));
            T.PixelIs(Red, c.At(41, 36), "centre mode extends to the opposite corner");
        });
        T.Run("ellipse: filled covers the middle but not the corners", () =>
        {
            var r = new Rig();
            r.Settings.ShapeStyle = ShapeStyle.Filled;
            r.Drag(ToolKind.Ellipse, (20, 20), (100, 70));
            T.PixelIs(Red, r.At(60, 45));
            T.PixelIs(0, r.At(21, 21));
            T.PixelIs(0, r.At(98, 22));
            T.True(Px.A(r.At(60, 20)) > 100, "top of the ellipse is reached");
        });
        T.Run("ellipse outline is a ring", () =>
        {
            var r = new Rig();
            r.Settings.ShapeStyle = ShapeStyle.Outline;
            r.Settings.ShapeLineWidth = 3;
            r.Drag(ToolKind.Ellipse, (20, 20), (100, 70));
            T.PixelIs(0, r.At(60, 45), "centre empty");
            T.True(Px.A(r.At(60, 20)) > 200 || Px.A(r.At(60, 21)) > 200, "top of the ring");
            T.True(Px.A(r.At(20, 45)) > 200 || Px.A(r.At(21, 45)) > 200, "left of the ring");
        });
        T.Run("a shape is one undo step and a bare click draws nothing", () =>
        {
            var r = new Rig();
            r.Drag(ToolKind.Rectangle, (20, 20), (80, 60));
            T.Equal(1, r.Doc.History.UndoCount);
            r.Drag(ToolKind.Rectangle, (30, 30));
            T.Equal(1, r.Doc.History.UndoCount);
            r.Doc.Undo();
            T.Equal(0, r.CountOpaque(new IntRect(0, 0, 120, 90)));
        });
        T.Run("escape-style cancel restores the drawing", () =>
        {
            var r = new Rig();
            Paint(r.Doc, new IntRect(0, 0, 10, 10), Blue);
            r.Tools.Select(ToolKind.Rectangle);
            r.Tools.PointerDown(new PointerInput(20, 20));
            r.Tools.PointerMove(new PointerInput(70, 60));
            T.True(r.CountOpaque(new IntRect(0, 0, 120, 90)) > 100, "preview is visible while dragging");
            r.Tools.Cancel();
            T.Equal(100, r.CountOpaque(new IntRect(0, 0, 120, 90)), "only the earlier blue square remains");
        });

        T.Suite("Fill, eyedropper, selection");
        T.Run("fill floods a closed shape and nothing outside", () =>
        {
            var r = new Rig();
            r.Settings.ShapeStyle = ShapeStyle.Outline;
            r.Settings.ShapeLineWidth = 2;
            r.Settings.PrimaryColor = ArgbColor.Black;
            r.Drag(ToolKind.Rectangle, (20, 20), (80, 60));
            r.Settings.PrimaryColor = ArgbColor.FromRgb(0, 0, 255);
            r.Drag(ToolKind.Fill, (50, 40));
            T.PixelIs(Blue, r.At(50, 40));
            T.PixelIs(Blue, r.At(25, 25));
            T.PixelIs(0, r.At(10, 10), "outside stays empty");
            T.PixelIs(0, r.At(90, 40));
            r.Doc.Undo();
            T.PixelIs(0, r.At(50, 40));
        });
        T.Run("fill on an empty layer fills the whole canvas", () =>
        {
            var r = new Rig();
            r.Drag(ToolKind.Fill, (5, 5));
            T.Equal(120 * 90, r.CountOpaque(new IntRect(0, 0, 120, 90)));
        });
        T.Run("fill leaves no light fringe next to anti-aliased lines", () =>
        {
            var r = new Rig();
            r.Settings.Brush.Size = 5;
            r.Settings.Brush.Smoothing = 0;
            r.Settings.PrimaryColor = ArgbColor.Black;
            r.Drag(ToolKind.Brush, (20, 20), (80, 20), (80, 60), (20, 60), (20, 20));
            r.Settings.PrimaryColor = ArgbColor.FromRgb(0, 255, 0);
            r.Settings.Fill.Tolerance = 0;
            r.Settings.Fill.Grow = 2;
            r.Drag(ToolKind.Fill, (50, 40));
            // The line is centred on x=20 and 5px wide, so x=17..22 is line. Its soft inner edge must have
            // green under it (alpha 255), and some pixel there must really be a black/green mix.
            bool mixed = false;
            for (int x = 20; x <= 26; x++)
            {
                uint p = r.At(x, 40);
                T.Equal(255, Px.A(p), $"inner edge pixel x={x} must be opaque (green under the line)");
                if (Px.G(p) > 20 && Px.G(p) < 235) mixed = true;
            }
            T.True(mixed, "an anti-aliased edge pixel blends black over green");
            T.True(Px.A(r.At(17, 40)) < 255, "the outside edge of the line is not filled");
            T.PixelIs(0, r.At(10, 40), "nothing outside");
        });
        T.Run("fill respects the selection and tolerance", () =>
        {
            var r = new Rig();
            r.Doc.SelectRect(new IntRect(10, 10, 30, 30));
            r.Drag(ToolKind.Fill, (20, 20));
            T.PixelIs(Red, r.At(15, 15));
            T.PixelIs(0, r.At(60, 60));
            T.Equal(30 * 30, r.CountOpaque(new IntRect(0, 0, 120, 90)));
        });
        T.Run("fill can look at all layers", () =>
        {
            var r = new Rig();
            var lines = r.Doc.ActiveLayer;
            r.Settings.ShapeStyle = ShapeStyle.Outline;
            r.Settings.ShapeLineWidth = 2;
            r.Settings.PrimaryColor = ArgbColor.Black;
            r.Drag(ToolKind.Rectangle, (20, 20), (80, 60));
            r.Doc.AddLayer();
            r.Settings.PrimaryColor = ArgbColor.FromRgb(255, 0, 0);
            r.Settings.Fill.SampleAllLayers = true;
            r.Drag(ToolKind.Fill, (50, 40));
            T.PixelIs(Red, r.At(50, 40), "painted on the new layer");
            T.PixelIs(0, r.At(10, 10), "bounded by the other layer's lines");
            T.PixelIs(0, PixelOf(lines, 0, 50, 40), "other layer untouched");
        });
        T.Run("eyedropper picks the flattened colour", () =>
        {
            var r = new Rig();
            Paint(r.Doc, new IntRect(10, 10, 20, 20), Blue);
            r.Drag(ToolKind.Eyedropper, (15, 15));
            T.True(r.Picked != null && r.Picked.Value.B == 255 && r.Picked.Value.R == 0);
            r.Picked = null;
            r.Drag(ToolKind.Eyedropper, (100, 80));
            T.True(r.Picked == null, "nothing to pick on transparent canvas");
        });
        T.Run("select tool makes and clears a rectangle", () =>
        {
            var r = new Rig();
            r.Drag(ToolKind.Select, (10, 10), (50, 40));
            T.Equal(new IntRect(10, 10, 40, 30), r.Doc.Selection);
            r.Drag(ToolKind.Select, (70, 70));
            T.True(r.Doc.Selection == null, "a plain click deselects");
        });
        T.Run("move tool drags the selected artwork as one undo step", () =>
        {
            var r = new Rig();
            Paint(r.Doc, new IntRect(10, 10, 20, 20), Red);
            r.Doc.SelectRect(new IntRect(5, 5, 30, 30));
            int steps = r.Doc.History.UndoCount;
            r.Drag(ToolKind.Move, (20, 20), (30, 25), (50, 40));
            T.PixelIs(0, r.At(12, 12), "old place is empty");
            T.PixelIs(Red, r.At(45, 35), "new place is painted");
            T.Equal(new IntRect(35, 25, 30, 30), r.Doc.Selection);
            T.Equal(steps + 1, r.Doc.History.UndoCount);
            r.Doc.Undo();
            T.PixelIs(Red, r.At(12, 12));
            T.PixelIs(0, r.At(45, 35));
        });
        T.Run("alt-drag copies instead of moving", () =>
        {
            var r = new Rig();
            Paint(r.Doc, new IntRect(10, 10, 20, 20), Red);
            r.Doc.SelectRect(new IntRect(10, 10, 20, 20));
            r.DragWith(ToolKind.Move, 1f, false, true, false, (20, 20), (70, 60));
            T.PixelIs(Red, r.At(15, 15), "original stays");
            T.PixelIs(Red, r.At(65, 55), "copy appears");
        });
        T.Run("move with no selection moves the whole drawing; shift locks the axis", () =>
        {
            var r = new Rig();
            Paint(r.Doc, new IntRect(10, 10, 10, 10), Red);
            r.DragWith(ToolKind.Move, 1f, true, false, false, (15, 15), (45, 20));
            T.PixelIs(Red, r.At(15 + 30, 10 + 3), "moved sideways only");
            T.PixelIs(0, r.At(15, 15));
        });
        T.Run("nudge moves artwork by a pixel", () =>
        {
            var r = new Rig();
            Paint(r.Doc, new IntRect(10, 10, 10, 10), Red);
            r.Doc.SelectRect(new IntRect(10, 10, 10, 10));
            T.True(r.Doc.NudgeSelection(1, 0));
            T.PixelIs(Red, r.At(20, 15));
            T.PixelIs(0, r.At(9, 15));
            T.Equal(new IntRect(11, 10, 10, 10), r.Doc.Selection);
        });
        T.Run("tool keeps working after the document is replaced", () =>
        {
            var r = new Rig();
            var fresh = NewDoc(50, 40);
            r.Tools.SetDocument(fresh);
            r.Drag(ToolKind.Brush, (10, 10), (30, 20));
            T.True(fresh.History.CanUndo);
        });

        T.Suite("Compositor");
        T.Run("layers composite with opacity, visibility and background", () =>
        {
            var r = new Rig(20, 20);
            r.Doc.SetBackground(BackgroundSettings.White);
            Paint(r.Doc, new IntRect(0, 0, 10, 10), Red);
            var top = r.Doc.AddLayer()!;
            Paint(r.Doc, new IntRect(5, 5, 10, 10), Blue);
            r.Doc.SetLayerOpacity(top, 0.5);
            var img = Compositor.ComposeFrame(r.Doc.Project, 0, true);
            T.PixelIs(White, img.GetPixel(18, 18), "background shows");
            T.PixelIs(Red, img.GetPixel(2, 2));
            var mix = img.GetPixel(12, 12);
            T.True(Px.B(mix) > 120 && Px.R(mix) > 120 && Px.R(mix) < 140, $"blue at 50% over white: {mix:X8}");
            r.Doc.SetLayerVisible(top, false);
            img = Compositor.ComposeFrame(r.Doc.Project, 0, true);
            T.PixelIs(White, img.GetPixel(12, 12), "hidden layer is skipped");
            var noBg = Compositor.ComposeFrame(r.Doc.Project, 0, false);
            T.PixelIs(0, noBg.GetPixel(18, 18), "transparent without a background");
        });

        T.Suite("PNG");
        T.Run("png round trip keeps every pixel", () =>
        {
            var buf = new PixelBuffer(37, 23);
            var rnd = new Random(5);
            for (int i = 0; i < buf.Pixels.Length; i++)
            {
                int a = rnd.Next(256);
                buf.Pixels[i] = Px.FromStraight(a, rnd.Next(256), rnd.Next(256), rnd.Next(256));
            }
            foreach (var level in new[] { PngCompression.Fast, PngCompression.Normal, PngCompression.Best })
            {
                var back = PngCodec.Decode(PngCodec.Encode(buf, new PngEncodeOptions { Compression = level }));
                T.Equal(37, back.Width);
                for (int i = 0; i < buf.Pixels.Length; i++)
                    T.PixelIs(buf.Pixels[i], back.Pixels[i], $"pixel {i} ({level})", tolerance: 1);
            }
        });
        T.Run("png without alpha is written as RGB", () =>
        {
            var buf = new PixelBuffer(8, 8);
            buf.Fill(Red);
            var back = PngCodec.Decode(PngCodec.Encode(buf, new PngEncodeOptions { Alpha = false }));
            T.PixelIs(Red, back.GetPixel(3, 3));
        });
        T.Run("png decoder rejects garbage with a clear error", () =>
        {
            T.Throws<InvalidDataException>(() => PngCodec.Decode(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }));
        });

        T.Suite("Performance");
        T.Run("a long stroke on a 1920x1080 canvas stays fast", () =>
        {
            var r = new Rig(1920, 1080);
            r.Settings.Brush.Size = 24;
            r.Settings.Brush.Hardness = 0.5;
            var sw = Stopwatch.StartNew();
            r.Tools.Select(ToolKind.Brush);
            r.Tools.PointerDown(new PointerInput(100, 500));
            for (int i = 1; i <= 1500; i++)
                r.Tools.PointerMove(new PointerInput(100 + i, 500 + 300 * MathF.Sin(i / 120f)));
            r.Tools.PointerUp(new PointerInput(1600, 500));
            long ms = sw.ElapsedMilliseconds;
            Console.WriteLine($"        1500 pointer events, 24px soft brush: {ms} ms total");
            T.True(ms < 1500, $"took {ms} ms");
        });
        T.Run("flood filling a full 1920x1080 canvas is quick", () =>
        {
            var r = new Rig(1920, 1080);
            var sw = Stopwatch.StartNew();
            r.Drag(ToolKind.Fill, (10, 10));
            long ms = sw.ElapsedMilliseconds;
            Console.WriteLine($"        full-canvas fill: {ms} ms");
            T.True(ms < 1500, $"took {ms} ms");
        });

        T.Suite("Sample pictures (written for visual inspection)");
        T.Run("draw a small scene with every tool", () =>
        {
            var r = new Rig(360, 240);
            r.Doc.SetBackground(BackgroundSettings.White);
            r.Settings.PrimaryColor = ArgbColor.FromRgb(120, 190, 255);
            r.Settings.ShapeStyle = ShapeStyle.Filled;
            r.Drag(ToolKind.Rectangle, (0, 0), (360, 150));
            r.Settings.PrimaryColor = ArgbColor.FromRgb(90, 170, 80);
            r.Drag(ToolKind.Rectangle, (0, 150), (360, 240));
            r.Settings.PrimaryColor = ArgbColor.FromRgb(255, 200, 40);
            r.Drag(ToolKind.Ellipse, (270, 20), (330, 80));
            r.Settings.PrimaryColor = ArgbColor.FromRgb(160, 90, 50);
            r.Drag(ToolKind.Rectangle, (60, 100), (140, 170));
            r.Settings.PrimaryColor = ArgbColor.FromRgb(200, 50, 50);
            r.Settings.ShapeStyle = ShapeStyle.OutlineAndFill;
            r.Settings.SecondaryColor = ArgbColor.FromRgb(220, 90, 60);
            r.Settings.ShapeLineWidth = 4;
            r.Drag(ToolKind.Rectangle, (50, 70), (150, 110));
            r.Settings.PrimaryColor = ArgbColor.Black;
            r.Settings.Brush.Size = 6;
            r.Settings.Brush.Hardness = 0.9;
            for (int i = 0; i < 3; i++)
                r.Drag(ToolKind.Brush, (180 + i * 30, 200), (190 + i * 30, 160), (200 + i * 30, 170), (215 + i * 30, 205));
            r.Settings.Brush.Size = 18;
            r.Settings.Brush.Hardness = 0.1;
            r.Settings.PrimaryColor = ArgbColor.FromRgb(255, 255, 255).WithAlpha(200);
            r.DragWith(ToolKind.Brush, 0.6f, false, false, false, (200, 40), (230, 30), (260, 45), (290, 38));
            r.Settings.PrimaryColor = ArgbColor.Black;
            r.Settings.Pencil.Size = 1;
            r.Drag(ToolKind.Pencil, (10, 10), (60, 40), (110, 15), (140, 50));
            r.Settings.ShapeLineWidth = 1;
            r.Drag(ToolKind.Line, (10, 230), (350, 160));
            r.Dump("scene");
            T.True(File.Exists(Path.Combine(OutDir, "scene.png")));
        });
    }
}
