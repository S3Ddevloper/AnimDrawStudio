using System.Diagnostics;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;

namespace AnimDraw.Core.Tests;

/// <summary>Tiny dependency-free test framework (no NuGet packages needed).</summary>
public static class T
{
    private static int _passed;
    private static int _skipped;
    private static readonly List<string> Failures = new();
    private static string _suite = "";

    public static void Suite(string name)
    {
        _suite = name;
        Console.WriteLine();
        Console.WriteLine($"== {name}");
    }

    public static void Run(string name, Action test)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            test();
            _passed++;
            Console.WriteLine($"  ok    {name} ({sw.ElapsedMilliseconds} ms)");
        }
        catch (Exception ex)
        {
            string line = $"{_suite} / {name}: {ex.GetType().Name}: {ex.Message}";
            Failures.Add(line);
            Console.WriteLine($"  FAIL  {name}");
            Console.WriteLine($"        {ex.GetType().Name}: {ex.Message}");
            string[] stack = (ex.StackTrace ?? "").Split('\n');
            foreach (var s in stack.Take(4)) Console.WriteLine("        " + s.Trim());
        }
    }

    /// <summary>Records a test that could not run here (for example one that needs a tool that is not installed).</summary>
    public static void Skip(string name, string reason)
    {
        _skipped++;
        Console.WriteLine($"  skip  {name} ({reason})");
    }

    public static int Finish()
    {
        Console.WriteLine();
        Console.WriteLine($"Passed: {_passed}   Failed: {Failures.Count}   Skipped: {_skipped}");
        foreach (var f in Failures) Console.WriteLine("  - " + f);
        return Failures.Count == 0 ? 0 : 1;
    }

    public static void True(bool condition, string message = "expected true")
    {
        if (!condition) throw new Exception(message);
    }

    public static void False(bool condition, string message = "expected false")
    {
        if (condition) throw new Exception(message);
    }

    public static void Equal<TValue>(TValue expected, TValue actual, string? message = null)
    {
        if (!EqualityComparer<TValue>.Default.Equals(expected, actual))
            throw new Exception($"{message ?? "values differ"}: expected <{expected}> but was <{actual}>");
    }

    public static void Near(double expected, double actual, double tolerance, string? message = null)
    {
        if (Math.Abs(expected - actual) > tolerance)
            throw new Exception($"{message ?? "values differ"}: expected {expected} ± {tolerance} but was {actual}");
    }

    public static void PixelIs(uint expected, uint actual, string? message = null, int tolerance = 0)
    {
        if (Px.MaxChannelDiff(expected, actual) > tolerance)
            throw new Exception($"{message ?? "pixel differs"}: expected {expected:X8} but was {actual:X8}");
    }

    public static void Throws<TException>(Action action) where TException : Exception
    {
        try { action(); }
        catch (TException) { return; }
        throw new Exception($"expected {typeof(TException).Name} but nothing was thrown");
    }
}

public static class Helpers
{
    public static readonly uint Red = Px.FromStraight(255, 255, 0, 0);
    public static readonly uint Green = Px.FromStraight(255, 0, 255, 0);
    public static readonly uint Blue = Px.FromStraight(255, 0, 0, 255);
    public static readonly uint White = Px.FromStraight(255, 255, 255, 255);

    public static Document NewDoc(int w = 64, int h = 48, int frames = 1)
    {
        var p = Project.CreateNew(w, h, 12, BackgroundSettings.Transparent);
        p.FrameCount = frames;
        return new Document(p);
    }

    /// <summary>Fills a rectangle on the active layer's current frame as one undo step.</summary>
    public static bool Paint(Document doc, IntRect rect, uint color, string name = "Paint")
    {
        var session = doc.BeginEdit(out _);
        if (session == null) return false;
        var buf = new PixelBuffer(rect.Width, rect.Height);
        buf.Fill(color);
        session.Surface.BlendBuffer(buf, rect.X, rect.Y, session.Recorder);
        session.AddDirty(rect);
        session.TakeDirty();
        return session.Commit(name);
    }

    public static uint PixelOf(Layer layer, int frame, int x, int y) =>
        layer.GetCelAt(frame)?.Surface.GetPixel(x, y) ?? 0u;
}
