using AnimDraw.Core.Animation;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;
using AnimDraw.Core.Rendering;
using static AnimDraw.Core.Tests.Helpers;

namespace AnimDraw.Core.Tests;

public static class AnimationTests
{
    /// <summary>A manual clock so playback timing can be tested exactly.</summary>
    private sealed class FakeClock
    {
        public long Ticks;
        public const long PerSecond = 1000;
        public void Advance(double seconds) => Ticks += (long)Math.Round(seconds * PerSecond);
    }

    private static PlaybackEngine Engine(FakeClock clock, int frames, double fps)
    {
        var e = new PlaybackEngine(() => clock.Ticks, FakeClock.PerSecond) { FrameCount = frames, Fps = fps };
        return e;
    }

    /// <summary>Three frames, each with its own square on the same layer at different places.</summary>
    private static Document ThreeFrameDoc()
    {
        var d = NewDoc(60, 40, 3);
        d.Project.Onion.Enabled = true;
        var layer = d.ActiveLayer;
        d.GoToFrame(0); d.InsertBlankKeyframe(layer, 0); Paint(d, new IntRect(2, 2, 6, 6), Red);
        d.GoToFrame(1); d.InsertBlankKeyframe(layer, 1); Paint(d, new IntRect(20, 2, 6, 6), Green);
        d.GoToFrame(2); d.InsertBlankKeyframe(layer, 2); Paint(d, new IntRect(40, 2, 6, 6), Blue);
        return d;
    }

    public static void RunAll()
    {
        T.Suite("Onion skin");
        T.Run("previous frame is a red ghost, next frame a blue ghost, current frame is not ghosted", () =>
        {
            var d = ThreeFrameDoc();
            d.Project.Onion.Opacity = 0.5;
            var buf = new PixelBuffer(60, 40);
            var r = new OnionSkinRenderer();
            T.True(r.Render(d.Project, 1, buf, buf.Bounds));
            uint prev = buf.GetPixel(4, 4);     // where frame 0 has its square
            uint next = buf.GetPixel(42, 4);    // where frame 2 has its square
            T.True(Px.A(prev) > 100 && Px.R(prev) > Px.B(prev) * 2, $"previous ghost is red: {prev:X8}");
            T.True(Px.A(next) > 100 && Px.B(next) > Px.R(next) * 2, $"next ghost is blue: {next:X8}");
            T.PixelIs(0, buf.GetPixel(22, 4), "the current frame's own drawing is not ghosted");
            T.PixelIs(0, buf.GetPixel(30, 30), "empty areas stay empty");
        });
        T.Run("ghost strength follows the opacity setting", () =>
        {
            var d = ThreeFrameDoc();
            var r = new OnionSkinRenderer();
            var weak = new PixelBuffer(60, 40);
            var strong = new PixelBuffer(60, 40);
            d.Project.Onion.Opacity = 0.2;
            r.Render(d.Project, 1, weak, weak.Bounds);
            d.Project.Onion.Opacity = 0.8;
            r.Render(d.Project, 1, strong, strong.Bounds);
            T.True(Px.A(strong.GetPixel(4, 4)) > Px.A(weak.GetPixel(4, 4)) * 2);
            T.True(Math.Abs(Px.A(weak.GetPixel(4, 4)) - 51) <= 2, "20% of 255");
        });
        T.Run("disabled onion skin draws nothing", () =>
        {
            var d = ThreeFrameDoc();
            d.Project.Onion.Enabled = false;
            var buf = new PixelBuffer(60, 40);
            T.False(new OnionSkinRenderer().Render(d.Project, 1, buf, buf.Bounds));
            T.True(buf.IsBlank());
        });
        T.Run("previous and next counts are honoured and edges are safe", () =>
        {
            var d = ThreeFrameDoc();
            d.Project.Onion.PreviousFrames = 0;
            d.Project.Onion.NextFrames = 0;
            var buf = new PixelBuffer(60, 40);
            T.False(new OnionSkinRenderer().Render(d.Project, 1, buf, buf.Bounds));
            d.Project.Onion.PreviousFrames = 2;
            d.Project.Onion.NextFrames = 0;
            T.True(new OnionSkinRenderer().Render(d.Project, 2, buf, buf.Bounds));
            T.True(Px.A(buf.GetPixel(4, 4)) > 0 && Px.A(buf.GetPixel(22, 4)) > 0, "two previous frames");
            T.False(new OnionSkinRenderer().Render(d.Project, 0, buf, buf.Bounds), "frame 0 has no previous or next ghost to show with next=0");
        });
        T.Run("a drawing held unchanged across frames is not ghosted", () =>
        {
            var d = NewDoc(60, 40, 3);
            var background = d.ActiveLayer;
            Paint(d, new IntRect(0, 0, 60, 40), Blue);            // one key at frame 0, held through frame 2
            d.AddLayer();
            d.GoToFrame(0); d.InsertBlankKeyframe(d.ActiveLayer, 0); Paint(d, new IntRect(2, 2, 6, 6), Red);
            d.GoToFrame(1); d.InsertBlankKeyframe(d.ActiveLayer, 1); Paint(d, new IntRect(20, 2, 6, 6), Green);
            var buf = new PixelBuffer(60, 40);
            new OnionSkinRenderer().Render(d.Project, 1, buf, buf.Bounds);
            T.PixelIs(0, buf.GetPixel(50, 30), "the static blue background does not wash out the canvas");
            T.True(Px.A(buf.GetPixel(4, 4)) > 0, "the character's previous pose is ghosted");
        });
        T.Run("uncoloured ghosts keep their own colours", () =>
        {
            var d = ThreeFrameDoc();
            d.Project.Onion.Colorize = false;
            d.Project.Onion.Opacity = 0.6;
            var buf = new PixelBuffer(60, 40);
            new OnionSkinRenderer().Render(d.Project, 1, buf, buf.Bounds);
            uint p = buf.GetPixel(4, 4);   // frame 0 was pure red
            T.True(Px.R(p) > 0 && Px.G(p) == 0 && Px.B(p) == 0, $"still pure red: {p:X8}");
        });
        T.Run("region-limited rendering leaves the rest alone", () =>
        {
            var d = ThreeFrameDoc();
            var buf = new PixelBuffer(60, 40);
            var r = new OnionSkinRenderer();
            r.Render(d.Project, 1, buf, new IntRect(0, 0, 30, 40));
            T.True(Px.A(buf.GetPixel(4, 4)) > 0);
            T.PixelIs(0, buf.GetPixel(42, 4), "outside the requested region");
        });

        T.Suite("Playback engine");
        T.Run("frames advance with the clock at the chosen fps", () =>
        {
            var clock = new FakeClock();
            var e = Engine(clock, 10, 10);
            var seen = new List<int>();
            e.FrameChanged += seen.Add;
            e.Play(0);
            T.Equal(PlaybackState.Playing, e.State);
            clock.Advance(0.05); e.Tick(); T.Equal(0, e.CurrentFrame);
            clock.Advance(0.06); e.Tick(); T.Equal(1, e.CurrentFrame);
            clock.Advance(0.25); e.Tick(); T.Equal(3, e.CurrentFrame);
            clock.Advance(0.30); e.Tick(); T.Equal(6, e.CurrentFrame);
        });
        T.Run("looping wraps around, non-looping stops on the last frame", () =>
        {
            var clock = new FakeClock();
            var e = Engine(clock, 5, 10);
            e.Loop = true;
            e.Play(0);
            clock.Advance(0.62); e.Tick();
            T.Equal(1, e.CurrentFrame);
            T.Equal(PlaybackState.Playing, e.State);

            var clock2 = new FakeClock();
            var e2 = Engine(clock2, 5, 10);
            e2.Loop = false;
            PlaybackState? last = null;
            e2.StateChanged += s => last = s;
            e2.Play(0);
            clock2.Advance(2.0); e2.Tick();
            T.Equal(4, e2.CurrentFrame);
            T.Equal(PlaybackState.Stopped, e2.State);
            T.Equal(PlaybackState.Stopped, last!.Value);
        });
        T.Run("pausing freezes time and resuming continues from the same frame", () =>
        {
            var clock = new FakeClock();
            var e = Engine(clock, 20, 10);
            e.Play(0);
            clock.Advance(0.35); e.Tick();
            T.Equal(3, e.CurrentFrame);
            e.Pause();
            T.Equal(PlaybackState.Paused, e.State);
            clock.Advance(5.0);
            e.Tick();
            T.Equal(3, e.CurrentFrame);
            e.Resume();
            clock.Advance(0.1); e.Tick();
            T.Equal(4, e.CurrentFrame);
        });
        T.Run("stop returns to the frame playback began from", () =>
        {
            var clock = new FakeClock();
            var e = Engine(clock, 20, 10);
            e.Play(5);
            clock.Advance(0.5); e.Tick();
            T.Equal(10, e.CurrentFrame);
            e.Stop();
            T.Equal(5, e.CurrentFrame);
            T.Equal(PlaybackState.Stopped, e.State);
            e.Play(5); clock.Advance(0.3); e.Tick();
            e.Stop(returnToStart: false);
            T.Equal(8, e.CurrentFrame);
        });
        T.Run("speed multiplier scales playback", () =>
        {
            var clock = new FakeClock();
            var e = Engine(clock, 100, 10);
            e.Speed = 2.0;
            e.Play(0);
            clock.Advance(1.0); e.Tick();
            T.Equal(20, e.CurrentFrame);
            e.Speed = 0.5;
            clock.Advance(1.0); e.Tick();
            T.Equal(25, e.CurrentFrame);
        });
        T.Run("changing fps mid-play does not make the frame jump", () =>
        {
            var clock = new FakeClock();
            var e = Engine(clock, 200, 10);
            e.Play(0);
            clock.Advance(1.0); e.Tick();
            T.Equal(10, e.CurrentFrame);
            e.Fps = 24;
            clock.Advance(0.0); e.Tick();
            T.Equal(10, e.CurrentFrame);
            clock.Advance(1.0); e.Tick();
            T.Equal(34, e.CurrentFrame);
        });
        T.Run("slow ticks skip frames to keep real time and count them as dropped", () =>
        {
            var clock = new FakeClock();
            var e = Engine(clock, 100, 10);
            e.Play(0);
            clock.Advance(0.1); e.Tick();
            clock.Advance(0.5); e.Tick();
            T.Equal(6, e.CurrentFrame);
            T.Equal(4L, e.DroppedFrames);
        });
        T.Run("seeking while playing continues from the new frame", () =>
        {
            var clock = new FakeClock();
            var e = Engine(clock, 100, 10);
            e.Play(0);
            clock.Advance(0.3); e.Tick();
            e.Seek(50);
            T.Equal(50, e.CurrentFrame);
            clock.Advance(0.2); e.Tick();
            T.Equal(52, e.CurrentFrame);
        });
        T.Run("play on the last frame of a non-looping animation starts over", () =>
        {
            var clock = new FakeClock();
            var e = Engine(clock, 5, 10);
            e.Loop = false;
            e.Play(4);
            T.Equal(0, e.CurrentFrame);
        });
        T.Run("play range limits playback", () =>
        {
            var clock = new FakeClock();
            var e = Engine(clock, 20, 10);
            e.SetRange(5, 8);
            e.Play(0);
            T.Equal(5, e.CurrentFrame);
            clock.Advance(0.3); e.Tick();
            T.Equal(8, e.CurrentFrame, "5,6,7,8 ...");
            clock.Advance(0.1); e.Tick();
            T.Equal(5, e.CurrentFrame, "... then back to 5");
            clock.Advance(0.1); e.Tick();
            T.Equal(6, e.CurrentFrame);
        });
        T.Run("measured fps is close to the requested one", () =>
        {
            var clock = new FakeClock();
            var e = Engine(clock, 1000, 24);
            e.Play(0);
            for (int i = 0; i < 100; i++) { clock.Advance(1.0 / 60); e.Tick(); }
            T.Near(24, e.MeasuredFps, 3.0);
        });
        T.Run("ticking while stopped does nothing", () =>
        {
            var clock = new FakeClock();
            var e = Engine(clock, 10, 10);
            clock.Advance(3);
            T.False(e.Tick());
            T.Equal(0, e.CurrentFrame);
        });

        T.Suite("Frame cache");
        T.Run("cached frames match a direct composite", () =>
        {
            var d = ThreeFrameDoc();
            using var cache = new FrameCache(d.CreateSnapshot());
            for (int f = 0; f < 3; f++)
            {
                var direct = Compositor.ComposeFrame(d.Project, f, true);
                var cached = cache.Get(f);
                for (int i = 0; i < direct.Pixels.Length; i++)
                    if (direct.Pixels[i] != cached.Pixels[i]) throw new Exception($"frame {f} pixel {i} differs");
            }
        });
        T.Run("background prefetch fills the cache ahead of the playhead", () =>
        {
            var d = NewDoc(40, 30, 12);
            using var cache = new FrameCache(d.CreateSnapshot());
            cache.StartPrefetch(0, loop: true);
            var sw = System.Diagnostics.Stopwatch.StartNew();
            while (cache.CachedCount < 12 && sw.ElapsedMilliseconds < 3000) Thread.Sleep(10);
            T.Equal(12, cache.CachedCount);
        });
        T.Run("cache stays within its memory budget", () =>
        {
            var d = NewDoc(100, 100, 30);
            long oneFrame = 100 * 100 * 4;
            using var cache = new FrameCache(d.CreateSnapshot(), true, oneFrame * 5);
            T.Equal(5, cache.Capacity);
            cache.StartPrefetch(0, true);
            Thread.Sleep(300);
            for (int f = 0; f < 30; f++) cache.Get(f);
            T.True(cache.CachedCount <= 5, $"{cache.CachedCount} frames cached");
        });
        T.Run("moving the playhead moves the window", () =>
        {
            var d = NewDoc(100, 100, 40);
            long oneFrame = 100 * 100 * 4;
            using var cache = new FrameCache(d.CreateSnapshot(), true, oneFrame * 6);
            cache.StartPrefetch(0, true);
            Thread.Sleep(200);
            cache.UpdatePlayhead(20);
            var sw = System.Diagnostics.Stopwatch.StartNew();
            while (!cache.TryGetCached(24, out _) && sw.ElapsedMilliseconds < 3000) Thread.Sleep(10);
            T.True(cache.TryGetCached(24, out _), "frames after the new playhead get cached");
        });
        T.Run("disposing stops the background thread", () =>
        {
            var d = NewDoc(40, 30, 50);
            var cache = new FrameCache(d.CreateSnapshot());
            cache.StartPrefetch(0, true);
            cache.Dispose();
            T.False(cache.IsPrefetching);
        });
    }
}
