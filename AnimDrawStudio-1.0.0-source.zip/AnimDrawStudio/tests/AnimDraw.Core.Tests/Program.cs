using AnimDraw.Core.Tests;

DocumentTests.RunAll();
DrawingTests.RunAll();
AnimationTests.RunAll();
ProjectIoTests.RunAll();
ExportTests.RunAll();
AppLayerTests.RunAll();

return T.Finish();
