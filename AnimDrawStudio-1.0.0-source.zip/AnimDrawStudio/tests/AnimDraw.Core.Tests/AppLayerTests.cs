using AnimDraw.Core.Animation;
using AnimDraw.Core.App;
using AnimDraw.Core.Editing;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.IO;
using AnimDraw.Core.Model;
using AnimDraw.Core.Settings;
using AnimDraw.Core.Tools;
using static AnimDraw.Core.Tests.Helpers;

namespace AnimDraw.Core.Tests;

public static class AppLayerTests
{
    private sealed class TempDir : IDisposable
    {
        public string Root { get; } = Path.Combine(Path.GetTempPath(), "animdraw-tests", Guid.NewGuid().ToString("N"));
        public TempDir() => Directory.CreateDirectory(Root);
        public string P(string name) => Path.Combine(Root, name);

        public void Dispose()
        {
            try { Directory.Delete(Root, recursive: true); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
    }

    private static Editor NewEditor(TempDir dir, PlaybackEngine? playback = null, string? session = null)
    {
        var settings = new SettingsManager(dir.P("settings"));
        settings.Load();
        var recovery = new RecoveryManager(dir.P("recovery"), session);
        recovery.Start();
        return new Editor(settings, recovery, playback);
    }

    public static void RunAll()
    {
        ViewportTests();
        ShortcutTests();
        EditorTests();
        PlaybackTests();
        SettingsTests();
    }

    // ------------------------------------------------------------------ viewport

    private static Viewport MakeView(int cw = 200, int ch = 100, double vw = 800, double vh = 600, double dpi = 1)
    {
        var v = new Viewport { DpiScale = dpi };
        v.SetCanvasSize(cw, ch);
        v.SetViewSize(vw, vh);
        v.CenterCanvas();
        return v;
    }

    private static void ViewportTests()
    {
        T.Suite("App layer: viewport (zoom and pan)");

        T.Run("canvas and view positions convert both ways", () =>
        {
            var v = MakeView();
            v.ZoomToCenter(2.5);
            v.PanBy(37, -21);
            var (vx, vy) = v.CanvasToView(40, 30);
            var (cx, cy) = v.ViewToCanvas(vx, vy);
            T.Near(40, cx, 1e-9);
            T.Near(30, cy, 1e-9);
        });

        T.Run("zooming keeps the point under the cursor in place", () =>
        {
            var v = MakeView();
            double ax = 300, ay = 250;
            var (cx0, cy0) = v.ViewToCanvas(ax, ay);
            v.ZoomTo(4, ax, ay);
            var (cx1, cy1) = v.ViewToCanvas(ax, ay);
            T.Near(cx0, cx1, 1e-6, "x");
            T.Near(cy0, cy1, 1e-6, "y");
            T.Near(4, v.Zoom, 1e-9);
        });

        T.Run("fit shows the whole canvas inside the view and centres it", () =>
        {
            var v = MakeView(1920, 1080, 1000, 700);
            v.FitToView(20);
            var r = v.CanvasRectInView();
            T.True(r.X >= 19.999 && r.Y >= 19.999, "inside left/top margin");
            T.True(r.X + r.Width <= 1000 - 19.999 && r.Y + r.Height <= 700 - 19.999, "inside right/bottom margin");
            T.Near(500, r.X + r.Width / 2, 1e-6, "centred horizontally");
            T.Near(350, r.Y + r.Height / 2, 1e-6, "centred vertically");
        });

        T.Run("100% means one canvas pixel per screen pixel on a scaled display", () =>
        {
            var v = MakeView(100, 100, 800, 600, dpi: 1.25);
            v.SetZoomCentered(1);
            T.Near(0.8, v.Scale, 1e-9, "view units per canvas pixel at 125% display scale");
            T.Near(80, v.CanvasRectInView().Width, 1e-9);
            T.Equal("100%", v.ZoomText);
        });

        T.Run("zoom steps move up and down and stop at the ends", () =>
        {
            var v = MakeView();
            v.SetZoomCentered(1);
            double up = Viewport.NextStep(1, +1), down = Viewport.NextStep(1, -1);
            T.True(up > 1 && down < 1, "direction");
            T.Equal(Viewport.ZoomSteps[^1], Viewport.NextStep(1000, +1));
            T.Equal(Viewport.ZoomSteps[0], Viewport.NextStep(0.0001, -1));
            for (int i = 1; i < Viewport.ZoomSteps.Length; i++) T.True(Viewport.ZoomSteps[i] > Viewport.ZoomSteps[i - 1], "steps increase");
            for (int i = 0; i < 100; i++) v.ZoomStep(+1, 400, 300);
            T.True(v.Zoom <= v.MaxZoomFor(200, 100) + 1e-9, "never above the limit");
        });

        T.Run("the canvas can never be panned out of reach", () =>
        {
            var v = MakeView();
            v.PanBy(1_000_000, 1_000_000);
            T.True(v.OffsetX < v.ViewWidth && v.OffsetY < v.ViewHeight, "top-left corner still inside the view");
            v.PanBy(-5_000_000, -5_000_000);
            var r = v.CanvasRectInView();
            T.True(r.X + r.Width > 0 && r.Y + r.Height > 0, "bottom-right corner still inside the view");
            T.False(v.VisibleCanvasRect().IsEmpty, "some canvas is always visible");
        });

        T.Run("large canvases limit how far one can zoom in", () =>
        {
            var v = MakeView(8192, 8192);
            v.ZoomToCenter(64);
            T.True(v.Scale * 8192 <= Viewport.MaxScaledExtent + 1, "zoomed canvas stays below the renderer limit");
            var small = MakeView(16, 16);
            small.ZoomToCenter(64);
            T.Near(64, small.Zoom, 1e-9);
        });

        T.Run("visible rectangle follows the pan and never leaves the canvas", () =>
        {
            var v = MakeView(1000, 1000, 400, 300);
            v.SetZoomCentered(1);
            var r = v.VisibleCanvasRect();
            T.True(new IntRect(0, 0, 1000, 1000).Contains(r), "inside canvas");
            T.True(r.Width <= 402 && r.Height <= 302, "about the size of the view");
            v.PanBy(-200, 0);
            var r2 = v.VisibleCanvasRect();
            T.True(r2.X > r.X, "moving the canvas left reveals content further right");
        });

        T.Run("resizing the window keeps the middle of the picture in the middle", () =>
        {
            var v = MakeView(500, 500, 800, 600);
            v.SetZoomCentered(1);
            v.PanBy(-60, 25);
            var (cx, cy) = v.ViewToCanvas(400, 300);
            v.SetViewSize(1000, 700);
            var (cx2, cy2) = v.ViewToCanvas(500, 350);
            T.Near(cx, cx2, 1e-6, "x");
            T.Near(cy, cy2, 1e-6, "y");
        });

        T.Run("zoom text", () =>
        {
            T.Equal("100%", Viewport.FormatZoom(1));
            T.Equal("50%", Viewport.FormatZoom(0.5));
            T.Equal("3200%", Viewport.FormatZoom(32));
            T.Equal("6.3%", Viewport.FormatZoom(0.0625));
        });
    }

    // ------------------------------------------------------------------ shortcuts

    private static void ShortcutTests()
    {
        T.Suite("App layer: keyboard shortcuts");

        T.Run("every command is listed once with a name and category", () =>
        {
            var ids = ShortcutMap.Commands.Select(c => c.Id).ToList();
            T.Equal(ids.Count, ids.Distinct().Count(), "no command listed twice");
            foreach (var id in Enum.GetValues<CommandId>())
                T.True(ids.Contains(id), $"{id} is missing from the command list");
            T.True(ShortcutMap.Commands.All(c => c.Name.Length > 0 && c.Category.Length > 0), "names present");
        });

        T.Run("default shortcuts never clash and all round-trip through text", () =>
        {
            var map = ShortcutMap.CreateDefault();
            var seen = new HashSet<KeyGestureSpec>();
            foreach (var (id, g) in map.AllBindings())
            {
                T.True(seen.Add(g), $"gesture {g} used twice");
                T.True(KeyGestureSpec.TryParse(g.ToStorageString(), out var back), $"parse {g}");
                T.Equal(g, back);
                T.Equal(id, map.Find(back)!.Value);
            }
            T.True(seen.Count > 60, "a good number of shortcuts");
        });

        T.Run("well-known shortcuts are what people expect", () =>
        {
            var map = ShortcutMap.CreateDefault();
            T.Equal("Ctrl+S", map.DisplayTextOf(CommandId.Save));
            T.Equal("Ctrl+Shift+S", map.DisplayTextOf(CommandId.SaveAs));
            T.Equal("Ctrl+Z", map.DisplayTextOf(CommandId.Undo));
            T.Equal("Ctrl+Y", map.DisplayTextOf(CommandId.Redo));
            T.Equal("B", map.DisplayTextOf(CommandId.ToolBrush));
            T.Equal("Enter", map.DisplayTextOf(CommandId.PlayPause));
            T.Equal("F5", map.DisplayTextOf(CommandId.InsertFrame));
            T.Equal("Ctrl+=", map.DisplayTextOf(CommandId.ZoomIn));
            T.Equal(CommandId.Redo, map.Find(new KeyGestureSpec("Z", Ctrl: true, Shift: true))!.Value);
            T.True(map.Find(new KeyGestureSpec("Q")) == null, "unbound key");
        });

        T.Run("binding a gesture again moves it", () =>
        {
            var map = ShortcutMap.CreateDefault();
            var g = new KeyGestureSpec("B");
            map.Bind(CommandId.ToolPencil, g);
            T.Equal(CommandId.ToolPencil, map.Find(g)!.Value);
            T.False(map.GesturesOf(CommandId.ToolBrush).Contains(g), "brush lost it");
        });

        T.Run("gesture text parsing is forgiving and strict about nonsense", () =>
        {
            T.True(KeyGestureSpec.TryParse(" ctrl + shift + F5 ", out var g));
            T.Equal(new KeyGestureSpec("F5", true, true, false), g);
            T.False(KeyGestureSpec.TryParse("", out _));
            T.False(KeyGestureSpec.TryParse("Ctrl+", out _));
            T.False(KeyGestureSpec.TryParse("A+B", out _));
            T.False(KeyGestureSpec.TryParse(null, out _));
        });
    }

    // ------------------------------------------------------------------ editor

    private static void EditorTests()
    {
        T.Suite("App layer: editor (project, files, clipboard)");

        T.Run("a new editor starts with an empty untouched project", () =>
        {
            using var dir = new TempDir();
            using var ed = NewEditor(dir);
            T.Equal(1280, ed.Document.CanvasWidth);
            T.Equal(720, ed.Document.CanvasHeight);
            T.Equal(1, ed.Document.Project.Layers.Count);
            T.False(ed.IsDirty, "not dirty");
            T.True(ed.FilePath == null, "no file");
            T.Equal("Untitled", ed.DisplayName);
        });

        T.Run("new project replaces the document and tells listeners", () =>
        {
            using var dir = new TempDir();
            using var ed = NewEditor(dir);
            int replaced = 0, titles = 0;
            ed.DocumentReplaced += () => replaced++;
            ed.FileStateChanged += () => titles++;
            var old = ed.Document;
            ed.NewProject(320, 200, 24, BackgroundSettings.Transparent);
            T.True(!ReferenceEquals(old, ed.Document), "new document");
            T.Equal(320, ed.Document.CanvasWidth);
            T.Equal(24.0, ed.Document.Project.Fps);
            T.Equal(BackgroundMode.Transparent, ed.Document.Project.Background.Mode);
            T.Equal(1, replaced);
            T.True(titles >= 1, "title refresh");
            T.True(ReferenceEquals(ed.Tools.Context.Document, ed.Document), "tools follow the document");
        });

        T.Run("an impossible size is refused and the open project survives", () =>
        {
            using var dir = new TempDir();
            using var ed = NewEditor(dir);
            var old = ed.Document;
            T.Throws<ArgumentOutOfRangeException>(() => ed.NewProject(0, 100, 12, BackgroundSettings.White));
            T.Throws<ArgumentOutOfRangeException>(() => ed.NewProject(9000, 9000, 12, BackgroundSettings.White));
            T.True(ReferenceEquals(old, ed.Document), "still the old document");
        });

        T.Run("drawing marks the project unsaved and saving clears it", () =>
        {
            using var dir = new TempDir();
            using var ed = NewEditor(dir);
            ed.NewProject(100, 80, 12, BackgroundSettings.White);
            T.False(ed.IsDirty);
            Paint(ed.Document, new IntRect(10, 10, 20, 20), Red);
            T.True(ed.IsDirty, "dirty after drawing");
            ed.SaveAsync(dir.P("a.animdraw"), null).GetAwaiter().GetResult();
            T.False(ed.IsDirty, "clean after saving");
            T.Equal(dir.P("a.animdraw"), ed.FilePath);
            T.Equal("a", ed.DisplayName);
            ed.Document.Undo();
            T.True(ed.IsDirty, "dirty again after undo");
        });

        T.Run("save then open in a fresh editor gives back the same drawing", () =>
        {
            using var dir = new TempDir();
            string file = dir.P("round.animdraw");
            using (var ed = NewEditor(dir))
            {
                ed.NewProject(120, 90, 15, BackgroundSettings.Custom(new ArgbColor(255, 10, 20, 30)));
                Paint(ed.Document, new IntRect(5, 6, 30, 20), Red);
                ed.Document.AddLayer("Ink");
                Paint(ed.Document, new IntRect(50, 40, 10, 10), Blue);
                ed.Document.InsertBlankFrameAfter(0);
                ed.Document.GoToFrame(1);
                Paint(ed.Document, new IntRect(1, 1, 4, 4), Green);
                ed.SaveAsync(file, null).GetAwaiter().GetResult();
            }
            using var dir2 = new TempDir();
            var settings = new SettingsManager(dir.P("settings"));
            settings.Load();
            using var ed2 = new Editor(settings, new RecoveryManager(dir2.P("rec")));
            ed2.OpenAsync(file).GetAwaiter().GetResult();
            var d = ed2.Document;
            T.Equal(120, d.CanvasWidth);
            T.Equal(15.0, d.Project.Fps);
            T.Equal(2, d.Project.Layers.Count);
            T.Equal(2, d.FrameCount);
            T.Equal(1, d.CurrentFrame);
            T.PixelIs(Red, PixelOf(d.Project.Layers[0], 0, 10, 10));
            T.PixelIs(Blue, PixelOf(d.Project.Layers[1], 0, 55, 45));
            T.PixelIs(Green, PixelOf(d.Project.Layers[1], 1, 2, 2));
            T.False(ed2.IsDirty, "freshly opened project is clean");
            T.Equal(file, ed2.FilePath);
            T.True(ed2.Settings.RecentProjects.Contains(Path.GetFullPath(file)), "in the recent list");
        });

        T.Run("opening a damaged file fails with a clear message and keeps the current project", () =>
        {
            using var dir = new TempDir();
            using var ed = NewEditor(dir);
            var old = ed.Document;
            File.WriteAllText(dir.P("bad.animdraw"), "this is not a zip file");
            bool threw = false;
            try { ed.OpenAsync(dir.P("bad.animdraw")).GetAwaiter().GetResult(); }
            catch (ProjectFileException ex) { threw = true; T.True(ex.Message.Length > 10, "message"); }
            T.True(threw, "ProjectFileException expected");
            T.True(ReferenceEquals(old, ed.Document), "document untouched");
            threw = false;
            try { ed.OpenAsync(dir.P("missing.animdraw")).GetAwaiter().GetResult(); }
            catch (ProjectFileException) { threw = true; }
            T.True(threw, "missing file reported");
        });

        T.Run("a crashed session's work can be recovered as an unsaved project", () =>
        {
            using var dir = new TempDir();
            using var running = NewEditor(dir, session: "running-session");
            running.NewProject(64, 64, 12, BackgroundSettings.White);
            Paint(running.Document, new IntRect(8, 8, 16, 16), Red);
            T.True(running.AutosaveIfNeededAsync().GetAwaiter().GetResult(), "autosave written");
            T.False(running.AutosaveIfNeededAsync().GetAwaiter().GetResult(), "nothing new to save");

            // A second copy of the program must not offer the running session's work as lost...
            using var next = NewEditor(dir, session: "second-session");
            T.Equal(0, next.FindRecoverable().Count, "a live session is left alone");

            // ...but when the first program dies without cleaning up (its files stay, its lock is gone) it does.
            string folder = dir.P("recovery");
            File.Copy(Path.Combine(folder, "running-session.animdraw"), Path.Combine(folder, "crashed.animdraw"));
            File.Copy(Path.Combine(folder, "running-session.json"), Path.Combine(folder, "crashed.json"));
            var found = next.FindRecoverable();
            T.Equal(1, found.Count);
            var loaded = RecoveryManager.Open(found[0]);
            next.AdoptRecovered(loaded, found[0].OriginalPath);
            T.PixelIs(Red, PixelOf(next.Document.Project.Layers[0], 0, 10, 10));
            T.True(next.IsDirty, "recovered work counts as unsaved");
            T.True(next.FilePath == null, "no file yet");
            RecoveryManager.Discard(found[0]);
            T.Equal(0, next.FindRecoverable().Count);
        });

        T.Run("leaving with unsaved work nobody gave up keeps the recovery copy for the next start", () =>
        {
            using var dir = new TempDir();
            var ed = NewEditor(dir, session: "ending-session");
            ed.NewProject(64, 64, 12, BackgroundSettings.White);
            Paint(ed.Document, new IntRect(8, 8, 16, 16), Red);
            T.True(ed.AutosaveIfNeededAsync().GetAwaiter().GetResult(), "autosave written");
            ed.Dispose(); // for example Windows logging off: nobody answered the "save changes?" question

            var next = NewEditor(dir, session: "next-session");
            var found = next.FindRecoverable();
            T.Equal(1, found.Count, "the unsaved work is offered again");
            var loaded = RecoveryManager.Open(found[0]);
            next.AdoptRecovered(loaded, found[0].OriginalPath);
            T.PixelIs(Red, PixelOf(next.Document.Project.Layers[0], 0, 10, 10));
            next.Dispose();
        });

        T.Run("leaving with the person's agreement removes the recovery copy", () =>
        {
            using var dir = new TempDir();
            var ed = NewEditor(dir, session: "approved-session");
            ed.NewProject(64, 64, 12, BackgroundSettings.White);
            Paint(ed.Document, new IntRect(8, 8, 16, 16), Red);
            T.True(ed.AutosaveIfNeededAsync().GetAwaiter().GetResult(), "autosave written");
            ed.ExitApproved = true; // "Don't save" was chosen
            ed.Dispose();
            T.Equal(0, Directory.GetFiles(dir.P("recovery")).Length, "nothing left behind");
            T.Equal(0, NewEditor(dir, session: "next-session").FindRecoverable().Count);
        });

        T.Run("a project without unsaved changes leaves nothing behind either way", () =>
        {
            using var dir = new TempDir();
            var ed = NewEditor(dir, session: "clean-session");
            ed.NewProject(64, 64, 12, BackgroundSettings.White);
            Paint(ed.Document, new IntRect(8, 8, 16, 16), Red);
            T.True(ed.AutosaveIfNeededAsync().GetAwaiter().GetResult(), "autosave written");
            ed.SaveAsync(dir.P("kept.animdraw"), null).GetAwaiter().GetResult();
            T.False(ed.IsDirty, "clean after saving");
            ed.Dispose();
            T.Equal(0, Directory.GetFiles(dir.P("recovery")).Length, "nothing left behind");
        });

        T.Run("the recovery copy can be written on demand and waited for", () =>
        {
            using var dir = new TempDir();
            using var ed = NewEditor(dir, session: "now-session");
            T.False(ed.SaveRecoveryCopyNow(TimeSpan.FromSeconds(10)), "nothing to write yet");
            Paint(ed.Document, new IntRect(2, 2, 8, 8), Blue);
            T.True(ed.SaveRecoveryCopyNow(TimeSpan.FromSeconds(10)), "written");
            T.True(File.Exists(ed.Recovery.DataFilePath), "file exists when the call returns");
            T.False(ed.SaveRecoveryCopyNow(TimeSpan.FromSeconds(10)), "unchanged since");
        });

        T.Run("copy, cut and paste move artwork between places and layers", () =>
        {
            using var dir = new TempDir();
            using var ed = NewEditor(dir);
            ed.NewProject(100, 100, 12, BackgroundSettings.White);
            var d = ed.Document;
            var first = d.ActiveLayer;
            Paint(d, new IntRect(10, 10, 20, 20), Red);
            d.SelectRect(new IntRect(10, 10, 20, 20));

            T.True(ed.Copy(), "copy");
            T.True(ed.Clipboard.HasImage, "clipboard filled");
            T.Equal(20, ed.Clipboard.Image!.Width);
            T.PixelIs(Red, PixelOf(first, 0, 15, 15), "copy leaves the original");

            var second = d.AddLayer("Second")!;
            T.True(ed.Paste(ed.Clipboard.Image!, 70, 70), "paste");
            T.PixelIs(Red, PixelOf(second, 0, 70, 70), "pasted at the chosen centre");
            T.PixelIs(0u, PixelOf(second, 0, 5, 5), "not elsewhere");
            T.Equal(new IntRect(60, 60, 20, 20), d.Selection!.Value);

            d.SetActiveLayer(first);
            d.SelectRect(new IntRect(10, 10, 20, 20));
            T.True(ed.Cut(), "cut");
            T.PixelIs(0u, PixelOf(first, 0, 15, 15), "cut removes the pixels");
            T.True(ed.Clipboard.HasImage, "cut fills the clipboard");
            d.Undo();
            T.PixelIs(Red, PixelOf(first, 0, 15, 15), "cut can be undone");
        });

        T.Run("copying nothing, or pasting onto a locked layer, says so instead of failing silently", () =>
        {
            using var dir = new TempDir();
            using var ed = NewEditor(dir);
            var messages = new List<string>();
            ed.Status += messages.Add;
            T.False(ed.Copy(), "empty layer");
            T.True(messages.Any(m => m.Contains("Nothing to copy")), "explained");
            Paint(ed.Document, new IntRect(0, 0, 8, 8), Red);
            ed.Document.SelectRect(new IntRect(0, 0, 8, 8));
            T.True(ed.Copy());
            ed.Document.SetLayerLocked(ed.Document.ActiveLayer, true);
            messages.Clear();
            T.False(ed.Paste(ed.Clipboard.Image!, 30, 30), "locked layer refuses");
            T.True(messages.Any(m => m.Contains("locked") || m.Contains("cannot be drawn")), "explained");
            T.False(ed.Cut(), "cut refuses on a locked layer");
        });

        T.Run("pasting a picture bigger than the canvas keeps what fits", () =>
        {
            using var dir = new TempDir();
            using var ed = NewEditor(dir);
            ed.NewProject(50, 50, 12, BackgroundSettings.White);
            var big = new PixelBuffer(200, 200);
            big.Fill(Blue);
            T.True(ed.Paste(big, 25, 25));
            T.PixelIs(Blue, PixelOf(ed.Document.ActiveLayer, 0, 0, 0));
            T.PixelIs(Blue, PixelOf(ed.Document.ActiveLayer, 0, 49, 49));
            T.Equal(new IntRect(0, 0, 50, 50), ed.Document.Selection!.Value);
        });

        T.Run("the eyedropper updates the colours and the recent list", () =>
        {
            using var dir = new TempDir();
            using var ed = NewEditor(dir);
            ed.Tools.Context.ColorPicked(new ArgbColor(255, 1, 2, 3), false);
            ed.Tools.Context.ColorPicked(new ArgbColor(255, 9, 8, 7), true);
            T.Equal(new ArgbColor(255, 1, 2, 3), ed.ToolSettings.PrimaryColor);
            T.Equal(new ArgbColor(255, 9, 8, 7), ed.ToolSettings.SecondaryColor);
            T.Equal("#080709".Length, ed.Settings.RecentColors[0].Length);
            T.Equal("#090807", ed.Settings.RecentColors[0]);
            T.Equal("#010203", ed.Settings.RecentColors[1]);
        });

        T.Run("tool options and colours are remembered between runs", () =>
        {
            using var dir = new TempDir();
            using (var ed = NewEditor(dir))
            {
                ed.ToolSettings.Brush.Size = 33;
                ed.ToolSettings.Brush.Opacity = 0.5;
                ed.ToolSettings.PrimaryColor = new ArgbColor(255, 200, 100, 50);
                ed.Document.AutoKeyframe = false;
                T.True(ed.PersistSettings(out string? error), error ?? "");
            }
            using var again = NewEditor(dir);
            T.Near(33, again.ToolSettings.Brush.Size, 1e-9);
            T.Near(0.5, again.ToolSettings.Brush.Opacity, 1e-9);
            T.Equal(new ArgbColor(255, 200, 100, 50), again.ToolSettings.PrimaryColor);
            T.False(again.Document.AutoKeyframe, "auto keyframe setting restored");
        });

        T.Run("background text round-trips", () =>
        {
            T.Equal(BackgroundMode.White, Editor.ParseBackground("White").Mode);
            T.Equal(BackgroundMode.Transparent, Editor.ParseBackground("transparent").Mode);
            T.Equal(BackgroundMode.White, Editor.ParseBackground("garbage").Mode);
            var custom = Editor.ParseBackground("#336699");
            T.Equal(BackgroundMode.Custom, custom.Mode);
            T.Equal("#336699", Editor.BackgroundToText(custom));
        });
    }

    // ------------------------------------------------------------------ playback

    private static void PlaybackTests()
    {
        T.Suite("App layer: playback in the editor");

        long now = 0;
        PlaybackEngine Clocked() => new(() => Interlocked.Read(ref now), 1000);

        Editor Prepare(TempDir dir, out Layer layer, int frames = 4, bool loop = true)
        {
            Interlocked.Exchange(ref now, 0);
            var ed = NewEditor(dir, Clocked());
            ed.NewProject(40, 30, 10, BackgroundSettings.Transparent);
            var d = ed.Document;
            layer = d.ActiveLayer;
            d.SetFrameCount(frames);
            uint[] colors = { Red, Green, Blue, White };
            for (int f = 0; f < frames; f++)
            {
                d.GoToFrame(f);
                d.InsertBlankKeyframe(layer, f);
                Paint(d, new IntRect(0, 0, 10, 10), colors[f % 4]);
            }
            d.SetLoop(loop);
            d.GoToFrame(0);
            return ed;
        }

        static void WaitForCache(Editor ed, int frame)
        {
            for (int i = 0; i < 400; i++)
            {
                if (ed.PlaybackCache!.TryGetCached(frame, out _)) return;
                Thread.Sleep(5);
            }
            throw new Exception($"frame {frame} was not prepared in time");
        }

        T.Run("playing steps through the frames at the project's frame rate", () =>
        {
            using var dir = new TempDir();
            using var ed = Prepare(dir, out _);
            ed.StartPlayback();
            T.True(ed.IsPlaying, "playing");
            T.Equal(0, ed.Playback.CurrentFrame);
            WaitForCache(ed, 1);
            WaitForCache(ed, 2);
            Interlocked.Exchange(ref now, 100); // 10 fps: one frame later
            var t1 = ed.TickPlayback();
            T.True(t1.FrameChanged, "advanced");
            T.Equal(1, t1.Frame);
            T.True(t1.Image != null, "picture ready");
            T.PixelIs(Green, t1.Image!.GetPixel(2, 2), "frame 1 is green");
            Interlocked.Exchange(ref now, 200);
            T.Equal(2, ed.TickPlayback().Frame);
            Interlocked.Exchange(ref now, 250);
            T.False(ed.TickPlayback().FrameChanged, "no change within the same frame period");
            Interlocked.Exchange(ref now, 400);
            T.Equal(0, ed.TickPlayback().Frame);
        });

        T.Run("pause keeps the frame, stop goes back to where playback began", () =>
        {
            using var dir = new TempDir();
            using var ed = Prepare(dir, out _);
            ed.Document.GoToFrame(1);
            ed.StartPlayback();
            Interlocked.Exchange(ref now, 200);
            ed.TickPlayback();
            T.Equal(3, ed.Playback.CurrentFrame);
            ed.PausePlayback();
            T.False(ed.IsPlaying, "paused");
            T.Equal(3, ed.Document.CurrentFrame);
            ed.StartPlayback();
            Interlocked.Exchange(ref now, 300);
            ed.TickPlayback();
            ed.StopPlayback();
            T.Equal(3, ed.Document.CurrentFrame, "stop returns to the start frame of the last run");
        });

        T.Run("a non-looping animation stops at the end and shows the last frame", () =>
        {
            using var dir = new TempDir();
            using var ed = Prepare(dir, out _, frames: 3, loop: false);
            ed.StartPlayback();
            Interlocked.Exchange(ref now, 1000);
            var tick = ed.TickPlayback();
            T.False(ed.IsPlaying, "stopped by itself");
            T.True(tick.FrameChanged, "reported");
            T.Equal(2, ed.Document.CurrentFrame);
        });

        T.Run("playback shows the edits made since the last run", () =>
        {
            using var dir = new TempDir();
            using var ed = Prepare(dir, out var layer);
            ed.StartPlayback();
            ed.PausePlayback();
            ed.Document.GoToFrame(1);
            ed.Document.SetActiveLayer(layer);
            Paint(ed.Document, new IntRect(20, 20, 5, 5), Blue);
            ed.Document.GoToFrame(0);
            ed.StartPlayback();
            WaitForCache(ed, 1);
            T.True(ed.PlaybackCache!.TryGetCached(1, out var frame1), "cached");
            T.PixelIs(Blue, frame1.GetPixel(22, 22), "new drawing is in the player");
        });

        T.Run("a single-frame project plays without trouble", () =>
        {
            using var dir = new TempDir();
            using var ed = Prepare(dir, out _, frames: 1);
            ed.StartPlayback();
            Interlocked.Exchange(ref now, 5000);
            ed.TickPlayback();
            ed.StopPlayback();
            T.Equal(0, ed.Document.CurrentFrame);
        });

        T.Run("opening another project while playing stops playback", () =>
        {
            using var dir = new TempDir();
            using var ed = Prepare(dir, out _);
            ed.StartPlayback();
            ed.NewProject(10, 10, 12, BackgroundSettings.White);
            T.False(ed.IsPlaying, "stopped");
            T.True(ed.PlaybackCache == null, "old frames released");
        });
    }

    // ------------------------------------------------------------------ settings additions

    private static void SettingsTests()
    {
        T.Suite("App layer: settings additions");

        T.Run("custom colours are kept, de-duplicated and limited", () =>
        {
            using var dir = new TempDir();
            var m = new SettingsManager(dir.P("s"));
            m.Load();
            T.True(m.AddCustomColor("#112233"));
            T.False(m.AddCustomColor("#112233"), "duplicate");
            T.False(m.AddCustomColor("#112233".ToLowerInvariant()), "duplicate in other case");
            for (int i = 0; i < 50; i++) m.AddCustomColor($"#00{i:X2}00");
            T.Equal(AppSettings.MaxCustomColors, m.Settings.CustomColors.Count);
            m.RemoveCustomColor("#112233");
            T.False(m.Settings.CustomColors.Contains("#112233"), "removed");
            T.True(m.Save(out string? error), error ?? "");
            var again = new SettingsManager(dir.P("s"));
            again.Load();
            T.Equal(m.Settings.CustomColors.Count, again.Settings.CustomColors.Count);
        });

        T.Run("a new-project size that is too big in total falls back to the default instead of breaking start-up", () =>
        {
            using var dir = new TempDir();
            var m = new SettingsManager(dir.P("s"));
            m.Load();
            m.Settings.NewProjectWidth = 8192; // each side is allowed, but 8192 x 8192 is more pixels than the program holds
            m.Settings.NewProjectHeight = 8192;
            m.Save(out _);

            var again = new SettingsManager(dir.P("s"));
            again.Load();
            T.True(ProjectLimits.IsValidSize(again.Settings.NewProjectWidth, again.Settings.NewProjectHeight, out _), "size is usable");
            using var ed = new Editor(again, new RecoveryManager(dir.P("rec")));
            T.True(ed.Document.CanvasWidth > 0, "an editor can be created from these settings");

            var direct = new AppSettings { NewProjectWidth = 100000, NewProjectHeight = -5 };
            direct.Normalize();
            T.True(ProjectLimits.IsValidSize(direct.NewProjectWidth, direct.NewProjectHeight, out _), "extreme values are clamped");
        });

        T.Run("the recent list can be read without touching the file system", () =>
        {
            using var dir = new TempDir();
            var m = new SettingsManager(dir.P("s"));
            m.Load();
            string real = dir.P("real.animdraw");
            File.WriteAllText(real, "x");
            string gone = dir.P("gone.animdraw");
            m.AddRecent(gone);
            m.AddRecent(real);
            T.Equal(2, m.GetRecent().Count);
            T.Equal(Path.GetFullPath(real), m.GetRecent()[0]);
            T.Equal(1, m.GetRecentExisting().Count);
        });

        T.Run("confirmation setting defaults to on and survives a reload", () =>
        {
            using var dir = new TempDir();
            var m = new SettingsManager(dir.P("s"));
            m.Load();
            T.True(m.Settings.ConfirmDestructive, "default on");
            m.Settings.ConfirmDestructive = false;
            m.Save(out _);
            var again = new SettingsManager(dir.P("s"));
            again.Load();
            T.False(again.Settings.ConfirmDestructive, "kept off");
        });
    }
}
