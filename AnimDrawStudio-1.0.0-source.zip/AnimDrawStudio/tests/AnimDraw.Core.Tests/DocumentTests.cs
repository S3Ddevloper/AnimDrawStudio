using AnimDraw.Core.Editing;
using AnimDraw.Core.Geometry;
using AnimDraw.Core.Imaging;
using AnimDraw.Core.Model;
using static AnimDraw.Core.Tests.Helpers;

namespace AnimDraw.Core.Tests;

public static class DocumentTests
{
    public static void RunAll()
    {
        T.Suite("Tiled surface");
        T.Run("pixels round-trip through tiles", () =>
        {
            var s = new TiledSurface(300, 200);
            var rec = new TileRecorder();
            s.GetTileForWrite(s.TileIndex(2, 1), rec).Data[5 * Tile.Size + 7] = Red;
            T.PixelIs(Red, s.GetPixel(2 * 128 + 7, 128 + 5));
            T.Equal(1, s.AllocatedTiles);
        });
        T.Run("clone is copy-on-write", () =>
        {
            var a = new TiledSurface(100, 100);
            a.BlendBuffer(Solid(10, 10, Red), 5, 5, null);
            var b = a.Clone();
            b.BlendBuffer(Solid(10, 10, Blue), 5, 5, null);
            T.PixelIs(Red, a.GetPixel(6, 6), "original unchanged");
            T.PixelIs(Blue, b.GetPixel(6, 6), "copy changed");
        });
        T.Run("edit finish drops blank and unchanged tiles", () =>
        {
            var s = new TiledSurface(256, 256);
            var rec = new TileRecorder();
            s.GetTileForWrite(0, rec);
            T.Equal(0, s.Finish(rec).Count);
            T.Equal(0, s.AllocatedTiles);
        });
        T.Run("content bounds", () =>
        {
            var s = new TiledSurface(500, 500);
            s.BlendBuffer(Solid(20, 10, Green), 130, 260, null);
            T.Equal(new IntRect(130, 260, 20, 10), s.GetContentBounds());
        });
        T.Run("resized moves pixels across tile borders", () =>
        {
            var s = new TiledSurface(300, 300);
            s.BlendBuffer(Solid(30, 30, Red), 120, 120, null);
            var r = s.Resized(400, 400, 100, 50);
            T.Equal(new IntRect(220, 170, 30, 30), r.GetContentBounds());
            T.PixelIs(Red, r.GetPixel(250 - 1, 200 - 1));
        });

        T.Suite("Document: drawing and history");
        T.Run("new document defaults", () =>
        {
            var d = NewDoc();
            T.Equal(1, d.Project.Layers.Count);
            T.Equal(1, d.FrameCount);
            T.Equal(0, d.CurrentFrame);
            T.False(d.IsDirty);
        });
        T.Run("paint, undo, redo", () =>
        {
            var d = NewDoc();
            T.True(Paint(d, new IntRect(10, 10, 8, 8), Red));
            T.PixelIs(Red, PixelOf(d.ActiveLayer, 0, 12, 12));
            T.True(d.IsDirty);
            T.True(d.Undo());
            T.PixelIs(0, PixelOf(d.ActiveLayer, 0, 12, 12));
            T.False(d.IsDirty, "back at the saved state");
            T.True(d.Redo());
            T.PixelIs(Red, PixelOf(d.ActiveLayer, 0, 12, 12));
        });
        T.Run("empty edit makes no history and no keyframe", () =>
        {
            var d = NewDoc();
            var s = d.BeginEdit(out _)!;
            T.False(s.Commit("Nothing"));
            T.False(d.History.CanUndo);
            T.Equal(0, d.ActiveLayer.Track.Count);
        });
        T.Run("locked and hidden layers refuse edits with a message", () =>
        {
            var d = NewDoc();
            d.SetLayerLocked(d.ActiveLayer, true);
            T.True(d.BeginEdit(out string? err) == null && err != null && err.Contains("locked"));
            d.SetLayerLocked(d.ActiveLayer, false);
            d.SetLayerVisible(d.ActiveLayer, false);
            T.True(d.BeginEdit(out err) == null && err != null && err.Contains("hidden"));
        });
        T.Run("saved marker follows undo and redo", () =>
        {
            var d = NewDoc();
            Paint(d, new IntRect(0, 0, 4, 4), Red);
            d.MarkSaved();
            T.False(d.IsDirty);
            Paint(d, new IntRect(10, 0, 4, 4), Blue);
            T.True(d.IsDirty);
            d.Undo();
            T.False(d.IsDirty);
            d.Undo();
            T.True(d.IsDirty);
            d.Redo();
            T.False(d.IsDirty);
        });
        T.Run("selection clips drawing", () =>
        {
            var d = NewDoc();
            d.SelectRect(new IntRect(0, 0, 10, 10));
            var s = d.BeginEdit(out _)!;
            T.Equal(new IntRect(0, 0, 10, 10), s.Clip);
            s.Commit("x");
        });

        T.Suite("Document: layers");
        T.Run("layers keep their own artwork", () =>
        {
            var d = NewDoc();
            var l1 = d.ActiveLayer;
            Paint(d, new IntRect(5, 5, 10, 10), Red);
            var l2 = d.AddLayer()!;
            T.True(ReferenceEquals(d.ActiveLayer, l2));
            Paint(d, new IntRect(8, 8, 10, 10), Blue);
            T.PixelIs(Red, PixelOf(l1, 0, 6, 6));
            T.PixelIs(0, PixelOf(l2, 0, 6, 6));
            T.PixelIs(Blue, PixelOf(l2, 0, 12, 12));
            T.PixelIs(Red, PixelOf(l1, 0, 12, 12), "lower layer untouched by upper layer edit");
        });
        T.Run("duplicated layer is independent", () =>
        {
            var d = NewDoc();
            var src = d.ActiveLayer;
            Paint(d, new IntRect(5, 5, 10, 10), Red);
            var copy = d.DuplicateLayer(src)!;
            T.Equal("Layer 1 copy", copy.Name);
            Paint(d, new IntRect(5, 5, 4, 4), Green); // edits the copy (now active)
            T.PixelIs(Green, PixelOf(copy, 0, 6, 6));
            T.PixelIs(Red, PixelOf(src, 0, 6, 6), "original must not change");
            d.Undo();
            T.PixelIs(Red, PixelOf(copy, 0, 6, 6));
            T.PixelIs(Red, PixelOf(src, 0, 6, 6));
        });
        T.Run("delete layer is undoable and keeps one layer", () =>
        {
            var d = NewDoc();
            var l1 = d.ActiveLayer;
            T.False(d.DeleteLayer(l1), "cannot delete the last layer");
            var l2 = d.AddLayer()!;
            Paint(d, new IntRect(0, 0, 5, 5), Red);
            T.True(d.DeleteLayer(l2));
            T.Equal(1, d.Project.Layers.Count);
            T.True(d.Undo());
            T.Equal(2, d.Project.Layers.Count);
            T.PixelIs(Red, PixelOf(l2, 0, 1, 1), "deleted layer keeps artwork when restored");
        });
        T.Run("reorder, rename, visibility, lock, opacity", () =>
        {
            var d = NewDoc();
            var a = d.ActiveLayer;
            var b = d.AddLayer()!;
            T.Equal(1, d.Project.IndexOfLayer(b));
            T.True(d.MoveLayerDown(b));
            T.Equal(0, d.Project.IndexOfLayer(b));
            T.True(d.RenameLayer(a, "  Ink  "));
            T.Equal("Ink", a.Name);
            T.False(d.RenameLayer(a, "   "));
            T.True(d.SetLayerVisible(a, false));
            T.True(d.SetLayerLocked(a, true));
            T.True(d.SetLayerOpacity(a, 0.4));
            T.Near(0.4, a.Opacity, 1e-9);
            d.Undo(); d.Undo(); d.Undo(); d.Undo(); d.Undo();
            T.Equal("Layer 1", a.Name);
            T.True(a.Visible);
            T.False(a.Locked);
            T.Near(1.0, a.Opacity, 1e-9);
        });
        T.Run("opacity drag collapses into one undo step", () =>
        {
            var d = NewDoc();
            var l = d.ActiveLayer;
            for (int i = 1; i <= 10; i++) d.SetLayerOpacity(l, 1 - i * 0.05, coalesce: true);
            T.Equal(1, d.History.UndoCount);
            d.Undo();
            T.Near(1.0, l.Opacity, 1e-9);
        });
        T.Run("merge down combines artwork", () =>
        {
            var d = NewDoc();
            var low = d.ActiveLayer;
            Paint(d, new IntRect(0, 0, 10, 10), Red);
            var up = d.AddLayer()!;
            Paint(d, new IntRect(5, 5, 10, 10), Blue);
            T.True(d.MergeDown(up));
            T.Equal(1, d.Project.Layers.Count);
            T.PixelIs(Red, PixelOf(low, 0, 2, 2));
            T.PixelIs(Blue, PixelOf(low, 0, 8, 8));
            d.Undo();
            T.Equal(2, d.Project.Layers.Count);
            T.PixelIs(Red, PixelOf(low, 0, 8, 8), "lower layer restored");
        });

        T.Suite("Document: frames and keyframes");
        T.Run("add blank frame gives the active layer a new keyframe", () =>
        {
            var d = NewDoc();
            Paint(d, new IntRect(0, 0, 5, 5), Red);
            T.True(d.InsertBlankFrameAfter(0));
            T.Equal(2, d.FrameCount);
            T.Equal(1, d.CurrentFrame);
            T.True(d.ActiveLayer.Track.IsKeyframe(1));
            T.PixelIs(0, PixelOf(d.ActiveLayer, 1, 1, 1));
            T.PixelIs(Red, PixelOf(d.ActiveLayer, 0, 1, 1));
        });
        T.Run("other layers hold across an added frame", () =>
        {
            var d = NewDoc(frames: 2);
            var bg = d.ActiveLayer;
            Paint(d, new IntRect(0, 0, 5, 5), Red);
            d.AddLayer();
            d.InsertBlankFrameAfter(0);
            T.Equal(3, d.FrameCount);
            T.PixelIs(Red, PixelOf(bg, 1, 1, 1), "background still shows on the new frame");
            T.PixelIs(Red, PixelOf(bg, 2, 1, 1));
        });
        T.Run("duplicate frame copies independently", () =>
        {
            var d = NewDoc();
            Paint(d, new IntRect(0, 0, 6, 6), Red);
            T.True(d.DuplicateFrame(0));
            T.Equal(1, d.CurrentFrame);
            T.PixelIs(Red, PixelOf(d.ActiveLayer, 1, 2, 2));
            Paint(d, new IntRect(0, 0, 3, 3), Blue);
            T.PixelIs(Blue, PixelOf(d.ActiveLayer, 1, 1, 1));
            T.PixelIs(Red, PixelOf(d.ActiveLayer, 0, 1, 1), "frame 0 untouched");
        });
        T.Run("drawing on a held frame creates a keyframe (auto-keyframe)", () =>
        {
            var d = NewDoc(frames: 5);
            Paint(d, new IntRect(0, 0, 6, 6), Red);
            d.GoToFrame(3);
            T.False(d.ActiveLayer.Track.IsKeyframe(3));
            Paint(d, new IntRect(10, 10, 4, 4), Blue);
            T.True(d.ActiveLayer.Track.IsKeyframe(3));
            T.PixelIs(Red, PixelOf(d.ActiveLayer, 3, 2, 2), "copied the held drawing");
            T.PixelIs(Blue, PixelOf(d.ActiveLayer, 3, 11, 11));
            T.PixelIs(0, PixelOf(d.ActiveLayer, 2, 11, 11), "earlier frames unchanged");
            d.Undo();
            T.False(d.ActiveLayer.Track.IsKeyframe(3), "undo removes the auto keyframe");
            d.Redo();
            T.True(d.ActiveLayer.Track.IsKeyframe(3));
        });
        T.Run("without auto-keyframe a held drawing is edited in place", () =>
        {
            var d = NewDoc(frames: 5);
            d.AutoKeyframe = false;
            Paint(d, new IntRect(0, 0, 6, 6), Red);
            d.GoToFrame(3);
            Paint(d, new IntRect(10, 10, 4, 4), Blue);
            T.False(d.ActiveLayer.Track.IsKeyframe(3));
            T.PixelIs(Blue, PixelOf(d.ActiveLayer, 0, 11, 11), "the shared drawing changed");
        });
        T.Run("delete frame keeps held drawings aligned", () =>
        {
            var d = NewDoc(frames: 6);
            var l = d.ActiveLayer;
            d.InsertKeyframe(l, 0);
            Paint(d, new IntRect(0, 0, 4, 4), Red);          // key 0 -> red
            d.GoToFrame(2);
            d.InsertBlankKeyframe(l, 2);
            Paint(d, new IntRect(0, 0, 4, 4), Green);        // key 2 -> green, holds 2..5
            T.True(d.DeleteFrame(2));                         // remove frame 2
            T.Equal(5, d.FrameCount);
            T.PixelIs(Green, PixelOf(l, 2, 1, 1), "green moved up and still covers its span");
            T.PixelIs(Green, PixelOf(l, 4, 1, 1));
            T.PixelIs(Red, PixelOf(l, 1, 1, 1));
            T.True(d.Undo());
            T.Equal(6, d.FrameCount);
            T.True(l.Track.IsKeyframe(2));
        });
        T.Run("delete frame: key whose successor is another key is dropped", () =>
        {
            var d = NewDoc(frames: 4);
            var l = d.ActiveLayer;
            d.InsertKeyframe(l, 0); Paint(d, new IntRect(0, 0, 4, 4), Red);
            d.GoToFrame(1); d.InsertBlankKeyframe(l, 1); Paint(d, new IntRect(0, 0, 4, 4), Green);
            d.GoToFrame(2); d.InsertBlankKeyframe(l, 2); Paint(d, new IntRect(0, 0, 4, 4), Blue);
            d.DeleteFrame(1);
            T.Equal(3, d.FrameCount);
            T.PixelIs(Red, PixelOf(l, 0, 1, 1));
            T.PixelIs(Blue, PixelOf(l, 1, 1, 1), "blue is now frame 1");
            T.True(l.Track.IsKeyframe(1));
            T.Equal(2, l.Track.Count);
        });
        T.Run("cannot delete the only frame", () =>
        {
            var d = NewDoc();
            T.False(d.DeleteFrame(0));
        });
        T.Run("keyframe insert and remove", () =>
        {
            var d = NewDoc(frames: 4);
            var l = d.ActiveLayer;
            Paint(d, new IntRect(0, 0, 4, 4), Red);
            T.True(d.InsertKeyframe(l, 2));
            T.PixelIs(Red, PixelOf(l, 2, 1, 1), "new keyframe starts as a copy");
            T.False(d.InsertKeyframe(l, 2), "already a keyframe");
            T.True(d.RemoveKeyframe(l, 2));
            T.False(l.Track.IsKeyframe(2));
            T.False(d.RemoveKeyframe(l, 2));
        });
        T.Run("shrinking frame count removes later keyframes, undo restores", () =>
        {
            var d = NewDoc(frames: 10);
            d.GoToFrame(7);
            Paint(d, new IntRect(0, 0, 4, 4), Red);
            T.True(d.SetFrameCount(5));
            T.Equal(5, d.FrameCount);
            T.False(d.ActiveLayer.Track.IsKeyframe(7));
            d.Undo();
            T.Equal(10, d.FrameCount);
            T.PixelIs(Red, PixelOf(d.ActiveLayer, 7, 1, 1));
        });
        T.Run("navigation is clamped", () =>
        {
            var d = NewDoc(frames: 3);
            d.GoToFrame(99);
            T.Equal(2, d.CurrentFrame);
            d.GoToFrame(-4);
            T.Equal(0, d.CurrentFrame);
        });

        T.Suite("Document: selection, clipboard, canvas size");
        T.Run("copy, cut, paste, duplicate", () =>
        {
            var d = NewDoc();
            Paint(d, new IntRect(10, 10, 10, 10), Red);
            d.SelectRect(new IntRect(10, 10, 10, 10));
            var copy = d.CopySelection();
            T.True(copy != null && copy.Width == 10 && copy.GetPixel(0, 0) == Red);
            T.True(d.CutSelection(out var cut));
            T.PixelIs(0, PixelOf(d.ActiveLayer, 0, 12, 12));
            T.True(cut != null);
            T.True(d.PasteBuffer(cut!, 30, 20));
            T.PixelIs(Red, PixelOf(d.ActiveLayer, 0, 32, 22));
            T.Equal(new IntRect(30, 20, 10, 10), d.Selection);
            T.True(d.DuplicateSelection(5, 5));
            T.PixelIs(Red, PixelOf(d.ActiveLayer, 0, 36, 26));
            T.PixelIs(Red, PixelOf(d.ActiveLayer, 0, 32, 22), "original stays");
        });
        T.Run("clear frame clears all unlocked layers as one step", () =>
        {
            var d = NewDoc();
            var a = d.ActiveLayer;
            Paint(d, new IntRect(0, 0, 5, 5), Red);
            var b = d.AddLayer()!;
            Paint(d, new IntRect(0, 0, 5, 5), Blue);
            d.SetLayerLocked(a, true);
            int before = d.History.UndoCount;
            T.True(d.ClearFrame());
            T.PixelIs(Red, PixelOf(a, 0, 1, 1), "locked layer untouched");
            T.PixelIs(0, PixelOf(b, 0, 1, 1));
            T.Equal(before + 1, d.History.UndoCount);
            d.Undo();
            T.PixelIs(Blue, PixelOf(b, 0, 1, 1));
        });
        T.Run("resize canvas crop/extend with anchor, and undo", () =>
        {
            var d = NewDoc(40, 30);
            Paint(d, new IntRect(0, 0, 10, 10), Red);
            T.True(d.ResizeCanvas(80, 60, CanvasResizeMode.CropOrExtend, 2, 2));
            T.Equal(80, d.Project.Width);
            T.PixelIs(Red, PixelOf(d.ActiveLayer, 0, 40 + 2, 30 + 2));
            T.PixelIs(0, PixelOf(d.ActiveLayer, 0, 2, 2));
            d.Undo();
            T.Equal(40, d.Project.Width);
            T.PixelIs(Red, PixelOf(d.ActiveLayer, 0, 2, 2));
        });
        T.Run("resize canvas scaling keeps content", () =>
        {
            var d = NewDoc(40, 40);
            Paint(d, new IntRect(0, 0, 40, 40), Red);
            T.True(d.ResizeCanvas(20, 20, CanvasResizeMode.ScaleContent));
            T.PixelIs(Red, PixelOf(d.ActiveLayer, 0, 10, 10), tolerance: 1);
            T.Equal(20, d.Project.Height);
        });
        T.Run("snapshot is isolated from later edits", () =>
        {
            var d = NewDoc();
            Paint(d, new IntRect(0, 0, 5, 5), Red);
            var snap = d.CreateSnapshot();
            Paint(d, new IntRect(0, 0, 5, 5), Blue);
            T.PixelIs(Red, PixelOf(snap.Layers[0], 0, 1, 1));
            T.PixelIs(Blue, PixelOf(d.ActiveLayer, 0, 1, 1));
        });
    }

    private static PixelBuffer Solid(int w, int h, uint color)
    {
        var b = new PixelBuffer(w, h);
        b.Fill(color);
        return b;
    }
}
