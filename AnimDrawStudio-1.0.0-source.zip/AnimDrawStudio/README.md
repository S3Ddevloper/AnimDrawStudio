# AnimDraw Studio

A 2D drawing and frame-by-frame animation program for Windows 10 and 11, written in C# on .NET 8 with WPF.
Think of a small mix of Krita (painting), Pencil2D (frame-by-frame animation) and Adobe Animate (timeline, keyframes,
onion skin, export).

- Draw on layers with a brush, pencil, eraser, shapes, fill and selection tools. A mouse or a pen tablet both work.
- Build animations frame by frame on a timeline, with keyframes, onion skin and a separate preview window.
- Save projects as `.animdraw` files, recover unsaved work after a crash, and export to GIF, MP4, PNG, PNG sequences and
  sprite sheets.

> **Read this first: what has and has not been tested**
>
> The drawing and animation engine (`AnimDraw.Core`) is covered by **250 automated tests, all passing** (they ran on
> Linux with the .NET 8 SDK). The WPF user interface (`AnimDraw.App`) was written and checked in a Linux environment
> that cannot run Windows programs, so **the program window has never been started, and the Release `.exe` and the
> installer have never been built or run by the author of this code.** The user-interface code was checked in four ways
> only: it compiles against the real WPF reference API, the XAML is checked by a script (element and property names,
> theme keys, icon path syntax, shortcut key names), the code was read through for mistakes, and the packaging scripts
> were read through. See [Testing status](#testing-status) for the exact list, and
> [`docs/WINDOWS-TEST-CHECKLIST.md`](docs/WINDOWS-TEST-CHECKLIST.md) for a step-by-step list you can follow to test the
> first Windows build in about 30 minutes. Expect to find some bugs in the user interface; the engine underneath is the
> well-tested part.

---

## Contents

1. [Features](#features)
2. [Build and run](#build-and-run)
3. [Make the .exe and the installer](#make-the-exe-and-the-installer)
4. [Using the program](#using-the-program)
5. [Keyboard shortcuts](#keyboard-shortcuts)
6. [Exporting, and FFmpeg for MP4](#exporting-and-ffmpeg-for-mp4)
7. [Project files, recovery and where things are stored](#project-files-recovery-and-where-things-are-stored)
8. [Limits](#limits)
9. [How the code is organised](#how-the-code-is-organised)
10. [Testing status](#testing-status)
11. [Differences from the original brief](#differences-from-the-original-brief)
12. [Troubleshooting](#troubleshooting)
13. [Licence](#licence)

---

## Features

Everything listed here is implemented in the source code. "Tested" is explained in [Testing status](#testing-status).

### Canvas and tools

| Area | What there is |
|---|---|
| Canvas | Sizes from 1 × 1 to 8192 × 8192 pixels (at most 50 megapixels in total). Memory is only used where something is drawn. Presets for HD, Full HD, 4K, square, portrait and pixel-art sizes. |
| Background | White, transparent (shown as a checkerboard) or any colour you choose. Can be changed later in Project Settings. |
| Zoom and pan | Mouse wheel zooms towards the pointer. Pan with Space + drag, the middle mouse button or the Hand tool. Zoom tool (click, Alt+click, right-click, or drag a rectangle). Fit, 100% and 200% commands, and zoom buttons with a list of presets in the status bar. Optional pixel grid. |
| Brush | Smooth freehand strokes. Size 1 to 500 px, opacity, hardness (soft to crisp edge), spacing, and smoothing (a stabiliser that trails behind the pointer). Overlapping dabs inside one stroke never build up beyond the chosen opacity. |
| Pencil | Hard, aliased pixels with optional "snap to pixels", for pixel art. |
| Eraser | Same engine as the brush. The back end of a pen erases. |
| Pen pressure | With a pen tablet, pressure can change the brush size and/or the opacity (two check boxes in the tool options). A mouse draws at full pressure. Touch input is treated like a mouse. |
| Shapes | Line, rectangle and ellipse. Outline, filled, or outline and fill. Line width up to 200 px. Shift keeps lines straight and makes squares and circles; Alt draws from the centre. |
| Fill | Paint bucket with tolerance, "grow" (spreads under line art so no light fringe is left), contiguous or everywhere, and a choice of the active layer or all visible layers. |
| Eyedropper | Left click sets the primary colour, right click the secondary one. Samples what you see or only the active layer. |
| Selection | Rectangular selection. The Move tool moves the selection (or everything on the active layer in this frame when nothing is selected); Alt drags a copy; Shift keeps to one axis. |
| Clipboard | Cut, copy, paste, paste in place and duplicate. Pictures are placed on the Windows clipboard as PNG, so other programs can paste them, and pictures copied elsewhere can be pasted in. Dropping a picture file on the window pastes it. |
| Clear | Clear the selection or the layer's drawing (Del), or clear the whole frame (Ctrl+Del). |
| Colour | Primary and secondary colour with swap (X). Colour square, hue bar, hex box and RGB boxes, a ready-made palette, recently used colours, and "My colours" for colours you want to keep. |
| Undo and redo | Up to 300 steps per session (fewer if the changes are very large: the history is capped at about 768 MB). Every step has a name that appears in the Edit menu. Layer, frame and canvas-size changes can be undone too. |

### Layers

New, rename, delete, duplicate, move up and down (by buttons or by dragging), merge down, hide and show, lock, opacity per
layer and an active layer. Each layer holds its own drawing in every frame, so changing one layer never touches another.
Up to 128 layers.

### Timeline and animation

- Frames: add, duplicate, delete, select. Frame numbers are shown. Up to 10,000 frames. *Add Frame* puts a new, blank
  drawing on the active layer; every other layer keeps showing what it showed, so a background layer carries on across
  the new frame. *Duplicate Frame* copies the drawings instead.
- Per-frame drawings. A drawing is held until the next keyframe; drawing on a held frame can make a keyframe
  automatically (switchable). Add keyframe (starts as a copy of what is shown), add blank keyframe, remove keyframe, jump
  to the previous or next keyframe.
- Playback: play, pause, stop, first, previous, next and last frame, frame rate (1 to 120 frames per second) and loop.
  Playback runs on its own clock and a background frame cache, so the window stays responsive.
- Onion skin: up to 5 earlier and 5 later frames, adjustable strength, optional red/blue tint. Onion skin is a drawing
  aid only and does not appear in playback or exports.
- Preview window: separate window with play/pause/stop, speed from 0.1× to 8×, zoom (Fit, 25% to 800%), a frame scrubber,
  the current frame number and time, and its own loop switch. It refreshes by itself when you edit.

### Export

Animated GIF, MP4 video (needs FFmpeg), one PNG, a PNG sequence (one numbered file per frame) and a sprite sheet (with an
optional `.json` file that says where every frame is). You choose the frame range, size, frame rate (GIF and MP4),
transparency (GIF and PNG kinds), quality (GIF and MP4), loop (GIF), scaling style (smooth or crisp pixels), the file or
folder, and the PNG compression level. Exports run in the background with a progress bar and a Cancel button. If FFmpeg is
missing the MP4 option explains that, offers to locate it and opens the download page; the other formats never need it.

### Projects and safety

- `.animdraw` project files (a ZIP with JSON and PNG files inside, so they are small and can be inspected).
- New, Open, Save, Save As, Open Recent, drag a project file onto the window to open it.
- Automatic recovery copies every few minutes (default 2, 0 turns it off) to a separate folder; after a crash or power
  cut the program offers to recover them at the next start. A recovery copy is also written when Windows logs off or shuts
  down while you have unsaved work.
- "Save changes?" questions before anything that would lose work (new, open, close, exit).
- Confirmation before deleting layers or frames and before clearing the canvas (can be switched off in Preferences).
- Errors are reported in plain language; technical details are written to a log folder.

### Interface

Menus File, Edit, View, Drawing, Animation, Layer, Export and Help. Tool palette on the left, canvas in the middle, Layers
and Colour panels on the right, tool options above the canvas, the timeline at the bottom and a status bar. Dark and light
themes (switchable while the program runs). Tooltips on the toolbar and panel buttons, with the shortcut where there is
one. Keyboard shortcuts for almost everything (see below).

---

## Build and run

You need **Windows 10 or Windows 11, 64-bit** (the .NET 8 runtime itself requires Windows 10 version 1607 or newer), and
one of:

- **Visual Studio 2022, version 17.8 or newer**, with the *.NET desktop development* workload, or
- the **.NET 8 SDK** (<https://dotnet.microsoft.com/download>) and any editor, with commands typed in a terminal.

Nothing else is needed. The program has no NuGet package dependencies of its own (see
[How the code is organised](#how-the-code-is-organised)); NuGet is only used by the SDK itself.

### In Visual Studio

1. Open `AnimDrawStudio.sln`.
2. Right-click **AnimDraw.App** in Solution Explorer and choose *Set as Startup Project*.
3. Pick **Release** (or Debug) in the toolbar and press **F5** (or Ctrl+F5 to run without the debugger).

Visual Studio restores and builds automatically.

### On the command line

Run these in the folder that contains `AnimDrawStudio.sln`:

```bat
dotnet restore AnimDrawStudio.sln
dotnet build AnimDrawStudio.sln -c Release
dotnet run --project src\AnimDraw.App\AnimDraw.App.csproj -c Release
```

The program is written to `src\AnimDraw.App\bin\Release\net8.0-windows\AnimDrawStudio.exe`. That plain build needs the
".NET 8 Desktop Runtime" on the PC; the next section makes one that needs nothing.

### Run the engine tests

```bat
dotnet run --project tests\AnimDraw.Core.Tests\AnimDraw.Core.Tests.csproj -c Release
```

The last line reads `Passed: 250   Failed: 0   Skipped: 0`. The exit code is not zero when a test fails. The tests need
no packages and no internet connection.

---

## Make the .exe and the installer

### One command

Double-click **`publish.cmd`**, or run it from a terminal in the solution folder:

```bat
publish.cmd
```

(`publish.cmd` calls `publish.ps1` with the PowerShell execution policy set for that one run, so you do not have to
change any Windows setting. You can also run `powershell -ExecutionPolicy Bypass -File .\publish.ps1`.)

It checks the SDK, restores, builds the Release configuration, runs the engine tests (a failing test stops the script),
and publishes **one self-contained file**:

```
publish\win-x64\AnimDrawStudio.exe
```

That file contains the .NET runtime, so it runs on a PC with no .NET installed. It is large (tens of megabytes, because it
carries .NET and WPF, which cannot be trimmed). **The first run needs an internet connection**: NuGet downloads the runtime
pack that is packed into the exe.

Options (put them after `publish.cmd`):

| Option | Meaning |
|---|---|
| `-Zip` | Also write `dist\AnimDrawStudio-1.0.0-win-x64.zip`. |
| `-Installer` | Also write `dist\AnimDrawStudio-Setup-1.0.0.exe` (needs [Inno Setup](https://jrsoftware.org/isdl.php) 6.3 or newer; see below). |
| `-SkipTests` | Do not run the engine tests first. |
| `-FrameworkDependent` | A small build (a few MB) that needs the ".NET 8 Desktop Runtime" on the PC. |
| `-ReadyToRun` | Pre-compile for a faster start (bigger file; downloads one more package). |
| `-Runtime win-arm64` | Build for Windows on ARM instead (not with `-Installer`). |
| `-FfmpegExe C:\path\ffmpeg.exe` | Copy FFmpeg into an `ffmpeg` folder beside the program so MP4 export works out of the box. Read the FFmpeg licence first (see [Licence](#licence)). |

Example: `publish.cmd -Zip -Installer`

### Installer

Install Inno Setup 6.3 or newer, then run `publish.cmd -Installer`. The setup program `dist\AnimDrawStudio-Setup-1.0.0.exe`
installs for the current user (no administrator rights needed; it also offers "all users"), adds a Start menu entry, an
optional desktop shortcut, and an optional file association for `.animdraw`. The script is `installer\AnimDrawStudio.iss`.
Uninstalling does not delete your settings, recovery copies or error reports.

### Build on GitHub

`.github\workflows\build.yml` builds on a Windows machine at GitHub, runs the tests, publishes, and uploads the zip and
the installer as a downloadable artifact. It only runs if you put this folder in a GitHub repository.

### Publishing from Visual Studio instead

*Build > Publish* also works: choose *Folder*, then in the profile settings choose target runtime `win-x64`,
deployment mode *Self-contained*, tick *Produce single file* and *Enable ReadyToRun* if you wish, and leave *Trim unused
code* **unticked** (WPF does not support trimming). `publish.ps1` uses exactly these settings, and it is the way that is
written down and repeatable.

---

## Using the program

1. **New project** (Ctrl+N): pick a size, frame rate and background. Settings are remembered for next time.
2. **Draw** on the canvas with the tool you picked in the toolbar on the left. The bar above the canvas shows the options
   of that tool. Right-click draws with the second colour.
3. **Layers** (right): the + button adds a layer, the eye hides it, the padlock locks it. Drag a layer to reorder it.
   Double-click a name or press F2 to rename. The slider sets the opacity of the active layer.
4. **Frames** (bottom): F5 adds a blank frame after the current one for the active layer (the other layers keep showing
   their drawing), Shift+F5 deletes it, Ctrl+Shift+D duplicates it. F6 makes a keyframe that starts as a copy of the drawing
   that is shown, F7 a blank keyframe. A drawing is held across the frames after its keyframe, and drawing on a held frame
   makes a keyframe by itself.
5. **Onion skin** (the onion button on the timeline) shows the neighbouring frames faintly so you can line the drawings
   up. Its settings are in *Animation > Onion Skin Settings*.
6. **Play** with Enter (Shift+Enter stops). *View > Preview Window* (Ctrl+P) opens a separate player with speed and zoom.
7. **Save** with Ctrl+S. **Export** with Ctrl+E.

Mouse, pen and other actions that are not in the menus:

| Action | How |
|---|---|
| Draw with the second colour | Right mouse button |
| Pan | Hold Space and drag, middle mouse button, or the Hand tool (H) |
| Zoom | Mouse wheel (towards the pointer); Zoom tool: click, Alt+click or right-click to zoom out, drag a rectangle |
| Scroll sideways / up and down | Shift + wheel / Alt + wheel |
| Straight line, square, circle | Hold Shift while dragging the Line, Rectangle or Ellipse tool |
| Shape from its centre | Hold Alt while dragging the Rectangle or Ellipse tool |
| Move a copy | Hold Alt while dragging with the Move tool |
| Nudge the selection | Arrow keys (Shift = 10 pixels). With nothing selected, Left and Right change the frame |
| Cancel | Esc stops playback, cancels the stroke being drawn, or removes the selection |
| Pick a colour | Eyedropper (I); Alt picks from the active layer only |
| Open a file | Drag an `.animdraw` project, or a picture, onto the window |

---

## Keyboard shortcuts

The same list is in the program under *Help > Keyboard Shortcuts* (F1).

**File**

| Command | Shortcut |
|---|---|
| New Project | `Ctrl+N` |
| Open Project | `Ctrl+O` |
| Save | `Ctrl+S` |
| Save As | `Ctrl+Shift+S` |
| Exit | `Alt+F4` |

**Edit**

| Command | Shortcut |
|---|---|
| Undo | `Ctrl+Z` |
| Redo | `Ctrl+Y` or `Ctrl+Shift+Z` |
| Cut | `Ctrl+X` |
| Copy | `Ctrl+C` |
| Paste | `Ctrl+V` |
| Paste in Place | `Ctrl+Shift+V` |
| Duplicate Selection | `Ctrl+D` |
| Select All | `Ctrl+A` |
| Deselect | `Ctrl+Shift+A` |
| Clear Selection / Layer Drawing | `Del` |
| Clear Canvas (all layers, this frame) | `Ctrl+Del` |
| Preferences | `Ctrl+,` |

**View**

| Command | Shortcut |
|---|---|
| Zoom In | `Ctrl+=` or `Ctrl+Num +` |
| Zoom Out | `Ctrl+-` or `Ctrl+Num -` |
| Fit Canvas to Window | `Ctrl+0` |
| Actual Size (100%) | `Ctrl+1` |
| Zoom 200% | `Ctrl+2` |
| Pixel Grid | `Ctrl+Shift+G` |
| Preview Window | `Ctrl+P` |

**Drawing**

| Command | Shortcut |
|---|---|
| Brush | `B` |
| Pencil | `P` |
| Eraser | `E` |
| Line | `L` |
| Rectangle | `R` |
| Ellipse | `O` |
| Fill | `G` |
| Eyedropper | `I` |
| Select | `M` |
| Move | `V` |
| Hand (pan) | `H` |
| Zoom Tool | `Z` |
| Swap Colours | `X` |
| Smaller Brush | `[` |
| Larger Brush | `]` |

**Animation**

| Command | Shortcut |
|---|---|
| Play / Pause | `Enter` |
| Stop | `Shift+Enter` |
| Loop | `Ctrl+L` |
| First Frame | `Home` |
| Previous Frame | `,` |
| Next Frame | `.` |
| Last Frame | `End` |
| Previous Keyframe | `Shift+,` |
| Next Keyframe | `Shift+.` |
| Add Frame | `F5` |
| Delete Frame | `Shift+F5` |
| Duplicate Frame | `Ctrl+Shift+D` |
| Add Keyframe | `F6` |
| Add Blank Keyframe | `F7` |
| Remove Keyframe | `Shift+F6` |
| Onion Skin | `Shift+O` |

**Layer**

| Command | Shortcut |
|---|---|
| New Layer | `Ctrl+Shift+N` |
| Delete Layer | `Ctrl+Shift+Del` |
| Duplicate Layer | `Ctrl+J` |
| Rename Layer | `F2` |
| Move Layer Up | `Ctrl+]` |
| Move Layer Down | `Ctrl+[` |
| Merge Down | `Ctrl+Shift+M` |

**Export and Help**

| Command | Shortcut |
|---|---|
| Export... | `Ctrl+E` |
| Keyboard Shortcuts | `F1` |

In the **Preview window**: Space play/pause, Left/Right previous/next frame, Home/End first/last frame, L loop,
F fit, 1 for 100%, + and - zoom, Esc stops playback (when it is not playing, Esc closes the window), Ctrl+wheel zoom,
double-click the picture to switch between fit and 100%.

---

## Exporting, and FFmpeg for MP4

Open *Export* (Ctrl+E), choose a format and its options. A summary under the options says what will be written (number of
frames, length in seconds, picture size, the file name) and what is wrong with the settings; the Export button stays off
until everything is usable. Existing files are never replaced without asking.

| Format | Notes |
|---|---|
| Animated GIF | Frame rate, loop, quality, transparency. GIF has 256 colours per frame, so smooth gradients can show banding. |
| MP4 video | H.264 through FFmpeg. No transparency (white or your background colour is used). |
| PNG image | One frame, with or without background. |
| PNG sequence | `prefix_0001.png`, `prefix_0002.png`, ... in a folder. |
| Sprite sheet | All frames in one PNG, with columns, spacing and an optional `.json` file of frame positions. |

### FFmpeg (MP4 only)

AnimDraw Studio does **not** include FFmpeg. GIF, PNG, PNG sequence and sprite sheet export are done by the program itself
and need nothing else. For MP4 it looks for `ffmpeg.exe` in this order and uses the first one that works:

1. the path you typed or browsed to in the export dialog or in Preferences (a file or the folder that contains it),
2. an `ffmpeg` folder (or `ffmpeg\bin`) next to `AnimDrawStudio.exe`, or `ffmpeg.exe` next to it,
3. any folder in the `PATH`.

The program runs `ffmpeg -version` to check it works and that it has an H.264 or MPEG-4 encoder. If FFmpeg is not found,
the MP4 export says so in plain words, offers *Browse...* and a link to <https://ffmpeg.org/download.html>, and every other
format keeps working. A Windows build such as the "essentials" build from gyan.dev or BtbN contains what is needed;
unzip it anywhere and point the program at `bin\ffmpeg.exe`.

---

## Project files, recovery and where things are stored

A `.animdraw` file is a ZIP archive:

```
manifest.json     format name and version
project.json      canvas size, frame rate, layers, keyframes, settings
cels/00001.png    one PNG per distinct drawing, cropped to its artwork
preview.png       a small picture of the first frame
```

Because every drawing is its own PNG, you can inspect a project with any ZIP program. Files are written to a temporary
name first and then swapped in, so a failed save does not damage the previous version. A file from a newer version of the
program, or a damaged file, is reported with a clear message instead of crashing.

| What | Where |
|---|---|
| Settings, recent files, custom colours | `%APPDATA%\AnimDraw Studio\settings.json` |
| Recovery copies (automatic backups) | `%LOCALAPPDATA%\AnimDraw Studio\Recovery` |
| Error reports | `%APPDATA%\AnimDraw Studio\logs` |

*Preferences* has buttons that open these folders. Recovery copies are removed when you save or close normally; they stay
only after a crash, a power cut or a Windows shutdown with unsaved work.

---

## Limits

| Thing | Limit |
|---|---|
| Canvas | 1 to 8192 pixels each way, 50 megapixels in total (a warning appears above 16 megapixels) |
| Layers | 128 |
| Frames | 10,000 |
| Frame rate | 1 to 120 frames per second |
| Onion skin | 5 frames before and 5 after |
| Brush size | 1 to 500 pixels |
| Export size | up to 8192 pixels each way |

A fully painted layer on a 4K canvas needs about 32 MB for each frame in which it has a drawing; empty areas use no memory.
Very large canvases with many layers and frames will need a lot of RAM.

---

## How the code is organised

```
AnimDrawStudio.sln
publish.cmd / publish.ps1       build, test and publish (self-contained single-file exe, zip, installer)
installer\AnimDrawStudio.iss    Inno Setup script
.github\workflows\build.yml     the same build on GitHub's Windows machines
docs\                           the Windows test checklist
src\AnimDraw.Core\              the engine: no UI, no NuGet packages, runs on any OS
tests\AnimDraw.Core.Tests\      250 tests with a tiny built-in test runner (no packages)
src\AnimDraw.App\               the WPF program (net8.0-windows, assembly AnimDrawStudio)
```

**AnimDraw.Core** (about 9,000 lines of C#)

| Folder | Contents |
|---|---|
| `Imaging` | Premultiplied-BGRA pixel type, 128 × 128 tiled copy-on-write surfaces (so big canvases and undo are cheap), colour type, resampling |
| `Drawing` | Brush settings and stroke engine (dabs, spacing, stabiliser, pressure), stroke buffer, flood fill |
| `Model` | Project, layers, cels and keyframe tracks, limits |
| `Editing` | Document with change events, edit sessions and the undo/redo history |
| `Tools` | Brush, pencil and eraser, the shape tool (line, rectangle, ellipse), fill, eyedropper, select, move |
| `Rendering` | Compositor (flattens the layers of a frame, with layer opacity and the background), onion-skin renderer, frame cache with a background prefetch thread |
| `Animation` | Playback engine: a clock-driven player that drops frames instead of slowing down |
| `Export` | GIF encoder and colour quantiser, PNG and sprite-sheet exporters, MP4 through FFmpeg, FFmpeg locator, export manager |
| `IO` | `.animdraw` reader/writer, recovery manager (lock files, autosave), PNG codec |
| `Settings` | Settings and the recent list, saved safely |
| `App` | The editor controller the window talks to, viewport maths, shortcut table |

**AnimDraw.App** (about 9,900 lines of C#, plus about 1,100 lines of XAML styles and colours) is only the user interface: the canvas control, the
timeline, the panels, the dialogs, the main window and the preview window. The windows and controls are built in C#
and styled by `Themes\Controls.xaml`, with the colours of the two themes in `Themes\Dark.xaml` and `Themes\Light.xaml`.
It does the drawing on screen through a `WriteableBitmap`, and all editing goes through `AnimDraw.Core`.

Design points:

- **Responsiveness.** Exports, loading and saving, the preview frame cache and the FFmpeg check run on background threads
  with progress and cancel. Playback never waits for a frame that is not ready.
- **Memory.** Surfaces are tiles; an empty tile costs nothing; a frame that repeats a drawing shares it. Undo stores only
  the tiles that changed.
- **Errors.** File, FFmpeg and clipboard problems are caught at the edge and shown in plain language. An unexpected
  exception is written to the error log and shown with a short message rather than closing the program.

---

## Testing status

### What was done

| Check | Result |
|---|---|
| Engine build (`AnimDraw.Core`) with the .NET 8 SDK | Builds with no errors or warnings |
| Engine tests (`AnimDraw.Core.Tests`) | **250 passed, 0 failed**. They cover drawing, layers, undo/redo, frames and keyframes, playback timing, onion skin, the project file format (including damaged files), recovery, settings, GIF/PNG/sprite-sheet/MP4 export (the MP4 tests ran against a real FFmpeg 6.1 on Linux: the video was decoded and its size, frame count and colours compared; a missing or fake FFmpeg is tested too), and the logic the windows use |
| WPF project (`AnimDraw.App`) compile check | Compiles with no errors or warnings against reference assemblies generated from the open-source `dotnet/wpf` 8.0 sources. This proves that every WPF call has a real, matching signature |
| XAML and theme check (a script) | 266 elements and 915 attributes checked; every theme key used in C# exists in both themes; all 140 icon path strings parse; all 67 keyboard shortcuts name real keys |
| Code review | All the user-interface code was read through for mistakes. An independent review of the main window found ten defects, all fixed (for example, closing the window while a "Save changes?" question was pending, and keyboard shortcuts firing while a menu was open). The canvas, timeline, panels, dialogs, export window and preview window were reviewed by the author only, because the independent reviews were cut short by usage limits |

### What was **not** done

- **The program was never run.** No window has been shown, no button has been clicked, no stroke has been drawn in the WPF
  program. This build environment runs Linux and cannot start WPF.
- **The Release exe, the installer, `publish.ps1`, `publish.cmd` and the GitHub workflow were never executed.** They were
  written carefully and read through, but the first real run happens on your machine. If the publish step fails, the
  message from `dotnet` says why; the most common reasons are a missing .NET 8 SDK, no internet for the first restore, or
  Inno Setup not being installed when you use `-Installer`.
- **Pen and tablet input** (pressure, the eraser end) is implemented but was never tried with real hardware.
- **High-DPI screens and multiple monitors with different scaling** are handled in the code (per-monitor DPI manifest,
  pixel-exact zoom) but were never tried.
- **Speed on large canvases** was not measured on Windows. The engine draws with its own software rasteriser (see the next
  section) and is probably slower than a GPU or SkiaSharp-based engine on 4K and larger canvases.
- **Looks and layout** (spacing, text clipping, theme contrast, tooltip wording) were never seen.

[`docs/WINDOWS-TEST-CHECKLIST.md`](docs/WINDOWS-TEST-CHECKLIST.md) lists what to try first, in the order that finds the most
problems fastest.

---

## Differences from the original brief

- **No SkiaSharp.** The brief allowed "SkiaSharp or another suitable 2D graphics library". The drawing engine instead uses
  its own small software rasteriser written in C# (brush dabs, shapes, flood fill, compositing, resampling, PNG and GIF
  encoders). It was chosen so that the engine has **no NuGet dependencies**, builds without internet, and can be tested
  without a screen, which is how the 250 tests were possible. The cost is speed on very large canvases, and less
  polish in some operations (for example, shape edges are anti-aliased but there is no GPU acceleration). WPF itself only
  displays the finished bitmap. Swapping the rasteriser for SkiaSharp later would touch `Drawing`, `Rendering` and part of
  `Imaging`.
- **MP4 export needs FFmpeg**, as the brief expected; FFmpeg is not bundled.
- **No licence file is included.** Choose one yourself before you share the code or the program (see below).

---

## Troubleshooting

| Problem | What to try |
|---|---|
| `publish.cmd` stops at the restore step | The first publish needs internet so NuGet can download the .NET runtime pack. Check the connection or a proxy setting and run it again. |
| "The .NET SDK was not found" | Install the .NET 8 SDK (not only the runtime) and open a new terminal. |
| Windows SmartScreen says "unrecognised app" | The exe is not code-signed. Choose *More info > Run anyway*. Signing needs a certificate you buy. |
| The program starts slowly the first time | A self-contained single-file exe unpacks some files on first start. Later starts are quicker. `publish.cmd -ReadyToRun` helps. |
| MP4 export says FFmpeg is missing | See [FFmpeg](#ffmpeg-mp4-only). Point the export dialog at `ffmpeg.exe`. |
| The program closed unexpectedly | Start it again; it offers to recover your work. Error reports are in `%APPDATA%\AnimDraw Studio\logs`; include the newest one if you report a problem. |
| A project will not open | The message says whether the file is damaged or was made by a newer version. Recovery copies of unsaved work are in the folder listed above. |
| Settings are in a bad state | Close the program and delete `%APPDATA%\AnimDraw Studio\settings.json`. Defaults come back on the next start. |

---

## Licence

No licence file is included in this folder: you, as the owner of the project, decide how it may be used.
The code uses no third-party libraries. It targets the .NET 8 runtime and WPF, which are provided under Microsoft's own
licences. **FFmpeg** is a separate program with its own licence (<https://ffmpeg.org/legal.html>, usually LGPL or GPL
depending on the build). If you ship FFmpeg together with AnimDraw Studio you must follow that licence.
